(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/84aae_@noble_curves_esm_secp256k1_a4996459.js",
  "static/chunks/84aae_@walletconnect_utils_dist_index_es_87cacf62.js",
  "static/chunks/84aae_@walletconnect_core_dist_index_es_e7137dfc.js",
  "static/chunks/84aae_@walletconnect_sign-client_dist_index_es_8da35ffc.js",
  "static/chunks/84aae_@walletconnect_ethereum-provider_dist_index_es_5ba3eb4c.js",
  "static/chunks/node_modules_011ef61f._.js"
],
    source: "dynamic"
});
