(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_20d3538f._.js",
  "static/chunks/node_modules_c8c13c28._.js"
],
    source: "dynamic"
});
