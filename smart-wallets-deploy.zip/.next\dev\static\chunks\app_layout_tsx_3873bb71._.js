(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_bbc21cf0._.js",
  "static/chunks/node_modules_viem__esm_8c7356a2._.js",
  "static/chunks/node_modules_6af044e4._.js",
  "static/chunks/node_modules_@aa-sdk_core_dist_esm_dff18489._.js",
  "static/chunks/node_modules_zod_cff25e21._.js",
  "static/chunks/node_modules_5b1d15b4._.js",
  "static/chunks/node_modules_c9e17f5f._.js",
  "static/chunks/node_modules_@tanstack_query-core_build_modern_fd0932b6._.js",
  "static/chunks/node_modules_@account-kit_react_dist_esm_df01d8c1._.js",
  "static/chunks/node_modules_@account-kit_signer_dist_esm_23b2c1c3._.js",
  "static/chunks/node_modules_next_9b932ea0._.js",
  "static/chunks/node_modules_854c52b0._.js",
  "static/chunks/node_modules_@solana_web3_js_lib_index_browser_esm_91fb059e.js",
  "static/chunks/node_modules_@turnkey_http_dist_1317ebb2._.js",
  "static/chunks/node_modules_@account-kit_smart-contracts_dist_esm_src_e834da83._.js",
  "static/chunks/node_modules_@account-kit_3cc1558b._.js",
  "static/chunks/node_modules_@solana_81005156._.js",
  "static/chunks/node_modules_@solana-mobile_26f51555._.js",
  "static/chunks/node_modules_0135d31a._.js",
  "static/chunks/_37f9f8d0._.js",
  "static/chunks/[root-of-the-server]__408d666e._.css"
],
    source: "dynamic"
});
