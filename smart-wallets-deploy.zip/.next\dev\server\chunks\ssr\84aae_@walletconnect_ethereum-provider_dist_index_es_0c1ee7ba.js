module.exports = [
"[project]/node_modules/wagmi/node_modules/@walletconnect/ethereum-provider/dist/index.es.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EthereumProvider",
    ()=>U0,
    "OPTIONAL_EVENTS",
    ()=>tl,
    "OPTIONAL_METHODS",
    ()=>el,
    "REQUIRED_EVENTS",
    ()=>mo,
    "REQUIRED_METHODS",
    ()=>wo,
    "default",
    ()=>ca
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$events__$5b$external$5d$__$28$events$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/events [external] (events, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$node_modules$2f40$walletconnect$2f$utils$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/wagmi/node_modules/@walletconnect/utils/dist/index.es.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$node_modules$2f40$walletconnect$2f$universal$2d$provider$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/wagmi/node_modules/@walletconnect/universal-provider/dist/index.es.js [app-ssr] (ecmascript)");
const __TURBOPACK__import$2e$meta__ = {
    get url () {
        return `file://${__turbopack_context__.P("node_modules/wagmi/node_modules/@walletconnect/ethereum-provider/dist/index.es.js")}`;
    }
};
;
;
;
const I0 = "wc", N0 = "ethereum_provider", k0 = `${I0}@2:${N0}:`, T0 = "https://rpc.walletconnect.org/v1/", wo = [
    "eth_sendTransaction",
    "personal_sign"
], el = [
    "eth_accounts",
    "eth_requestAccounts",
    "eth_sendRawTransaction",
    "eth_sign",
    "eth_signTransaction",
    "eth_signTypedData",
    "eth_signTypedData_v3",
    "eth_signTypedData_v4",
    "eth_sendTransaction",
    "personal_sign",
    "wallet_switchEthereumChain",
    "wallet_addEthereumChain",
    "wallet_getPermissions",
    "wallet_requestPermissions",
    "wallet_registerOnboarding",
    "wallet_watchAsset",
    "wallet_scanQRCode",
    "wallet_sendCalls",
    "wallet_getCapabilities",
    "wallet_getCallsStatus",
    "wallet_showCallsStatus"
], mo = [
    "chainChanged",
    "accountsChanged"
], tl = [
    "chainChanged",
    "accountsChanged",
    "message",
    "disconnect",
    "connect"
];
var O0 = Object.defineProperty, $0 = Object.defineProperties, P0 = Object.getOwnPropertyDescriptors, rl = Object.getOwnPropertySymbols, B0 = Object.prototype.hasOwnProperty, R0 = Object.prototype.propertyIsEnumerable, da = (t, e, r)=>e in t ? O0(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : t[e] = r, xr = (t, e)=>{
    for(var r in e || (e = {}))B0.call(e, r) && da(t, r, e[r]);
    if (rl) for (var r of rl(e))R0.call(e, r) && da(t, r, e[r]);
    return t;
}, Dn = (t, e)=>$0(t, P0(e)), ot = (t, e, r)=>da(t, typeof e != "symbol" ? e + "" : e, r);
function bo(t) {
    return Number(t[0].split(":")[1]);
}
function vo(t) {
    return `0x${t.toString(16)}`;
}
function L0(t) {
    const { chains: e, optionalChains: r, methods: n, optionalMethods: i, events: o, optionalEvents: s, rpcMap: a } = t;
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$node_modules$2f40$walletconnect$2f$utils$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isValidArray"])(e)) throw new Error("Invalid chains");
    const c = {
        chains: e,
        methods: n || wo,
        events: o || mo,
        rpcMap: xr({}, e.length ? {
            [bo(e)]: a[bo(e)]
        } : {})
    }, l = o?.filter((p)=>!mo.includes(p)), d = n?.filter((p)=>!wo.includes(p));
    if (!r && !s && !i && !(l != null && l.length) && !(d != null && d.length)) return {
        required: e.length ? c : void 0
    };
    const u = l?.length && d?.length || !r, h = {
        chains: [
            ...new Set(u ? c.chains.concat(r || []) : r)
        ],
        methods: [
            ...new Set(c.methods.concat(i != null && i.length ? i : el))
        ],
        events: [
            ...new Set(c.events.concat(s != null && s.length ? s : tl))
        ],
        rpcMap: a
    };
    return {
        required: e.length ? c : void 0,
        optional: r.length ? h : void 0
    };
}
class ca {
    constructor(){
        ot(this, "events", new __TURBOPACK__imported__module__$5b$externals$5d2f$events__$5b$external$5d$__$28$events$2c$__cjs$29$__["EventEmitter"]), ot(this, "namespace", "eip155"), ot(this, "accounts", []), ot(this, "signer"), ot(this, "chainId", 1), ot(this, "modal"), ot(this, "rpc"), ot(this, "STORAGE_KEY", k0), ot(this, "on", (e, r)=>(this.events.on(e, r), this)), ot(this, "once", (e, r)=>(this.events.once(e, r), this)), ot(this, "removeListener", (e, r)=>(this.events.removeListener(e, r), this)), ot(this, "off", (e, r)=>(this.events.off(e, r), this)), ot(this, "parseAccount", (e)=>this.isCompatibleChainId(e) ? this.parseAccountId(e).address : e), this.signer = {}, this.rpc = {};
    }
    static async init(e) {
        const r = new ca;
        return await r.initialize(e), r;
    }
    async request(e, r) {
        return await this.signer.request(e, this.formatChainId(this.chainId), r);
    }
    sendAsync(e, r, n) {
        this.signer.sendAsync(e, r, this.formatChainId(this.chainId), n);
    }
    get connected() {
        return this.signer.client ? this.signer.client.core.relayer.connected : !1;
    }
    get connecting() {
        return this.signer.client ? this.signer.client.core.relayer.connecting : !1;
    }
    async enable() {
        return this.session || await this.connect(), await this.request({
            method: "eth_requestAccounts"
        });
    }
    async connect(e) {
        var r;
        if (!this.signer.client) throw new Error("Provider not initialized. Call init() first");
        this.loadConnectOpts(e);
        const { required: n, optional: i } = L0(this.rpc);
        try {
            const o = await new Promise(async (a, c)=>{
                var l, d;
                this.rpc.showQrModal && ((l = this.modal) == null || l.open(), (d = this.modal) == null || d.subscribeState((h)=>{
                    !h.open && !this.signer.session && (this.signer.abortPairingAttempt(), c(new Error("Connection request reset. Please try again.")));
                }));
                const u = e != null && e.scopedProperties ? {
                    [this.namespace]: e.scopedProperties
                } : void 0;
                await this.signer.connect(Dn(xr({
                    namespaces: xr({}, n && {
                        [this.namespace]: n
                    })
                }, i && {
                    optionalNamespaces: {
                        [this.namespace]: i
                    }
                }), {
                    pairingTopic: e?.pairingTopic,
                    scopedProperties: u
                })).then((h)=>{
                    a(h);
                }).catch((h)=>{
                    var p;
                    (p = this.modal) == null || p.showErrorMessage("Unable to connect"), c(new Error(h.message));
                });
            });
            if (!o) return;
            const s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$node_modules$2f40$walletconnect$2f$utils$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getAccountsFromNamespaces"])(o.namespaces, [
                this.namespace
            ]);
            this.setChainIds(this.rpc.chains.length ? this.rpc.chains : s), this.setAccounts(s), this.events.emit("connect", {
                chainId: vo(this.chainId)
            });
        } catch (o) {
            throw this.signer.logger.error(o), o;
        } finally{
            (r = this.modal) == null || r.close();
        }
    }
    async authenticate(e, r) {
        var n;
        if (!this.signer.client) throw new Error("Provider not initialized. Call init() first");
        this.loadConnectOpts({
            chains: e?.chains
        });
        try {
            const i = await new Promise(async (s, a)=>{
                var c, l;
                this.rpc.showQrModal && ((c = this.modal) == null || c.open(), (l = this.modal) == null || l.subscribeState((d)=>{
                    !d.open && !this.signer.session && (this.signer.abortPairingAttempt(), a(new Error("Connection request reset. Please try again.")));
                })), await this.signer.authenticate(Dn(xr({}, e), {
                    chains: this.rpc.chains
                }), r).then((d)=>{
                    s(d);
                }).catch((d)=>{
                    var u;
                    (u = this.modal) == null || u.showErrorMessage("Unable to connect"), a(new Error(d.message));
                });
            }), o = i.session;
            if (o) {
                const s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$node_modules$2f40$walletconnect$2f$utils$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getAccountsFromNamespaces"])(o.namespaces, [
                    this.namespace
                ]);
                this.setChainIds(this.rpc.chains.length ? this.rpc.chains : s), this.setAccounts(s), this.events.emit("connect", {
                    chainId: vo(this.chainId)
                });
            }
            return i;
        } catch (i) {
            throw this.signer.logger.error(i), i;
        } finally{
            (n = this.modal) == null || n.close();
        }
    }
    async disconnect() {
        this.session && await this.signer.disconnect(), this.reset();
    }
    get isWalletConnect() {
        return !0;
    }
    get session() {
        return this.signer.session;
    }
    registerEventListeners() {
        this.signer.on("session_event", (e)=>{
            const { params: r } = e, { event: n } = r;
            n.name === "accountsChanged" ? (this.accounts = this.parseAccounts(n.data), this.events.emit("accountsChanged", this.accounts)) : n.name === "chainChanged" ? this.setChainId(this.formatChainId(n.data)) : this.events.emit(n.name, n.data), this.events.emit("session_event", e);
        }), this.signer.on("accountsChanged", (e)=>{
            this.accounts = this.parseAccounts(e), this.events.emit("accountsChanged", this.accounts);
        }), this.signer.on("chainChanged", (e)=>{
            const r = parseInt(e);
            this.chainId = r, this.events.emit("chainChanged", vo(this.chainId)), this.persist();
        }), this.signer.on("session_update", (e)=>{
            this.events.emit("session_update", e);
        }), this.signer.on("session_delete", (e)=>{
            this.reset(), this.events.emit("session_delete", e), this.events.emit("disconnect", Dn(xr({}, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$node_modules$2f40$walletconnect$2f$utils$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getSdkError"])("USER_DISCONNECTED")), {
                data: e.topic,
                name: "USER_DISCONNECTED"
            }));
        }), this.signer.on("display_uri", (e)=>{
            this.events.emit("display_uri", e);
        });
    }
    switchEthereumChain(e) {
        this.request({
            method: "wallet_switchEthereumChain",
            params: [
                {
                    chainId: e.toString(16)
                }
            ]
        });
    }
    isCompatibleChainId(e) {
        return typeof e == "string" ? e.startsWith(`${this.namespace}:`) : !1;
    }
    formatChainId(e) {
        return `${this.namespace}:${e}`;
    }
    parseChainId(e) {
        return Number(e.split(":")[1]);
    }
    setChainIds(e) {
        const r = e.filter((n)=>this.isCompatibleChainId(n)).map((n)=>this.parseChainId(n));
        r.length && (this.chainId = r[0], this.events.emit("chainChanged", vo(this.chainId)), this.persist());
    }
    setChainId(e) {
        if (this.isCompatibleChainId(e)) {
            const r = this.parseChainId(e);
            this.chainId = r, this.switchEthereumChain(r);
        }
    }
    parseAccountId(e) {
        const [r, n, i] = e.split(":");
        return {
            chainId: `${r}:${n}`,
            address: i
        };
    }
    setAccounts(e) {
        this.accounts = e.filter((r)=>this.parseChainId(this.parseAccountId(r).chainId) === this.chainId).map((r)=>this.parseAccountId(r).address), this.events.emit("accountsChanged", this.accounts);
    }
    getRpcConfig(e) {
        var r, n;
        const i = (r = e?.chains) != null ? r : [], o = (n = e?.optionalChains) != null ? n : [], s = i.concat(o);
        if (!s.length) throw new Error("No chains specified in either `chains` or `optionalChains`");
        const a = i.length ? e?.methods || wo : [], c = i.length ? e?.events || mo : [], l = e?.optionalMethods || [], d = e?.optionalEvents || [], u = e?.rpcMap || this.buildRpcMap(s, e.projectId), h = e?.qrModalOptions || void 0;
        return {
            chains: i?.map((p)=>this.formatChainId(p)),
            optionalChains: o.map((p)=>this.formatChainId(p)),
            methods: a,
            events: c,
            optionalMethods: l,
            optionalEvents: d,
            rpcMap: u,
            showQrModal: !!(e != null && e.showQrModal),
            qrModalOptions: h,
            projectId: e.projectId,
            metadata: e.metadata
        };
    }
    buildRpcMap(e, r) {
        const n = {};
        return e.forEach((i)=>{
            n[i] = this.getRpcUrl(i, r);
        }), n;
    }
    async initialize(e) {
        if (this.rpc = this.getRpcConfig(e), this.chainId = this.rpc.chains.length ? bo(this.rpc.chains) : bo(this.rpc.optionalChains), this.signer = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$node_modules$2f40$walletconnect$2f$universal$2d$provider$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UniversalProvider"].init({
            projectId: this.rpc.projectId,
            metadata: this.rpc.metadata,
            disableProviderPing: e.disableProviderPing,
            relayUrl: e.relayUrl,
            storage: e.storage,
            storageOptions: e.storageOptions,
            customStoragePrefix: e.customStoragePrefix,
            telemetryEnabled: e.telemetryEnabled,
            logger: e.logger
        }), this.registerEventListeners(), await this.loadPersistedSession(), this.rpc.showQrModal) {
            let r;
            try {
                const { createAppKit: n } = await Promise.resolve().then(function() {
                    return l2;
                }), { convertWCMToAppKitOptions: i } = await Promise.resolve().then(function() {
                    return C2;
                }), o = i(Dn(xr({}, this.rpc.qrModalOptions), {
                    chains: [
                        ...new Set([
                            ...this.rpc.chains,
                            ...this.rpc.optionalChains
                        ])
                    ],
                    metadata: this.rpc.metadata,
                    projectId: this.rpc.projectId
                }));
                if (!o.networks.length) throw new Error("No networks found for WalletConnect\xB7");
                r = n(Dn(xr({}, o), {
                    universalProvider: this.signer,
                    manualWCControl: !0
                }));
            } catch  {
                throw new Error("To use QR modal, please install @reown/appkit package");
            }
            if (r) try {
                this.modal = r;
            } catch (n) {
                throw this.signer.logger.error(n), new Error("Could not generate WalletConnectModal Instance");
            }
        }
    }
    loadConnectOpts(e) {
        if (!e) return;
        const { chains: r, optionalChains: n, rpcMap: i } = e;
        r && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$node_modules$2f40$walletconnect$2f$utils$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isValidArray"])(r) && (this.rpc.chains = r.map((o)=>this.formatChainId(o)), r.forEach((o)=>{
            this.rpc.rpcMap[o] = i?.[o] || this.getRpcUrl(o);
        })), n && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$node_modules$2f40$walletconnect$2f$utils$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isValidArray"])(n) && (this.rpc.optionalChains = [], this.rpc.optionalChains = n?.map((o)=>this.formatChainId(o)), n.forEach((o)=>{
            this.rpc.rpcMap[o] = i?.[o] || this.getRpcUrl(o);
        }));
    }
    getRpcUrl(e, r) {
        var n;
        return ((n = this.rpc.rpcMap) == null ? void 0 : n[e]) || `${T0}?chainId=eip155:${e}&projectId=${r || this.rpc.projectId}`;
    }
    async loadPersistedSession() {
        if (this.session) try {
            const e = await this.signer.client.core.storage.getItem(`${this.STORAGE_KEY}/chainId`), r = this.session.namespaces[`${this.namespace}:${e}`] ? this.session.namespaces[`${this.namespace}:${e}`] : this.session.namespaces[this.namespace];
            this.setChainIds(e ? [
                this.formatChainId(e)
            ] : r?.accounts), this.setAccounts(r?.accounts);
        } catch (e) {
            this.signer.logger.error("Failed to load persisted session, clearing state..."), this.signer.logger.error(e), await this.disconnect().catch((r)=>this.signer.logger.warn(r));
        }
    }
    reset() {
        this.chainId = 1, this.accounts = [];
    }
    persist() {
        this.session && this.signer.client.core.storage.setItem(`${this.STORAGE_KEY}/chainId`, this.chainId);
    }
    parseAccounts(e) {
        return typeof e == "string" || e instanceof String ? [
            this.parseAccount(e)
        ] : e.map((r)=>this.parseAccount(r));
    }
}
const U0 = ca;
var Co = typeof globalThis < "u" ? globalThis : ("TURBOPACK compile-time value", "undefined") < "u" ? window : ("TURBOPACK compile-time value", "object") < "u" ? /*TURBOPACK member replacement*/ __turbopack_context__.g : typeof self < "u" ? self : {}, nl = {
    exports: {}
};
(function(t, e) {
    (function(r, n) {
        t.exports = n();
    })(Co, function() {
        var r = 1e3, n = 6e4, i = 36e5, o = "millisecond", s = "second", a = "minute", c = "hour", l = "day", d = "week", u = "month", h = "quarter", p = "year", v = "date", m = "Invalid Date", g = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, b = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, y = {
            name: "en",
            weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
            months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"),
            ordinal: function(_) {
                var S = [
                    "th",
                    "st",
                    "nd",
                    "rd"
                ], A = _ % 100;
                return "[" + _ + (S[(A - 20) % 10] || S[A] || S[0]) + "]";
            }
        }, x = function(_, S, A) {
            var P = String(_);
            return !P || P.length >= S ? _ : "" + Array(S + 1 - P.length).join(A) + _;
        }, E = {
            s: x,
            z: function(_) {
                var S = -_.utcOffset(), A = Math.abs(S), P = Math.floor(A / 60), k = A % 60;
                return (S <= 0 ? "+" : "-") + x(P, 2, "0") + ":" + x(k, 2, "0");
            },
            m: function _(S, A) {
                if (S.date() < A.date()) return -_(A, S);
                var P = 12 * (A.year() - S.year()) + (A.month() - S.month()), k = S.clone().add(P, u), K = A - k < 0, X = S.clone().add(P + (K ? -1 : 1), u);
                return +(-(P + (A - k) / (K ? k - X : X - k)) || 0);
            },
            a: function(_) {
                return _ < 0 ? Math.ceil(_) || 0 : Math.floor(_);
            },
            p: function(_) {
                return ({
                    M: u,
                    y: p,
                    w: d,
                    d: l,
                    D: v,
                    h: c,
                    m: a,
                    s,
                    ms: o,
                    Q: h
                })[_] || String(_ || "").toLowerCase().replace(/s$/, "");
            },
            u: function(_) {
                return _ === void 0;
            }
        }, I = "en", $ = {};
        $[I] = y;
        var L = "$isDayjsObject", Z = function(_) {
            return _ instanceof ee || !(!_ || !_[L]);
        }, B = function _(S, A, P) {
            var k;
            if (!S) return I;
            if (typeof S == "string") {
                var K = S.toLowerCase();
                $[K] && (k = K), A && ($[K] = A, k = K);
                var X = S.split("-");
                if (!k && X.length > 1) return _(X[0]);
            } else {
                var ae = S.name;
                $[ae] = S, k = ae;
            }
            return !P && k && (I = k), k || !P && I;
        }, R = function(_, S) {
            if (Z(_)) return _.clone();
            var A = typeof S == "object" ? S : {};
            return A.date = _, A.args = arguments, new ee(A);
        }, N = E;
        N.l = B, N.i = Z, N.w = function(_, S) {
            return R(_, {
                locale: S.$L,
                utc: S.$u,
                x: S.$x,
                $offset: S.$offset
            });
        };
        var ee = function() {
            function _(A) {
                this.$L = B(A.locale, null, !0), this.parse(A), this.$x = this.$x || A.x || {}, this[L] = !0;
            }
            var S = _.prototype;
            return S.parse = function(A) {
                this.$d = function(P) {
                    var k = P.date, K = P.utc;
                    if (k === null) return new Date(NaN);
                    if (N.u(k)) return new Date;
                    if (k instanceof Date) return new Date(k);
                    if (typeof k == "string" && !/Z$/i.test(k)) {
                        var X = k.match(g);
                        if (X) {
                            var ae = X[2] - 1 || 0, fe = (X[7] || "0").substring(0, 3);
                            return K ? new Date(Date.UTC(X[1], ae, X[3] || 1, X[4] || 0, X[5] || 0, X[6] || 0, fe)) : new Date(X[1], ae, X[3] || 1, X[4] || 0, X[5] || 0, X[6] || 0, fe);
                        }
                    }
                    return new Date(k);
                }(A), this.init();
            }, S.init = function() {
                var A = this.$d;
                this.$y = A.getFullYear(), this.$M = A.getMonth(), this.$D = A.getDate(), this.$W = A.getDay(), this.$H = A.getHours(), this.$m = A.getMinutes(), this.$s = A.getSeconds(), this.$ms = A.getMilliseconds();
            }, S.$utils = function() {
                return N;
            }, S.isValid = function() {
                return this.$d.toString() !== m;
            }, S.isSame = function(A, P) {
                var k = R(A);
                return this.startOf(P) <= k && k <= this.endOf(P);
            }, S.isAfter = function(A, P) {
                return R(A) < this.startOf(P);
            }, S.isBefore = function(A, P) {
                return this.endOf(P) < R(A);
            }, S.$g = function(A, P, k) {
                return N.u(A) ? this[P] : this.set(k, A);
            }, S.unix = function() {
                return Math.floor(this.valueOf() / 1e3);
            }, S.valueOf = function() {
                return this.$d.getTime();
            }, S.startOf = function(A, P) {
                var k = this, K = !!N.u(P) || P, X = N.p(A), ae = function(qe, Re) {
                    var Ke = N.w(k.$u ? Date.UTC(k.$y, Re, qe) : new Date(k.$y, Re, qe), k);
                    return K ? Ke : Ke.endOf(l);
                }, fe = function(qe, Re) {
                    return N.w(k.toDate()[qe].apply(k.toDate("s"), (K ? [
                        0,
                        0,
                        0,
                        0
                    ] : [
                        23,
                        59,
                        59,
                        999
                    ]).slice(Re)), k);
                }, me = this.$W, ge = this.$M, ke = this.$D, Fe = "set" + (this.$u ? "UTC" : "");
                switch(X){
                    case p:
                        return K ? ae(1, 0) : ae(31, 11);
                    case u:
                        return K ? ae(1, ge) : ae(0, ge + 1);
                    case d:
                        var yt = this.$locale().weekStart || 0, nt = (me < yt ? me + 7 : me) - yt;
                        return ae(K ? ke - nt : ke + (6 - nt), ge);
                    case l:
                    case v:
                        return fe(Fe + "Hours", 0);
                    case c:
                        return fe(Fe + "Minutes", 1);
                    case a:
                        return fe(Fe + "Seconds", 2);
                    case s:
                        return fe(Fe + "Milliseconds", 3);
                    default:
                        return this.clone();
                }
            }, S.endOf = function(A) {
                return this.startOf(A, !1);
            }, S.$set = function(A, P) {
                var k, K = N.p(A), X = "set" + (this.$u ? "UTC" : ""), ae = (k = {}, k[l] = X + "Date", k[v] = X + "Date", k[u] = X + "Month", k[p] = X + "FullYear", k[c] = X + "Hours", k[a] = X + "Minutes", k[s] = X + "Seconds", k[o] = X + "Milliseconds", k)[K], fe = K === l ? this.$D + (P - this.$W) : P;
                if (K === u || K === p) {
                    var me = this.clone().set(v, 1);
                    me.$d[ae](fe), me.init(), this.$d = me.set(v, Math.min(this.$D, me.daysInMonth())).$d;
                } else ae && this.$d[ae](fe);
                return this.init(), this;
            }, S.set = function(A, P) {
                return this.clone().$set(A, P);
            }, S.get = function(A) {
                return this[N.p(A)]();
            }, S.add = function(A, P) {
                var k, K = this;
                A = Number(A);
                var X = N.p(P), ae = function(ge) {
                    var ke = R(K);
                    return N.w(ke.date(ke.date() + Math.round(ge * A)), K);
                };
                if (X === u) return this.set(u, this.$M + A);
                if (X === p) return this.set(p, this.$y + A);
                if (X === l) return ae(1);
                if (X === d) return ae(7);
                var fe = (k = {}, k[a] = n, k[c] = i, k[s] = r, k)[X] || 1, me = this.$d.getTime() + A * fe;
                return N.w(me, this);
            }, S.subtract = function(A, P) {
                return this.add(-1 * A, P);
            }, S.format = function(A) {
                var P = this, k = this.$locale();
                if (!this.isValid()) return k.invalidDate || m;
                var K = A || "YYYY-MM-DDTHH:mm:ssZ", X = N.z(this), ae = this.$H, fe = this.$m, me = this.$M, ge = k.weekdays, ke = k.months, Fe = k.meridiem, yt = function(Re, Ke, it, Nt) {
                    return Re && (Re[Ke] || Re(P, K)) || it[Ke].slice(0, Nt);
                }, nt = function(Re) {
                    return N.s(ae % 12 || 12, Re, "0");
                }, qe = Fe || function(Re, Ke, it) {
                    var Nt = Re < 12 ? "AM" : "PM";
                    return it ? Nt.toLowerCase() : Nt;
                };
                return K.replace(b, function(Re, Ke) {
                    return Ke || function(it) {
                        switch(it){
                            case "YY":
                                return String(P.$y).slice(-2);
                            case "YYYY":
                                return N.s(P.$y, 4, "0");
                            case "M":
                                return me + 1;
                            case "MM":
                                return N.s(me + 1, 2, "0");
                            case "MMM":
                                return yt(k.monthsShort, me, ke, 3);
                            case "MMMM":
                                return yt(ke, me);
                            case "D":
                                return P.$D;
                            case "DD":
                                return N.s(P.$D, 2, "0");
                            case "d":
                                return String(P.$W);
                            case "dd":
                                return yt(k.weekdaysMin, P.$W, ge, 2);
                            case "ddd":
                                return yt(k.weekdaysShort, P.$W, ge, 3);
                            case "dddd":
                                return ge[P.$W];
                            case "H":
                                return String(ae);
                            case "HH":
                                return N.s(ae, 2, "0");
                            case "h":
                                return nt(1);
                            case "hh":
                                return nt(2);
                            case "a":
                                return qe(ae, fe, !0);
                            case "A":
                                return qe(ae, fe, !1);
                            case "m":
                                return String(fe);
                            case "mm":
                                return N.s(fe, 2, "0");
                            case "s":
                                return String(P.$s);
                            case "ss":
                                return N.s(P.$s, 2, "0");
                            case "SSS":
                                return N.s(P.$ms, 3, "0");
                            case "Z":
                                return X;
                        }
                        return null;
                    }(Re) || X.replace(":", "");
                });
            }, S.utcOffset = function() {
                return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
            }, S.diff = function(A, P, k) {
                var K, X = this, ae = N.p(P), fe = R(A), me = (fe.utcOffset() - this.utcOffset()) * n, ge = this - fe, ke = function() {
                    return N.m(X, fe);
                };
                switch(ae){
                    case p:
                        K = ke() / 12;
                        break;
                    case u:
                        K = ke();
                        break;
                    case h:
                        K = ke() / 3;
                        break;
                    case d:
                        K = (ge - me) / 6048e5;
                        break;
                    case l:
                        K = (ge - me) / 864e5;
                        break;
                    case c:
                        K = ge / i;
                        break;
                    case a:
                        K = ge / n;
                        break;
                    case s:
                        K = ge / r;
                        break;
                    default:
                        K = ge;
                }
                return k ? K : N.a(K);
            }, S.daysInMonth = function() {
                return this.endOf(u).$D;
            }, S.$locale = function() {
                return $[this.$L];
            }, S.locale = function(A, P) {
                if (!A) return this.$L;
                var k = this.clone(), K = B(A, P, !0);
                return K && (k.$L = K), k;
            }, S.clone = function() {
                return N.w(this.$d, this);
            }, S.toDate = function() {
                return new Date(this.valueOf());
            }, S.toJSON = function() {
                return this.isValid() ? this.toISOString() : null;
            }, S.toISOString = function() {
                return this.$d.toISOString();
            }, S.toString = function() {
                return this.$d.toUTCString();
            }, _;
        }(), pe = ee.prototype;
        return R.prototype = pe, [
            [
                "$ms",
                o
            ],
            [
                "$s",
                s
            ],
            [
                "$m",
                a
            ],
            [
                "$H",
                c
            ],
            [
                "$W",
                l
            ],
            [
                "$M",
                u
            ],
            [
                "$y",
                p
            ],
            [
                "$D",
                v
            ]
        ].forEach(function(_) {
            pe[_[1]] = function(S) {
                return this.$g(S, _[0], _[1]);
            };
        }), R.extend = function(_, S) {
            return _.$i || (_(S, ee, R), _.$i = !0), R;
        }, R.locale = B, R.isDayjs = Z, R.unix = function(_) {
            return R(1e3 * _);
        }, R.en = $[I], R.Ls = $, R.p = {}, R;
    });
})(nl);
var ua = nl.exports, il = {
    exports: {}
};
(function(t, e) {
    (function(r, n) {
        t.exports = n();
    })(Co, function() {
        return {
            name: "en",
            weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
            months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"),
            ordinal: function(r) {
                var n = [
                    "th",
                    "st",
                    "nd",
                    "rd"
                ], i = r % 100;
                return "[" + r + (n[(i - 20) % 10] || n[i] || n[0]) + "]";
            }
        };
    });
})(il);
var M0 = il.exports, ol = {
    exports: {}
};
(function(t, e) {
    (function(r, n) {
        t.exports = n();
    })(Co, function() {
        return function(r, n, i) {
            r = r || {};
            var o = n.prototype, s = {
                future: "in %s",
                past: "%s ago",
                s: "a few seconds",
                m: "a minute",
                mm: "%d minutes",
                h: "an hour",
                hh: "%d hours",
                d: "a day",
                dd: "%d days",
                M: "a month",
                MM: "%d months",
                y: "a year",
                yy: "%d years"
            };
            function a(l, d, u, h) {
                return o.fromToBase(l, d, u, h);
            }
            i.en.relativeTime = s, o.fromToBase = function(l, d, u, h, p) {
                for(var v, m, g, b = u.$locale().relativeTime || s, y = r.thresholds || [
                    {
                        l: "s",
                        r: 44,
                        d: "second"
                    },
                    {
                        l: "m",
                        r: 89
                    },
                    {
                        l: "mm",
                        r: 44,
                        d: "minute"
                    },
                    {
                        l: "h",
                        r: 89
                    },
                    {
                        l: "hh",
                        r: 21,
                        d: "hour"
                    },
                    {
                        l: "d",
                        r: 35
                    },
                    {
                        l: "dd",
                        r: 25,
                        d: "day"
                    },
                    {
                        l: "M",
                        r: 45
                    },
                    {
                        l: "MM",
                        r: 10,
                        d: "month"
                    },
                    {
                        l: "y",
                        r: 17
                    },
                    {
                        l: "yy",
                        d: "year"
                    }
                ], x = y.length, E = 0; E < x; E += 1){
                    var I = y[E];
                    I.d && (v = h ? i(l).diff(u, I.d, !0) : u.diff(l, I.d, !0));
                    var $ = (r.rounding || Math.round)(Math.abs(v));
                    if (g = v > 0, $ <= I.r || !I.r) {
                        $ <= 1 && E > 0 && (I = y[E - 1]);
                        var L = b[I.l];
                        p && ($ = p("" + $)), m = typeof L == "string" ? L.replace("%d", $) : L($, d, I.l, g);
                        break;
                    }
                }
                if (d) return m;
                var Z = g ? b.future : b.past;
                return typeof Z == "function" ? Z(m) : Z.replace("%s", m);
            }, o.to = function(l, d) {
                return a(l, d, this, !0);
            }, o.from = function(l, d) {
                return a(l, d, this);
            };
            var c = function(l) {
                return l.$u ? i.utc() : i();
            };
            o.toNow = function(l) {
                return this.to(c(this), l);
            }, o.fromNow = function(l) {
                return this.from(c(this), l);
            };
        };
    });
})(ol);
var D0 = ol.exports, sl = {
    exports: {}
};
(function(t, e) {
    (function(r, n) {
        t.exports = n();
    })(Co, function() {
        return function(r, n, i) {
            i.updateLocale = function(o, s) {
                var a = i.Ls[o];
                if (a) return (s ? Object.keys(s) : []).forEach(function(c) {
                    a[c] = s[c];
                }), a;
            };
        };
    });
})(sl);
var z0 = sl.exports;
ua.extend(D0), ua.extend(z0);
const W0 = {
    ...M0,
    name: "en-web3-modal",
    relativeTime: {
        future: "in %s",
        past: "%s ago",
        s: "%d sec",
        m: "1 min",
        mm: "%d min",
        h: "1 hr",
        hh: "%d hrs",
        d: "1 d",
        dd: "%d d",
        M: "1 mo",
        MM: "%d mo",
        y: "1 yr",
        yy: "%d yr"
    }
};
ua.locale("en-web3-modal", W0);
const al = {
    caipNetworkIdToNumber (t) {
        return t ? Number(t.split(":")[1]) : void 0;
    },
    parseEvmChainId (t) {
        return typeof t == "string" ? this.caipNetworkIdToNumber(t) : t;
    },
    getNetworksByNamespace (t, e) {
        return t?.filter((r)=>r.chainNamespace === e) || [];
    },
    getFirstNetworkByNamespace (t, e) {
        return this.getNetworksByNamespace(t, e)[0];
    }
};
var j0 = 20, F0 = 1, Er = 1e6, cl = 1e6, H0 = -7, V0 = 21, Z0 = !1, zn = "[big.js] ", Ar = zn + "Invalid ", yo = Ar + "decimal places", G0 = Ar + "rounding mode", ll = zn + "Division by zero", ve = {}, kt = void 0, q0 = /^-?(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i;
function dl() {
    function t(e) {
        var r = this;
        if (!(r instanceof t)) return e === kt ? dl() : new t(e);
        if (e instanceof t) r.s = e.s, r.e = e.e, r.c = e.c.slice();
        else {
            if (typeof e != "string") {
                if (t.strict === !0 && typeof e != "bigint") throw TypeError(Ar + "value");
                e = e === 0 && 1 / e < 0 ? "-0" : String(e);
            }
            K0(r, e);
        }
        r.constructor = t;
    }
    return t.prototype = ve, t.DP = j0, t.RM = F0, t.NE = H0, t.PE = V0, t.strict = Z0, t.roundDown = 0, t.roundHalfUp = 1, t.roundHalfEven = 2, t.roundUp = 3, t;
}
function K0(t, e) {
    var r, n, i;
    if (!q0.test(e)) throw Error(Ar + "number");
    for(t.s = e.charAt(0) == "-" ? (e = e.slice(1), -1) : 1, (r = e.indexOf(".")) > -1 && (e = e.replace(".", "")), (n = e.search(/e/i)) > 0 ? (r < 0 && (r = n), r += +e.slice(n + 1), e = e.substring(0, n)) : r < 0 && (r = e.length), i = e.length, n = 0; n < i && e.charAt(n) == "0";)++n;
    if (n == i) t.c = [
        t.e = 0
    ];
    else {
        for(; i > 0 && e.charAt(--i) == "0";);
        for(t.e = r - n - 1, t.c = [], r = 0; n <= i;)t.c[r++] = +e.charAt(n++);
    }
    return t;
}
function Sr(t, e, r, n) {
    var i = t.c;
    if (r === kt && (r = t.constructor.RM), r !== 0 && r !== 1 && r !== 2 && r !== 3) throw Error(G0);
    if (e < 1) n = r === 3 && (n || !!i[0]) || e === 0 && (r === 1 && i[0] >= 5 || r === 2 && (i[0] > 5 || i[0] === 5 && (n || i[1] !== kt))), i.length = 1, n ? (t.e = t.e - e + 1, i[0] = 1) : i[0] = t.e = 0;
    else if (e < i.length) {
        if (n = r === 1 && i[e] >= 5 || r === 2 && (i[e] > 5 || i[e] === 5 && (n || i[e + 1] !== kt || i[e - 1] & 1)) || r === 3 && (n || !!i[0]), i.length = e, n) {
            for(; ++i[--e] > 9;)if (i[e] = 0, e === 0) {
                ++t.e, i.unshift(1);
                break;
            }
        }
        for(e = i.length; !i[--e];)i.pop();
    }
    return t;
}
function _r(t, e, r) {
    var n = t.e, i = t.c.join(""), o = i.length;
    if (e) i = i.charAt(0) + (o > 1 ? "." + i.slice(1) : "") + (n < 0 ? "e" : "e+") + n;
    else if (n < 0) {
        for(; ++n;)i = "0" + i;
        i = "0." + i;
    } else if (n > 0) if (++n > o) for(n -= o; n--;)i += "0";
    else n < o && (i = i.slice(0, n) + "." + i.slice(n));
    else o > 1 && (i = i.charAt(0) + "." + i.slice(1));
    return t.s < 0 && r ? "-" + i : i;
}
ve.abs = function() {
    var t = new this.constructor(this);
    return t.s = 1, t;
}, ve.cmp = function(t) {
    var e, r = this, n = r.c, i = (t = new r.constructor(t)).c, o = r.s, s = t.s, a = r.e, c = t.e;
    if (!n[0] || !i[0]) return n[0] ? o : i[0] ? -s : 0;
    if (o != s) return o;
    if (e = o < 0, a != c) return a > c ^ e ? 1 : -1;
    for(s = (a = n.length) < (c = i.length) ? a : c, o = -1; ++o < s;)if (n[o] != i[o]) return n[o] > i[o] ^ e ? 1 : -1;
    return a == c ? 0 : a > c ^ e ? 1 : -1;
}, ve.div = function(t) {
    var e = this, r = e.constructor, n = e.c, i = (t = new r(t)).c, o = e.s == t.s ? 1 : -1, s = r.DP;
    if (s !== ~~s || s < 0 || s > Er) throw Error(yo);
    if (!i[0]) throw Error(ll);
    if (!n[0]) return t.s = o, t.c = [
        t.e = 0
    ], t;
    var a, c, l, d, u, h = i.slice(), p = a = i.length, v = n.length, m = n.slice(0, a), g = m.length, b = t, y = b.c = [], x = 0, E = s + (b.e = e.e - t.e) + 1;
    for(b.s = o, o = E < 0 ? 0 : E, h.unshift(0); g++ < a;)m.push(0);
    do {
        for(l = 0; l < 10; l++){
            if (a != (g = m.length)) d = a > g ? 1 : -1;
            else for(u = -1, d = 0; ++u < a;)if (i[u] != m[u]) {
                d = i[u] > m[u] ? 1 : -1;
                break;
            }
            if (d < 0) {
                for(c = g == a ? i : h; g;){
                    if (m[--g] < c[g]) {
                        for(u = g; u && !m[--u];)m[u] = 9;
                        --m[u], m[g] += 10;
                    }
                    m[g] -= c[g];
                }
                for(; !m[0];)m.shift();
            } else break;
        }
        y[x++] = d ? l : ++l, m[0] && d ? m[g] = n[p] || 0 : m = [
            n[p]
        ];
    }while ((p++ < v || m[0] !== kt) && o--)
    return !y[0] && x != 1 && (y.shift(), b.e--, E--), x > E && Sr(b, E, r.RM, m[0] !== kt), b;
}, ve.eq = function(t) {
    return this.cmp(t) === 0;
}, ve.gt = function(t) {
    return this.cmp(t) > 0;
}, ve.gte = function(t) {
    return this.cmp(t) > -1;
}, ve.lt = function(t) {
    return this.cmp(t) < 0;
}, ve.lte = function(t) {
    return this.cmp(t) < 1;
}, ve.minus = ve.sub = function(t) {
    var e, r, n, i, o = this, s = o.constructor, a = o.s, c = (t = new s(t)).s;
    if (a != c) return t.s = -c, o.plus(t);
    var l = o.c.slice(), d = o.e, u = t.c, h = t.e;
    if (!l[0] || !u[0]) return u[0] ? t.s = -c : l[0] ? t = new s(o) : t.s = 1, t;
    if (a = d - h) {
        for((i = a < 0) ? (a = -a, n = l) : (h = d, n = u), n.reverse(), c = a; c--;)n.push(0);
        n.reverse();
    } else for(r = ((i = l.length < u.length) ? l : u).length, a = c = 0; c < r; c++)if (l[c] != u[c]) {
        i = l[c] < u[c];
        break;
    }
    if (i && (n = l, l = u, u = n, t.s = -t.s), (c = (r = u.length) - (e = l.length)) > 0) for(; c--;)l[e++] = 0;
    for(c = e; r > a;){
        if (l[--r] < u[r]) {
            for(e = r; e && !l[--e];)l[e] = 9;
            --l[e], l[r] += 10;
        }
        l[r] -= u[r];
    }
    for(; l[--c] === 0;)l.pop();
    for(; l[0] === 0;)l.shift(), --h;
    return l[0] || (t.s = 1, l = [
        h = 0
    ]), t.c = l, t.e = h, t;
}, ve.mod = function(t) {
    var e, r = this, n = r.constructor, i = r.s, o = (t = new n(t)).s;
    if (!t.c[0]) throw Error(ll);
    return r.s = t.s = 1, e = t.cmp(r) == 1, r.s = i, t.s = o, e ? new n(r) : (i = n.DP, o = n.RM, n.DP = n.RM = 0, r = r.div(t), n.DP = i, n.RM = o, this.minus(r.times(t)));
}, ve.neg = function() {
    var t = new this.constructor(this);
    return t.s = -t.s, t;
}, ve.plus = ve.add = function(t) {
    var e, r, n, i = this, o = i.constructor;
    if (t = new o(t), i.s != t.s) return t.s = -t.s, i.minus(t);
    var s = i.e, a = i.c, c = t.e, l = t.c;
    if (!a[0] || !l[0]) return l[0] || (a[0] ? t = new o(i) : t.s = i.s), t;
    if (a = a.slice(), e = s - c) {
        for(e > 0 ? (c = s, n = l) : (e = -e, n = a), n.reverse(); e--;)n.push(0);
        n.reverse();
    }
    for(a.length - l.length < 0 && (n = l, l = a, a = n), e = l.length, r = 0; e; a[e] %= 10)r = (a[--e] = a[e] + l[e] + r) / 10 | 0;
    for(r && (a.unshift(r), ++c), e = a.length; a[--e] === 0;)a.pop();
    return t.c = a, t.e = c, t;
}, ve.pow = function(t) {
    var e = this, r = new e.constructor("1"), n = r, i = t < 0;
    if (t !== ~~t || t < -cl || t > cl) throw Error(Ar + "exponent");
    for(i && (t = -t); t & 1 && (n = n.times(e)), t >>= 1, !!t;)e = e.times(e);
    return i ? r.div(n) : n;
}, ve.prec = function(t, e) {
    if (t !== ~~t || t < 1 || t > Er) throw Error(Ar + "precision");
    return Sr(new this.constructor(this), t, e);
}, ve.round = function(t, e) {
    if (t === kt) t = 0;
    else if (t !== ~~t || t < -Er || t > Er) throw Error(yo);
    return Sr(new this.constructor(this), t + this.e + 1, e);
}, ve.sqrt = function() {
    var t, e, r, n = this, i = n.constructor, o = n.s, s = n.e, a = new i("0.5");
    if (!n.c[0]) return new i(n);
    if (o < 0) throw Error(zn + "No square root");
    o = Math.sqrt(+_r(n, !0, !0)), o === 0 || o === 1 / 0 ? (e = n.c.join(""), e.length + s & 1 || (e += "0"), o = Math.sqrt(e), s = ((s + 1) / 2 | 0) - (s < 0 || s & 1), t = new i((o == 1 / 0 ? "5e" : (o = o.toExponential()).slice(0, o.indexOf("e") + 1)) + s)) : t = new i(o + ""), s = t.e + (i.DP += 4);
    do r = t, t = a.times(r.plus(n.div(r)));
    while (r.c.slice(0, s).join("") !== t.c.slice(0, s).join(""))
    return Sr(t, (i.DP -= 4) + t.e + 1, i.RM);
}, ve.times = ve.mul = function(t) {
    var e, r = this, n = r.constructor, i = r.c, o = (t = new n(t)).c, s = i.length, a = o.length, c = r.e, l = t.e;
    if (t.s = r.s == t.s ? 1 : -1, !i[0] || !o[0]) return t.c = [
        t.e = 0
    ], t;
    for(t.e = c + l, s < a && (e = i, i = o, o = e, l = s, s = a, a = l), e = new Array(l = s + a); l--;)e[l] = 0;
    for(c = a; c--;){
        for(a = 0, l = s + c; l > c;)a = e[l] + o[c] * i[l - c - 1] + a, e[l--] = a % 10, a = a / 10 | 0;
        e[l] = a;
    }
    for(a ? ++t.e : e.shift(), c = e.length; !e[--c];)e.pop();
    return t.c = e, t;
}, ve.toExponential = function(t, e) {
    var r = this, n = r.c[0];
    if (t !== kt) {
        if (t !== ~~t || t < 0 || t > Er) throw Error(yo);
        for(r = Sr(new r.constructor(r), ++t, e); r.c.length < t;)r.c.push(0);
    }
    return _r(r, !0, !!n);
}, ve.toFixed = function(t, e) {
    var r = this, n = r.c[0];
    if (t !== kt) {
        if (t !== ~~t || t < 0 || t > Er) throw Error(yo);
        for(r = Sr(new r.constructor(r), t + r.e + 1, e), t = t + r.e + 1; r.c.length < t;)r.c.push(0);
    }
    return _r(r, !1, !!n);
}, ve[Symbol.for("nodejs.util.inspect.custom")] = ve.toJSON = ve.toString = function() {
    var t = this, e = t.constructor;
    return _r(t, t.e <= e.NE || t.e >= e.PE, !!t.c[0]);
}, ve.toNumber = function() {
    var t = +_r(this, !0, !0);
    if (this.constructor.strict === !0 && !this.eq(t.toString())) throw Error(zn + "Imprecise conversion");
    return t;
}, ve.toPrecision = function(t, e) {
    var r = this, n = r.constructor, i = r.c[0];
    if (t !== kt) {
        if (t !== ~~t || t < 1 || t > Er) throw Error(Ar + "precision");
        for(r = Sr(new n(r), t, e); r.c.length < t;)r.c.push(0);
    }
    return _r(r, t <= r.e || r.e <= n.NE || r.e >= n.PE, !!i);
}, ve.valueOf = function() {
    var t = this, e = t.constructor;
    if (e.strict === !0) throw Error(zn + "valueOf disallowed");
    return _r(t, t.e <= e.NE || t.e >= e.PE, !0);
};
var Wn = dl();
const xo = {
    bigNumber (t) {
        return t ? new Wn(t) : new Wn(0);
    },
    multiply (t, e) {
        if (t === void 0 || e === void 0) return new Wn(0);
        const r = new Wn(t), n = new Wn(e);
        return r.times(n);
    },
    formatNumberToLocalString (t, e = 2) {
        return t === void 0 ? "0.00" : typeof t == "number" ? t.toLocaleString("en-US", {
            maximumFractionDigits: e,
            minimumFractionDigits: e
        }) : parseFloat(t).toLocaleString("en-US", {
            maximumFractionDigits: e,
            minimumFractionDigits: e
        });
    },
    parseLocalStringToNumber (t) {
        return t === void 0 ? 0 : parseFloat(t.replace(/,/gu, ""));
    }
}, Y0 = [
    {
        type: "function",
        name: "transfer",
        stateMutability: "nonpayable",
        inputs: [
            {
                name: "_to",
                type: "address"
            },
            {
                name: "_value",
                type: "uint256"
            }
        ],
        outputs: [
            {
                name: "",
                type: "bool"
            }
        ]
    },
    {
        type: "function",
        name: "transferFrom",
        stateMutability: "nonpayable",
        inputs: [
            {
                name: "_from",
                type: "address"
            },
            {
                name: "_to",
                type: "address"
            },
            {
                name: "_value",
                type: "uint256"
            }
        ],
        outputs: [
            {
                name: "",
                type: "bool"
            }
        ]
    }
], X0 = [
    {
        type: "function",
        name: "approve",
        stateMutability: "nonpayable",
        inputs: [
            {
                name: "spender",
                type: "address"
            },
            {
                name: "amount",
                type: "uint256"
            }
        ],
        outputs: [
            {
                type: "bool"
            }
        ]
    }
], J0 = [
    {
        type: "function",
        name: "transfer",
        stateMutability: "nonpayable",
        inputs: [
            {
                name: "recipient",
                type: "address"
            },
            {
                name: "amount",
                type: "uint256"
            }
        ],
        outputs: []
    },
    {
        type: "function",
        name: "transferFrom",
        stateMutability: "nonpayable",
        inputs: [
            {
                name: "sender",
                type: "address"
            },
            {
                name: "recipient",
                type: "address"
            },
            {
                name: "amount",
                type: "uint256"
            }
        ],
        outputs: [
            {
                name: "",
                type: "bool"
            }
        ]
    }
], G = {
    WC_NAME_SUFFIX: ".reown.id",
    WC_NAME_SUFFIX_LEGACY: ".wcn.id",
    BLOCKCHAIN_API_RPC_URL: "https://rpc.walletconnect.org",
    PULSE_API_URL: "https://pulse.walletconnect.org",
    W3M_API_URL: "https://api.web3modal.org",
    CONNECTOR_ID: {
        WALLET_CONNECT: "walletConnect",
        INJECTED: "injected",
        WALLET_STANDARD: "announced",
        COINBASE: "coinbaseWallet",
        COINBASE_SDK: "coinbaseWalletSDK",
        SAFE: "safe",
        LEDGER: "ledger",
        OKX: "okx",
        EIP6963: "eip6963",
        AUTH: "ID_AUTH"
    },
    CONNECTOR_NAMES: {
        AUTH: "Auth"
    },
    AUTH_CONNECTOR_SUPPORTED_CHAINS: [
        "eip155",
        "solana"
    ],
    LIMITS: {
        PENDING_TRANSACTIONS: 99
    },
    CHAIN: {
        EVM: "eip155",
        SOLANA: "solana",
        POLKADOT: "polkadot",
        BITCOIN: "bip122"
    },
    CHAIN_NAME_MAP: {
        eip155: "EVM Networks",
        solana: "Solana",
        polkadot: "Polkadot",
        bip122: "Bitcoin"
    },
    ADAPTER_TYPES: {
        BITCOIN: "bitcoin",
        SOLANA: "solana",
        WAGMI: "wagmi",
        ETHERS: "ethers",
        ETHERS5: "ethers5"
    },
    USDT_CONTRACT_ADDRESSES: [
        "0xdac17f958d2ee523a2206206994597c13d831ec7",
        "0xc2132d05d31c914a87c6611c10748aeb04b58e8f",
        "0x9702230a8ea53601f5cd2dc00fdbc13d4df4a8c7",
        "0x919C1c267BC06a7039e03fcc2eF738525769109c",
        "0x48065fbBE25f71C9282ddf5e1cD6D6A887483D5e",
        "0x55d398326f99059fF775485246999027B3197955",
        "0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9"
    ],
    HTTP_STATUS_CODES: {
        SERVICE_UNAVAILABLE: 503,
        FORBIDDEN: 403
    },
    UNSUPPORTED_NETWORK_NAME: "Unknown Network"
}, Q0 = {
    getERC20Abi: (t)=>G.USDT_CONTRACT_ADDRESSES.includes(t) ? J0 : Y0,
    getSwapAbi: ()=>X0
}, nr = {
    validateCaipAddress (t) {
        if (t.split(":")?.length !== 3) throw new Error("Invalid CAIP Address");
        return t;
    },
    parseCaipAddress (t) {
        const e = t.split(":");
        if (e.length !== 3) throw new Error(`Invalid CAIP-10 address: ${t}`);
        const [r, n, i] = e;
        if (!r || !n || !i) throw new Error(`Invalid CAIP-10 address: ${t}`);
        return {
            chainNamespace: r,
            chainId: n,
            address: i
        };
    },
    parseCaipNetworkId (t) {
        const e = t.split(":");
        if (e.length !== 2) throw new Error(`Invalid CAIP-2 network id: ${t}`);
        const [r, n] = e;
        if (!r || !n) throw new Error(`Invalid CAIP-2 network id: ${t}`);
        return {
            chainNamespace: r,
            chainId: n
        };
    }
}, ce = {
    WALLET_ID: "@appkit/wallet_id",
    WALLET_NAME: "@appkit/wallet_name",
    SOLANA_WALLET: "@appkit/solana_wallet",
    SOLANA_CAIP_CHAIN: "@appkit/solana_caip_chain",
    ACTIVE_CAIP_NETWORK_ID: "@appkit/active_caip_network_id",
    CONNECTED_SOCIAL: "@appkit/connected_social",
    CONNECTED_SOCIAL_USERNAME: "@appkit-wallet/SOCIAL_USERNAME",
    RECENT_WALLETS: "@appkit/recent_wallets",
    DEEPLINK_CHOICE: "WALLETCONNECT_DEEPLINK_CHOICE",
    ACTIVE_NAMESPACE: "@appkit/active_namespace",
    CONNECTED_NAMESPACES: "@appkit/connected_namespaces",
    CONNECTION_STATUS: "@appkit/connection_status",
    SIWX_AUTH_TOKEN: "@appkit/siwx-auth-token",
    SIWX_NONCE_TOKEN: "@appkit/siwx-nonce-token",
    TELEGRAM_SOCIAL_PROVIDER: "@appkit/social_provider",
    NATIVE_BALANCE_CACHE: "@appkit/native_balance_cache",
    PORTFOLIO_CACHE: "@appkit/portfolio_cache",
    ENS_CACHE: "@appkit/ens_cache",
    IDENTITY_CACHE: "@appkit/identity_cache",
    PREFERRED_ACCOUNT_TYPES: "@appkit/preferred_account_types"
};
function ha(t) {
    if (!t) throw new Error("Namespace is required for CONNECTED_CONNECTOR_ID");
    return `@appkit/${t}:connected_connector_id`;
}
const se = {
    setItem (t, e) {
        jn() && e !== void 0 && localStorage.setItem(t, e);
    },
    getItem (t) {
        if (jn()) return localStorage.getItem(t) || void 0;
    },
    removeItem (t) {
        jn() && localStorage.removeItem(t);
    },
    clear () {
        jn() && localStorage.clear();
    }
};
function jn() {
    return ("TURBOPACK compile-time value", "undefined") < "u" && typeof localStorage < "u";
}
function ir(t, e) {
    return e === "light" ? {
        "--w3m-accent": t?.["--w3m-accent"] || "hsla(231, 100%, 70%, 1)",
        "--w3m-background": "#fff"
    } : {
        "--w3m-accent": t?.["--w3m-accent"] || "hsla(230, 100%, 67%, 1)",
        "--w3m-background": "#121313"
    };
}
const e1 = Symbol(), ul = Object.getPrototypeOf, pa = new WeakMap, t1 = (t)=>t && (pa.has(t) ? pa.get(t) : ul(t) === Object.prototype || ul(t) === Array.prototype), r1 = (t)=>t1(t) && t[e1] || null, hl = (t, e = !0)=>{
    pa.set(t, e);
}, fa = (t)=>typeof t == "object" && t !== null, or = new WeakMap, Fn = new WeakSet, n1 = (t = Object.is, e = (l, d)=>new Proxy(l, d), r = (l)=>fa(l) && !Fn.has(l) && (Array.isArray(l) || !(Symbol.iterator in l)) && !(l instanceof WeakMap) && !(l instanceof WeakSet) && !(l instanceof Error) && !(l instanceof Number) && !(l instanceof Date) && !(l instanceof String) && !(l instanceof RegExp) && !(l instanceof ArrayBuffer), n = (l)=>{
    switch(l.status){
        case "fulfilled":
            return l.value;
        case "rejected":
            throw l.reason;
        default:
            throw l;
    }
}, i = new WeakMap, o = (l, d, u = n)=>{
    const h = i.get(l);
    if (h?.[0] === d) return h[1];
    const p = Array.isArray(l) ? [] : Object.create(Object.getPrototypeOf(l));
    return hl(p, !0), i.set(l, [
        d,
        p
    ]), Reflect.ownKeys(l).forEach((v)=>{
        if (Object.getOwnPropertyDescriptor(p, v)) return;
        const m = Reflect.get(l, v), { enumerable: g } = Reflect.getOwnPropertyDescriptor(l, v), b = {
            value: m,
            enumerable: g,
            configurable: !0
        };
        if (Fn.has(m)) hl(m, !1);
        else if (m instanceof Promise) delete b.value, b.get = ()=>u(m);
        else if (or.has(m)) {
            const [y, x] = or.get(m);
            b.value = o(y, x(), u);
        }
        Object.defineProperty(p, v, b);
    }), Object.preventExtensions(p);
}, s = new WeakMap, a = [
    1,
    1
], c = (l)=>{
    if (!fa(l)) throw new Error("object required");
    const d = s.get(l);
    if (d) return d;
    let u = a[0];
    const h = new Set, p = (B, R = ++a[0])=>{
        u !== R && (u = R, h.forEach((N)=>N(B, R)));
    };
    let v = a[1];
    const m = (B = ++a[1])=>(v !== B && !h.size && (v = B, b.forEach(([R])=>{
            const N = R[1](B);
            N > u && (u = N);
        })), u), g = (B)=>(R, N)=>{
            const ee = [
                ...R
            ];
            ee[1] = [
                B,
                ...ee[1]
            ], p(ee, N);
        }, b = new Map, y = (B, R)=>{
        if ((__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production" && b.has(B)) throw new Error("prop listener already exists");
        if (h.size) {
            const N = R[3](g(B));
            b.set(B, [
                R,
                N
            ]);
        } else b.set(B, [
            R
        ]);
    }, x = (B)=>{
        var R;
        const N = b.get(B);
        N && (b.delete(B), (R = N[1]) == null || R.call(N));
    }, E = (B)=>(h.add(B), h.size === 1 && b.forEach(([N, ee], pe)=>{
            if ((__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production" && ee) throw new Error("remove already exists");
            const _ = N[3](g(pe));
            b.set(pe, [
                N,
                _
            ]);
        }), ()=>{
            h.delete(B), h.size === 0 && b.forEach(([N, ee], pe)=>{
                ee && (ee(), b.set(pe, [
                    N
                ]));
            });
        }), I = Array.isArray(l) ? [] : Object.create(Object.getPrototypeOf(l)), L = e(I, {
        deleteProperty (B, R) {
            const N = Reflect.get(B, R);
            x(R);
            const ee = Reflect.deleteProperty(B, R);
            return ee && p([
                "delete",
                [
                    R
                ],
                N
            ]), ee;
        },
        set (B, R, N, ee) {
            const pe = Reflect.has(B, R), _ = Reflect.get(B, R, ee);
            if (pe && (t(_, N) || s.has(N) && t(_, s.get(N)))) return !0;
            x(R), fa(N) && (N = r1(N) || N);
            let S = N;
            if (N instanceof Promise) N.then((A)=>{
                N.status = "fulfilled", N.value = A, p([
                    "resolve",
                    [
                        R
                    ],
                    A
                ]);
            }).catch((A)=>{
                N.status = "rejected", N.reason = A, p([
                    "reject",
                    [
                        R
                    ],
                    A
                ]);
            });
            else {
                !or.has(N) && r(N) && (S = c(N));
                const A = !Fn.has(S) && or.get(S);
                A && y(R, A);
            }
            return Reflect.set(B, R, S, ee), p([
                "set",
                [
                    R
                ],
                N,
                _
            ]), !0;
        }
    });
    s.set(l, L);
    const Z = [
        I,
        m,
        o,
        E
    ];
    return or.set(L, Z), Reflect.ownKeys(l).forEach((B)=>{
        const R = Object.getOwnPropertyDescriptor(l, B);
        "value" in R && (L[B] = l[B], delete R.value, delete R.writable), Object.defineProperty(I, B, R);
    }), L;
})=>[
        c,
        or,
        Fn,
        t,
        e,
        r,
        n,
        i,
        o,
        s,
        a
    ], [i1] = n1();
function xe(t = {}) {
    return i1(t);
}
function We(t, e, r) {
    const n = or.get(t);
    (__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production" && !n && console.warn("Please use proxy object");
    let i;
    const o = [], s = n[3];
    let a = !1;
    const l = s((d)=>{
        if (o.push(d), r) {
            e(o.splice(0));
            return;
        }
        i || (i = Promise.resolve().then(()=>{
            i = void 0, a && e(o.splice(0));
        }));
    });
    return a = !0, ()=>{
        a = !1, l();
    };
}
function Hn(t, e) {
    const r = or.get(t);
    (__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production" && !r && console.warn("Please use proxy object");
    const [n, i, o] = r;
    return o(n, i(), e);
}
function Ir(t) {
    return Fn.add(t), t;
}
function He(t, e, r, n) {
    let i = t[e];
    return We(t, ()=>{
        const o = t[e];
        Object.is(i, o) || r(i = o);
    }, n);
}
function o1(t) {
    const e = xe({
        data: Array.from(t || []),
        has (r) {
            return this.data.some((n)=>n[0] === r);
        },
        set (r, n) {
            const i = this.data.find((o)=>o[0] === r);
            return i ? i[1] = n : this.data.push([
                r,
                n
            ]), this;
        },
        get (r) {
            var n;
            return (n = this.data.find((i)=>i[0] === r)) == null ? void 0 : n[1];
        },
        delete (r) {
            const n = this.data.findIndex((i)=>i[0] === r);
            return n === -1 ? !1 : (this.data.splice(n, 1), !0);
        },
        clear () {
            this.data.splice(0);
        },
        get size () {
            return this.data.length;
        },
        toJSON () {
            return new Map(this.data);
        },
        forEach (r) {
            this.data.forEach((n)=>{
                r(n[1], n[0], this);
            });
        },
        keys () {
            return this.data.map((r)=>r[0]).values();
        },
        values () {
            return this.data.map((r)=>r[1]).values();
        },
        entries () {
            return new Map(this.data).entries();
        },
        get [Symbol.toStringTag] () {
            return "Map";
        },
        [Symbol.iterator] () {
            return this.entries();
        }
    });
    return Object.defineProperties(e, {
        data: {
            enumerable: !1
        },
        size: {
            enumerable: !1
        },
        toJSON: {
            enumerable: !1
        }
    }), Object.seal(e), e;
}
const ga = (typeof process < "u" && typeof process.env < "u" ? process.env.NEXT_PUBLIC_SECURE_SITE_ORIGIN : void 0) || "https://secure.walletconnect.org", s1 = [
    {
        label: "Coinbase",
        name: "coinbase",
        feeRange: "1-2%",
        url: "",
        supportedChains: [
            "eip155"
        ]
    },
    {
        label: "Meld.io",
        name: "meld",
        feeRange: "1-2%",
        url: "https://meldcrypto.com",
        supportedChains: [
            "eip155",
            "solana"
        ]
    }
], Te = {
    FOUR_MINUTES_MS: 24e4,
    TEN_SEC_MS: 1e4,
    FIVE_SEC_MS: 5e3,
    THREE_SEC_MS: 3e3,
    ONE_SEC_MS: 1e3,
    SECURE_SITE: ga,
    SECURE_SITE_DASHBOARD: `${ga}/dashboard`,
    SECURE_SITE_FAVICON: `${ga}/images/favicon.png`,
    RESTRICTED_TIMEZONES: [
        "ASIA/SHANGHAI",
        "ASIA/URUMQI",
        "ASIA/CHONGQING",
        "ASIA/HARBIN",
        "ASIA/KASHGAR",
        "ASIA/MACAU",
        "ASIA/HONG_KONG",
        "ASIA/MACAO",
        "ASIA/BEIJING",
        "ASIA/HARBIN"
    ],
    WC_COINBASE_PAY_SDK_CHAINS: [
        "ethereum",
        "arbitrum",
        "polygon",
        "berachain",
        "avalanche-c-chain",
        "optimism",
        "celo",
        "base"
    ],
    WC_COINBASE_PAY_SDK_FALLBACK_CHAIN: "ethereum",
    WC_COINBASE_PAY_SDK_CHAIN_NAME_MAP: {
        Ethereum: "ethereum",
        "Arbitrum One": "arbitrum",
        Polygon: "polygon",
        Berachain: "berachain",
        Avalanche: "avalanche-c-chain",
        "OP Mainnet": "optimism",
        Celo: "celo",
        Base: "base"
    },
    WC_COINBASE_ONRAMP_APP_ID: "bf18c88d-495a-463b-b249-0b9d3656cf5e",
    SWAP_SUGGESTED_TOKENS: [
        "ETH",
        "UNI",
        "1INCH",
        "AAVE",
        "SOL",
        "ADA",
        "AVAX",
        "DOT",
        "LINK",
        "NITRO",
        "GAIA",
        "MILK",
        "TRX",
        "NEAR",
        "GNO",
        "WBTC",
        "DAI",
        "WETH",
        "USDC",
        "USDT",
        "ARB",
        "BAL",
        "BICO",
        "CRV",
        "ENS",
        "MATIC",
        "OP"
    ],
    SWAP_POPULAR_TOKENS: [
        "ETH",
        "UNI",
        "1INCH",
        "AAVE",
        "SOL",
        "ADA",
        "AVAX",
        "DOT",
        "LINK",
        "NITRO",
        "GAIA",
        "MILK",
        "TRX",
        "NEAR",
        "GNO",
        "WBTC",
        "DAI",
        "WETH",
        "USDC",
        "USDT",
        "ARB",
        "BAL",
        "BICO",
        "CRV",
        "ENS",
        "MATIC",
        "OP",
        "METAL",
        "DAI",
        "CHAMP",
        "WOLF",
        "SALE",
        "BAL",
        "BUSD",
        "MUST",
        "BTCpx",
        "ROUTE",
        "HEX",
        "WELT",
        "amDAI",
        "VSQ",
        "VISION",
        "AURUM",
        "pSP",
        "SNX",
        "VC",
        "LINK",
        "CHP",
        "amUSDT",
        "SPHERE",
        "FOX",
        "GIDDY",
        "GFC",
        "OMEN",
        "OX_OLD",
        "DE",
        "WNT"
    ],
    BALANCE_SUPPORTED_CHAINS: [
        "eip155",
        "solana"
    ],
    SWAP_SUPPORTED_NETWORKS: [
        "eip155:1",
        "eip155:42161",
        "eip155:10",
        "eip155:324",
        "eip155:8453",
        "eip155:56",
        "eip155:137",
        "eip155:100",
        "eip155:43114",
        "eip155:250",
        "eip155:8217",
        "eip155:1313161554"
    ],
    NAMES_SUPPORTED_CHAIN_NAMESPACES: [
        "eip155"
    ],
    ONRAMP_SUPPORTED_CHAIN_NAMESPACES: [
        "eip155",
        "solana"
    ],
    ACTIVITY_ENABLED_CHAIN_NAMESPACES: [
        "eip155"
    ],
    NATIVE_TOKEN_ADDRESS: {
        eip155: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
        solana: "So11111111111111111111111111111111111111111",
        polkadot: "0x",
        bip122: "0x"
    },
    CONVERT_SLIPPAGE_TOLERANCE: 1,
    CONNECT_LABELS: {
        MOBILE: "Open and continue in a new browser tab"
    },
    DEFAULT_FEATURES: {
        swaps: !0,
        onramp: !0,
        receive: !0,
        send: !0,
        email: !0,
        emailShowWallets: !0,
        socials: [
            "google",
            "x",
            "discord",
            "farcaster",
            "github",
            "apple",
            "facebook"
        ],
        connectorTypeOrder: [
            "walletConnect",
            "recent",
            "injected",
            "featured",
            "custom",
            "external",
            "recommended"
        ],
        history: !0,
        analytics: !0,
        allWallets: !0,
        legalCheckbox: !1,
        smartSessions: !1,
        collapseWallets: !1,
        walletFeaturesOrder: [
            "onramp",
            "swaps",
            "receive",
            "send"
        ],
        connectMethodsOrder: void 0
    },
    DEFAULT_ACCOUNT_TYPES: {
        bip122: "payment",
        eip155: "smartAccount",
        polkadot: "eoa",
        solana: "eoa"
    },
    ADAPTER_TYPES: {
        UNIVERSAL: "universal",
        SOLANA: "solana",
        WAGMI: "wagmi",
        ETHERS: "ethers",
        ETHERS5: "ethers5",
        BITCOIN: "bitcoin"
    }
}, q = {
    cacheExpiry: {
        portfolio: 3e4,
        nativeBalance: 3e4,
        ens: 3e5,
        identity: 3e5
    },
    isCacheExpired (t, e) {
        return Date.now() - t > e;
    },
    getActiveNetworkProps () {
        const t = q.getActiveNamespace(), e = q.getActiveCaipNetworkId(), r = e ? e.split(":")[1] : void 0, n = r ? isNaN(Number(r)) ? r : Number(r) : void 0;
        return {
            namespace: t,
            caipNetworkId: e,
            chainId: n
        };
    },
    setWalletConnectDeepLink ({ name: t, href: e }) {
        try {
            se.setItem(ce.DEEPLINK_CHOICE, JSON.stringify({
                href: e,
                name: t
            }));
        } catch  {
            console.info("Unable to set WalletConnect deep link");
        }
    },
    getWalletConnectDeepLink () {
        try {
            const t = se.getItem(ce.DEEPLINK_CHOICE);
            if (t) return JSON.parse(t);
        } catch  {
            console.info("Unable to get WalletConnect deep link");
        }
    },
    deleteWalletConnectDeepLink () {
        try {
            se.removeItem(ce.DEEPLINK_CHOICE);
        } catch  {
            console.info("Unable to delete WalletConnect deep link");
        }
    },
    setActiveNamespace (t) {
        try {
            se.setItem(ce.ACTIVE_NAMESPACE, t);
        } catch  {
            console.info("Unable to set active namespace");
        }
    },
    setActiveCaipNetworkId (t) {
        try {
            se.setItem(ce.ACTIVE_CAIP_NETWORK_ID, t), q.setActiveNamespace(t.split(":")[0]);
        } catch  {
            console.info("Unable to set active caip network id");
        }
    },
    getActiveCaipNetworkId () {
        try {
            return se.getItem(ce.ACTIVE_CAIP_NETWORK_ID);
        } catch  {
            console.info("Unable to get active caip network id");
            return;
        }
    },
    deleteActiveCaipNetworkId () {
        try {
            se.removeItem(ce.ACTIVE_CAIP_NETWORK_ID);
        } catch  {
            console.info("Unable to delete active caip network id");
        }
    },
    deleteConnectedConnectorId (t) {
        try {
            const e = ha(t);
            se.removeItem(e);
        } catch  {
            console.info("Unable to delete connected connector id");
        }
    },
    setAppKitRecent (t) {
        try {
            const e = q.getRecentWallets();
            e.find((n)=>n.id === t.id) || (e.unshift(t), e.length > 2 && e.pop(), se.setItem(ce.RECENT_WALLETS, JSON.stringify(e)));
        } catch  {
            console.info("Unable to set AppKit recent");
        }
    },
    getRecentWallets () {
        try {
            const t = se.getItem(ce.RECENT_WALLETS);
            return t ? JSON.parse(t) : [];
        } catch  {
            console.info("Unable to get AppKit recent");
        }
        return [];
    },
    setConnectedConnectorId (t, e) {
        try {
            const r = ha(t);
            se.setItem(r, e);
        } catch  {
            console.info("Unable to set Connected Connector Id");
        }
    },
    getActiveNamespace () {
        try {
            return se.getItem(ce.ACTIVE_NAMESPACE);
        } catch  {
            console.info("Unable to get active namespace");
        }
    },
    getConnectedConnectorId (t) {
        if (t) try {
            const e = ha(t);
            return se.getItem(e);
        } catch  {
            console.info("Unable to get connected connector id in namespace ", t);
        }
    },
    setConnectedSocialProvider (t) {
        try {
            se.setItem(ce.CONNECTED_SOCIAL, t);
        } catch  {
            console.info("Unable to set connected social provider");
        }
    },
    getConnectedSocialProvider () {
        try {
            return se.getItem(ce.CONNECTED_SOCIAL);
        } catch  {
            console.info("Unable to get connected social provider");
        }
    },
    deleteConnectedSocialProvider () {
        try {
            se.removeItem(ce.CONNECTED_SOCIAL);
        } catch  {
            console.info("Unable to delete connected social provider");
        }
    },
    getConnectedSocialUsername () {
        try {
            return se.getItem(ce.CONNECTED_SOCIAL_USERNAME);
        } catch  {
            console.info("Unable to get connected social username");
        }
    },
    getStoredActiveCaipNetworkId () {
        return se.getItem(ce.ACTIVE_CAIP_NETWORK_ID)?.split(":")?.[1];
    },
    setConnectionStatus (t) {
        try {
            se.setItem(ce.CONNECTION_STATUS, t);
        } catch  {
            console.info("Unable to set connection status");
        }
    },
    getConnectionStatus () {
        try {
            return se.getItem(ce.CONNECTION_STATUS);
        } catch  {
            return;
        }
    },
    getConnectedNamespaces () {
        try {
            const t = se.getItem(ce.CONNECTED_NAMESPACES);
            return t?.length ? t.split(",") : [];
        } catch  {
            return [];
        }
    },
    setConnectedNamespaces (t) {
        try {
            const e = Array.from(new Set(t));
            se.setItem(ce.CONNECTED_NAMESPACES, e.join(","));
        } catch  {
            console.info("Unable to set namespaces in storage");
        }
    },
    addConnectedNamespace (t) {
        try {
            const e = q.getConnectedNamespaces();
            e.includes(t) || (e.push(t), q.setConnectedNamespaces(e));
        } catch  {
            console.info("Unable to add connected namespace");
        }
    },
    removeConnectedNamespace (t) {
        try {
            const e = q.getConnectedNamespaces(), r = e.indexOf(t);
            r > -1 && (e.splice(r, 1), q.setConnectedNamespaces(e));
        } catch  {
            console.info("Unable to remove connected namespace");
        }
    },
    getTelegramSocialProvider () {
        try {
            return se.getItem(ce.TELEGRAM_SOCIAL_PROVIDER);
        } catch  {
            return console.info("Unable to get telegram social provider"), null;
        }
    },
    setTelegramSocialProvider (t) {
        try {
            se.setItem(ce.TELEGRAM_SOCIAL_PROVIDER, t);
        } catch  {
            console.info("Unable to set telegram social provider");
        }
    },
    removeTelegramSocialProvider () {
        try {
            se.removeItem(ce.TELEGRAM_SOCIAL_PROVIDER);
        } catch  {
            console.info("Unable to remove telegram social provider");
        }
    },
    getBalanceCache () {
        let t = {};
        try {
            const e = se.getItem(ce.PORTFOLIO_CACHE);
            t = e ? JSON.parse(e) : {};
        } catch  {
            console.info("Unable to get balance cache");
        }
        return t;
    },
    removeAddressFromBalanceCache (t) {
        try {
            const e = q.getBalanceCache();
            se.setItem(ce.PORTFOLIO_CACHE, JSON.stringify({
                ...e,
                [t]: void 0
            }));
        } catch  {
            console.info("Unable to remove address from balance cache", t);
        }
    },
    getBalanceCacheForCaipAddress (t) {
        try {
            const r = q.getBalanceCache()[t];
            if (r && !this.isCacheExpired(r.timestamp, this.cacheExpiry.portfolio)) return r.balance;
            q.removeAddressFromBalanceCache(t);
        } catch  {
            console.info("Unable to get balance cache for address", t);
        }
    },
    updateBalanceCache (t) {
        try {
            const e = q.getBalanceCache();
            e[t.caipAddress] = t, se.setItem(ce.PORTFOLIO_CACHE, JSON.stringify(e));
        } catch  {
            console.info("Unable to update balance cache", t);
        }
    },
    getNativeBalanceCache () {
        let t = {};
        try {
            const e = se.getItem(ce.NATIVE_BALANCE_CACHE);
            t = e ? JSON.parse(e) : {};
        } catch  {
            console.info("Unable to get balance cache");
        }
        return t;
    },
    removeAddressFromNativeBalanceCache (t) {
        try {
            const e = q.getBalanceCache();
            se.setItem(ce.NATIVE_BALANCE_CACHE, JSON.stringify({
                ...e,
                [t]: void 0
            }));
        } catch  {
            console.info("Unable to remove address from balance cache", t);
        }
    },
    getNativeBalanceCacheForCaipAddress (t) {
        try {
            const r = q.getNativeBalanceCache()[t];
            if (r && !this.isCacheExpired(r.timestamp, this.cacheExpiry.nativeBalance)) return r;
            console.info("Discarding cache for address", t), q.removeAddressFromBalanceCache(t);
        } catch  {
            console.info("Unable to get balance cache for address", t);
        }
    },
    updateNativeBalanceCache (t) {
        try {
            const e = q.getNativeBalanceCache();
            e[t.caipAddress] = t, se.setItem(ce.NATIVE_BALANCE_CACHE, JSON.stringify(e));
        } catch  {
            console.info("Unable to update balance cache", t);
        }
    },
    getEnsCache () {
        let t = {};
        try {
            const e = se.getItem(ce.ENS_CACHE);
            t = e ? JSON.parse(e) : {};
        } catch  {
            console.info("Unable to get ens name cache");
        }
        return t;
    },
    getEnsFromCacheForAddress (t) {
        try {
            const r = q.getEnsCache()[t];
            if (r && !this.isCacheExpired(r.timestamp, this.cacheExpiry.ens)) return r.ens;
            q.removeEnsFromCache(t);
        } catch  {
            console.info("Unable to get ens name from cache", t);
        }
    },
    updateEnsCache (t) {
        try {
            const e = q.getEnsCache();
            e[t.address] = t, se.setItem(ce.ENS_CACHE, JSON.stringify(e));
        } catch  {
            console.info("Unable to update ens name cache", t);
        }
    },
    removeEnsFromCache (t) {
        try {
            const e = q.getEnsCache();
            se.setItem(ce.ENS_CACHE, JSON.stringify({
                ...e,
                [t]: void 0
            }));
        } catch  {
            console.info("Unable to remove ens name from cache", t);
        }
    },
    getIdentityCache () {
        let t = {};
        try {
            const e = se.getItem(ce.IDENTITY_CACHE);
            t = e ? JSON.parse(e) : {};
        } catch  {
            console.info("Unable to get identity cache");
        }
        return t;
    },
    getIdentityFromCacheForAddress (t) {
        try {
            const r = q.getIdentityCache()[t];
            if (r && !this.isCacheExpired(r.timestamp, this.cacheExpiry.identity)) return r.identity;
            q.removeIdentityFromCache(t);
        } catch  {
            console.info("Unable to get identity from cache", t);
        }
    },
    updateIdentityCache (t) {
        try {
            const e = q.getIdentityCache();
            e[t.address] = {
                identity: t.identity,
                timestamp: t.timestamp
            }, se.setItem(ce.IDENTITY_CACHE, JSON.stringify(e));
        } catch  {
            console.info("Unable to update identity cache", t);
        }
    },
    removeIdentityFromCache (t) {
        try {
            const e = q.getIdentityCache();
            se.setItem(ce.IDENTITY_CACHE, JSON.stringify({
                ...e,
                [t]: void 0
            }));
        } catch  {
            console.info("Unable to remove identity from cache", t);
        }
    },
    clearAddressCache () {
        try {
            se.removeItem(ce.PORTFOLIO_CACHE), se.removeItem(ce.NATIVE_BALANCE_CACHE), se.removeItem(ce.ENS_CACHE), se.removeItem(ce.IDENTITY_CACHE);
        } catch  {
            console.info("Unable to clear address cache");
        }
    },
    setPreferredAccountTypes (t) {
        try {
            se.setItem(ce.PREFERRED_ACCOUNT_TYPES, JSON.stringify(t));
        } catch  {
            console.info("Unable to set preferred account types", t);
        }
    },
    getPreferredAccountTypes () {
        try {
            const t = se.getItem(ce.PREFERRED_ACCOUNT_TYPES);
            return JSON.parse(t);
        } catch  {
            console.info("Unable to get preferred account types");
        }
    }
}, U = {
    isMobile () {
        return this.isClient() ? !!(window?.matchMedia("(pointer:coarse)")?.matches || /Android|webOS|iPhone|iPad|iPod|BlackBerry|Opera Mini/u.test(navigator.userAgent)) : !1;
    },
    checkCaipNetwork (t, e = "") {
        return t?.caipNetworkId.toLocaleLowerCase().includes(e.toLowerCase());
    },
    isAndroid () {
        if (!this.isMobile()) return !1;
        const t = window?.navigator.userAgent.toLowerCase();
        return U.isMobile() && t.includes("android");
    },
    isIos () {
        if (!this.isMobile()) return !1;
        const t = window?.navigator.userAgent.toLowerCase();
        return t.includes("iphone") || t.includes("ipad");
    },
    isSafari () {
        return this.isClient() ? (window?.navigator.userAgent.toLowerCase()).includes("safari") : !1;
    },
    isClient () {
        return ("TURBOPACK compile-time value", "undefined") < "u";
    },
    isPairingExpired (t) {
        return t ? t - Date.now() <= Te.TEN_SEC_MS : !0;
    },
    isAllowedRetry (t, e = Te.ONE_SEC_MS) {
        return Date.now() - t >= e;
    },
    copyToClopboard (t) {
        navigator.clipboard.writeText(t);
    },
    isIframe () {
        try {
            return window?.self !== window?.top;
        } catch  {
            return !1;
        }
    },
    getPairingExpiry () {
        return Date.now() + Te.FOUR_MINUTES_MS;
    },
    getNetworkId (t) {
        return t?.split(":")[1];
    },
    getPlainAddress (t) {
        return t?.split(":")[2];
    },
    async wait (t) {
        return new Promise((e)=>{
            setTimeout(e, t);
        });
    },
    debounce (t, e = 500) {
        let r;
        return (...n)=>{
            function i() {
                t(...n);
            }
            r && clearTimeout(r), r = setTimeout(i, e);
        };
    },
    isHttpUrl (t) {
        return t.startsWith("http://") || t.startsWith("https://");
    },
    formatNativeUrl (t, e) {
        if (U.isHttpUrl(t)) return this.formatUniversalUrl(t, e);
        let r = t;
        r.includes("://") || (r = t.replaceAll("/", "").replaceAll(":", ""), r = `${r}://`), r.endsWith("/") || (r = `${r}/`), this.isTelegram() && this.isAndroid() && (e = encodeURIComponent(e));
        const n = encodeURIComponent(e);
        return {
            redirect: `${r}wc?uri=${n}`,
            href: r
        };
    },
    formatUniversalUrl (t, e) {
        if (!U.isHttpUrl(t)) return this.formatNativeUrl(t, e);
        let r = t;
        r.endsWith("/") || (r = `${r}/`);
        const n = encodeURIComponent(e);
        return {
            redirect: `${r}wc?uri=${n}`,
            href: r
        };
    },
    getOpenTargetForPlatform (t) {
        return t === "popupWindow" ? t : this.isTelegram() ? q.getTelegramSocialProvider() ? "_top" : "_blank" : t;
    },
    openHref (t, e, r) {
        window?.open(t, this.getOpenTargetForPlatform(e), r || "noreferrer noopener");
    },
    returnOpenHref (t, e, r) {
        return window?.open(t, this.getOpenTargetForPlatform(e), r || "noreferrer noopener");
    },
    isTelegram () {
        return ("TURBOPACK compile-time value", "undefined") < "u" && (!!window.TelegramWebviewProxy || !!window.Telegram || !!window.TelegramWebviewProxyProto);
    },
    async preloadImage (t) {
        const e = new Promise((r, n)=>{
            const i = new Image;
            i.onload = r, i.onerror = n, i.crossOrigin = "anonymous", i.src = t;
        });
        return Promise.race([
            e,
            U.wait(2e3)
        ]);
    },
    formatBalance (t, e) {
        let r = "0.000";
        if (typeof t == "string") {
            const n = Number(t);
            if (n) {
                const i = Math.floor(n * 1e3) / 1e3;
                i && (r = i.toString());
            }
        }
        return `${r}${e ? ` ${e}` : ""}`;
    },
    formatBalance2 (t, e) {
        let r;
        if (t === "0") r = "0";
        else if (typeof t == "string") {
            const n = Number(t);
            n && (r = n.toString().match(/^-?\d+(?:\.\d{0,3})?/u)?.[0]);
        }
        return {
            value: r ?? "0",
            rest: r === "0" ? "000" : "",
            symbol: e
        };
    },
    getApiUrl () {
        return G.W3M_API_URL;
    },
    getBlockchainApiUrl () {
        return G.BLOCKCHAIN_API_RPC_URL;
    },
    getAnalyticsUrl () {
        return G.PULSE_API_URL;
    },
    getUUID () {
        return crypto?.randomUUID ? crypto.randomUUID() : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/gu, (t)=>{
            const e = Math.random() * 16 | 0;
            return (t === "x" ? e : e & 3 | 8).toString(16);
        });
    },
    parseError (t) {
        return typeof t == "string" ? t : typeof t?.issues?.[0]?.message == "string" ? t.issues[0].message : t instanceof Error ? t.message : "Unknown error";
    },
    sortRequestedNetworks (t, e = []) {
        const r = {};
        return e && t && (t.forEach((n, i)=>{
            r[n] = i;
        }), e.sort((n, i)=>{
            const o = r[n.id], s = r[i.id];
            return o !== void 0 && s !== void 0 ? o - s : o !== void 0 ? -1 : s !== void 0 ? 1 : 0;
        })), e;
    },
    calculateBalance (t) {
        let e = 0;
        for (const r of t)e += r.value ?? 0;
        return e;
    },
    formatTokenBalance (t) {
        const e = t.toFixed(2), [r, n] = e.split(".");
        return {
            dollars: r,
            pennies: n
        };
    },
    isAddress (t, e = "eip155") {
        switch(e){
            case "eip155":
                if (/^(?:0x)?[0-9a-f]{40}$/iu.test(t)) {
                    if (/^(?:0x)?[0-9a-f]{40}$/iu.test(t) || /^(?:0x)?[0-9A-F]{40}$/iu.test(t)) return !0;
                } else return !1;
                return !1;
            case "solana":
                return /[1-9A-HJ-NP-Za-km-z]{32,44}$/iu.test(t);
            default:
                return !1;
        }
    },
    uniqueBy (t, e) {
        const r = new Set;
        return t.filter((n)=>{
            const i = n[e];
            return r.has(i) ? !1 : (r.add(i), !0);
        });
    },
    generateSdkVersion (t, e, r) {
        const i = t.length === 0 ? Te.ADAPTER_TYPES.UNIVERSAL : t.map((o)=>o.adapterType).join(",");
        return `${e}-${i}-${r}`;
    },
    createAccount (t, e, r, n, i) {
        return {
            namespace: t,
            address: e,
            type: r,
            publicKey: n,
            path: i
        };
    },
    isCaipAddress (t) {
        if (typeof t != "string") return !1;
        const e = t.split(":"), r = e[0];
        return e.filter(Boolean).length === 3 && r in G.CHAIN_NAME_MAP;
    },
    isMac () {
        const t = window?.navigator.userAgent.toLowerCase();
        return t.includes("macintosh") && !t.includes("safari");
    },
    formatTelegramSocialLoginUrl (t) {
        const e = `--${encodeURIComponent(window?.location.href)}`, r = "state=";
        if (new URL(t).host === "auth.magic.link") {
            const i = "provider_authorization_url=", o = t.substring(t.indexOf(i) + i.length), s = this.injectIntoUrl(decodeURIComponent(o), r, e);
            return t.replace(o, encodeURIComponent(s));
        }
        return this.injectIntoUrl(t, r, e);
    },
    injectIntoUrl (t, e, r) {
        const n = t.indexOf(e);
        if (n === -1) throw new Error(`${e} parameter not found in the URL: ${t}`);
        const i = t.indexOf("&", n), o = e.length, s = i !== -1 ? i : t.length, a = t.substring(0, n + o), c = t.substring(n + o, s), l = t.substring(i), d = c + r;
        return a + d + l;
    }
};
async function Vn(...t) {
    const e = await fetch(...t);
    if (!e.ok) throw new Error(`HTTP status code: ${e.status}`, {
        cause: e
    });
    return e;
}
class Eo {
    constructor({ baseUrl: e, clientId: r }){
        this.baseUrl = e, this.clientId = r;
    }
    async get({ headers: e, signal: r, cache: n, ...i }) {
        const o = this.createUrl(i);
        return (await Vn(o, {
            method: "GET",
            headers: e,
            signal: r,
            cache: n
        })).json();
    }
    async getBlob({ headers: e, signal: r, ...n }) {
        const i = this.createUrl(n);
        return (await Vn(i, {
            method: "GET",
            headers: e,
            signal: r
        })).blob();
    }
    async post({ body: e, headers: r, signal: n, ...i }) {
        const o = this.createUrl(i);
        return (await Vn(o, {
            method: "POST",
            headers: r,
            body: e ? JSON.stringify(e) : void 0,
            signal: n
        })).json();
    }
    async put({ body: e, headers: r, signal: n, ...i }) {
        const o = this.createUrl(i);
        return (await Vn(o, {
            method: "PUT",
            headers: r,
            body: e ? JSON.stringify(e) : void 0,
            signal: n
        })).json();
    }
    async delete({ body: e, headers: r, signal: n, ...i }) {
        const o = this.createUrl(i);
        return (await Vn(o, {
            method: "DELETE",
            headers: r,
            body: e ? JSON.stringify(e) : void 0,
            signal: n
        })).json();
    }
    createUrl({ path: e, params: r }) {
        const n = new URL(e, this.baseUrl);
        return r && Object.entries(r).forEach(([i, o])=>{
            o && n.searchParams.append(i, o);
        }), this.clientId && n.searchParams.append("clientId", this.clientId), n;
    }
}
const a1 = {
    handleSolanaDeeplinkRedirect (t) {
        if (f.state.activeChain === G.CHAIN.SOLANA) {
            const e = window.location.href, r = encodeURIComponent(e);
            if (t === "Phantom" && !("phantom" in window)) {
                const n = e.startsWith("https") ? "https" : "http", i = e.split("/")[2], o = encodeURIComponent(`${n}://${i}`);
                window.location.href = `https://phantom.app/ul/browse/${r}?ref=${o}`;
            }
            t === "Coinbase Wallet" && !("coinbaseSolana" in window) && (window.location.href = `https://go.cb-w.com/dapp?cb_url=${r}`);
        }
    }
}, st = xe({
    walletImages: {},
    networkImages: {},
    chainImages: {},
    connectorImages: {},
    tokenImages: {},
    currencyImages: {}
}), Ye = {
    state: st,
    subscribeNetworkImages (t) {
        return We(st.networkImages, ()=>t(st.networkImages));
    },
    subscribeKey (t, e) {
        return He(st, t, e);
    },
    subscribe (t) {
        return We(st, ()=>t(st));
    },
    setWalletImage (t, e) {
        st.walletImages[t] = e;
    },
    setNetworkImage (t, e) {
        st.networkImages[t] = e;
    },
    setChainImage (t, e) {
        st.chainImages[t] = e;
    },
    setConnectorImage (t, e) {
        st.connectorImages = {
            ...st.connectorImages,
            [t]: e
        };
    },
    setTokenImage (t, e) {
        st.tokenImages[t] = e;
    },
    setCurrencyImage (t, e) {
        st.currencyImages[t] = e;
    }
}, c1 = {
    eip155: "ba0ba0cd-17c6-4806-ad93-f9d174f17900",
    solana: "a1b58899-f671-4276-6a5e-56ca5bd59700",
    polkadot: "",
    bip122: "0b4838db-0161-4ffe-022d-532bf03dba00"
}, wa = xe({
    networkImagePromises: {}
}), Oe = {
    async fetchWalletImage (t) {
        if (t) return await W._fetchWalletImage(t), this.getWalletImageById(t);
    },
    async fetchNetworkImage (t) {
        if (!t) return;
        const e = this.getNetworkImageById(t);
        return e || (wa.networkImagePromises[t] || (wa.networkImagePromises[t] = W._fetchNetworkImage(t)), await wa.networkImagePromises[t], this.getNetworkImageById(t));
    },
    getWalletImageById (t) {
        if (t) return Ye.state.walletImages[t];
    },
    getWalletImage (t) {
        if (t?.image_url) return t?.image_url;
        if (t?.image_id) return Ye.state.walletImages[t.image_id];
    },
    getNetworkImage (t) {
        if (t?.assets?.imageUrl) return t?.assets?.imageUrl;
        if (t?.assets?.imageId) return Ye.state.networkImages[t.assets.imageId];
    },
    getNetworkImageById (t) {
        if (t) return Ye.state.networkImages[t];
    },
    getConnectorImage (t) {
        if (t?.imageUrl) return t.imageUrl;
        if (t?.imageId) return Ye.state.connectorImages[t.imageId];
    },
    getChainImage (t) {
        return Ye.state.networkImages[c1[t]];
    }
}, l1 = {
    getFeatureValue (t, e) {
        const r = e?.[t];
        return r === void 0 ? Te.DEFAULT_FEATURES[t] : r;
    },
    filterSocialsByPlatform (t) {
        if (!t || !t.length) return t;
        if (U.isTelegram()) {
            if (U.isIos()) return t.filter((e)=>e !== "google");
            if (U.isMac()) return t.filter((e)=>e !== "x");
            if (U.isAndroid()) return t.filter((e)=>![
                    "facebook",
                    "x"
                ].includes(e));
        }
        return t;
    }
}, ne = xe({
    features: Te.DEFAULT_FEATURES,
    projectId: "",
    sdkType: "appkit",
    sdkVersion: "html-wagmi-undefined",
    defaultAccountTypes: {
        solana: "eoa",
        bip122: "payment",
        polkadot: "eoa",
        eip155: "smartAccount"
    },
    enableNetworkSwitch: !0
}), T = {
    state: ne,
    subscribeKey (t, e) {
        return He(ne, t, e);
    },
    setOptions (t) {
        Object.assign(ne, t);
    },
    setFeatures (t) {
        if (!t) return;
        ne.features || (ne.features = Te.DEFAULT_FEATURES);
        const e = {
            ...ne.features,
            ...t
        };
        ne.features = e, ne.features.socials && (ne.features.socials = l1.filterSocialsByPlatform(ne.features.socials));
    },
    setProjectId (t) {
        ne.projectId = t;
    },
    setCustomRpcUrls (t) {
        ne.customRpcUrls = t;
    },
    setAllWallets (t) {
        ne.allWallets = t;
    },
    setIncludeWalletIds (t) {
        ne.includeWalletIds = t;
    },
    setExcludeWalletIds (t) {
        ne.excludeWalletIds = t;
    },
    setFeaturedWalletIds (t) {
        ne.featuredWalletIds = t;
    },
    setTokens (t) {
        ne.tokens = t;
    },
    setTermsConditionsUrl (t) {
        ne.termsConditionsUrl = t;
    },
    setPrivacyPolicyUrl (t) {
        ne.privacyPolicyUrl = t;
    },
    setCustomWallets (t) {
        ne.customWallets = t;
    },
    setIsSiweEnabled (t) {
        ne.isSiweEnabled = t;
    },
    setIsUniversalProvider (t) {
        ne.isUniversalProvider = t;
    },
    setSdkVersion (t) {
        ne.sdkVersion = t;
    },
    setMetadata (t) {
        ne.metadata = t;
    },
    setDisableAppend (t) {
        ne.disableAppend = t;
    },
    setEIP6963Enabled (t) {
        ne.enableEIP6963 = t;
    },
    setDebug (t) {
        ne.debug = t;
    },
    setEnableWalletConnect (t) {
        ne.enableWalletConnect = t;
    },
    setEnableWalletGuide (t) {
        ne.enableWalletGuide = t;
    },
    setEnableAuthLogger (t) {
        ne.enableAuthLogger = t;
    },
    setEnableWallets (t) {
        ne.enableWallets = t;
    },
    setHasMultipleAddresses (t) {
        ne.hasMultipleAddresses = t;
    },
    setSIWX (t) {
        ne.siwx = t;
    },
    setConnectMethodsOrder (t) {
        ne.features = {
            ...ne.features,
            connectMethodsOrder: t
        };
    },
    setWalletFeaturesOrder (t) {
        ne.features = {
            ...ne.features,
            walletFeaturesOrder: t
        };
    },
    setSocialsOrder (t) {
        ne.features = {
            ...ne.features,
            socials: t
        };
    },
    setCollapseWallets (t) {
        ne.features = {
            ...ne.features,
            collapseWallets: t
        };
    },
    setEnableEmbedded (t) {
        ne.enableEmbedded = t;
    },
    setAllowUnsupportedChain (t) {
        ne.allowUnsupportedChain = t;
    },
    setManualWCControl (t) {
        ne.manualWCControl = t;
    },
    setEnableNetworkSwitch (t) {
        ne.enableNetworkSwitch = t;
    },
    setDefaultAccountTypes (t = {}) {
        Object.entries(t).forEach(([e, r])=>{
            r && (ne.defaultAccountTypes[e] = r);
        });
    },
    setUniversalProviderConfigOverride (t) {
        ne.universalProviderConfigOverride = t;
    },
    getUniversalProviderConfigOverride () {
        return ne.universalProviderConfigOverride;
    },
    getSnapshot () {
        return Hn(ne);
    }
}, sr = xe({
    message: "",
    variant: "info",
    open: !1
}), ar = {
    state: sr,
    subscribeKey (t, e) {
        return He(sr, t, e);
    },
    open (t, e) {
        const { debug: r } = T.state, { shortMessage: n, longMessage: i } = t;
        r && (sr.message = n, sr.variant = e, sr.open = !0), i && console.error(typeof i == "function" ? i() : i);
    },
    close () {
        sr.open = !1, sr.message = "", sr.variant = "info";
    }
}, d1 = U.getAnalyticsUrl(), u1 = new Eo({
    baseUrl: d1,
    clientId: null
}), h1 = [
    "MODAL_CREATED"
], Mt = xe({
    timestamp: Date.now(),
    reportedErrors: {},
    data: {
        type: "track",
        event: "MODAL_CREATED"
    }
}), le = {
    state: Mt,
    subscribe (t) {
        return We(Mt, ()=>t(Mt));
    },
    getSdkProperties () {
        const { projectId: t, sdkType: e, sdkVersion: r } = T.state;
        return {
            projectId: t,
            st: e,
            sv: r || "html-wagmi-4.2.2"
        };
    },
    async _sendAnalyticsEvent (t) {
        try {
            const e = Q.state.address;
            if (h1.includes(t.data.event) || ("TURBOPACK compile-time value", "undefined") > "u") return;
            await u1.post({
                path: "/e",
                params: le.getSdkProperties(),
                body: {
                    eventId: U.getUUID(),
                    url: window.location.href,
                    domain: window.location.hostname,
                    timestamp: t.timestamp,
                    props: {
                        ...t.data,
                        address: e
                    }
                }
            }), Mt.reportedErrors.FORBIDDEN = !1;
        } catch (e) {
            e instanceof Error && e.cause instanceof Response && e.cause.status === G.HTTP_STATUS_CODES.FORBIDDEN && !Mt.reportedErrors.FORBIDDEN && (ar.open({
                shortMessage: "Invalid App Configuration",
                longMessage: `Origin ${jn() ? window.origin : "uknown"} not found on Allowlist - update configuration on cloud.reown.com`
            }, "error"), Mt.reportedErrors.FORBIDDEN = !0);
        }
    },
    sendEvent (t) {
        Mt.timestamp = Date.now(), Mt.data = t, T.state.features?.analytics && le._sendAnalyticsEvent(Mt);
    }
}, p1 = [
    "1ca0bdd4747578705b1939af023d120677c64fe6ca76add81fda36e350605e79",
    "fd20dc426fb37566d803205b19bbc1d4096b248ac04548e3cfb6b3a38bd033aa",
    "a797aa35c0fadbfc1a53e7f675162ed5226968b44a19ee3d24385c64d1d3c393"
], f1 = U.getApiUrl(), ht = new Eo({
    baseUrl: f1,
    clientId: null
}), g1 = 40, pl = 4, w1 = 20, Ce = xe({
    promises: {},
    page: 1,
    count: 0,
    featured: [],
    allFeatured: [],
    recommended: [],
    allRecommended: [],
    wallets: [],
    search: [],
    isAnalyticsEnabled: !1,
    excludedWallets: [],
    isFetchingRecommendedWallets: !1
}), W = {
    state: Ce,
    subscribeKey (t, e) {
        return He(Ce, t, e);
    },
    _getSdkProperties () {
        const { projectId: t, sdkType: e, sdkVersion: r } = T.state;
        return {
            projectId: t,
            st: e || "appkit",
            sv: r || "html-wagmi-4.2.2"
        };
    },
    _filterOutExtensions (t) {
        return T.state.isUniversalProvider ? t.filter((e)=>!!(e.mobile_link || e.desktop_link || e.webapp_link)) : t;
    },
    async _fetchWalletImage (t) {
        const e = `${ht.baseUrl}/getWalletImage/${t}`, r = await ht.getBlob({
            path: e,
            params: W._getSdkProperties()
        });
        Ye.setWalletImage(t, URL.createObjectURL(r));
    },
    async _fetchNetworkImage (t) {
        const e = `${ht.baseUrl}/public/getAssetImage/${t}`, r = await ht.getBlob({
            path: e,
            params: W._getSdkProperties()
        });
        Ye.setNetworkImage(t, URL.createObjectURL(r));
    },
    async _fetchConnectorImage (t) {
        const e = `${ht.baseUrl}/public/getAssetImage/${t}`, r = await ht.getBlob({
            path: e,
            params: W._getSdkProperties()
        });
        Ye.setConnectorImage(t, URL.createObjectURL(r));
    },
    async _fetchCurrencyImage (t) {
        const e = `${ht.baseUrl}/public/getCurrencyImage/${t}`, r = await ht.getBlob({
            path: e,
            params: W._getSdkProperties()
        });
        Ye.setCurrencyImage(t, URL.createObjectURL(r));
    },
    async _fetchTokenImage (t) {
        const e = `${ht.baseUrl}/public/getTokenImage/${t}`, r = await ht.getBlob({
            path: e,
            params: W._getSdkProperties()
        });
        Ye.setTokenImage(t, URL.createObjectURL(r));
    },
    async fetchNetworkImages () {
        const e = f.getAllRequestedCaipNetworks()?.map(({ assets: r })=>r?.imageId).filter(Boolean).filter((r)=>!Oe.getNetworkImageById(r));
        e && await Promise.allSettled(e.map((r)=>W._fetchNetworkImage(r)));
    },
    async fetchConnectorImages () {
        const { connectors: t } = j.state, e = t.map(({ imageId: r })=>r).filter(Boolean);
        await Promise.allSettled(e.map((r)=>W._fetchConnectorImage(r)));
    },
    async fetchCurrencyImages (t = []) {
        await Promise.allSettled(t.map((e)=>W._fetchCurrencyImage(e)));
    },
    async fetchTokenImages (t = []) {
        await Promise.allSettled(t.map((e)=>W._fetchTokenImage(e)));
    },
    async fetchWallets (t) {
        const e = t.exclude ?? [];
        return W._getSdkProperties().sv.startsWith("html-core-") && e.push(...p1), await ht.get({
            path: "/getWallets",
            params: {
                ...W._getSdkProperties(),
                ...t,
                page: String(t.page),
                entries: String(t.entries),
                include: t.include?.join(","),
                exclude: t.exclude?.join(",")
            }
        });
    },
    async fetchFeaturedWallets () {
        const { featuredWalletIds: t } = T.state;
        if (t?.length) {
            const e = {
                ...W._getSdkProperties(),
                page: 1,
                entries: t?.length ?? pl,
                include: t
            }, { data: r } = await W.fetchWallets(e);
            r.sort((i, o)=>t.indexOf(i.id) - t.indexOf(o.id));
            const n = r.map((i)=>i.image_id).filter(Boolean);
            await Promise.allSettled(n.map((i)=>W._fetchWalletImage(i))), Ce.featured = r, Ce.allFeatured = r;
        }
    },
    async fetchRecommendedWallets () {
        try {
            Ce.isFetchingRecommendedWallets = !0;
            const { includeWalletIds: t, excludeWalletIds: e, featuredWalletIds: r } = T.state, n = [
                ...e ?? [],
                ...r ?? []
            ].filter(Boolean), i = f.getRequestedCaipNetworkIds().join(","), o = {
                page: 1,
                entries: pl,
                include: t,
                exclude: n,
                chains: i
            }, { data: s, count: a } = await W.fetchWallets(o), c = q.getRecentWallets(), l = s.map((u)=>u.image_id).filter(Boolean), d = c.map((u)=>u.image_id).filter(Boolean);
            await Promise.allSettled([
                ...l,
                ...d
            ].map((u)=>W._fetchWalletImage(u))), Ce.recommended = s, Ce.allRecommended = s, Ce.count = a ?? 0;
        } catch  {} finally{
            Ce.isFetchingRecommendedWallets = !1;
        }
    },
    async fetchWalletsByPage ({ page: t }) {
        const { includeWalletIds: e, excludeWalletIds: r, featuredWalletIds: n } = T.state, i = f.getRequestedCaipNetworkIds().join(","), o = [
            ...Ce.recommended.map(({ id: d })=>d),
            ...r ?? [],
            ...n ?? []
        ].filter(Boolean), s = {
            page: t,
            entries: g1,
            include: e,
            exclude: o,
            chains: i
        }, { data: a, count: c } = await W.fetchWallets(s), l = a.slice(0, w1).map((d)=>d.image_id).filter(Boolean);
        await Promise.allSettled(l.map((d)=>W._fetchWalletImage(d))), Ce.wallets = U.uniqueBy([
            ...Ce.wallets,
            ...W._filterOutExtensions(a)
        ], "id"), Ce.count = c > Ce.count ? c : Ce.count, Ce.page = t;
    },
    async initializeExcludedWallets ({ ids: t }) {
        const e = f.getRequestedCaipNetworkIds().join(","), r = {
            page: 1,
            entries: t.length,
            include: t,
            chains: e
        }, { data: n } = await W.fetchWallets(r);
        n && n.forEach((i)=>{
            Ce.excludedWallets.push({
                rdns: i.rdns,
                name: i.name
            });
        });
    },
    async searchWallet ({ search: t, badge: e }) {
        const { includeWalletIds: r, excludeWalletIds: n } = T.state, i = f.getRequestedCaipNetworkIds().join(",");
        Ce.search = [];
        const o = {
            page: 1,
            entries: 100,
            search: t?.trim(),
            badge_type: e,
            include: r,
            exclude: n,
            chains: i
        }, { data: s } = await W.fetchWallets(o);
        le.sendEvent({
            type: "track",
            event: "SEARCH_WALLET",
            properties: {
                badge: e ?? "",
                search: t ?? ""
            }
        });
        const a = s.map((c)=>c.image_id).filter(Boolean);
        await Promise.allSettled([
            ...a.map((c)=>W._fetchWalletImage(c)),
            U.wait(300)
        ]), Ce.search = W._filterOutExtensions(s);
    },
    initPromise (t, e) {
        const r = Ce.promises[t];
        return r || (Ce.promises[t] = e());
    },
    prefetch ({ fetchConnectorImages: t = !0, fetchFeaturedWallets: e = !0, fetchRecommendedWallets: r = !0, fetchNetworkImages: n = !0 } = {}) {
        const i = [
            t && W.initPromise("connectorImages", W.fetchConnectorImages),
            e && W.initPromise("featuredWallets", W.fetchFeaturedWallets),
            r && W.initPromise("recommendedWallets", W.fetchRecommendedWallets),
            n && W.initPromise("networkImages", W.fetchNetworkImages)
        ].filter(Boolean);
        return Promise.allSettled(i);
    },
    prefetchAnalyticsConfig () {
        T.state.features?.analytics && W.fetchAnalyticsConfig();
    },
    async fetchAnalyticsConfig () {
        try {
            const { isAnalyticsEnabled: t } = await ht.get({
                path: "/getAnalyticsConfig",
                params: W._getSdkProperties()
            });
            T.setFeatures({
                analytics: t
            });
        } catch  {
            T.setFeatures({
                analytics: !1
            });
        }
    },
    setFilterByNamespace (t) {
        if (!t) {
            Ce.featured = Ce.allFeatured, Ce.recommended = Ce.allRecommended;
            return;
        }
        const e = f.getRequestedCaipNetworkIds().join(",");
        Ce.featured = Ce.allFeatured.filter((r)=>r.chains?.some((n)=>e.includes(n))), Ce.recommended = Ce.allRecommended.filter((r)=>r.chains?.some((n)=>e.includes(n)));
    }
}, be = xe({
    view: "Connect",
    history: [
        "Connect"
    ],
    transactionStack: []
}), D = {
    state: be,
    subscribeKey (t, e) {
        return He(be, t, e);
    },
    pushTransactionStack (t) {
        be.transactionStack.push(t);
    },
    popTransactionStack (t) {
        const e = be.transactionStack.pop();
        if (e) if (t) this.goBack(), e?.onCancel?.();
        else {
            if (e.goBack) this.goBack();
            else if (e.replace) {
                const n = be.history.indexOf("ConnectingSiwe");
                n > 0 ? this.goBackToIndex(n - 1) : (he.close(), be.history = []);
            } else e.view && this.reset(e.view);
            e?.onSuccess?.();
        }
    },
    push (t, e) {
        t !== be.view && (be.view = t, be.history.push(t), be.data = e);
    },
    reset (t, e) {
        be.view = t, be.history = [
            t
        ], be.data = e;
    },
    replace (t, e) {
        be.history.at(-1) === t || (be.view = t, be.history[be.history.length - 1] = t, be.data = e);
    },
    goBack () {
        const t = !f.state.activeCaipAddress && this.state.view === "ConnectingFarcaster";
        if (be.history.length > 1 && !be.history.includes("UnsupportedChain")) {
            be.history.pop();
            const [e] = be.history.slice(-1);
            e && (be.view = e);
        } else he.close();
        be.data?.wallet && (be.data.wallet = void 0), setTimeout(()=>{
            if (t) {
                Q.setFarcasterUrl(void 0, f.state.activeChain);
                const e = j.getAuthConnector();
                e?.provider?.reload();
                const r = Hn(T.state);
                e?.provider?.syncDappData?.({
                    metadata: r.metadata,
                    sdkVersion: r.sdkVersion,
                    projectId: r.projectId,
                    sdkType: r.sdkType
                });
            }
        }, 100);
    },
    goBackToIndex (t) {
        if (be.history.length > 1) {
            be.history = be.history.slice(0, t + 1);
            const [e] = be.history.slice(-1);
            e && (be.view = e);
        }
    }
}, Dt = xe({
    themeMode: "dark",
    themeVariables: {},
    w3mThemeVariables: void 0
}), $e = {
    state: Dt,
    subscribe (t) {
        return We(Dt, ()=>t(Dt));
    },
    setThemeMode (t) {
        Dt.themeMode = t;
        try {
            const e = j.getAuthConnector();
            if (e) {
                const r = $e.getSnapshot().themeVariables;
                e.provider.syncTheme({
                    themeMode: t,
                    themeVariables: r,
                    w3mThemeVariables: ir(r, t)
                });
            }
        } catch  {
            console.info("Unable to sync theme to auth connector");
        }
    },
    setThemeVariables (t) {
        Dt.themeVariables = {
            ...Dt.themeVariables,
            ...t
        };
        try {
            const e = j.getAuthConnector();
            if (e) {
                const r = $e.getSnapshot().themeVariables;
                e.provider.syncTheme({
                    themeVariables: r,
                    w3mThemeVariables: ir(Dt.themeVariables, Dt.themeMode)
                });
            }
        } catch  {
            console.info("Unable to sync theme to auth connector");
        }
    },
    getSnapshot () {
        return Hn(Dt);
    }
}, fl = {
    eip155: void 0,
    solana: void 0,
    polkadot: void 0,
    bip122: void 0
}, ye = xe({
    allConnectors: [],
    connectors: [],
    activeConnector: void 0,
    filterByNamespace: void 0,
    activeConnectorIds: {
        ...fl
    }
}), j = {
    state: ye,
    subscribe (t) {
        return We(ye, ()=>{
            t(ye);
        });
    },
    subscribeKey (t, e) {
        return He(ye, t, e);
    },
    initialize (t) {
        t.forEach((e)=>{
            const r = q.getConnectedConnectorId(e);
            r && this.setConnectorId(r, e);
        });
    },
    setActiveConnector (t) {
        t && (ye.activeConnector = Ir(t));
    },
    setConnectors (t) {
        t.filter((r)=>!ye.allConnectors.some((n)=>n.id === r.id && this.getConnectorName(n.name) === this.getConnectorName(r.name) && n.chain === r.chain)).forEach((r)=>{
            r.type !== "MULTI_CHAIN" && ye.allConnectors.push(Ir(r));
        }), ye.connectors = this.mergeMultiChainConnectors(ye.allConnectors);
    },
    removeAdapter (t) {
        ye.allConnectors = ye.allConnectors.filter((e)=>e.chain !== t), ye.connectors = this.mergeMultiChainConnectors(ye.allConnectors);
    },
    mergeMultiChainConnectors (t) {
        const e = this.generateConnectorMapByName(t), r = [];
        return e.forEach((n)=>{
            const i = n[0], o = i?.id === G.CONNECTOR_ID.AUTH;
            n.length > 1 && i ? r.push({
                name: i.name,
                imageUrl: i.imageUrl,
                imageId: i.imageId,
                connectors: [
                    ...n
                ],
                type: o ? "AUTH" : "MULTI_CHAIN",
                chain: "eip155",
                id: i?.id || ""
            }) : i && r.push(i);
        }), r;
    },
    generateConnectorMapByName (t) {
        const e = new Map;
        return t.forEach((r)=>{
            const { name: n } = r, i = this.getConnectorName(n);
            if (!i) return;
            const o = e.get(i) || [];
            o.find((a)=>a.chain === r.chain) || o.push(r), e.set(i, o);
        }), e;
    },
    getConnectorName (t) {
        return t && (({
            "Trust Wallet": "Trust"
        })[t] || t);
    },
    getUniqueConnectorsByName (t) {
        const e = [];
        return t.forEach((r)=>{
            e.find((n)=>n.chain === r.chain) || e.push(r);
        }), e;
    },
    addConnector (t) {
        if (t.id === G.CONNECTOR_ID.AUTH) {
            const e = t, r = Hn(T.state), n = $e.getSnapshot().themeMode, i = $e.getSnapshot().themeVariables;
            e?.provider?.syncDappData?.({
                metadata: r.metadata,
                sdkVersion: r.sdkVersion,
                projectId: r.projectId,
                sdkType: r.sdkType
            }), e?.provider?.syncTheme({
                themeMode: n,
                themeVariables: i,
                w3mThemeVariables: ir(i, n)
            }), this.setConnectors([
                t
            ]);
        } else this.setConnectors([
            t
        ]);
    },
    getAuthConnector (t) {
        const e = t || f.state.activeChain, r = ye.connectors.find((n)=>n.id === G.CONNECTOR_ID.AUTH);
        if (r) return r?.connectors?.length ? r.connectors.find((i)=>i.chain === e) : r;
    },
    getAnnouncedConnectorRdns () {
        return ye.connectors.filter((t)=>t.type === "ANNOUNCED").map((t)=>t.info?.rdns);
    },
    getConnectorById (t) {
        return ye.allConnectors.find((e)=>e.id === t);
    },
    getConnector (t, e) {
        return ye.allConnectors.filter((n)=>n.chain === f.state.activeChain).find((n)=>n.explorerId === t || n.info?.rdns === e);
    },
    syncIfAuthConnector (t) {
        if (t.id !== "ID_AUTH") return;
        const e = t, r = Hn(T.state), n = $e.getSnapshot().themeMode, i = $e.getSnapshot().themeVariables;
        e?.provider?.syncDappData?.({
            metadata: r.metadata,
            sdkVersion: r.sdkVersion,
            sdkType: r.sdkType,
            projectId: r.projectId
        }), e.provider.syncTheme({
            themeMode: n,
            themeVariables: i,
            w3mThemeVariables: ir(i, n)
        });
    },
    getConnectorsByNamespace (t) {
        const e = ye.allConnectors.filter((r)=>r.chain === t);
        return this.mergeMultiChainConnectors(e);
    },
    selectWalletConnector (t) {
        const e = j.getConnector(t.id, t.rdns);
        f.state.activeChain === G.CHAIN.SOLANA && a1.handleSolanaDeeplinkRedirect(e?.name || t.name || ""), e ? D.push("ConnectingExternal", {
            connector: e
        }) : D.push("ConnectingWalletConnect", {
            wallet: t
        });
    },
    getConnectors (t) {
        return t ? this.getConnectorsByNamespace(t) : this.mergeMultiChainConnectors(ye.allConnectors);
    },
    setFilterByNamespace (t) {
        ye.filterByNamespace = t, ye.connectors = this.getConnectors(t), W.setFilterByNamespace(t);
    },
    setConnectorId (t, e) {
        t && (ye.activeConnectorIds = {
            ...ye.activeConnectorIds,
            [e]: t
        }, q.setConnectedConnectorId(e, t));
    },
    removeConnectorId (t) {
        ye.activeConnectorIds = {
            ...ye.activeConnectorIds,
            [t]: void 0
        }, q.deleteConnectedConnectorId(t);
    },
    getConnectorId (t) {
        if (t) return ye.activeConnectorIds[t];
    },
    isConnected (t) {
        return t ? !!ye.activeConnectorIds[t] : Object.values(ye.activeConnectorIds).some((e)=>!!e);
    },
    resetConnectorIds () {
        ye.activeConnectorIds = {
            ...fl
        };
    }
};
function Ao(t, e) {
    return j.getConnectorId(t) === e;
}
function m1(t) {
    const e = Array.from(f.state.chains.keys());
    let r = [];
    return t ? (r.push([
        t,
        f.state.chains.get(t)
    ]), Ao(t, G.CONNECTOR_ID.WALLET_CONNECT) ? e.forEach((n)=>{
        n !== t && Ao(n, G.CONNECTOR_ID.WALLET_CONNECT) && r.push([
            n,
            f.state.chains.get(n)
        ]);
    }) : Ao(t, G.CONNECTOR_ID.AUTH) && e.forEach((n)=>{
        n !== t && Ao(n, G.CONNECTOR_ID.AUTH) && r.push([
            n,
            f.state.chains.get(n)
        ]);
    })) : r = Array.from(f.state.chains.entries()), r;
}
const b1 = "https://secure.walletconnect.org/sdk";
typeof process < "u" && typeof process.env < "u" && process.env.NEXT_PUBLIC_SECURE_SITE_SDK_URL, typeof process < "u" && typeof process.env < "u" && process.env.NEXT_PUBLIC_DEFAULT_LOG_LEVEL, typeof process < "u" && typeof process.env < "u" && process.env.NEXT_PUBLIC_SECURE_SITE_SDK_VERSION;
const cr = {
    SAFE_RPC_METHODS: [
        "eth_accounts",
        "eth_blockNumber",
        "eth_call",
        "eth_chainId",
        "eth_estimateGas",
        "eth_feeHistory",
        "eth_gasPrice",
        "eth_getAccount",
        "eth_getBalance",
        "eth_getBlockByHash",
        "eth_getBlockByNumber",
        "eth_getBlockReceipts",
        "eth_getBlockTransactionCountByHash",
        "eth_getBlockTransactionCountByNumber",
        "eth_getCode",
        "eth_getFilterChanges",
        "eth_getFilterLogs",
        "eth_getLogs",
        "eth_getProof",
        "eth_getStorageAt",
        "eth_getTransactionByBlockHashAndIndex",
        "eth_getTransactionByBlockNumberAndIndex",
        "eth_getTransactionByHash",
        "eth_getTransactionCount",
        "eth_getTransactionReceipt",
        "eth_getUncleCountByBlockHash",
        "eth_getUncleCountByBlockNumber",
        "eth_maxPriorityFeePerGas",
        "eth_newBlockFilter",
        "eth_newFilter",
        "eth_newPendingTransactionFilter",
        "eth_sendRawTransaction",
        "eth_syncing",
        "eth_uninstallFilter",
        "wallet_getCapabilities",
        "wallet_getCallsStatus",
        "eth_getUserOperationReceipt",
        "eth_estimateUserOperationGas",
        "eth_getUserOperationByHash",
        "eth_supportedEntryPoints",
        "wallet_getAssets"
    ],
    NOT_SAFE_RPC_METHODS: [
        "personal_sign",
        "eth_signTypedData_v4",
        "eth_sendTransaction",
        "solana_signMessage",
        "solana_signTransaction",
        "solana_signAllTransactions",
        "solana_signAndSendTransaction",
        "wallet_sendCalls",
        "wallet_grantPermissions",
        "wallet_revokePermissions",
        "eth_sendUserOperation"
    ],
    GET_CHAIN_ID: "eth_chainId",
    RPC_METHOD_NOT_ALLOWED_MESSAGE: "Requested RPC call is not allowed",
    RPC_METHOD_NOT_ALLOWED_UI_MESSAGE: "Action not allowed",
    ACCOUNT_TYPES: {
        EOA: "eoa",
        SMART_ACCOUNT: "smartAccount"
    }
}, Nr = Object.freeze({
    message: "",
    variant: "success",
    svg: void 0,
    open: !1,
    autoClose: !0
}), Pe = xe({
    ...Nr
}), Ee = {
    state: Pe,
    subscribeKey (t, e) {
        return He(Pe, t, e);
    },
    showLoading (t, e = {}) {
        this._showMessage({
            message: t,
            variant: "loading",
            ...e
        });
    },
    showSuccess (t) {
        this._showMessage({
            message: t,
            variant: "success"
        });
    },
    showSvg (t, e) {
        this._showMessage({
            message: t,
            svg: e
        });
    },
    showError (t) {
        const e = U.parseError(t);
        this._showMessage({
            message: e,
            variant: "error"
        });
    },
    hide () {
        Pe.message = Nr.message, Pe.variant = Nr.variant, Pe.svg = Nr.svg, Pe.open = Nr.open, Pe.autoClose = Nr.autoClose;
    },
    _showMessage ({ message: t, svg: e, variant: r = "success", autoClose: n = Nr.autoClose }) {
        Pe.open ? (Pe.open = !1, setTimeout(()=>{
            Pe.message = t, Pe.variant = r, Pe.svg = e, Pe.open = !0, Pe.autoClose = n;
        }, 150)) : (Pe.message = t, Pe.variant = r, Pe.svg = e, Pe.open = !0, Pe.autoClose = n);
    }
}, lr = {
    getSIWX () {
        return T.state.siwx;
    },
    async initializeIfEnabled () {
        const t = T.state.siwx, e = f.getActiveCaipAddress();
        if (!(t && e)) return;
        const [r, n, i] = e.split(":");
        if (f.checkIfSupportedNetwork(r)) try {
            if ((await t.getSessions(`${r}:${n}`, i)).length) return;
            await he.open({
                view: "SIWXSignMessage"
            });
        } catch (o) {
            console.error("SIWXUtil:initializeIfEnabled", o), le.sendEvent({
                type: "track",
                event: "SIWX_AUTH_ERROR",
                properties: this.getSIWXEventProperties()
            }), await Y._getClient()?.disconnect().catch(console.error), D.reset("Connect"), Ee.showError("A problem occurred while trying initialize authentication");
        }
    },
    async requestSignMessage () {
        const t = T.state.siwx, e = U.getPlainAddress(f.getActiveCaipAddress()), r = f.getActiveCaipNetwork(), n = Y._getClient();
        if (!t) throw new Error("SIWX is not enabled");
        if (!e) throw new Error("No ActiveCaipAddress found");
        if (!r) throw new Error("No ActiveCaipNetwork or client found");
        if (!n) throw new Error("No ConnectionController client found");
        try {
            const i = await t.createMessage({
                chainId: r.caipNetworkId,
                accountAddress: e
            }), o = i.toString();
            j.getConnectorId(r.chainNamespace) === G.CONNECTOR_ID.AUTH && D.pushTransactionStack({
                view: null,
                goBack: !1,
                replace: !0
            });
            const a = await n.signMessage(o);
            await t.addSession({
                data: i,
                message: o,
                signature: a
            }), he.close(), le.sendEvent({
                type: "track",
                event: "SIWX_AUTH_SUCCESS",
                properties: this.getSIWXEventProperties()
            });
        } catch (i) {
            const o = this.getSIWXEventProperties();
            (!he.state.open || D.state.view === "ApproveTransaction") && await he.open({
                view: "SIWXSignMessage"
            }), o.isSmartAccount ? Ee.showError("This application might not support Smart Accounts") : Ee.showError("Signature declined"), le.sendEvent({
                type: "track",
                event: "SIWX_AUTH_ERROR",
                properties: o
            }), console.error("SWIXUtil:requestSignMessage", i);
        }
    },
    async cancelSignMessage () {
        try {
            this.getSIWX()?.getRequired?.() ? await Y.disconnect() : he.close(), D.reset("Connect"), le.sendEvent({
                event: "CLICK_CANCEL_SIWX",
                type: "track",
                properties: this.getSIWXEventProperties()
            });
        } catch (t) {
            console.error("SIWXUtil:cancelSignMessage", t);
        }
    },
    async getSessions () {
        const t = T.state.siwx, e = U.getPlainAddress(f.getActiveCaipAddress()), r = f.getActiveCaipNetwork();
        return t && e && r ? t.getSessions(r.caipNetworkId, e) : [];
    },
    async isSIWXCloseDisabled () {
        const t = this.getSIWX();
        if (t) {
            const e = D.state.view === "ApproveTransaction", r = D.state.view === "SIWXSignMessage";
            if (e || r) return t.getRequired?.() && (await this.getSessions()).length === 0;
        }
        return !1;
    },
    async universalProviderAuthenticate ({ universalProvider: t, chains: e, methods: r }) {
        const n = lr.getSIWX(), i = new Set(e.map((a)=>a.split(":")[0]));
        if (!n || i.size !== 1 || !i.has("eip155")) return !1;
        const o = await n.createMessage({
            chainId: f.getActiveCaipNetwork()?.caipNetworkId || "",
            accountAddress: ""
        }), s = await t.authenticate({
            nonce: o.nonce,
            domain: o.domain,
            uri: o.uri,
            exp: o.expirationTime,
            iat: o.issuedAt,
            nbf: o.notBefore,
            requestId: o.requestId,
            version: o.version,
            resources: o.resources,
            statement: o.statement,
            chainId: o.chainId,
            methods: r,
            chains: [
                o.chainId,
                ...e.filter((a)=>a !== o.chainId)
            ]
        });
        if (Ee.showLoading("Authenticating...", {
            autoClose: !1
        }), Q.setConnectedWalletInfo({
            ...s.session.peer.metadata,
            name: s.session.peer.metadata.name,
            icon: s.session.peer.metadata.icons?.[0],
            type: "WALLET_CONNECT"
        }, Array.from(i)[0]), s?.auths?.length) {
            const a = s.auths.map((c)=>{
                const l = t.client.formatAuthMessage({
                    request: c.p,
                    iss: c.p.iss
                });
                return {
                    data: {
                        ...c.p,
                        accountAddress: c.p.iss.split(":").slice(-1).join(""),
                        chainId: c.p.iss.split(":").slice(2, 4).join(":"),
                        uri: c.p.aud,
                        version: c.p.version || o.version,
                        expirationTime: c.p.exp,
                        issuedAt: c.p.iat,
                        notBefore: c.p.nbf
                    },
                    message: l,
                    signature: c.s.s,
                    cacao: c
                };
            });
            try {
                await n.setSessions(a), le.sendEvent({
                    type: "track",
                    event: "SIWX_AUTH_SUCCESS",
                    properties: lr.getSIWXEventProperties()
                });
            } catch (c) {
                throw console.error("SIWX:universalProviderAuth - failed to set sessions", c), le.sendEvent({
                    type: "track",
                    event: "SIWX_AUTH_ERROR",
                    properties: lr.getSIWXEventProperties()
                }), await t.disconnect().catch(console.error), c;
            } finally{
                Ee.hide();
            }
        }
        return !0;
    },
    getSIWXEventProperties () {
        const t = f.state.activeChain;
        return {
            network: f.state.activeCaipNetwork?.caipNetworkId || "",
            isSmartAccount: Q.state.preferredAccountTypes?.[t] === cr.ACCOUNT_TYPES.SMART_ACCOUNT
        };
    },
    async clearSessions () {
        const t = this.getSIWX();
        t && await t.setSessions([]);
    }
}, Ae = xe({
    transactions: [],
    coinbaseTransactions: {},
    transactionsByYear: {},
    lastNetworkInView: void 0,
    loading: !1,
    empty: !1,
    next: void 0
}), v1 = {
    state: Ae,
    subscribe (t) {
        return We(Ae, ()=>t(Ae));
    },
    setLastNetworkInView (t) {
        Ae.lastNetworkInView = t;
    },
    async fetchTransactions (t, e) {
        if (!t) throw new Error("Transactions can't be fetched without an accountAddress");
        Ae.loading = !0;
        try {
            const r = await oe.fetchTransactions({
                account: t,
                cursor: Ae.next,
                onramp: e,
                cache: e === "coinbase" ? "no-cache" : void 0,
                chainId: f.state.activeCaipNetwork?.caipNetworkId
            }), n = this.filterSpamTransactions(r.data), i = this.filterByConnectedChain(n), o = [
                ...Ae.transactions,
                ...i
            ];
            Ae.loading = !1, e === "coinbase" ? Ae.coinbaseTransactions = this.groupTransactionsByYearAndMonth(Ae.coinbaseTransactions, r.data) : (Ae.transactions = o, Ae.transactionsByYear = this.groupTransactionsByYearAndMonth(Ae.transactionsByYear, i)), Ae.empty = o.length === 0, Ae.next = r.next ? r.next : void 0;
        } catch  {
            const n = f.state.activeChain;
            le.sendEvent({
                type: "track",
                event: "ERROR_FETCH_TRANSACTIONS",
                properties: {
                    address: t,
                    projectId: T.state.projectId,
                    cursor: Ae.next,
                    isSmartAccount: Q.state.preferredAccountTypes?.[n] === cr.ACCOUNT_TYPES.SMART_ACCOUNT
                }
            }), Ee.showError("Failed to fetch transactions"), Ae.loading = !1, Ae.empty = !0, Ae.next = void 0;
        }
    },
    groupTransactionsByYearAndMonth (t = {}, e = []) {
        const r = t;
        return e.forEach((n)=>{
            const i = new Date(n.metadata.minedAt).getFullYear(), o = new Date(n.metadata.minedAt).getMonth(), s = r[i] ?? {}, c = (s[o] ?? []).filter((l)=>l.id !== n.id);
            r[i] = {
                ...s,
                [o]: [
                    ...c,
                    n
                ].sort((l, d)=>new Date(d.metadata.minedAt).getTime() - new Date(l.metadata.minedAt).getTime())
            };
        }), r;
    },
    filterSpamTransactions (t) {
        return t.filter((e)=>!e.transfers.every((n)=>n.nft_info?.flags.is_spam === !0));
    },
    filterByConnectedChain (t) {
        const e = f.state.activeCaipNetwork?.caipNetworkId;
        return t.filter((n)=>n.metadata.chain === e);
    },
    clearCursor () {
        Ae.next = void 0;
    },
    resetTransactions () {
        Ae.transactions = [], Ae.transactionsByYear = {}, Ae.lastNetworkInView = void 0, Ae.loading = !1, Ae.empty = !1, Ae.next = void 0;
    }
}, Se = xe({
    wcError: !1,
    buffering: !1,
    status: "disconnected"
});
let rn;
const Y = {
    state: Se,
    subscribeKey (t, e) {
        return He(Se, t, e);
    },
    _getClient () {
        return Se._client;
    },
    setClient (t) {
        Se._client = Ir(t);
    },
    async connectWalletConnect () {
        if (U.isTelegram() || U.isSafari() && U.isIos()) {
            if (rn) {
                await rn, rn = void 0;
                return;
            }
            if (!U.isPairingExpired(Se?.wcPairingExpiry)) {
                const t = Se.wcUri;
                Se.wcUri = t;
                return;
            }
            rn = this._getClient()?.connectWalletConnect?.().catch(()=>{}), this.state.status = "connecting", await rn, rn = void 0, Se.wcPairingExpiry = void 0, this.state.status = "connected";
        } else await this._getClient()?.connectWalletConnect?.();
    },
    async connectExternal (t, e, r = !0) {
        await this._getClient()?.connectExternal?.(t), r && f.setActiveNamespace(e);
    },
    async reconnectExternal (t) {
        await this._getClient()?.reconnectExternal?.(t);
        const e = t.chain || f.state.activeChain;
        e && j.setConnectorId(t.id, e);
    },
    async setPreferredAccountType (t, e) {
        he.setLoading(!0, f.state.activeChain);
        const r = j.getAuthConnector();
        r && (Q.setPreferredAccountType(t, e), await r.provider.setPreferredAccount(t), q.setPreferredAccountTypes(Q.state.preferredAccountTypes ?? {
            [e]: t
        }), await this.reconnectExternal(r), he.setLoading(!1, f.state.activeChain), le.sendEvent({
            type: "track",
            event: "SET_PREFERRED_ACCOUNT_TYPE",
            properties: {
                accountType: t,
                network: f.state.activeCaipNetwork?.caipNetworkId || ""
            }
        }));
    },
    async signMessage (t) {
        return this._getClient()?.signMessage(t);
    },
    parseUnits (t, e) {
        return this._getClient()?.parseUnits(t, e);
    },
    formatUnits (t, e) {
        return this._getClient()?.formatUnits(t, e);
    },
    async sendTransaction (t) {
        return this._getClient()?.sendTransaction(t);
    },
    async getCapabilities (t) {
        return this._getClient()?.getCapabilities(t);
    },
    async grantPermissions (t) {
        return this._getClient()?.grantPermissions(t);
    },
    async walletGetAssets (t) {
        return this._getClient()?.walletGetAssets(t) ?? {};
    },
    async estimateGas (t) {
        return this._getClient()?.estimateGas(t);
    },
    async writeContract (t) {
        return this._getClient()?.writeContract(t);
    },
    async getEnsAddress (t) {
        return this._getClient()?.getEnsAddress(t);
    },
    async getEnsAvatar (t) {
        return this._getClient()?.getEnsAvatar(t);
    },
    checkInstalled (t) {
        return this._getClient()?.checkInstalled?.(t) || !1;
    },
    resetWcConnection () {
        Se.wcUri = void 0, Se.wcPairingExpiry = void 0, Se.wcLinking = void 0, Se.recentWallet = void 0, Se.status = "disconnected", v1.resetTransactions(), q.deleteWalletConnectDeepLink();
    },
    resetUri () {
        Se.wcUri = void 0, Se.wcPairingExpiry = void 0;
    },
    finalizeWcConnection () {
        const { wcLinking: t, recentWallet: e } = Y.state;
        t && q.setWalletConnectDeepLink(t), e && q.setAppKitRecent(e), le.sendEvent({
            type: "track",
            event: "CONNECT_SUCCESS",
            properties: {
                method: t ? "mobile" : "qrcode",
                name: D.state.data?.wallet?.name || "Unknown"
            }
        });
    },
    setWcBasic (t) {
        Se.wcBasic = t;
    },
    setUri (t) {
        Se.wcUri = t, Se.wcPairingExpiry = U.getPairingExpiry();
    },
    setWcLinking (t) {
        Se.wcLinking = t;
    },
    setWcError (t) {
        Se.wcError = t, Se.buffering = !1;
    },
    setRecentWallet (t) {
        Se.recentWallet = t;
    },
    setBuffering (t) {
        Se.buffering = t;
    },
    setStatus (t) {
        Se.status = t;
    },
    async disconnect (t) {
        try {
            he.setLoading(!0, t), await lr.clearSessions(), await f.disconnect(t), he.setLoading(!1, t), j.setFilterByNamespace(void 0);
        } catch  {
            throw new Error("Failed to disconnect");
        }
    }
}, nn = xe({
    loading: !1,
    open: !1,
    selectedNetworkId: void 0,
    activeChain: void 0,
    initialized: !1
}), zt = {
    state: nn,
    subscribe (t) {
        return We(nn, ()=>t(nn));
    },
    subscribeOpen (t) {
        return He(nn, "open", t);
    },
    set (t) {
        Object.assign(nn, {
            ...nn,
            ...t
        });
    }
};
function Zn(t, { strict: e = !0 } = {}) {
    return !t || typeof t != "string" ? !1 : e ? /^0x[0-9a-fA-F]*$/.test(t) : t.startsWith("0x");
}
function dr(t) {
    return Zn(t, {
        strict: !1
    }) ? Math.ceil((t.length - 2) / 2) : t.length;
}
const gl = "2.27.0";
let ma = {
    getDocsUrl: ({ docsBaseUrl: t, docsPath: e = "", docsSlug: r })=>e ? `${t ?? "https://viem.sh"}${e}${r ? `#${r}` : ""}` : void 0,
    version: `viem@${gl}`
};
class de extends Error {
    constructor(e, r = {}){
        const n = r.cause instanceof de ? r.cause.details : r.cause?.message ? r.cause.message : r.details, i = r.cause instanceof de && r.cause.docsPath || r.docsPath, o = ma.getDocsUrl?.({
            ...r,
            docsPath: i
        }), s = [
            e || "An error occurred.",
            "",
            ...r.metaMessages ? [
                ...r.metaMessages,
                ""
            ] : [],
            ...o ? [
                `Docs: ${o}`
            ] : [],
            ...n ? [
                `Details: ${n}`
            ] : [],
            ...ma.version ? [
                `Version: ${ma.version}`
            ] : []
        ].join(`
`);
        super(s, r.cause ? {
            cause: r.cause
        } : void 0), Object.defineProperty(this, "details", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "docsPath", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "metaMessages", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "shortMessage", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "version", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "name", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: "BaseError"
        }), this.details = n, this.docsPath = i, this.metaMessages = r.metaMessages, this.name = r.name ?? this.name, this.shortMessage = e, this.version = gl;
    }
    walk(e) {
        return wl(this, e);
    }
}
function wl(t, e) {
    return e?.(t) ? t : t && typeof t == "object" && "cause" in t && t.cause !== void 0 ? wl(t.cause, e) : e ? null : t;
}
class ml extends de {
    constructor({ offset: e, position: r, size: n }){
        super(`Slice ${r === "start" ? "starting" : "ending"} at offset "${e}" is out-of-bounds (size: ${n}).`, {
            name: "SliceOffsetOutOfBoundsError"
        });
    }
}
class bl extends de {
    constructor({ size: e, targetSize: r, type: n }){
        super(`${n.charAt(0).toUpperCase()}${n.slice(1).toLowerCase()} size (${e}) exceeds padding size (${r}).`, {
            name: "SizeExceedsPaddingSizeError"
        });
    }
}
function on(t, { dir: e, size: r = 32 } = {}) {
    return typeof t == "string" ? C1(t, {
        dir: e,
        size: r
    }) : y1(t, {
        dir: e,
        size: r
    });
}
function C1(t, { dir: e, size: r = 32 } = {}) {
    if (r === null) return t;
    const n = t.replace("0x", "");
    if (n.length > r * 2) throw new bl({
        size: Math.ceil(n.length / 2),
        targetSize: r,
        type: "hex"
    });
    return `0x${n[e === "right" ? "padEnd" : "padStart"](r * 2, "0")}`;
}
function y1(t, { dir: e, size: r = 32 } = {}) {
    if (r === null) return t;
    if (t.length > r) throw new bl({
        size: t.length,
        targetSize: r,
        type: "bytes"
    });
    const n = new Uint8Array(r);
    for(let i = 0; i < r; i++){
        const o = e === "right";
        n[o ? i : r - i - 1] = t[o ? i : t.length - i - 1];
    }
    return n;
}
class x1 extends de {
    constructor({ max: e, min: r, signed: n, size: i, value: o }){
        super(`Number "${o}" is not in safe ${i ? `${i * 8}-bit ${n ? "signed" : "unsigned"} ` : ""}integer range ${e ? `(${r} to ${e})` : `(above ${r})`}`, {
            name: "IntegerOutOfRangeError"
        });
    }
}
class E1 extends de {
    constructor({ givenSize: e, maxSize: r }){
        super(`Size cannot exceed ${r} bytes. Given size: ${e} bytes.`, {
            name: "SizeOverflowError"
        });
    }
}
function sn(t, { dir: e = "left" } = {}) {
    let r = typeof t == "string" ? t.replace("0x", "") : t, n = 0;
    for(let i = 0; i < r.length - 1 && r[e === "left" ? i : r.length - i - 1].toString() === "0"; i++)n++;
    return r = e === "left" ? r.slice(n) : r.slice(0, r.length - n), typeof t == "string" ? (r.length === 1 && e === "right" && (r = `${r}0`), `0x${r.length % 2 === 1 ? `0${r}` : r}`) : r;
}
function an(t, { size: e }) {
    if (dr(t) > e) throw new E1({
        givenSize: dr(t),
        maxSize: e
    });
}
function Wt(t, e = {}) {
    const { signed: r } = e;
    e.size && an(t, {
        size: e.size
    });
    const n = BigInt(t);
    if (!r) return n;
    const i = (t.length - 2) / 2, o = (1n << BigInt(i) * 8n - 1n) - 1n;
    return n <= o ? n : n - BigInt(`0x${"f".padStart(i * 2, "f")}`) - 1n;
}
function So(t, e = {}) {
    return Number(Wt(t, e));
}
const A1 = Array.from({
    length: 256
}, (t, e)=>e.toString(16).padStart(2, "0"));
function ie(t, e = {}) {
    return typeof t == "number" || typeof t == "bigint" ? Ve(t, e) : typeof t == "string" ? vl(t, e) : typeof t == "boolean" ? S1(t, e) : jt(t, e);
}
function S1(t, e = {}) {
    const r = `0x${Number(t)}`;
    return typeof e.size == "number" ? (an(r, {
        size: e.size
    }), on(r, {
        size: e.size
    })) : r;
}
function jt(t, e = {}) {
    let r = "";
    for(let i = 0; i < t.length; i++)r += A1[t[i]];
    const n = `0x${r}`;
    return typeof e.size == "number" ? (an(n, {
        size: e.size
    }), on(n, {
        dir: "right",
        size: e.size
    })) : n;
}
function Ve(t, e = {}) {
    const { signed: r, size: n } = e, i = BigInt(t);
    let o;
    n ? r ? o = (1n << BigInt(n) * 8n - 1n) - 1n : o = 2n ** (BigInt(n) * 8n) - 1n : typeof t == "number" && (o = BigInt(Number.MAX_SAFE_INTEGER));
    const s = typeof o == "bigint" && r ? -o - 1n : 0;
    if (o && i > o || i < s) {
        const c = typeof t == "bigint" ? "n" : "";
        throw new x1({
            max: o ? `${o}${c}` : void 0,
            min: `${s}${c}`,
            signed: r,
            size: n,
            value: `${t}${c}`
        });
    }
    const a = `0x${(r && i < 0 ? (1n << BigInt(n * 8)) + BigInt(i) : i).toString(16)}`;
    return n ? on(a, {
        size: n
    }) : a;
}
const _1 = new TextEncoder;
function vl(t, e = {}) {
    const r = _1.encode(t);
    return jt(r, e);
}
const I1 = new TextEncoder;
function Cl(t, e = {}) {
    return typeof t == "number" || typeof t == "bigint" ? k1(t, e) : typeof t == "boolean" ? N1(t, e) : Zn(t) ? kr(t, e) : xl(t, e);
}
function N1(t, e = {}) {
    const r = new Uint8Array(1);
    return r[0] = Number(t), typeof e.size == "number" ? (an(r, {
        size: e.size
    }), on(r, {
        size: e.size
    })) : r;
}
const Ft = {
    zero: 48,
    nine: 57,
    A: 65,
    F: 70,
    a: 97,
    f: 102
};
function yl(t) {
    if (t >= Ft.zero && t <= Ft.nine) return t - Ft.zero;
    if (t >= Ft.A && t <= Ft.F) return t - (Ft.A - 10);
    if (t >= Ft.a && t <= Ft.f) return t - (Ft.a - 10);
}
function kr(t, e = {}) {
    let r = t;
    e.size && (an(r, {
        size: e.size
    }), r = on(r, {
        dir: "right",
        size: e.size
    }));
    let n = r.slice(2);
    n.length % 2 && (n = `0${n}`);
    const i = n.length / 2, o = new Uint8Array(i);
    for(let s = 0, a = 0; s < i; s++){
        const c = yl(n.charCodeAt(a++)), l = yl(n.charCodeAt(a++));
        if (c === void 0 || l === void 0) throw new de(`Invalid byte sequence ("${n[a - 2]}${n[a - 1]}" in "${n}").`);
        o[s] = c * 16 + l;
    }
    return o;
}
function k1(t, e) {
    const r = Ve(t, e);
    return kr(r);
}
function xl(t, e = {}) {
    const r = I1.encode(t);
    return typeof e.size == "number" ? (an(r, {
        size: e.size
    }), on(r, {
        dir: "right",
        size: e.size
    })) : r;
}
function _o(t) {
    if (!Number.isSafeInteger(t) || t < 0) throw new Error("positive integer expected, got " + t);
}
function T1(t) {
    return t instanceof Uint8Array || ArrayBuffer.isView(t) && t.constructor.name === "Uint8Array";
}
function Gn(t, ...e) {
    if (!T1(t)) throw new Error("Uint8Array expected");
    if (e.length > 0 && !e.includes(t.length)) throw new Error("Uint8Array expected of length " + e + ", got length=" + t.length);
}
function O1(t) {
    if (typeof t != "function" || typeof t.create != "function") throw new Error("Hash should be wrapped by utils.wrapConstructor");
    _o(t.outputLen), _o(t.blockLen);
}
function cn(t, e = !0) {
    if (t.destroyed) throw new Error("Hash instance has been destroyed");
    if (e && t.finished) throw new Error("Hash#digest() has already been called");
}
function El(t, e) {
    Gn(t);
    const r = e.outputLen;
    if (t.length < r) throw new Error("digestInto() expects output buffer of length at least " + r);
}
const Io = BigInt(2 ** 32 - 1), Al = BigInt(32);
function $1(t, e = !1) {
    return e ? {
        h: Number(t & Io),
        l: Number(t >> Al & Io)
    } : {
        h: Number(t >> Al & Io) | 0,
        l: Number(t & Io) | 0
    };
}
function P1(t, e = !1) {
    let r = new Uint32Array(t.length), n = new Uint32Array(t.length);
    for(let i = 0; i < t.length; i++){
        const { h: o, l: s } = $1(t[i], e);
        [r[i], n[i]] = [
            o,
            s
        ];
    }
    return [
        r,
        n
    ];
}
const B1 = (t, e, r)=>t << r | e >>> 32 - r, R1 = (t, e, r)=>e << r | t >>> 32 - r, L1 = (t, e, r)=>e << r - 32 | t >>> 64 - r, U1 = (t, e, r)=>t << r - 32 | e >>> 64 - r, ln = typeof globalThis == "object" && "crypto" in globalThis ? globalThis.crypto : void 0;
function M1(t) {
    return new Uint32Array(t.buffer, t.byteOffset, Math.floor(t.byteLength / 4));
}
function ba(t) {
    return new DataView(t.buffer, t.byteOffset, t.byteLength);
}
function Tt(t, e) {
    return t << 32 - e | t >>> e;
}
const Sl = new Uint8Array(new Uint32Array([
    287454020
]).buffer)[0] === 68;
function D1(t) {
    return t << 24 & 4278190080 | t << 8 & 16711680 | t >>> 8 & 65280 | t >>> 24 & 255;
}
function _l(t) {
    for(let e = 0; e < t.length; e++)t[e] = D1(t[e]);
}
function z1(t) {
    if (typeof t != "string") throw new Error("utf8ToBytes expected string, got " + typeof t);
    return new Uint8Array(new TextEncoder().encode(t));
}
function No(t) {
    return typeof t == "string" && (t = z1(t)), Gn(t), t;
}
function W1(...t) {
    let e = 0;
    for(let n = 0; n < t.length; n++){
        const i = t[n];
        Gn(i), e += i.length;
    }
    const r = new Uint8Array(e);
    for(let n = 0, i = 0; n < t.length; n++){
        const o = t[n];
        r.set(o, i), i += o.length;
    }
    return r;
}
class va {
    clone() {
        return this._cloneInto();
    }
}
function Il(t) {
    const e = (n)=>t().update(No(n)).digest(), r = t();
    return e.outputLen = r.outputLen, e.blockLen = r.blockLen, e.create = ()=>t(), e;
}
function j1(t = 32) {
    if (ln && typeof ln.getRandomValues == "function") return ln.getRandomValues(new Uint8Array(t));
    if (ln && typeof ln.randomBytes == "function") return ln.randomBytes(t);
    throw new Error("crypto.getRandomValues must be defined");
}
const Nl = [], kl = [], Tl = [], F1 = BigInt(0), qn = BigInt(1), H1 = BigInt(2), V1 = BigInt(7), Z1 = BigInt(256), G1 = BigInt(113);
for(let t = 0, e = qn, r = 1, n = 0; t < 24; t++){
    [r, n] = [
        n,
        (2 * r + 3 * n) % 5
    ], Nl.push(2 * (5 * n + r)), kl.push((t + 1) * (t + 2) / 2 % 64);
    let i = F1;
    for(let o = 0; o < 7; o++)e = (e << qn ^ (e >> V1) * G1) % Z1, e & H1 && (i ^= qn << (qn << BigInt(o)) - qn);
    Tl.push(i);
}
const [q1, K1] = P1(Tl, !0), Ol = (t, e, r)=>r > 32 ? L1(t, e, r) : B1(t, e, r), $l = (t, e, r)=>r > 32 ? U1(t, e, r) : R1(t, e, r);
function Y1(t, e = 24) {
    const r = new Uint32Array(10);
    for(let n = 24 - e; n < 24; n++){
        for(let s = 0; s < 10; s++)r[s] = t[s] ^ t[s + 10] ^ t[s + 20] ^ t[s + 30] ^ t[s + 40];
        for(let s = 0; s < 10; s += 2){
            const a = (s + 8) % 10, c = (s + 2) % 10, l = r[c], d = r[c + 1], u = Ol(l, d, 1) ^ r[a], h = $l(l, d, 1) ^ r[a + 1];
            for(let p = 0; p < 50; p += 10)t[s + p] ^= u, t[s + p + 1] ^= h;
        }
        let i = t[2], o = t[3];
        for(let s = 0; s < 24; s++){
            const a = kl[s], c = Ol(i, o, a), l = $l(i, o, a), d = Nl[s];
            i = t[d], o = t[d + 1], t[d] = c, t[d + 1] = l;
        }
        for(let s = 0; s < 50; s += 10){
            for(let a = 0; a < 10; a++)r[a] = t[s + a];
            for(let a = 0; a < 10; a++)t[s + a] ^= ~r[(a + 2) % 10] & r[(a + 4) % 10];
        }
        t[0] ^= q1[n], t[1] ^= K1[n];
    }
    r.fill(0);
}
class Xc extends va {
    constructor(e, r, n, i = !1, o = 24){
        if (super(), this.blockLen = e, this.suffix = r, this.outputLen = n, this.enableXOF = i, this.rounds = o, this.pos = 0, this.posOut = 0, this.finished = !1, this.destroyed = !1, _o(n), 0 >= this.blockLen || this.blockLen >= 200) throw new Error("Sha3 supports only keccak-f1600 function");
        this.state = new Uint8Array(200), this.state32 = M1(this.state);
    }
    keccak() {
        Sl || _l(this.state32), Y1(this.state32, this.rounds), Sl || _l(this.state32), this.posOut = 0, this.pos = 0;
    }
    update(e) {
        cn(this);
        const { blockLen: r, state: n } = this;
        e = No(e);
        const i = e.length;
        for(let o = 0; o < i;){
            const s = Math.min(r - this.pos, i - o);
            for(let a = 0; a < s; a++)n[this.pos++] ^= e[o++];
            this.pos === r && this.keccak();
        }
        return this;
    }
    finish() {
        if (this.finished) return;
        this.finished = !0;
        const { state: e, suffix: r, pos: n, blockLen: i } = this;
        e[n] ^= r, (r & 128) !== 0 && n === i - 1 && this.keccak(), e[i - 1] ^= 128, this.keccak();
    }
    writeInto(e) {
        cn(this, !1), Gn(e), this.finish();
        const r = this.state, { blockLen: n } = this;
        for(let i = 0, o = e.length; i < o;){
            this.posOut >= n && this.keccak();
            const s = Math.min(n - this.posOut, o - i);
            e.set(r.subarray(this.posOut, this.posOut + s), i), this.posOut += s, i += s;
        }
        return e;
    }
    xofInto(e) {
        if (!this.enableXOF) throw new Error("XOF is not possible for this instance");
        return this.writeInto(e);
    }
    xof(e) {
        return _o(e), this.xofInto(new Uint8Array(e));
    }
    digestInto(e) {
        if (El(e, this), this.finished) throw new Error("digest() was already called");
        return this.writeInto(e), this.destroy(), e;
    }
    digest() {
        return this.digestInto(new Uint8Array(this.outputLen));
    }
    destroy() {
        this.destroyed = !0, this.state.fill(0);
    }
    _cloneInto(e) {
        const { blockLen: r, suffix: n, outputLen: i, rounds: o, enableXOF: s } = this;
        return e || (e = new Xc(r, n, i, s, o)), e.state32.set(this.state32), e.pos = this.pos, e.posOut = this.posOut, e.finished = this.finished, e.rounds = o, e.suffix = n, e.outputLen = i, e.enableXOF = s, e.destroyed = this.destroyed, e;
    }
}
const X1 = (t, e, r)=>Il(()=>new Xc(e, t, r)), Pl = X1(1, 136, 256 / 8);
function J1(t, e) {
    const r = e || "hex", n = Pl(Zn(t, {
        strict: !1
    }) ? Cl(t) : t);
    return r === "bytes" ? n : ie(n);
}
class ur extends de {
    constructor({ address: e }){
        super(`Address "${e}" is invalid.`, {
            metaMessages: [
                "- Address must be a hex value of 20 bytes (40 hex characters).",
                "- Address must match its checksum counterpart."
            ],
            name: "InvalidAddressError"
        });
    }
}
class ko extends Map {
    constructor(e){
        super(), Object.defineProperty(this, "maxSize", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.maxSize = e;
    }
    get(e) {
        const r = super.get(e);
        return super.has(e) && r !== void 0 && (this.delete(e), super.set(e, r)), r;
    }
    set(e, r) {
        if (super.set(e, r), this.maxSize && this.size > this.maxSize) {
            const n = this.keys().next().value;
            n && this.delete(n);
        }
        return this;
    }
}
const Ca = new ko(8192);
function Q1(t, e) {
    if (Ca.has(`${t}.${e}`)) return Ca.get(`${t}.${e}`);
    const r = e ? `${e}${t.toLowerCase()}` : t.substring(2).toLowerCase(), n = J1(xl(r), "bytes"), i = (e ? r.substring(`${e}0x`.length) : r).split("");
    for(let s = 0; s < 40; s += 2)n[s >> 1] >> 4 >= 8 && i[s] && (i[s] = i[s].toUpperCase()), (n[s >> 1] & 15) >= 8 && i[s + 1] && (i[s + 1] = i[s + 1].toUpperCase());
    const o = `0x${i.join("")}`;
    return Ca.set(`${t}.${e}`, o), o;
}
const eh = /^0x[a-fA-F0-9]{40}$/, ya = new ko(8192);
function Ht(t, e) {
    const { strict: r = !0 } = e ?? {}, n = `${t}.${r}`;
    if (ya.has(n)) return ya.get(n);
    const i = eh.test(t) ? t.toLowerCase() === t ? !0 : r ? Q1(t) === t : !0 : !1;
    return ya.set(n, i), i;
}
function dn(t) {
    return `0x${t.reduce((e, r)=>e + r.replace("0x", ""), "")}`;
}
function th(t, e, r, { strict: n } = {}) {
    return Zn(t, {
        strict: !1
    }) ? nh(t, e, r, {
        strict: n
    }) : rh(t, e, r, {
        strict: n
    });
}
function Bl(t, e) {
    if (typeof e == "number" && e > 0 && e > dr(t) - 1) throw new ml({
        offset: e,
        position: "start",
        size: dr(t)
    });
}
function Rl(t, e, r) {
    if (typeof e == "number" && typeof r == "number" && dr(t) !== r - e) throw new ml({
        offset: r,
        position: "end",
        size: dr(t)
    });
}
function rh(t, e, r, { strict: n } = {}) {
    Bl(t, e);
    const i = t.slice(e, r);
    return n && Rl(i, e, r), i;
}
function nh(t, e, r, { strict: n } = {}) {
    Bl(t, e);
    const i = `0x${t.replace("0x", "").slice((e ?? 0) * 2, (r ?? t.length) * 2)}`;
    return n && Rl(i, e, r), i;
}
class Ll extends de {
    constructor({ offset: e }){
        super(`Offset \`${e}\` cannot be negative.`, {
            name: "NegativeOffsetError"
        });
    }
}
class ih extends de {
    constructor({ length: e, position: r }){
        super(`Position \`${r}\` is out of bounds (\`0 < position < ${e}\`).`, {
            name: "PositionOutOfBoundsError"
        });
    }
}
class oh extends de {
    constructor({ count: e, limit: r }){
        super(`Recursive read limit of \`${r}\` exceeded (recursive read count: \`${e}\`).`, {
            name: "RecursiveReadLimitExceededError"
        });
    }
}
const sh = {
    bytes: new Uint8Array,
    dataView: new DataView(new ArrayBuffer(0)),
    position: 0,
    positionReadCount: new Map,
    recursiveReadCount: 0,
    recursiveReadLimit: Number.POSITIVE_INFINITY,
    assertReadLimit () {
        if (this.recursiveReadCount >= this.recursiveReadLimit) throw new oh({
            count: this.recursiveReadCount + 1,
            limit: this.recursiveReadLimit
        });
    },
    assertPosition (t) {
        if (t < 0 || t > this.bytes.length - 1) throw new ih({
            length: this.bytes.length,
            position: t
        });
    },
    decrementPosition (t) {
        if (t < 0) throw new Ll({
            offset: t
        });
        const e = this.position - t;
        this.assertPosition(e), this.position = e;
    },
    getReadCount (t) {
        return this.positionReadCount.get(t || this.position) || 0;
    },
    incrementPosition (t) {
        if (t < 0) throw new Ll({
            offset: t
        });
        const e = this.position + t;
        this.assertPosition(e), this.position = e;
    },
    inspectByte (t) {
        const e = t ?? this.position;
        return this.assertPosition(e), this.bytes[e];
    },
    inspectBytes (t, e) {
        const r = e ?? this.position;
        return this.assertPosition(r + t - 1), this.bytes.subarray(r, r + t);
    },
    inspectUint8 (t) {
        const e = t ?? this.position;
        return this.assertPosition(e), this.bytes[e];
    },
    inspectUint16 (t) {
        const e = t ?? this.position;
        return this.assertPosition(e + 1), this.dataView.getUint16(e);
    },
    inspectUint24 (t) {
        const e = t ?? this.position;
        return this.assertPosition(e + 2), (this.dataView.getUint16(e) << 8) + this.dataView.getUint8(e + 2);
    },
    inspectUint32 (t) {
        const e = t ?? this.position;
        return this.assertPosition(e + 3), this.dataView.getUint32(e);
    },
    pushByte (t) {
        this.assertPosition(this.position), this.bytes[this.position] = t, this.position++;
    },
    pushBytes (t) {
        this.assertPosition(this.position + t.length - 1), this.bytes.set(t, this.position), this.position += t.length;
    },
    pushUint8 (t) {
        this.assertPosition(this.position), this.bytes[this.position] = t, this.position++;
    },
    pushUint16 (t) {
        this.assertPosition(this.position + 1), this.dataView.setUint16(this.position, t), this.position += 2;
    },
    pushUint24 (t) {
        this.assertPosition(this.position + 2), this.dataView.setUint16(this.position, t >> 8), this.dataView.setUint8(this.position + 2, t & 255), this.position += 3;
    },
    pushUint32 (t) {
        this.assertPosition(this.position + 3), this.dataView.setUint32(this.position, t), this.position += 4;
    },
    readByte () {
        this.assertReadLimit(), this._touch();
        const t = this.inspectByte();
        return this.position++, t;
    },
    readBytes (t, e) {
        this.assertReadLimit(), this._touch();
        const r = this.inspectBytes(t);
        return this.position += e ?? t, r;
    },
    readUint8 () {
        this.assertReadLimit(), this._touch();
        const t = this.inspectUint8();
        return this.position += 1, t;
    },
    readUint16 () {
        this.assertReadLimit(), this._touch();
        const t = this.inspectUint16();
        return this.position += 2, t;
    },
    readUint24 () {
        this.assertReadLimit(), this._touch();
        const t = this.inspectUint24();
        return this.position += 3, t;
    },
    readUint32 () {
        this.assertReadLimit(), this._touch();
        const t = this.inspectUint32();
        return this.position += 4, t;
    },
    get remaining () {
        return this.bytes.length - this.position;
    },
    setPosition (t) {
        const e = this.position;
        return this.assertPosition(t), this.position = t, ()=>this.position = e;
    },
    _touch () {
        if (this.recursiveReadLimit === Number.POSITIVE_INFINITY) return;
        const t = this.getReadCount();
        this.positionReadCount.set(this.position, t + 1), t > 0 && this.recursiveReadCount++;
    }
};
function Ul(t, { recursiveReadLimit: e = 8192 } = {}) {
    const r = Object.create(sh);
    return r.bytes = t, r.dataView = new DataView(t.buffer, t.byteOffset, t.byteLength), r.positionReadCount = new Map, r.recursiveReadLimit = e, r;
}
const Tr = (t, e, r)=>JSON.stringify(t, (n, i)=>{
        const o = typeof i == "bigint" ? i.toString() : i;
        return typeof e == "function" ? e(n, o) : o;
    }, r), ah = {
    ether: -9,
    wei: 9
};
function Ml(t, e) {
    let r = t.toString();
    const n = r.startsWith("-");
    n && (r = r.slice(1)), r = r.padStart(e, "0");
    let [i, o] = [
        r.slice(0, r.length - e),
        r.slice(r.length - e)
    ];
    return o = o.replace(/(0+)$/, ""), `${n ? "-" : ""}${i || "0"}${o ? `.${o}` : ""}`;
}
function xa(t, e = "wei") {
    return Ml(t, ah[e]);
}
function ch(t) {
    const e = Object.entries(t).map(([n, i])=>i === void 0 || i === !1 ? null : [
            n,
            i
        ]).filter(Boolean), r = e.reduce((n, [i])=>Math.max(n, i.length), 0);
    return e.map(([n, i])=>`  ${`${n}:`.padEnd(r + 1)}  ${i}`).join(`
`);
}
class lh extends de {
    constructor({ v: e }){
        super(`Invalid \`v\` value "${e}". Expected 27 or 28.`, {
            name: "InvalidLegacyVError"
        });
    }
}
class dh extends de {
    constructor({ transaction: e }){
        super("Cannot infer a transaction type from provided transaction.", {
            metaMessages: [
                "Provided Transaction:",
                "{",
                ch(e),
                "}",
                "",
                "To infer the type, either provide:",
                "- a `type` to the Transaction, or",
                "- an EIP-1559 Transaction with `maxFeePerGas`, or",
                "- an EIP-2930 Transaction with `gasPrice` & `accessList`, or",
                "- an EIP-4844 Transaction with `blobs`, `blobVersionedHashes`, `sidecars`, or",
                "- an EIP-7702 Transaction with `authorizationList`, or",
                "- a Legacy Transaction with `gasPrice`"
            ],
            name: "InvalidSerializableTransactionError"
        });
    }
}
class uh extends de {
    constructor({ storageKey: e }){
        super(`Size for storage key "${e}" is invalid. Expected 32 bytes. Got ${Math.floor((e.length - 2) / 2)} bytes.`, {
            name: "InvalidStorageKeySizeError"
        });
    }
}
const Ea = (t)=>t;
class Kn extends de {
    constructor({ body: e, cause: r, details: n, headers: i, status: o, url: s }){
        super("HTTP request failed.", {
            cause: r,
            details: n,
            metaMessages: [
                o && `Status: ${o}`,
                `URL: ${Ea(s)}`,
                e && `Request body: ${Tr(e)}`
            ].filter(Boolean),
            name: "HttpRequestError"
        }), Object.defineProperty(this, "body", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "headers", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "status", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "url", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.body = e, this.headers = i, this.status = o, this.url = s;
    }
}
class Dl extends de {
    constructor({ body: e, error: r, url: n }){
        super("RPC Request failed.", {
            cause: r,
            details: r.message,
            metaMessages: [
                `URL: ${Ea(n)}`,
                `Request body: ${Tr(e)}`
            ],
            name: "RpcRequestError"
        }), Object.defineProperty(this, "code", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "data", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.code = r.code, this.data = r.data;
    }
}
class zl extends de {
    constructor({ body: e, url: r }){
        super("The request took too long to respond.", {
            details: "The request timed out.",
            metaMessages: [
                `URL: ${Ea(r)}`,
                `Request body: ${Tr(e)}`
            ],
            name: "TimeoutError"
        });
    }
}
const hh = -1;
class Xe extends de {
    constructor(e, { code: r, docsPath: n, metaMessages: i, name: o, shortMessage: s }){
        super(s, {
            cause: e,
            docsPath: n,
            metaMessages: i || e?.metaMessages,
            name: o || "RpcError"
        }), Object.defineProperty(this, "code", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.name = o || e.name, this.code = e instanceof Dl ? e.code : r ?? hh;
    }
}
class at extends Xe {
    constructor(e, r){
        super(e, r), Object.defineProperty(this, "data", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.data = r.data;
    }
}
class Gi extends Xe {
    constructor(e){
        super(e, {
            code: Gi.code,
            name: "ParseRpcError",
            shortMessage: "Invalid JSON was received by the server. An error occurred on the server while parsing the JSON text."
        });
    }
}
Object.defineProperty(Gi, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: -32700
});
class qi extends Xe {
    constructor(e){
        super(e, {
            code: qi.code,
            name: "InvalidRequestRpcError",
            shortMessage: "JSON is not a valid request object."
        });
    }
}
Object.defineProperty(qi, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: -32600
});
class Ki extends Xe {
    constructor(e, { method: r } = {}){
        super(e, {
            code: Ki.code,
            name: "MethodNotFoundRpcError",
            shortMessage: `The method${r ? ` "${r}"` : ""} does not exist / is not available.`
        });
    }
}
Object.defineProperty(Ki, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: -32601
});
class Yi extends Xe {
    constructor(e){
        super(e, {
            code: Yi.code,
            name: "InvalidParamsRpcError",
            shortMessage: [
                "Invalid parameters were provided to the RPC method.",
                "Double check you have provided the correct parameters."
            ].join(`
`)
        });
    }
}
Object.defineProperty(Yi, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: -32602
});
class Ln extends Xe {
    constructor(e){
        super(e, {
            code: Ln.code,
            name: "InternalRpcError",
            shortMessage: "An internal error was received."
        });
    }
}
Object.defineProperty(Ln, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: -32603
});
class Xi extends Xe {
    constructor(e){
        super(e, {
            code: Xi.code,
            name: "InvalidInputRpcError",
            shortMessage: [
                "Missing or invalid parameters.",
                "Double check you have provided the correct parameters."
            ].join(`
`)
        });
    }
}
Object.defineProperty(Xi, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: -32e3
});
class Ji extends Xe {
    constructor(e){
        super(e, {
            code: Ji.code,
            name: "ResourceNotFoundRpcError",
            shortMessage: "Requested resource not found."
        }), Object.defineProperty(this, "name", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: "ResourceNotFoundRpcError"
        });
    }
}
Object.defineProperty(Ji, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: -32001
});
class Qi extends Xe {
    constructor(e){
        super(e, {
            code: Qi.code,
            name: "ResourceUnavailableRpcError",
            shortMessage: "Requested resource not available."
        });
    }
}
Object.defineProperty(Qi, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: -32002
});
class Un extends Xe {
    constructor(e){
        super(e, {
            code: Un.code,
            name: "TransactionRejectedRpcError",
            shortMessage: "Transaction creation failed."
        });
    }
}
Object.defineProperty(Un, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: -32003
});
class Qr extends Xe {
    constructor(e, { method: r } = {}){
        super(e, {
            code: Qr.code,
            name: "MethodNotSupportedRpcError",
            shortMessage: `Method${r ? ` "${r}"` : ""} is not supported.`
        });
    }
}
Object.defineProperty(Qr, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: -32004
});
class Mn extends Xe {
    constructor(e){
        super(e, {
            code: Mn.code,
            name: "LimitExceededRpcError",
            shortMessage: "Request exceeds defined limit."
        });
    }
}
Object.defineProperty(Mn, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: -32005
});
class eo extends Xe {
    constructor(e){
        super(e, {
            code: eo.code,
            name: "JsonRpcVersionUnsupportedError",
            shortMessage: "Version of JSON-RPC protocol is not supported."
        });
    }
}
Object.defineProperty(eo, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: -32006
});
class en extends at {
    constructor(e){
        super(e, {
            code: en.code,
            name: "UserRejectedRequestError",
            shortMessage: "User rejected the request."
        });
    }
}
Object.defineProperty(en, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: 4001
});
class to extends at {
    constructor(e){
        super(e, {
            code: to.code,
            name: "UnauthorizedProviderError",
            shortMessage: "The requested method and/or account has not been authorized by the user."
        });
    }
}
Object.defineProperty(to, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: 4100
});
class ro extends at {
    constructor(e, { method: r } = {}){
        super(e, {
            code: ro.code,
            name: "UnsupportedProviderMethodError",
            shortMessage: `The Provider does not support the requested method${r ? ` " ${r}"` : ""}.`
        });
    }
}
Object.defineProperty(ro, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: 4200
});
class no extends at {
    constructor(e){
        super(e, {
            code: no.code,
            name: "ProviderDisconnectedError",
            shortMessage: "The Provider is disconnected from all chains."
        });
    }
}
Object.defineProperty(no, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: 4900
});
class io extends at {
    constructor(e){
        super(e, {
            code: io.code,
            name: "ChainDisconnectedError",
            shortMessage: "The Provider is not connected to the requested chain."
        });
    }
}
Object.defineProperty(io, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: 4901
});
class oo extends at {
    constructor(e){
        super(e, {
            code: oo.code,
            name: "SwitchChainError",
            shortMessage: "An error occurred when attempting to switch chain."
        });
    }
}
Object.defineProperty(oo, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: 4902
});
class so extends at {
    constructor(e){
        super(e, {
            code: so.code,
            name: "UnsupportedNonOptionalCapabilityError",
            shortMessage: "This Wallet does not support a capability that was not marked as optional."
        });
    }
}
Object.defineProperty(so, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: 5700
});
class ao extends at {
    constructor(e){
        super(e, {
            code: ao.code,
            name: "UnsupportedChainIdError",
            shortMessage: "This Wallet does not support the requested chain ID."
        });
    }
}
Object.defineProperty(ao, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: 5710
});
class co extends at {
    constructor(e){
        super(e, {
            code: co.code,
            name: "DuplicateIdError",
            shortMessage: "There is already a bundle submitted with this ID."
        });
    }
}
Object.defineProperty(co, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: 5720
});
class lo extends at {
    constructor(e){
        super(e, {
            code: lo.code,
            name: "UnknownBundleIdError",
            shortMessage: "This bundle id is unknown / has not been submitted"
        });
    }
}
Object.defineProperty(lo, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: 5730
});
class uo extends at {
    constructor(e){
        super(e, {
            code: uo.code,
            name: "BundleTooLargeError",
            shortMessage: "The call bundle is too large for the Wallet to process."
        });
    }
}
Object.defineProperty(uo, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: 5740
});
class ho extends at {
    constructor(e){
        super(e, {
            code: ho.code,
            name: "AtomicReadyWalletRejectedUpgradeError",
            shortMessage: "The Wallet can support atomicity after an upgrade, but the user rejected the upgrade."
        });
    }
}
Object.defineProperty(ho, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: 5750
});
class po extends at {
    constructor(e){
        super(e, {
            code: po.code,
            name: "AtomicityNotSupportedError",
            shortMessage: "The wallet does not support atomic execution but the request requires it."
        });
    }
}
Object.defineProperty(po, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: 5760
});
class ph extends Xe {
    constructor(e){
        super(e, {
            name: "UnknownRpcError",
            shortMessage: "An unknown RPC error occurred."
        });
    }
}
function hr(t, e = "hex") {
    const r = Wl(t), n = Ul(new Uint8Array(r.length));
    return r.encode(n), e === "hex" ? jt(n.bytes) : n.bytes;
}
function Wl(t) {
    return Array.isArray(t) ? fh(t.map((e)=>Wl(e))) : gh(t);
}
function fh(t) {
    const e = t.reduce((i, o)=>i + o.length, 0), r = jl(e);
    return {
        length: e <= 55 ? 1 + e : 1 + r + e,
        encode (i) {
            e <= 55 ? i.pushByte(192 + e) : (i.pushByte(247 + r), r === 1 ? i.pushUint8(e) : r === 2 ? i.pushUint16(e) : r === 3 ? i.pushUint24(e) : i.pushUint32(e));
            for (const { encode: o } of t)o(i);
        }
    };
}
function gh(t) {
    const e = typeof t == "string" ? kr(t) : t, r = jl(e.length);
    return {
        length: e.length === 1 && e[0] < 128 ? 1 : e.length <= 55 ? 1 + e.length : 1 + r + e.length,
        encode (i) {
            e.length === 1 && e[0] < 128 ? i.pushBytes(e) : e.length <= 55 ? (i.pushByte(128 + e.length), i.pushBytes(e)) : (i.pushByte(183 + r), r === 1 ? i.pushUint8(e.length) : r === 2 ? i.pushUint16(e.length) : r === 3 ? i.pushUint24(e.length) : i.pushUint32(e.length), i.pushBytes(e));
        }
    };
}
function jl(t) {
    if (t < 2 ** 8) return 1;
    if (t < 2 ** 16) return 2;
    if (t < 2 ** 24) return 3;
    if (t < 2 ** 32) return 4;
    throw new de("Length is too large.");
}
class Aa extends de {
    constructor({ cause: e, message: r } = {}){
        const n = r?.replace("execution reverted: ", "")?.replace("execution reverted", "");
        super(`Execution reverted ${n ? `with reason: ${n}` : "for an unknown reason"}.`, {
            cause: e,
            name: "ExecutionRevertedError"
        });
    }
}
Object.defineProperty(Aa, "code", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: 3
}), Object.defineProperty(Aa, "nodeMessage", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: /execution reverted/
});
class Yn extends de {
    constructor({ cause: e, maxFeePerGas: r } = {}){
        super(`The fee cap (\`maxFeePerGas\`${r ? ` = ${xa(r)} gwei` : ""}) cannot be higher than the maximum allowed value (2^256-1).`, {
            cause: e,
            name: "FeeCapTooHighError"
        });
    }
}
Object.defineProperty(Yn, "nodeMessage", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: /max fee per gas higher than 2\^256-1|fee cap higher than 2\^256-1/
});
class Sa extends de {
    constructor({ cause: e, maxPriorityFeePerGas: r, maxFeePerGas: n } = {}){
        super([
            `The provided tip (\`maxPriorityFeePerGas\`${r ? ` = ${xa(r)} gwei` : ""}) cannot be higher than the fee cap (\`maxFeePerGas\`${n ? ` = ${xa(n)} gwei` : ""}).`
        ].join(`
`), {
            cause: e,
            name: "TipAboveFeeCapError"
        });
    }
}
Object.defineProperty(Sa, "nodeMessage", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: /max priority fee per gas higher than max fee per gas|tip higher than fee cap/
});
function To(t, e) {
    return ({ exclude: r, format: n })=>({
            exclude: r,
            format: (i)=>{
                const o = e(i);
                if (r) for (const s of r)delete o[s];
                return {
                    ...o,
                    ...n(i)
                };
            },
            type: t
        });
}
const wh = {
    legacy: "0x0",
    eip2930: "0x1",
    eip1559: "0x2",
    eip4844: "0x3",
    eip7702: "0x4"
};
function mh(t) {
    const e = {};
    return typeof t.authorizationList < "u" && (e.authorizationList = vh(t.authorizationList)), typeof t.accessList < "u" && (e.accessList = t.accessList), typeof t.blobVersionedHashes < "u" && (e.blobVersionedHashes = t.blobVersionedHashes), typeof t.blobs < "u" && (typeof t.blobs[0] != "string" ? e.blobs = t.blobs.map((r)=>jt(r)) : e.blobs = t.blobs), typeof t.data < "u" && (e.data = t.data), typeof t.from < "u" && (e.from = t.from), typeof t.gas < "u" && (e.gas = Ve(t.gas)), typeof t.gasPrice < "u" && (e.gasPrice = Ve(t.gasPrice)), typeof t.maxFeePerBlobGas < "u" && (e.maxFeePerBlobGas = Ve(t.maxFeePerBlobGas)), typeof t.maxFeePerGas < "u" && (e.maxFeePerGas = Ve(t.maxFeePerGas)), typeof t.maxPriorityFeePerGas < "u" && (e.maxPriorityFeePerGas = Ve(t.maxPriorityFeePerGas)), typeof t.nonce < "u" && (e.nonce = Ve(t.nonce)), typeof t.to < "u" && (e.to = t.to), typeof t.type < "u" && (e.type = wh[t.type]), typeof t.value < "u" && (e.value = Ve(t.value)), e;
}
const bh = To("transactionRequest", mh);
function vh(t) {
    return t.map((e)=>({
            address: e.address,
            r: e.r ? Ve(BigInt(e.r)) : e.r,
            s: e.s ? Ve(BigInt(e.s)) : e.s,
            chainId: Ve(e.chainId),
            nonce: Ve(e.nonce),
            ...typeof e.yParity < "u" ? {
                yParity: Ve(e.yParity)
            } : {},
            ...typeof e.v < "u" && typeof e.yParity > "u" ? {
                v: Ve(e.v)
            } : {}
        }));
}
const Oo = 2n ** 256n - 1n, Fl = {
    "0x0": "legacy",
    "0x1": "eip2930",
    "0x2": "eip1559",
    "0x3": "eip4844",
    "0x4": "eip7702"
};
function $o(t) {
    const e = {
        ...t,
        blockHash: t.blockHash ? t.blockHash : null,
        blockNumber: t.blockNumber ? BigInt(t.blockNumber) : null,
        chainId: t.chainId ? So(t.chainId) : void 0,
        gas: t.gas ? BigInt(t.gas) : void 0,
        gasPrice: t.gasPrice ? BigInt(t.gasPrice) : void 0,
        maxFeePerBlobGas: t.maxFeePerBlobGas ? BigInt(t.maxFeePerBlobGas) : void 0,
        maxFeePerGas: t.maxFeePerGas ? BigInt(t.maxFeePerGas) : void 0,
        maxPriorityFeePerGas: t.maxPriorityFeePerGas ? BigInt(t.maxPriorityFeePerGas) : void 0,
        nonce: t.nonce ? So(t.nonce) : void 0,
        to: t.to ? t.to : null,
        transactionIndex: t.transactionIndex ? Number(t.transactionIndex) : null,
        type: t.type ? Fl[t.type] : void 0,
        typeHex: t.type ? t.type : void 0,
        value: t.value ? BigInt(t.value) : void 0,
        v: t.v ? BigInt(t.v) : void 0
    };
    return t.authorizationList && (e.authorizationList = Ch(t.authorizationList)), e.yParity = (()=>{
        if (t.yParity) return Number(t.yParity);
        if (typeof e.v == "bigint") {
            if (e.v === 0n || e.v === 27n) return 0;
            if (e.v === 1n || e.v === 28n) return 1;
            if (e.v >= 35n) return e.v % 2n === 0n ? 1 : 0;
        }
    })(), e.type === "legacy" && (delete e.accessList, delete e.maxFeePerBlobGas, delete e.maxFeePerGas, delete e.maxPriorityFeePerGas, delete e.yParity), e.type === "eip2930" && (delete e.maxFeePerBlobGas, delete e.maxFeePerGas, delete e.maxPriorityFeePerGas), e.type === "eip1559" && delete e.maxFeePerBlobGas, e;
}
const Hl = To("transaction", $o);
function Ch(t) {
    return t.map((e)=>({
            address: e.address,
            chainId: Number(e.chainId),
            nonce: Number(e.nonce),
            r: e.r,
            s: e.s,
            yParity: Number(e.yParity)
        }));
}
function yh(t) {
    const e = (t.transactions ?? []).map((r)=>typeof r == "string" ? r : $o(r));
    return {
        ...t,
        baseFeePerGas: t.baseFeePerGas ? BigInt(t.baseFeePerGas) : null,
        blobGasUsed: t.blobGasUsed ? BigInt(t.blobGasUsed) : void 0,
        difficulty: t.difficulty ? BigInt(t.difficulty) : void 0,
        excessBlobGas: t.excessBlobGas ? BigInt(t.excessBlobGas) : void 0,
        gasLimit: t.gasLimit ? BigInt(t.gasLimit) : void 0,
        gasUsed: t.gasUsed ? BigInt(t.gasUsed) : void 0,
        hash: t.hash ? t.hash : null,
        logsBloom: t.logsBloom ? t.logsBloom : null,
        nonce: t.nonce ? t.nonce : null,
        number: t.number ? BigInt(t.number) : null,
        size: t.size ? BigInt(t.size) : void 0,
        timestamp: t.timestamp ? BigInt(t.timestamp) : void 0,
        transactions: e,
        totalDifficulty: t.totalDifficulty ? BigInt(t.totalDifficulty) : null
    };
}
const Vl = To("block", yh);
function Zl(t) {
    const { kzg: e } = t, r = t.to ?? (typeof t.blobs[0] == "string" ? "hex" : "bytes"), n = typeof t.blobs[0] == "string" ? t.blobs.map((o)=>kr(o)) : t.blobs, i = [];
    for (const o of n)i.push(Uint8Array.from(e.blobToKzgCommitment(o)));
    return r === "bytes" ? i : i.map((o)=>jt(o));
}
function Gl(t) {
    const { kzg: e } = t, r = t.to ?? (typeof t.blobs[0] == "string" ? "hex" : "bytes"), n = typeof t.blobs[0] == "string" ? t.blobs.map((s)=>kr(s)) : t.blobs, i = typeof t.commitments[0] == "string" ? t.commitments.map((s)=>kr(s)) : t.commitments, o = [];
    for(let s = 0; s < n.length; s++){
        const a = n[s], c = i[s];
        o.push(Uint8Array.from(e.computeBlobKzgProof(a, c)));
    }
    return r === "bytes" ? o : o.map((s)=>jt(s));
}
function xh(t, e, r, n) {
    if (typeof t.setBigUint64 == "function") return t.setBigUint64(e, r, n);
    const i = BigInt(32), o = BigInt(4294967295), s = Number(r >> i & o), a = Number(r & o), c = n ? 4 : 0, l = n ? 0 : 4;
    t.setUint32(e + c, s, n), t.setUint32(e + l, a, n);
}
function Eh(t, e, r) {
    return t & e ^ ~t & r;
}
function Ah(t, e, r) {
    return t & e ^ t & r ^ e & r;
}
class Sh extends va {
    constructor(e, r, n, i){
        super(), this.blockLen = e, this.outputLen = r, this.padOffset = n, this.isLE = i, this.finished = !1, this.length = 0, this.pos = 0, this.destroyed = !1, this.buffer = new Uint8Array(e), this.view = ba(this.buffer);
    }
    update(e) {
        cn(this);
        const { view: r, buffer: n, blockLen: i } = this;
        e = No(e);
        const o = e.length;
        for(let s = 0; s < o;){
            const a = Math.min(i - this.pos, o - s);
            if (a === i) {
                const c = ba(e);
                for(; i <= o - s; s += i)this.process(c, s);
                continue;
            }
            n.set(e.subarray(s, s + a), this.pos), this.pos += a, s += a, this.pos === i && (this.process(r, 0), this.pos = 0);
        }
        return this.length += e.length, this.roundClean(), this;
    }
    digestInto(e) {
        cn(this), El(e, this), this.finished = !0;
        const { buffer: r, view: n, blockLen: i, isLE: o } = this;
        let { pos: s } = this;
        r[s++] = 128, this.buffer.subarray(s).fill(0), this.padOffset > i - s && (this.process(n, 0), s = 0);
        for(let u = s; u < i; u++)r[u] = 0;
        xh(n, i - 8, BigInt(this.length * 8), o), this.process(n, 0);
        const a = ba(e), c = this.outputLen;
        if (c % 4) throw new Error("_sha2: outputLen should be aligned to 32bit");
        const l = c / 4, d = this.get();
        if (l > d.length) throw new Error("_sha2: outputLen bigger than state");
        for(let u = 0; u < l; u++)a.setUint32(4 * u, d[u], o);
    }
    digest() {
        const { buffer: e, outputLen: r } = this;
        this.digestInto(e);
        const n = e.slice(0, r);
        return this.destroy(), n;
    }
    _cloneInto(e) {
        e || (e = new this.constructor), e.set(...this.get());
        const { blockLen: r, buffer: n, length: i, finished: o, destroyed: s, pos: a } = this;
        return e.length = i, e.pos = a, e.finished = o, e.destroyed = s, i % r && e.buffer.set(n), e;
    }
}
const _h = new Uint32Array([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
]), pr = new Uint32Array([
    1779033703,
    3144134277,
    1013904242,
    2773480762,
    1359893119,
    2600822924,
    528734635,
    1541459225
]), fr = new Uint32Array(64);
class Ih extends Sh {
    constructor(){
        super(64, 32, 8, !1), this.A = pr[0] | 0, this.B = pr[1] | 0, this.C = pr[2] | 0, this.D = pr[3] | 0, this.E = pr[4] | 0, this.F = pr[5] | 0, this.G = pr[6] | 0, this.H = pr[7] | 0;
    }
    get() {
        const { A: e, B: r, C: n, D: i, E: o, F: s, G: a, H: c } = this;
        return [
            e,
            r,
            n,
            i,
            o,
            s,
            a,
            c
        ];
    }
    set(e, r, n, i, o, s, a, c) {
        this.A = e | 0, this.B = r | 0, this.C = n | 0, this.D = i | 0, this.E = o | 0, this.F = s | 0, this.G = a | 0, this.H = c | 0;
    }
    process(e, r) {
        for(let u = 0; u < 16; u++, r += 4)fr[u] = e.getUint32(r, !1);
        for(let u = 16; u < 64; u++){
            const h = fr[u - 15], p = fr[u - 2], v = Tt(h, 7) ^ Tt(h, 18) ^ h >>> 3, m = Tt(p, 17) ^ Tt(p, 19) ^ p >>> 10;
            fr[u] = m + fr[u - 7] + v + fr[u - 16] | 0;
        }
        let { A: n, B: i, C: o, D: s, E: a, F: c, G: l, H: d } = this;
        for(let u = 0; u < 64; u++){
            const h = Tt(a, 6) ^ Tt(a, 11) ^ Tt(a, 25), p = d + h + Eh(a, c, l) + _h[u] + fr[u] | 0, m = (Tt(n, 2) ^ Tt(n, 13) ^ Tt(n, 22)) + Ah(n, i, o) | 0;
            d = l, l = c, c = a, a = s + p | 0, s = o, o = i, i = n, n = p + m | 0;
        }
        n = n + this.A | 0, i = i + this.B | 0, o = o + this.C | 0, s = s + this.D | 0, a = a + this.E | 0, c = c + this.F | 0, l = l + this.G | 0, d = d + this.H | 0, this.set(n, i, o, s, a, c, l, d);
    }
    roundClean() {
        fr.fill(0);
    }
    destroy() {
        this.set(0, 0, 0, 0, 0, 0, 0, 0), this.buffer.fill(0);
    }
}
const ql = Il(()=>new Ih);
function Nh(t, e) {
    const r = e || "hex", n = ql(Zn(t, {
        strict: !1
    }) ? Cl(t) : t);
    return r === "bytes" ? n : ie(n);
}
function kh(t) {
    const { commitment: e, version: r = 1 } = t, n = t.to ?? (typeof e == "string" ? "hex" : "bytes"), i = Nh(e, "bytes");
    return i.set([
        r
    ], 0), n === "bytes" ? i : jt(i);
}
function Th(t) {
    const { commitments: e, version: r } = t, n = t.to ?? (typeof e[0] == "string" ? "hex" : "bytes"), i = [];
    for (const o of e)i.push(kh({
        commitment: o,
        to: n,
        version: r
    }));
    return i;
}
const Kl = 6, Yl = 32, _a = 4096, Xl = Yl * _a, Jl = Xl * Kl - 1 - 1 * _a * Kl, Ql = 1;
class Oh extends de {
    constructor({ maxSize: e, size: r }){
        super("Blob size is too large.", {
            metaMessages: [
                `Max: ${e} bytes`,
                `Given: ${r} bytes`
            ],
            name: "BlobSizeTooLargeError"
        });
    }
}
class ed extends de {
    constructor(){
        super("Blob data must not be empty.", {
            name: "EmptyBlobError"
        });
    }
}
class $h extends de {
    constructor({ hash: e, size: r }){
        super(`Versioned hash "${e}" size is invalid.`, {
            metaMessages: [
                "Expected: 32",
                `Received: ${r}`
            ],
            name: "InvalidVersionedHashSizeError"
        });
    }
}
class Ph extends de {
    constructor({ hash: e, version: r }){
        super(`Versioned hash "${e}" version is invalid.`, {
            metaMessages: [
                `Expected: ${Ql}`,
                `Received: ${r}`
            ],
            name: "InvalidVersionedHashVersionError"
        });
    }
}
function Bh(t) {
    const e = t.to ?? (typeof t.data == "string" ? "hex" : "bytes"), r = typeof t.data == "string" ? kr(t.data) : t.data, n = dr(r);
    if (!n) throw new ed;
    if (n > Jl) throw new Oh({
        maxSize: Jl,
        size: n
    });
    const i = [];
    let o = !0, s = 0;
    for(; o;){
        const a = Ul(new Uint8Array(Xl));
        let c = 0;
        for(; c < _a;){
            const l = r.slice(s, s + (Yl - 1));
            if (a.pushByte(0), a.pushBytes(l), l.length < 31) {
                a.pushByte(128), o = !1;
                break;
            }
            c++, s += 31;
        }
        i.push(a);
    }
    return e === "bytes" ? i.map((a)=>a.bytes) : i.map((a)=>jt(a.bytes));
}
function Rh(t) {
    const { data: e, kzg: r, to: n } = t, i = t.blobs ?? Bh({
        data: e,
        to: n
    }), o = t.commitments ?? Zl({
        blobs: i,
        kzg: r,
        to: n
    }), s = t.proofs ?? Gl({
        blobs: i,
        commitments: o,
        kzg: r,
        to: n
    }), a = [];
    for(let c = 0; c < i.length; c++)a.push({
        blob: i[c],
        commitment: o[c],
        proof: s[c]
    });
    return a;
}
function Lh(t) {
    if (t.type) return t.type;
    if (typeof t.authorizationList < "u") return "eip7702";
    if (typeof t.blobs < "u" || typeof t.blobVersionedHashes < "u" || typeof t.maxFeePerBlobGas < "u" || typeof t.sidecars < "u") return "eip4844";
    if (typeof t.maxFeePerGas < "u" || typeof t.maxPriorityFeePerGas < "u") return "eip1559";
    if (typeof t.gasPrice < "u") return typeof t.accessList < "u" ? "eip2930" : "legacy";
    throw new dh({
        transaction: t
    });
}
function Uh(t, { args: e, eventName: r } = {}) {
    return {
        ...t,
        blockHash: t.blockHash ? t.blockHash : null,
        blockNumber: t.blockNumber ? BigInt(t.blockNumber) : null,
        logIndex: t.logIndex ? Number(t.logIndex) : null,
        transactionHash: t.transactionHash ? t.transactionHash : null,
        transactionIndex: t.transactionIndex ? Number(t.transactionIndex) : null,
        ...r ? {
            args: e,
            eventName: r
        } : {}
    };
}
class Xn extends de {
    constructor({ chainId: e }){
        super(typeof e == "number" ? `Chain ID "${e}" is invalid.` : "Chain ID is invalid.", {
            name: "InvalidChainIdError"
        });
    }
}
function Mh() {
    let t = ()=>{}, e = ()=>{};
    return {
        promise: new Promise((n, i)=>{
            t = n, e = i;
        }),
        resolve: t,
        reject: e
    };
}
const Ia = new Map;
function Dh({ fn: t, id: e, shouldSplitBatch: r, wait: n = 0, sort: i }) {
    const o = async ()=>{
        const d = c();
        s();
        const u = d.map(({ args: h })=>h);
        u.length !== 0 && t(u).then((h)=>{
            i && Array.isArray(h) && h.sort(i);
            for(let p = 0; p < d.length; p++){
                const { resolve: v } = d[p];
                v?.([
                    h[p],
                    h
                ]);
            }
        }).catch((h)=>{
            for(let p = 0; p < d.length; p++){
                const { reject: v } = d[p];
                v?.(h);
            }
        });
    }, s = ()=>Ia.delete(e), a = ()=>c().map(({ args: d })=>d), c = ()=>Ia.get(e) || [], l = (d)=>Ia.set(e, [
            ...c(),
            d
        ]);
    return {
        flush: s,
        async schedule (d) {
            const { promise: u, resolve: h, reject: p } = Mh();
            return r?.([
                ...a(),
                d
            ]) && o(), c().length > 0 ? (l({
                args: d,
                resolve: h,
                reject: p
            }), u) : (l({
                args: d,
                resolve: h,
                reject: p
            }), setTimeout(o, n), u);
        }
    };
}
async function td(t) {
    return new Promise((e)=>setTimeout(e, t));
}
new ko(128);
const Na = 256;
let Po = Na, Bo;
function zh(t = 11) {
    if (!Bo || Po + t > Na * 2) {
        Bo = "", Po = 0;
        for(let e = 0; e < Na; e++)Bo += (256 + Math.random() * 256 | 0).toString(16).substring(1);
    }
    return Bo.substring(Po, Po++ + t);
}
const Ro = new ko(8192);
function Wh(t, { enabled: e = !0, id: r }) {
    if (!e || !r) return t();
    if (Ro.get(r)) return Ro.get(r);
    const n = t().finally(()=>Ro.delete(r));
    return Ro.set(r, n), n;
}
function jh(t, { delay: e = 100, retryCount: r = 2, shouldRetry: n = ()=>!0 } = {}) {
    return new Promise((i, o)=>{
        const s = async ({ count: a = 0 } = {})=>{
            const c = async ({ error: l })=>{
                const d = typeof e == "function" ? e({
                    count: a,
                    error: l
                }) : e;
                d && await td(d), s({
                    count: a + 1
                });
            };
            try {
                const l = await t();
                i(l);
            } catch (l) {
                if (a < r && await n({
                    count: a,
                    error: l
                })) return c({
                    error: l
                });
                o(l);
            }
        };
        s();
    });
}
function Fh(t, e = {}) {
    return async (r, n = {})=>{
        const { dedupe: i = !1, methods: o, retryDelay: s = 150, retryCount: a = 3, uid: c } = {
            ...e,
            ...n
        }, { method: l } = r;
        if (o?.exclude?.includes(l)) throw new Qr(new Error("method not supported"), {
            method: l
        });
        if (o?.include && !o.include.includes(l)) throw new Qr(new Error("method not supported"), {
            method: l
        });
        const d = i ? vl(`${c}.${Tr(r)}`) : void 0;
        return Wh(()=>jh(async ()=>{
                try {
                    return await t(r);
                } catch (u) {
                    const h = u;
                    switch(h.code){
                        case Gi.code:
                            throw new Gi(h);
                        case qi.code:
                            throw new qi(h);
                        case Ki.code:
                            throw new Ki(h, {
                                method: r.method
                            });
                        case Yi.code:
                            throw new Yi(h);
                        case Ln.code:
                            throw new Ln(h);
                        case Xi.code:
                            throw new Xi(h);
                        case Ji.code:
                            throw new Ji(h);
                        case Qi.code:
                            throw new Qi(h);
                        case Un.code:
                            throw new Un(h);
                        case Qr.code:
                            throw new Qr(h, {
                                method: r.method
                            });
                        case Mn.code:
                            throw new Mn(h);
                        case eo.code:
                            throw new eo(h);
                        case en.code:
                            throw new en(h);
                        case to.code:
                            throw new to(h);
                        case ro.code:
                            throw new ro(h);
                        case no.code:
                            throw new no(h);
                        case io.code:
                            throw new io(h);
                        case oo.code:
                            throw new oo(h);
                        case so.code:
                            throw new so(h);
                        case ao.code:
                            throw new ao(h);
                        case co.code:
                            throw new co(h);
                        case lo.code:
                            throw new lo(h);
                        case uo.code:
                            throw new uo(h);
                        case ho.code:
                            throw new ho(h);
                        case po.code:
                            throw new po(h);
                        case 5e3:
                            throw new en(h);
                        default:
                            throw u instanceof de ? u : new ph(h);
                    }
                }
            }, {
                delay: ({ count: u, error: h })=>{
                    if (h && h instanceof Kn) {
                        const p = h?.headers?.get("Retry-After");
                        if (p?.match(/\d/)) return Number.parseInt(p) * 1e3;
                    }
                    return ~~(1 << u) * s;
                },
                retryCount: a,
                shouldRetry: ({ error: u })=>Hh(u)
            }), {
            enabled: i,
            id: d
        });
    };
}
function Hh(t) {
    return "code" in t && typeof t.code == "number" ? t.code === -1 || t.code === Mn.code || t.code === Ln.code : t instanceof Kn && t.status ? t.status === 403 || t.status === 408 || t.status === 413 || t.status === 429 || t.status === 500 || t.status === 502 || t.status === 503 || t.status === 504 : !0;
}
function rd({ key: t, methods: e, name: r, request: n, retryCount: i = 3, retryDelay: o = 150, timeout: s, type: a }, c) {
    const l = zh();
    return {
        config: {
            key: t,
            methods: e,
            name: r,
            request: n,
            retryCount: i,
            retryDelay: o,
            timeout: s,
            type: a
        },
        request: Fh(n, {
            methods: e,
            retryCount: i,
            retryDelay: o,
            uid: l
        }),
        value: c
    };
}
function nd(t, e = {}) {
    const { key: r = "fallback", name: n = "Fallback", rank: i = !1, shouldThrow: o = Vh, retryCount: s, retryDelay: a } = e;
    return ({ chain: c, pollingInterval: l = 4e3, timeout: d, ...u })=>{
        let h = t, p = ()=>{};
        const v = rd({
            key: r,
            name: n,
            async request ({ method: m, params: g }) {
                let b;
                const y = async (x = 0)=>{
                    const E = h[x]({
                        ...u,
                        chain: c,
                        retryCount: 0,
                        timeout: d
                    });
                    try {
                        const I = await E.request({
                            method: m,
                            params: g
                        });
                        return p({
                            method: m,
                            params: g,
                            response: I,
                            transport: E,
                            status: "success"
                        }), I;
                    } catch (I) {
                        if (p({
                            error: I,
                            method: m,
                            params: g,
                            transport: E,
                            status: "error"
                        }), o(I) || x === h.length - 1 || (b ??= h.slice(x + 1).some(($)=>{
                            const { include: L, exclude: Z } = $({
                                chain: c
                            }).config.methods || {};
                            return L ? L.includes(m) : Z ? !Z.includes(m) : !0;
                        }), !b)) throw I;
                        return y(x + 1);
                    }
                };
                return y();
            },
            retryCount: s,
            retryDelay: a,
            type: "fallback"
        }, {
            onResponse: (m)=>p = m,
            transports: h.map((m)=>m({
                    chain: c,
                    retryCount: 0
                }))
        });
        if (i) {
            const m = typeof i == "object" ? i : {};
            Zh({
                chain: c,
                interval: m.interval ?? l,
                onTransports: (g)=>h = g,
                ping: m.ping,
                sampleCount: m.sampleCount,
                timeout: m.timeout,
                transports: h,
                weights: m.weights
            });
        }
        return v;
    };
}
function Vh(t) {
    return !!("code" in t && typeof t.code == "number" && (t.code === Un.code || t.code === en.code || Aa.nodeMessage.test(t.message) || t.code === 5e3));
}
function Zh({ chain: t, interval: e = 4e3, onTransports: r, ping: n, sampleCount: i = 10, timeout: o = 1e3, transports: s, weights: a = {} }) {
    const { stability: c = .7, latency: l = .3 } = a, d = [], u = async ()=>{
        const h = await Promise.all(s.map(async (m)=>{
            const g = m({
                chain: t,
                retryCount: 0,
                timeout: o
            }), b = Date.now();
            let y, x;
            try {
                await (n ? n({
                    transport: g
                }) : g.request({
                    method: "net_listening"
                })), x = 1;
            } catch  {
                x = 0;
            } finally{
                y = Date.now();
            }
            return {
                latency: y - b,
                success: x
            };
        }));
        d.push(h), d.length > i && d.shift();
        const p = Math.max(...d.map((m)=>Math.max(...m.map(({ latency: g })=>g)))), v = s.map((m, g)=>{
            const b = d.map(($)=>$[g].latency), x = 1 - b.reduce(($, L)=>$ + L, 0) / b.length / p, E = d.map(($)=>$[g].success), I = E.reduce(($, L)=>$ + L, 0) / E.length;
            return I === 0 ? [
                0,
                g
            ] : [
                l * x + c * I,
                g
            ];
        }).sort((m, g)=>g[0] - m[0]);
        r(v.map(([, m])=>s[m])), await td(e), u();
    };
    u();
}
class Gh extends de {
    constructor(){
        super("No URL was provided to the Transport. Please provide a valid RPC URL to the Transport.", {
            docsPath: "/docs/clients/intro",
            name: "UrlRequiredError"
        });
    }
}
function qh(t, { errorInstance: e = new Error("timed out"), timeout: r, signal: n }) {
    return new Promise((i, o)=>{
        (async ()=>{
            let s;
            try {
                const a = new AbortController;
                r > 0 && (s = setTimeout(()=>{
                    n ? a.abort() : o(e);
                }, r)), i(await t({
                    signal: a?.signal || null
                }));
            } catch (a) {
                a?.name === "AbortError" && o(e), o(a);
            } finally{
                clearTimeout(s);
            }
        })();
    });
}
function Kh() {
    return {
        current: 0,
        take () {
            return this.current++;
        },
        reset () {
            this.current = 0;
        }
    };
}
const id = Kh();
function Yh(t, e = {}) {
    return {
        async request (r) {
            const { body: n, onRequest: i = e.onRequest, onResponse: o = e.onResponse, timeout: s = e.timeout ?? 1e4 } = r, a = {
                ...e.fetchOptions ?? {},
                ...r.fetchOptions ?? {}
            }, { headers: c, method: l, signal: d } = a;
            try {
                const u = await qh(async ({ signal: p })=>{
                    const v = {
                        ...a,
                        body: Array.isArray(n) ? Tr(n.map((y)=>({
                                jsonrpc: "2.0",
                                id: y.id ?? id.take(),
                                ...y
                            }))) : Tr({
                            jsonrpc: "2.0",
                            id: n.id ?? id.take(),
                            ...n
                        }),
                        headers: {
                            "Content-Type": "application/json",
                            ...c
                        },
                        method: l || "POST",
                        signal: d || (s > 0 ? p : null)
                    }, m = new Request(t, v), g = await i?.(m, v) ?? {
                        ...v,
                        url: t
                    };
                    return await fetch(g.url ?? t, g);
                }, {
                    errorInstance: new zl({
                        body: n,
                        url: t
                    }),
                    timeout: s,
                    signal: !0
                });
                o && await o(u);
                let h;
                if (u.headers.get("Content-Type")?.startsWith("application/json")) h = await u.json();
                else {
                    h = await u.text();
                    try {
                        h = JSON.parse(h || "{}");
                    } catch (p) {
                        if (u.ok) throw p;
                        h = {
                            error: h
                        };
                    }
                }
                if (!u.ok) throw new Kn({
                    body: n,
                    details: Tr(h.error) || u.statusText,
                    headers: u.headers,
                    status: u.status,
                    url: t
                });
                return h;
            } catch (u) {
                throw u instanceof Kn || u instanceof zl ? u : new Kn({
                    body: n,
                    cause: u,
                    url: t
                });
            }
        }
    };
}
function Lo(t, e = {}) {
    const { batch: r, fetchOptions: n, key: i = "http", methods: o, name: s = "HTTP JSON-RPC", onFetchRequest: a, onFetchResponse: c, retryDelay: l, raw: d } = e;
    return ({ chain: u, retryCount: h, timeout: p })=>{
        const { batchSize: v = 1e3, wait: m = 0 } = typeof r == "object" ? r : {}, g = e.retryCount ?? h, b = p ?? e.timeout ?? 1e4, y = t || u?.rpcUrls.default.http[0];
        if (!y) throw new Gh;
        const x = Yh(y, {
            fetchOptions: n,
            onRequest: a,
            onResponse: c,
            timeout: b
        });
        return rd({
            key: i,
            methods: o,
            name: s,
            async request ({ method: E, params: I }) {
                const $ = {
                    method: E,
                    params: I
                }, { schedule: L } = Dh({
                    id: y,
                    wait: m,
                    shouldSplitBatch (N) {
                        return N.length > v;
                    },
                    fn: (N)=>x.request({
                            body: N
                        }),
                    sort: (N, ee)=>N.id - ee.id
                }), Z = async (N)=>r ? L(N) : [
                        await x.request({
                            body: N
                        })
                    ], [{ error: B, result: R }] = await Z($);
                if (d) return {
                    error: B,
                    result: R
                };
                if (B) throw new Dl({
                    body: $,
                    error: B,
                    url: y
                });
                return R;
            },
            retryCount: g,
            retryDelay: l,
            timeout: b,
            type: "http"
        }, {
            fetchOptions: n,
            url: y
        });
    };
}
function J(t) {
    return {
        formatters: void 0,
        fees: void 0,
        serializers: void 0,
        ...t
    };
}
function Xh(t) {
    const { authorizationList: e } = t;
    if (e) for (const r of e){
        const { chainId: n } = r, i = r.address;
        if (!Ht(i)) throw new ur({
            address: i
        });
        if (n < 0) throw new Xn({
            chainId: n
        });
    }
    ka(t);
}
function Jh(t) {
    const { blobVersionedHashes: e } = t;
    if (e) {
        if (e.length === 0) throw new ed;
        for (const r of e){
            const n = dr(r), i = So(th(r, 0, 1));
            if (n !== 32) throw new $h({
                hash: r,
                size: n
            });
            if (i !== Ql) throw new Ph({
                hash: r,
                version: i
            });
        }
    }
    ka(t);
}
function ka(t) {
    const { chainId: e, maxPriorityFeePerGas: r, maxFeePerGas: n, to: i } = t;
    if (e <= 0) throw new Xn({
        chainId: e
    });
    if (i && !Ht(i)) throw new ur({
        address: i
    });
    if (n && n > Oo) throw new Yn({
        maxFeePerGas: n
    });
    if (r && n && r > n) throw new Sa({
        maxFeePerGas: n,
        maxPriorityFeePerGas: r
    });
}
function Qh(t) {
    const { chainId: e, maxPriorityFeePerGas: r, gasPrice: n, maxFeePerGas: i, to: o } = t;
    if (e <= 0) throw new Xn({
        chainId: e
    });
    if (o && !Ht(o)) throw new ur({
        address: o
    });
    if (r || i) throw new de("`maxFeePerGas`/`maxPriorityFeePerGas` is not a valid EIP-2930 Transaction attribute.");
    if (n && n > Oo) throw new Yn({
        maxFeePerGas: n
    });
}
function ep(t) {
    const { chainId: e, maxPriorityFeePerGas: r, gasPrice: n, maxFeePerGas: i, to: o } = t;
    if (o && !Ht(o)) throw new ur({
        address: o
    });
    if (typeof e < "u" && e <= 0) throw new Xn({
        chainId: e
    });
    if (r || i) throw new de("`maxFeePerGas`/`maxPriorityFeePerGas` is not a valid Legacy Transaction attribute.");
    if (n && n > Oo) throw new Yn({
        maxFeePerGas: n
    });
}
function Jn(t) {
    if (!t || t.length === 0) return [];
    const e = [];
    for(let r = 0; r < t.length; r++){
        const { address: n, storageKeys: i } = t[r];
        for(let o = 0; o < i.length; o++)if (i[o].length - 2 !== 64) throw new uh({
            storageKey: i[o]
        });
        if (!Ht(n, {
            strict: !1
        })) throw new ur({
            address: n
        });
        e.push([
            n,
            i
        ]);
    }
    return e;
}
function tp(t, e) {
    const r = Lh(t);
    return r === "eip1559" ? ip(t, e) : r === "eip2930" ? op(t, e) : r === "eip4844" ? np(t, e) : r === "eip7702" ? rp(t, e) : sp(t, e);
}
function rp(t, e) {
    const { authorizationList: r, chainId: n, gas: i, nonce: o, to: s, value: a, maxFeePerGas: c, maxPriorityFeePerGas: l, accessList: d, data: u } = t;
    Xh(t);
    const h = Jn(d), p = ap(r);
    return dn([
        "0x04",
        hr([
            ie(n),
            o ? ie(o) : "0x",
            l ? ie(l) : "0x",
            c ? ie(c) : "0x",
            i ? ie(i) : "0x",
            s ?? "0x",
            a ? ie(a) : "0x",
            u ?? "0x",
            h,
            p,
            ...un(t, e)
        ])
    ]);
}
function np(t, e) {
    const { chainId: r, gas: n, nonce: i, to: o, value: s, maxFeePerBlobGas: a, maxFeePerGas: c, maxPriorityFeePerGas: l, accessList: d, data: u } = t;
    Jh(t);
    let h = t.blobVersionedHashes, p = t.sidecars;
    if (t.blobs && (typeof h > "u" || typeof p > "u")) {
        const x = typeof t.blobs[0] == "string" ? t.blobs : t.blobs.map(($)=>jt($)), E = t.kzg, I = Zl({
            blobs: x,
            kzg: E
        });
        if (typeof h > "u" && (h = Th({
            commitments: I
        })), typeof p > "u") {
            const $ = Gl({
                blobs: x,
                commitments: I,
                kzg: E
            });
            p = Rh({
                blobs: x,
                commitments: I,
                proofs: $
            });
        }
    }
    const v = Jn(d), m = [
        ie(r),
        i ? ie(i) : "0x",
        l ? ie(l) : "0x",
        c ? ie(c) : "0x",
        n ? ie(n) : "0x",
        o ?? "0x",
        s ? ie(s) : "0x",
        u ?? "0x",
        v,
        a ? ie(a) : "0x",
        h ?? [],
        ...un(t, e)
    ], g = [], b = [], y = [];
    if (p) for(let x = 0; x < p.length; x++){
        const { blob: E, commitment: I, proof: $ } = p[x];
        g.push(E), b.push(I), y.push($);
    }
    return dn([
        "0x03",
        hr(p ? [
            m,
            g,
            b,
            y
        ] : m)
    ]);
}
function ip(t, e) {
    const { chainId: r, gas: n, nonce: i, to: o, value: s, maxFeePerGas: a, maxPriorityFeePerGas: c, accessList: l, data: d } = t;
    ka(t);
    const u = Jn(l), h = [
        ie(r),
        i ? ie(i) : "0x",
        c ? ie(c) : "0x",
        a ? ie(a) : "0x",
        n ? ie(n) : "0x",
        o ?? "0x",
        s ? ie(s) : "0x",
        d ?? "0x",
        u,
        ...un(t, e)
    ];
    return dn([
        "0x02",
        hr(h)
    ]);
}
function op(t, e) {
    const { chainId: r, gas: n, data: i, nonce: o, to: s, value: a, accessList: c, gasPrice: l } = t;
    Qh(t);
    const d = Jn(c), u = [
        ie(r),
        o ? ie(o) : "0x",
        l ? ie(l) : "0x",
        n ? ie(n) : "0x",
        s ?? "0x",
        a ? ie(a) : "0x",
        i ?? "0x",
        d,
        ...un(t, e)
    ];
    return dn([
        "0x01",
        hr(u)
    ]);
}
function sp(t, e) {
    const { chainId: r = 0, gas: n, data: i, nonce: o, to: s, value: a, gasPrice: c } = t;
    ep(t);
    let l = [
        o ? ie(o) : "0x",
        c ? ie(c) : "0x",
        n ? ie(n) : "0x",
        s ?? "0x",
        a ? ie(a) : "0x",
        i ?? "0x"
    ];
    if (e) {
        const d = (()=>{
            if (e.v >= 35n) return (e.v - 35n) / 2n > 0 ? e.v : 27n + (e.v === 35n ? 0n : 1n);
            if (r > 0) return BigInt(r * 2) + BigInt(35n + e.v - 27n);
            const p = 27n + (e.v === 27n ? 0n : 1n);
            if (e.v !== p) throw new lh({
                v: e.v
            });
            return p;
        })(), u = sn(e.r), h = sn(e.s);
        l = [
            ...l,
            ie(d),
            u === "0x00" ? "0x" : u,
            h === "0x00" ? "0x" : h
        ];
    } else r > 0 && (l = [
        ...l,
        ie(r),
        "0x",
        "0x"
    ]);
    return hr(l);
}
function un(t, e) {
    const r = e ?? t, { v: n, yParity: i } = r;
    if (typeof r.r > "u") return [];
    if (typeof r.s > "u") return [];
    if (typeof n > "u" && typeof i > "u") return [];
    const o = sn(r.r), s = sn(r.s);
    return [
        typeof i == "number" ? i ? ie(1) : "0x" : n === 0n ? "0x" : n === 1n ? ie(1) : n === 27n ? "0x" : ie(1),
        o === "0x00" ? "0x" : o,
        s === "0x00" ? "0x" : s
    ];
}
function ap(t) {
    if (!t || t.length === 0) return [];
    const e = [];
    for (const r of t){
        const { chainId: n, nonce: i, ...o } = r, s = r.address;
        e.push([
            n ? ie(n) : "0x",
            s,
            i ? ie(i) : "0x",
            ...un({}, o)
        ]);
    }
    return e;
}
const cp = {
    "0x0": "reverted",
    "0x1": "success"
};
function lp(t) {
    const e = {
        ...t,
        blockNumber: t.blockNumber ? BigInt(t.blockNumber) : null,
        contractAddress: t.contractAddress ? t.contractAddress : null,
        cumulativeGasUsed: t.cumulativeGasUsed ? BigInt(t.cumulativeGasUsed) : null,
        effectiveGasPrice: t.effectiveGasPrice ? BigInt(t.effectiveGasPrice) : null,
        gasUsed: t.gasUsed ? BigInt(t.gasUsed) : null,
        logs: t.logs ? t.logs.map((r)=>Uh(r)) : null,
        to: t.to ? t.to : null,
        transactionIndex: t.transactionIndex ? So(t.transactionIndex) : null,
        status: t.status ? cp[t.status] : null,
        type: t.type ? Fl[t.type] || t.type : null
    };
    return t.blobGasPrice && (e.blobGasPrice = BigInt(t.blobGasPrice)), t.blobGasUsed && (e.blobGasUsed = BigInt(t.blobGasUsed)), e;
}
const dp = To("transactionReceipt", lp), up = new Uint8Array([
    7,
    4,
    13,
    1,
    10,
    6,
    15,
    3,
    12,
    0,
    9,
    5,
    2,
    14,
    11,
    8
]), od = new Uint8Array(new Array(16).fill(0).map((t, e)=>e)), hp = od.map((t)=>(9 * t + 5) % 16);
let pp = [
    od
], fp = [
    hp
];
for(let t = 0; t < 4; t++)for (let e of [
    pp,
    fp
])e.push(e[t].map((r)=>up[r])); /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */ 
const Uo = BigInt(0), Mo = BigInt(1), gp = BigInt(2);
function Or(t) {
    return t instanceof Uint8Array || ArrayBuffer.isView(t) && t.constructor.name === "Uint8Array";
}
function Qn(t) {
    if (!Or(t)) throw new Error("Uint8Array expected");
}
function hn(t, e) {
    if (typeof e != "boolean") throw new Error(t + " boolean expected, got " + e);
}
const wp = Array.from({
    length: 256
}, (t, e)=>e.toString(16).padStart(2, "0"));
function pn(t) {
    Qn(t);
    let e = "";
    for(let r = 0; r < t.length; r++)e += wp[t[r]];
    return e;
}
function fn(t) {
    const e = t.toString(16);
    return e.length & 1 ? "0" + e : e;
}
function Ta(t) {
    if (typeof t != "string") throw new Error("hex string expected, got " + typeof t);
    return t === "" ? Uo : BigInt("0x" + t);
}
const Vt = {
    _0: 48,
    _9: 57,
    A: 65,
    F: 70,
    a: 97,
    f: 102
};
function sd(t) {
    if (t >= Vt._0 && t <= Vt._9) return t - Vt._0;
    if (t >= Vt.A && t <= Vt.F) return t - (Vt.A - 10);
    if (t >= Vt.a && t <= Vt.f) return t - (Vt.a - 10);
}
function gn(t) {
    if (typeof t != "string") throw new Error("hex string expected, got " + typeof t);
    const e = t.length, r = e / 2;
    if (e % 2) throw new Error("hex string expected, got unpadded hex of length " + e);
    const n = new Uint8Array(r);
    for(let i = 0, o = 0; i < r; i++, o += 2){
        const s = sd(t.charCodeAt(o)), a = sd(t.charCodeAt(o + 1));
        if (s === void 0 || a === void 0) {
            const c = t[o] + t[o + 1];
            throw new Error('hex string expected, got non-hex character "' + c + '" at index ' + o);
        }
        n[i] = s * 16 + a;
    }
    return n;
}
function $r(t) {
    return Ta(pn(t));
}
function Oa(t) {
    return Qn(t), Ta(pn(Uint8Array.from(t).reverse()));
}
function wn(t, e) {
    return gn(t.toString(16).padStart(e * 2, "0"));
}
function $a(t, e) {
    return wn(t, e).reverse();
}
function mp(t) {
    return gn(fn(t));
}
function xt(t, e, r) {
    let n;
    if (typeof e == "string") try {
        n = gn(e);
    } catch (o) {
        throw new Error(t + " must be hex string or Uint8Array, cause: " + o);
    }
    else if (Or(e)) n = Uint8Array.from(e);
    else throw new Error(t + " must be hex string or Uint8Array");
    const i = n.length;
    if (typeof r == "number" && i !== r) throw new Error(t + " of length " + r + " expected, got " + i);
    return n;
}
function ei(...t) {
    let e = 0;
    for(let n = 0; n < t.length; n++){
        const i = t[n];
        Qn(i), e += i.length;
    }
    const r = new Uint8Array(e);
    for(let n = 0, i = 0; n < t.length; n++){
        const o = t[n];
        r.set(o, i), i += o.length;
    }
    return r;
}
function bp(t, e) {
    if (t.length !== e.length) return !1;
    let r = 0;
    for(let n = 0; n < t.length; n++)r |= t[n] ^ e[n];
    return r === 0;
}
function vp(t) {
    if (typeof t != "string") throw new Error("string expected");
    return new Uint8Array(new TextEncoder().encode(t));
}
const Pa = (t)=>typeof t == "bigint" && Uo <= t;
function Do(t, e, r) {
    return Pa(t) && Pa(e) && Pa(r) && e <= t && t < r;
}
function Pr(t, e, r, n) {
    if (!Do(e, r, n)) throw new Error("expected valid " + t + ": " + r + " <= n < " + n + ", got " + e);
}
function ad(t) {
    let e;
    for(e = 0; t > Uo; t >>= Mo, e += 1);
    return e;
}
function Cp(t, e) {
    return t >> BigInt(e) & Mo;
}
function yp(t, e, r) {
    return t | (r ? Mo : Uo) << BigInt(e);
}
const Ba = (t)=>(gp << BigInt(t - 1)) - Mo, Ra = (t)=>new Uint8Array(t), cd = (t)=>Uint8Array.from(t);
function ld(t, e, r) {
    if (typeof t != "number" || t < 2) throw new Error("hashLen must be a number");
    if (typeof e != "number" || e < 2) throw new Error("qByteLen must be a number");
    if (typeof r != "function") throw new Error("hmacFn must be a function");
    let n = Ra(t), i = Ra(t), o = 0;
    const s = ()=>{
        n.fill(1), i.fill(0), o = 0;
    }, a = (...u)=>r(i, n, ...u), c = (u = Ra())=>{
        i = a(cd([
            0
        ]), u), n = a(), u.length !== 0 && (i = a(cd([
            1
        ]), u), n = a());
    }, l = ()=>{
        if (o++ >= 1e3) throw new Error("drbg: tried 1000 values");
        let u = 0;
        const h = [];
        for(; u < e;){
            n = a();
            const p = n.slice();
            h.push(p), u += n.length;
        }
        return ei(...h);
    };
    return (u, h)=>{
        s(), c(u);
        let p;
        for(; !(p = h(l()));)c();
        return s(), p;
    };
}
const xp = {
    bigint: (t)=>typeof t == "bigint",
    function: (t)=>typeof t == "function",
    boolean: (t)=>typeof t == "boolean",
    string: (t)=>typeof t == "string",
    stringOrUint8Array: (t)=>typeof t == "string" || Or(t),
    isSafeInteger: (t)=>Number.isSafeInteger(t),
    array: (t)=>Array.isArray(t),
    field: (t, e)=>e.Fp.isValid(t),
    hash: (t)=>typeof t == "function" && Number.isSafeInteger(t.outputLen)
};
function ti(t, e, r = {}) {
    const n = (i, o, s)=>{
        const a = xp[o];
        if (typeof a != "function") throw new Error("invalid validator function");
        const c = t[i];
        if (!(s && c === void 0) && !a(c, t)) throw new Error("param " + String(i) + " is invalid. Expected " + o + ", got " + c);
    };
    for (const [i, o] of Object.entries(e))n(i, o, !1);
    for (const [i, o] of Object.entries(r))n(i, o, !0);
    return t;
}
const Ep = ()=>{
    throw new Error("not implemented");
};
function La(t) {
    const e = new WeakMap;
    return (r, ...n)=>{
        const i = e.get(r);
        if (i !== void 0) return i;
        const o = t(r, ...n);
        return e.set(r, o), o;
    };
}
var Ap = Object.freeze({
    __proto__: null,
    isBytes: Or,
    abytes: Qn,
    abool: hn,
    bytesToHex: pn,
    numberToHexUnpadded: fn,
    hexToNumber: Ta,
    hexToBytes: gn,
    bytesToNumberBE: $r,
    bytesToNumberLE: Oa,
    numberToBytesBE: wn,
    numberToBytesLE: $a,
    numberToVarBytesBE: mp,
    ensureBytes: xt,
    concatBytes: ei,
    equalBytes: bp,
    utf8ToBytes: vp,
    inRange: Do,
    aInRange: Pr,
    bitLen: ad,
    bitGet: Cp,
    bitSet: yp,
    bitMask: Ba,
    createHmacDrbg: ld,
    validateObject: ti,
    notImplemented: Ep,
    memoized: La
});
const Sp = "0.1.1";
function _p() {
    return Sp;
}
class Ge extends Error {
    constructor(e, r = {}){
        const n = (()=>{
            if (r.cause instanceof Ge) {
                if (r.cause.details) return r.cause.details;
                if (r.cause.shortMessage) return r.cause.shortMessage;
            }
            return r.cause?.message ? r.cause.message : r.details;
        })(), i = r.cause instanceof Ge && r.cause.docsPath || r.docsPath, s = `https://oxlib.sh${i ?? ""}`, a = [
            e || "An error occurred.",
            ...r.metaMessages ? [
                "",
                ...r.metaMessages
            ] : [],
            ...n || i ? [
                "",
                n ? `Details: ${n}` : void 0,
                i ? `See: ${s}` : void 0
            ] : []
        ].filter((c)=>typeof c == "string").join(`
`);
        super(a, r.cause ? {
            cause: r.cause
        } : void 0), Object.defineProperty(this, "details", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "docs", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "docsPath", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "shortMessage", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "cause", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "name", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: "BaseError"
        }), Object.defineProperty(this, "version", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: `ox@${_p()}`
        }), this.cause = r.cause, this.details = n, this.docs = s, this.docsPath = i, this.shortMessage = e;
    }
    walk(e) {
        return dd(this, e);
    }
}
function dd(t, e) {
    return e?.(t) ? t : t && typeof t == "object" && "cause" in t && t.cause ? dd(t.cause, e) : e ? null : t;
}
function Ip(t, e) {
    if (pd(t) > e) throw new Rp({
        givenSize: pd(t),
        maxSize: e
    });
}
const Zt = {
    zero: 48,
    nine: 57,
    A: 65,
    F: 70,
    a: 97,
    f: 102
};
function ud(t) {
    if (t >= Zt.zero && t <= Zt.nine) return t - Zt.zero;
    if (t >= Zt.A && t <= Zt.F) return t - (Zt.A - 10);
    if (t >= Zt.a && t <= Zt.f) return t - (Zt.a - 10);
}
function Np(t, e = {}) {
    const { dir: r, size: n = 32 } = e;
    if (n === 0) return t;
    if (t.length > n) throw new Lp({
        size: t.length,
        targetSize: n,
        type: "Bytes"
    });
    const i = new Uint8Array(n);
    for(let o = 0; o < n; o++){
        const s = r === "right";
        i[s ? o : n - o - 1] = t[s ? o : t.length - o - 1];
    }
    return i;
}
function Ua(t, e) {
    if (Da(t) > e) throw new Fp({
        givenSize: Da(t),
        maxSize: e
    });
}
function hd(t, e = {}) {
    const { dir: r, size: n = 32 } = e;
    if (n === 0) return t;
    const i = t.replace("0x", "");
    if (i.length > n * 2) throw new Hp({
        size: Math.ceil(i.length / 2),
        targetSize: n,
        type: "Hex"
    });
    return `0x${i[r === "right" ? "padEnd" : "padStart"](n * 2, "0")}`;
}
const kp = new TextEncoder;
function Tp(t) {
    return t instanceof Uint8Array ? t : typeof t == "string" ? $p(t) : Op(t);
}
function Op(t) {
    return t instanceof Uint8Array ? t : new Uint8Array(t);
}
function $p(t, e = {}) {
    const { size: r } = e;
    let n = t;
    r && (Ua(t, r), n = Ma(t, r));
    let i = n.slice(2);
    i.length % 2 && (i = `0${i}`);
    const o = i.length / 2, s = new Uint8Array(o);
    for(let a = 0, c = 0; a < o; a++){
        const l = ud(i.charCodeAt(c++)), d = ud(i.charCodeAt(c++));
        if (l === void 0 || d === void 0) throw new Ge(`Invalid byte sequence ("${i[c - 2]}${i[c - 1]}" in "${i}").`);
        s[a] = l * 16 + d;
    }
    return s;
}
function Pp(t, e = {}) {
    const { size: r } = e, n = kp.encode(t);
    return typeof r == "number" ? (Ip(n, r), Bp(n, r)) : n;
}
function Bp(t, e) {
    return Np(t, {
        dir: "right",
        size: e
    });
}
function pd(t) {
    return t.length;
}
class Rp extends Ge {
    constructor({ givenSize: e, maxSize: r }){
        super(`Size cannot exceed \`${r}\` bytes. Given size: \`${e}\` bytes.`), Object.defineProperty(this, "name", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: "Bytes.SizeOverflowError"
        });
    }
}
class Lp extends Ge {
    constructor({ size: e, targetSize: r, type: n }){
        super(`${n.charAt(0).toUpperCase()}${n.slice(1).toLowerCase()} size (\`${e}\`) exceeds padding size (\`${r}\`).`), Object.defineProperty(this, "name", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: "Bytes.SizeExceedsPaddingSizeError"
        });
    }
}
const Up = new TextEncoder, Mp = Array.from({
    length: 256
}, (t, e)=>e.toString(16).padStart(2, "0"));
function fd(...t) {
    return `0x${t.reduce((e, r)=>e + r.replace("0x", ""), "")}`;
}
function Dp(t, e = {}) {
    const r = `0x${Number(t)}`;
    return typeof e.size == "number" ? (Ua(r, e.size), zo(r, e.size)) : r;
}
function gd(t, e = {}) {
    let r = "";
    for(let i = 0; i < t.length; i++)r += Mp[t[i]];
    const n = `0x${r}`;
    return typeof e.size == "number" ? (Ua(n, e.size), Ma(n, e.size)) : n;
}
function zp(t, e = {}) {
    const { signed: r, size: n } = e, i = BigInt(t);
    let o;
    n ? r ? o = (1n << BigInt(n) * 8n - 1n) - 1n : o = 2n ** (BigInt(n) * 8n) - 1n : typeof t == "number" && (o = BigInt(Number.MAX_SAFE_INTEGER));
    const s = typeof o == "bigint" && r ? -o - 1n : 0;
    if (o && i > o || i < s) {
        const l = typeof t == "bigint" ? "n" : "";
        throw new jp({
            max: o ? `${o}${l}` : void 0,
            min: `${s}${l}`,
            signed: r,
            size: n,
            value: `${t}${l}`
        });
    }
    const c = `0x${(r && i < 0 ? (1n << BigInt(n * 8)) + BigInt(i) : i).toString(16)}`;
    return n ? zo(c, n) : c;
}
function Wp(t, e = {}) {
    return gd(Up.encode(t), e);
}
function zo(t, e) {
    return hd(t, {
        dir: "left",
        size: e
    });
}
function Ma(t, e) {
    return hd(t, {
        dir: "right",
        size: e
    });
}
function Da(t) {
    return Math.ceil((t.length - 2) / 2);
}
class jp extends Ge {
    constructor({ max: e, min: r, signed: n, size: i, value: o }){
        super(`Number \`${o}\` is not in safe${i ? ` ${i * 8}-bit` : ""}${n ? " signed" : " unsigned"} integer range ${e ? `(\`${r}\` to \`${e}\`)` : `(above \`${r}\`)`}`), Object.defineProperty(this, "name", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: "Hex.IntegerOutOfRangeError"
        });
    }
}
class Fp extends Ge {
    constructor({ givenSize: e, maxSize: r }){
        super(`Size cannot exceed \`${r}\` bytes. Given size: \`${e}\` bytes.`), Object.defineProperty(this, "name", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: "Hex.SizeOverflowError"
        });
    }
}
class Hp extends Ge {
    constructor({ size: e, targetSize: r, type: n }){
        super(`${n.charAt(0).toUpperCase()}${n.slice(1).toLowerCase()} size (\`${e}\`) exceeds padding size (\`${r}\`).`), Object.defineProperty(this, "name", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: "Hex.SizeExceedsPaddingSizeError"
        });
    }
}
function Vp(t, e = {}) {
    const { as: r = typeof t == "string" ? "Hex" : "Bytes" } = e, n = Pl(Tp(t));
    return r === "Bytes" ? n : gd(n);
}
class Zp extends Map {
    constructor(e){
        super(), Object.defineProperty(this, "maxSize", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.maxSize = e;
    }
    get(e) {
        const r = super.get(e);
        return super.has(e) && r !== void 0 && (this.delete(e), super.set(e, r)), r;
    }
    set(e, r) {
        if (super.set(e, r), this.maxSize && this.size > this.maxSize) {
            const n = this.keys().next().value;
            n && this.delete(n);
        }
        return this;
    }
}
const Gp = {
    checksum: new Zp(8192)
}, za = Gp.checksum, qp = /^0x[a-fA-F0-9]{40}$/;
function wd(t, e = {}) {
    const { strict: r = !0 } = e;
    if (!qp.test(t)) throw new md({
        address: t,
        cause: new Yp
    });
    if (r) {
        if (t.toLowerCase() === t) return;
        if (Kp(t) !== t) throw new md({
            address: t,
            cause: new Xp
        });
    }
}
function Kp(t) {
    if (za.has(t)) return za.get(t);
    wd(t, {
        strict: !1
    });
    const e = t.substring(2).toLowerCase(), r = Vp(Pp(e), {
        as: "Bytes"
    }), n = e.split("");
    for(let o = 0; o < 40; o += 2)r[o >> 1] >> 4 >= 8 && n[o] && (n[o] = n[o].toUpperCase()), (r[o >> 1] & 15) >= 8 && n[o + 1] && (n[o + 1] = n[o + 1].toUpperCase());
    const i = `0x${n.join("")}`;
    return za.set(t, i), i;
}
class md extends Ge {
    constructor({ address: e, cause: r }){
        super(`Address "${e}" is invalid.`, {
            cause: r
        }), Object.defineProperty(this, "name", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: "Address.InvalidAddressError"
        });
    }
}
class Yp extends Ge {
    constructor(){
        super("Address is not a 20 byte (40 hexadecimal character) value."), Object.defineProperty(this, "name", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: "Address.InvalidInputError"
        });
    }
}
class Xp extends Ge {
    constructor(){
        super("Address does not match its checksum counterpart."), Object.defineProperty(this, "name", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: "Address.InvalidChecksumError"
        });
    }
}
const Jp = /^(.*)\[([0-9]*)\]$/, Qp = /^bytes([1-9]|1[0-9]|2[0-9]|3[0-2])?$/, ef = /^(u?int)(8|16|24|32|40|48|56|64|72|80|88|96|104|112|120|128|136|144|152|160|168|176|184|192|200|208|216|224|232|240|248|256)?$/;
function Wa(t, e) {
    if (t.length !== e.length) throw new rf({
        expectedLength: t.length,
        givenLength: e.length
    });
    const r = [];
    for(let n = 0; n < t.length; n++){
        const i = t[n], o = e[n];
        r.push(Wa.encode(i, o));
    }
    return fd(...r);
}
(function(t) {
    function e(r, n, i = !1) {
        if (r === "address") {
            const c = n;
            return wd(c), zo(c.toLowerCase(), i ? 32 : 0);
        }
        if (r === "string") return Wp(n);
        if (r === "bytes") return n;
        if (r === "bool") return zo(Dp(n), i ? 32 : 1);
        const o = r.match(ef);
        if (o) {
            const [c, l, d = "256"] = o, u = Number.parseInt(d) / 8;
            return zp(n, {
                size: i ? 32 : u,
                signed: l === "int"
            });
        }
        const s = r.match(Qp);
        if (s) {
            const [c, l] = s;
            if (Number.parseInt(l) !== (n.length - 2) / 2) throw new tf({
                expectedSize: Number.parseInt(l),
                value: n
            });
            return Ma(n, i ? 32 : 0);
        }
        const a = r.match(Jp);
        if (a && Array.isArray(n)) {
            const [c, l] = a, d = [];
            for(let u = 0; u < n.length; u++)d.push(e(l, n[u], !0));
            return d.length === 0 ? "0x" : fd(...d);
        }
        throw new nf(r);
    }
    t.encode = e;
})(Wa || (Wa = {}));
class tf extends Ge {
    constructor({ expectedSize: e, value: r }){
        super(`Size of bytes "${r}" (bytes${Da(r)}) does not match expected size (bytes${e}).`), Object.defineProperty(this, "name", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: "AbiParameters.BytesSizeMismatchError"
        });
    }
}
class rf extends Ge {
    constructor({ expectedLength: e, givenLength: r }){
        super([
            "ABI encoding parameters/values length mismatch.",
            `Expected length (parameters): ${e}`,
            `Given length (values): ${r}`
        ].join(`
`)), Object.defineProperty(this, "name", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: "AbiParameters.LengthMismatchError"
        });
    }
}
class nf extends Ge {
    constructor(e){
        super(`Type \`${e}\` is not a valid ABI Type.`), Object.defineProperty(this, "name", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: "AbiParameters.InvalidTypeError"
        });
    }
}
class bd extends va {
    constructor(e, r){
        super(), this.finished = !1, this.destroyed = !1, O1(e);
        const n = No(r);
        if (this.iHash = e.create(), typeof this.iHash.update != "function") throw new Error("Expected instance of class which extends utils.Hash");
        this.blockLen = this.iHash.blockLen, this.outputLen = this.iHash.outputLen;
        const i = this.blockLen, o = new Uint8Array(i);
        o.set(n.length > i ? e.create().update(n).digest() : n);
        for(let s = 0; s < o.length; s++)o[s] ^= 54;
        this.iHash.update(o), this.oHash = e.create();
        for(let s = 0; s < o.length; s++)o[s] ^= 106;
        this.oHash.update(o), o.fill(0);
    }
    update(e) {
        return cn(this), this.iHash.update(e), this;
    }
    digestInto(e) {
        cn(this), Gn(e, this.outputLen), this.finished = !0, this.iHash.digestInto(e), this.oHash.update(e), this.oHash.digestInto(e), this.destroy();
    }
    digest() {
        const e = new Uint8Array(this.oHash.outputLen);
        return this.digestInto(e), e;
    }
    _cloneInto(e) {
        e || (e = Object.create(Object.getPrototypeOf(this), {}));
        const { oHash: r, iHash: n, finished: i, destroyed: o, blockLen: s, outputLen: a } = this;
        return e = e, e.finished = i, e.destroyed = o, e.blockLen = s, e.outputLen = a, e.oHash = r._cloneInto(e.oHash), e.iHash = n._cloneInto(e.iHash), e;
    }
    destroy() {
        this.destroyed = !0, this.oHash.destroy(), this.iHash.destroy();
    }
}
const vd = (t, e, r)=>new bd(t, e).update(r).digest();
vd.create = (t, e)=>new bd(t, e);
const Le = BigInt(0), Ie = BigInt(1), Br = BigInt(2), of = BigInt(3), ja = BigInt(4), Cd = BigInt(5), yd = BigInt(8);
function Je(t, e) {
    const r = t % e;
    return r >= Le ? r : e + r;
}
function sf(t, e, r) {
    if (e < Le) throw new Error("invalid exponent, negatives unsupported");
    if (r <= Le) throw new Error("invalid modulus");
    if (r === Ie) return Le;
    let n = Ie;
    for(; e > Le;)e & Ie && (n = n * t % r), t = t * t % r, e >>= Ie;
    return n;
}
function pt(t, e, r) {
    let n = t;
    for(; e-- > Le;)n *= n, n %= r;
    return n;
}
function Fa(t, e) {
    if (t === Le) throw new Error("invert: expected non-zero number");
    if (e <= Le) throw new Error("invert: expected positive modulus, got " + e);
    let r = Je(t, e), n = e, i = Le, o = Ie;
    for(; r !== Le;){
        const a = n / r, c = n % r, l = i - o * a;
        n = r, r = c, i = o, o = l;
    }
    if (n !== Ie) throw new Error("invert: does not exist");
    return Je(i, e);
}
function af(t) {
    const e = (t - Ie) / Br;
    let r, n, i;
    for(r = t - Ie, n = 0; r % Br === Le; r /= Br, n++);
    for(i = Br; i < t && sf(i, e, t) !== t - Ie; i++)if (i > 1e3) throw new Error("Cannot find square root: likely non-prime P");
    if (n === 1) {
        const s = (t + Ie) / ja;
        return function(c, l) {
            const d = c.pow(l, s);
            if (!c.eql(c.sqr(d), l)) throw new Error("Cannot find square root");
            return d;
        };
    }
    const o = (r + Ie) / Br;
    return function(a, c) {
        if (a.pow(c, e) === a.neg(a.ONE)) throw new Error("Cannot find square root");
        let l = n, d = a.pow(a.mul(a.ONE, i), r), u = a.pow(c, o), h = a.pow(c, r);
        for(; !a.eql(h, a.ONE);){
            if (a.eql(h, a.ZERO)) return a.ZERO;
            let p = 1;
            for(let m = a.sqr(h); p < l && !a.eql(m, a.ONE); p++)m = a.sqr(m);
            const v = a.pow(d, Ie << BigInt(l - p - 1));
            d = a.sqr(v), u = a.mul(u, v), h = a.mul(h, d), l = p;
        }
        return u;
    };
}
function cf(t) {
    if (t % ja === of) {
        const e = (t + Ie) / ja;
        return function(n, i) {
            const o = n.pow(i, e);
            if (!n.eql(n.sqr(o), i)) throw new Error("Cannot find square root");
            return o;
        };
    }
    if (t % yd === Cd) {
        const e = (t - Cd) / yd;
        return function(n, i) {
            const o = n.mul(i, Br), s = n.pow(o, e), a = n.mul(i, s), c = n.mul(n.mul(a, Br), s), l = n.mul(a, n.sub(c, n.ONE));
            if (!n.eql(n.sqr(l), i)) throw new Error("Cannot find square root");
            return l;
        };
    }
    return af(t);
}
const lf = [
    "create",
    "isValid",
    "is0",
    "neg",
    "inv",
    "sqrt",
    "sqr",
    "eql",
    "add",
    "sub",
    "mul",
    "pow",
    "div",
    "addN",
    "subN",
    "mulN",
    "sqrN"
];
function df(t) {
    const e = {
        ORDER: "bigint",
        MASK: "bigint",
        BYTES: "isSafeInteger",
        BITS: "isSafeInteger"
    }, r = lf.reduce((n, i)=>(n[i] = "function", n), e);
    return ti(t, r);
}
function uf(t, e, r) {
    if (r < Le) throw new Error("invalid exponent, negatives unsupported");
    if (r === Le) return t.ONE;
    if (r === Ie) return e;
    let n = t.ONE, i = e;
    for(; r > Le;)r & Ie && (n = t.mul(n, i)), i = t.sqr(i), r >>= Ie;
    return n;
}
function hf(t, e) {
    const r = new Array(e.length), n = e.reduce((o, s, a)=>t.is0(s) ? o : (r[a] = o, t.mul(o, s)), t.ONE), i = t.inv(n);
    return e.reduceRight((o, s, a)=>t.is0(s) ? o : (r[a] = t.mul(o, r[a]), t.mul(o, s)), i), r;
}
function xd(t, e) {
    const r = e !== void 0 ? e : t.toString(2).length, n = Math.ceil(r / 8);
    return {
        nBitLength: r,
        nByteLength: n
    };
}
function Ed(t, e, r = !1, n = {}) {
    if (t <= Le) throw new Error("invalid field: expected ORDER > 0, got " + t);
    const { nBitLength: i, nByteLength: o } = xd(t, e);
    if (o > 2048) throw new Error("invalid field: expected ORDER of <= 2048 bytes");
    let s;
    const a = Object.freeze({
        ORDER: t,
        isLE: r,
        BITS: i,
        BYTES: o,
        MASK: Ba(i),
        ZERO: Le,
        ONE: Ie,
        create: (c)=>Je(c, t),
        isValid: (c)=>{
            if (typeof c != "bigint") throw new Error("invalid field element: expected bigint, got " + typeof c);
            return Le <= c && c < t;
        },
        is0: (c)=>c === Le,
        isOdd: (c)=>(c & Ie) === Ie,
        neg: (c)=>Je(-c, t),
        eql: (c, l)=>c === l,
        sqr: (c)=>Je(c * c, t),
        add: (c, l)=>Je(c + l, t),
        sub: (c, l)=>Je(c - l, t),
        mul: (c, l)=>Je(c * l, t),
        pow: (c, l)=>uf(a, c, l),
        div: (c, l)=>Je(c * Fa(l, t), t),
        sqrN: (c)=>c * c,
        addN: (c, l)=>c + l,
        subN: (c, l)=>c - l,
        mulN: (c, l)=>c * l,
        inv: (c)=>Fa(c, t),
        sqrt: n.sqrt || ((c)=>(s || (s = cf(t)), s(a, c))),
        invertBatch: (c)=>hf(a, c),
        cmov: (c, l, d)=>d ? l : c,
        toBytes: (c)=>r ? $a(c, o) : wn(c, o),
        fromBytes: (c)=>{
            if (c.length !== o) throw new Error("Field.fromBytes: expected " + o + " bytes, got " + c.length);
            return r ? Oa(c) : $r(c);
        }
    });
    return Object.freeze(a);
}
function Ad(t) {
    if (typeof t != "bigint") throw new Error("field order must be bigint");
    const e = t.toString(2).length;
    return Math.ceil(e / 8);
}
function Sd(t) {
    const e = Ad(t);
    return e + Math.ceil(e / 2);
}
function pf(t, e, r = !1) {
    const n = t.length, i = Ad(e), o = Sd(e);
    if (n < 16 || n < o || n > 1024) throw new Error("expected " + o + "-1024 bytes of input, got " + n);
    const s = r ? Oa(t) : $r(t), a = Je(s, e - Ie) + Ie;
    return r ? $a(a, i) : wn(a, i);
}
const _d = BigInt(0), Wo = BigInt(1);
function Ha(t, e) {
    const r = e.negate();
    return t ? r : e;
}
function Id(t, e) {
    if (!Number.isSafeInteger(t) || t <= 0 || t > e) throw new Error("invalid window size, expected [1.." + e + "], got W=" + t);
}
function Va(t, e) {
    Id(t, e);
    const r = Math.ceil(e / t) + 1, n = 2 ** (t - 1);
    return {
        windows: r,
        windowSize: n
    };
}
function ff(t, e) {
    if (!Array.isArray(t)) throw new Error("array expected");
    t.forEach((r, n)=>{
        if (!(r instanceof e)) throw new Error("invalid point at index " + n);
    });
}
function gf(t, e) {
    if (!Array.isArray(t)) throw new Error("array of scalars expected");
    t.forEach((r, n)=>{
        if (!e.isValid(r)) throw new Error("invalid scalar at index " + n);
    });
}
const Za = new WeakMap, Nd = new WeakMap;
function Ga(t) {
    return Nd.get(t) || 1;
}
function wf(t, e) {
    return {
        constTimeNegate: Ha,
        hasPrecomputes (r) {
            return Ga(r) !== 1;
        },
        unsafeLadder (r, n, i = t.ZERO) {
            let o = r;
            for(; n > _d;)n & Wo && (i = i.add(o)), o = o.double(), n >>= Wo;
            return i;
        },
        precomputeWindow (r, n) {
            const { windows: i, windowSize: o } = Va(n, e), s = [];
            let a = r, c = a;
            for(let l = 0; l < i; l++){
                c = a, s.push(c);
                for(let d = 1; d < o; d++)c = c.add(a), s.push(c);
                a = c.double();
            }
            return s;
        },
        wNAF (r, n, i) {
            const { windows: o, windowSize: s } = Va(r, e);
            let a = t.ZERO, c = t.BASE;
            const l = BigInt(2 ** r - 1), d = 2 ** r, u = BigInt(r);
            for(let h = 0; h < o; h++){
                const p = h * s;
                let v = Number(i & l);
                i >>= u, v > s && (v -= d, i += Wo);
                const m = p, g = p + Math.abs(v) - 1, b = h % 2 !== 0, y = v < 0;
                v === 0 ? c = c.add(Ha(b, n[m])) : a = a.add(Ha(y, n[g]));
            }
            return {
                p: a,
                f: c
            };
        },
        wNAFUnsafe (r, n, i, o = t.ZERO) {
            const { windows: s, windowSize: a } = Va(r, e), c = BigInt(2 ** r - 1), l = 2 ** r, d = BigInt(r);
            for(let u = 0; u < s; u++){
                const h = u * a;
                if (i === _d) break;
                let p = Number(i & c);
                if (i >>= d, p > a && (p -= l, i += Wo), p === 0) continue;
                let v = n[h + Math.abs(p) - 1];
                p < 0 && (v = v.negate()), o = o.add(v);
            }
            return o;
        },
        getPrecomputes (r, n, i) {
            let o = Za.get(n);
            return o || (o = this.precomputeWindow(n, r), r !== 1 && Za.set(n, i(o))), o;
        },
        wNAFCached (r, n, i) {
            const o = Ga(r);
            return this.wNAF(o, this.getPrecomputes(o, r, i), n);
        },
        wNAFCachedUnsafe (r, n, i, o) {
            const s = Ga(r);
            return s === 1 ? this.unsafeLadder(r, n, o) : this.wNAFUnsafe(s, this.getPrecomputes(s, r, i), n, o);
        },
        setWindowSize (r, n) {
            Id(n, e), Nd.set(r, n), Za.delete(r);
        }
    };
}
function mf(t, e, r, n) {
    if (ff(r, t), gf(n, e), r.length !== n.length) throw new Error("arrays of points and scalars must have equal length");
    const i = t.ZERO, o = ad(BigInt(r.length)), s = o > 12 ? o - 3 : o > 4 ? o - 2 : o ? 2 : 1, a = (1 << s) - 1, c = new Array(a + 1).fill(i), l = Math.floor((e.BITS - 1) / s) * s;
    let d = i;
    for(let u = l; u >= 0; u -= s){
        c.fill(i);
        for(let p = 0; p < n.length; p++){
            const v = n[p], m = Number(v >> BigInt(u) & BigInt(a));
            c[m] = c[m].add(r[p]);
        }
        let h = i;
        for(let p = c.length - 1, v = i; p > 0; p--)v = v.add(c[p]), h = h.add(v);
        if (d = d.add(h), u !== 0) for(let p = 0; p < s; p++)d = d.double();
    }
    return d;
}
function kd(t) {
    return df(t.Fp), ti(t, {
        n: "bigint",
        h: "bigint",
        Gx: "field",
        Gy: "field"
    }, {
        nBitLength: "isSafeInteger",
        nByteLength: "isSafeInteger"
    }), Object.freeze({
        ...xd(t.n, t.nBitLength),
        ...t,
        p: t.Fp.ORDER
    });
}
function Td(t) {
    t.lowS !== void 0 && hn("lowS", t.lowS), t.prehash !== void 0 && hn("prehash", t.prehash);
}
function bf(t) {
    const e = kd(t);
    ti(e, {
        a: "field",
        b: "field"
    }, {
        allowedPrivateKeyLengths: "array",
        wrapPrivateKey: "boolean",
        isTorsionFree: "function",
        clearCofactor: "function",
        allowInfinityPoint: "boolean",
        fromBytes: "function",
        toBytes: "function"
    });
    const { endo: r, Fp: n, a: i } = e;
    if (r) {
        if (!n.eql(i, n.ZERO)) throw new Error("invalid endomorphism, can only be defined for Koblitz curves that have a=0");
        if (typeof r != "object" || typeof r.beta != "bigint" || typeof r.splitScalar != "function") throw new Error("invalid endomorphism, expected beta: bigint and splitScalar: function");
    }
    return Object.freeze({
        ...e
    });
}
const { bytesToNumberBE: vf, hexToBytes: Cf } = Ap;
class yf extends Error {
    constructor(e = ""){
        super(e);
    }
}
const Gt = {
    Err: yf,
    _tlv: {
        encode: (t, e)=>{
            const { Err: r } = Gt;
            if (t < 0 || t > 256) throw new r("tlv.encode: wrong tag");
            if (e.length & 1) throw new r("tlv.encode: unpadded data");
            const n = e.length / 2, i = fn(n);
            if (i.length / 2 & 128) throw new r("tlv.encode: long form length too big");
            const o = n > 127 ? fn(i.length / 2 | 128) : "";
            return fn(t) + o + i + e;
        },
        decode (t, e) {
            const { Err: r } = Gt;
            let n = 0;
            if (t < 0 || t > 256) throw new r("tlv.encode: wrong tag");
            if (e.length < 2 || e[n++] !== t) throw new r("tlv.decode: wrong tlv");
            const i = e[n++], o = !!(i & 128);
            let s = 0;
            if (!o) s = i;
            else {
                const c = i & 127;
                if (!c) throw new r("tlv.decode(long): indefinite length not supported");
                if (c > 4) throw new r("tlv.decode(long): byte length is too big");
                const l = e.subarray(n, n + c);
                if (l.length !== c) throw new r("tlv.decode: length bytes not complete");
                if (l[0] === 0) throw new r("tlv.decode(long): zero leftmost byte");
                for (const d of l)s = s << 8 | d;
                if (n += c, s < 128) throw new r("tlv.decode(long): not minimal encoding");
            }
            const a = e.subarray(n, n + s);
            if (a.length !== s) throw new r("tlv.decode: wrong value length");
            return {
                v: a,
                l: e.subarray(n + s)
            };
        }
    },
    _int: {
        encode (t) {
            const { Err: e } = Gt;
            if (t < qt) throw new e("integer: negative integers are not allowed");
            let r = fn(t);
            if (Number.parseInt(r[0], 16) & 8 && (r = "00" + r), r.length & 1) throw new e("unexpected DER parsing assertion: unpadded hex");
            return r;
        },
        decode (t) {
            const { Err: e } = Gt;
            if (t[0] & 128) throw new e("invalid signature integer: negative");
            if (t[0] === 0 && !(t[1] & 128)) throw new e("invalid signature integer: unnecessary leading zero");
            return vf(t);
        }
    },
    toSig (t) {
        const { Err: e, _int: r, _tlv: n } = Gt, i = typeof t == "string" ? Cf(t) : t;
        Qn(i);
        const { v: o, l: s } = n.decode(48, i);
        if (s.length) throw new e("invalid signature: left bytes after parsing");
        const { v: a, l: c } = n.decode(2, o), { v: l, l: d } = n.decode(2, c);
        if (d.length) throw new e("invalid signature: left bytes after parsing");
        return {
            r: r.decode(a),
            s: r.decode(l)
        };
    },
    hexFromSig (t) {
        const { _tlv: e, _int: r } = Gt, n = e.encode(2, r.encode(t.r)), i = e.encode(2, r.encode(t.s)), o = n + i;
        return e.encode(48, o);
    }
}, qt = BigInt(0), Ue = BigInt(1);
BigInt(2);
const Od = BigInt(3);
BigInt(4);
function xf(t) {
    const e = bf(t), { Fp: r } = e, n = Ed(e.n, e.nBitLength), i = e.toBytes || ((m, g, b)=>{
        const y = g.toAffine();
        return ei(Uint8Array.from([
            4
        ]), r.toBytes(y.x), r.toBytes(y.y));
    }), o = e.fromBytes || ((m)=>{
        const g = m.subarray(1), b = r.fromBytes(g.subarray(0, r.BYTES)), y = r.fromBytes(g.subarray(r.BYTES, 2 * r.BYTES));
        return {
            x: b,
            y
        };
    });
    function s(m) {
        const { a: g, b } = e, y = r.sqr(m), x = r.mul(y, m);
        return r.add(r.add(x, r.mul(m, g)), b);
    }
    if (!r.eql(r.sqr(e.Gy), s(e.Gx))) throw new Error("bad generator point: equation left != right");
    function a(m) {
        return Do(m, Ue, e.n);
    }
    function c(m) {
        const { allowedPrivateKeyLengths: g, nByteLength: b, wrapPrivateKey: y, n: x } = e;
        if (g && typeof m != "bigint") {
            if (Or(m) && (m = pn(m)), typeof m != "string" || !g.includes(m.length)) throw new Error("invalid private key");
            m = m.padStart(b * 2, "0");
        }
        let E;
        try {
            E = typeof m == "bigint" ? m : $r(xt("private key", m, b));
        } catch  {
            throw new Error("invalid private key, expected hex or " + b + " bytes, got " + typeof m);
        }
        return y && (E = Je(E, x)), Pr("private key", E, Ue, x), E;
    }
    function l(m) {
        if (!(m instanceof h)) throw new Error("ProjectivePoint expected");
    }
    const d = La((m, g)=>{
        const { px: b, py: y, pz: x } = m;
        if (r.eql(x, r.ONE)) return {
            x: b,
            y
        };
        const E = m.is0();
        g == null && (g = E ? r.ONE : r.inv(x));
        const I = r.mul(b, g), $ = r.mul(y, g), L = r.mul(x, g);
        if (E) return {
            x: r.ZERO,
            y: r.ZERO
        };
        if (!r.eql(L, r.ONE)) throw new Error("invZ was invalid");
        return {
            x: I,
            y: $
        };
    }), u = La((m)=>{
        if (m.is0()) {
            if (e.allowInfinityPoint && !r.is0(m.py)) return;
            throw new Error("bad point: ZERO");
        }
        const { x: g, y: b } = m.toAffine();
        if (!r.isValid(g) || !r.isValid(b)) throw new Error("bad point: x or y not FE");
        const y = r.sqr(b), x = s(g);
        if (!r.eql(y, x)) throw new Error("bad point: equation left != right");
        if (!m.isTorsionFree()) throw new Error("bad point: not in prime-order subgroup");
        return !0;
    });
    class h {
        constructor(g, b, y){
            if (this.px = g, this.py = b, this.pz = y, g == null || !r.isValid(g)) throw new Error("x required");
            if (b == null || !r.isValid(b)) throw new Error("y required");
            if (y == null || !r.isValid(y)) throw new Error("z required");
            Object.freeze(this);
        }
        static fromAffine(g) {
            const { x: b, y } = g || {};
            if (!g || !r.isValid(b) || !r.isValid(y)) throw new Error("invalid affine point");
            if (g instanceof h) throw new Error("projective point not allowed");
            const x = (E)=>r.eql(E, r.ZERO);
            return x(b) && x(y) ? h.ZERO : new h(b, y, r.ONE);
        }
        get x() {
            return this.toAffine().x;
        }
        get y() {
            return this.toAffine().y;
        }
        static normalizeZ(g) {
            const b = r.invertBatch(g.map((y)=>y.pz));
            return g.map((y, x)=>y.toAffine(b[x])).map(h.fromAffine);
        }
        static fromHex(g) {
            const b = h.fromAffine(o(xt("pointHex", g)));
            return b.assertValidity(), b;
        }
        static fromPrivateKey(g) {
            return h.BASE.multiply(c(g));
        }
        static msm(g, b) {
            return mf(h, n, g, b);
        }
        _setWindowSize(g) {
            v.setWindowSize(this, g);
        }
        assertValidity() {
            u(this);
        }
        hasEvenY() {
            const { y: g } = this.toAffine();
            if (r.isOdd) return !r.isOdd(g);
            throw new Error("Field doesn't support isOdd");
        }
        equals(g) {
            l(g);
            const { px: b, py: y, pz: x } = this, { px: E, py: I, pz: $ } = g, L = r.eql(r.mul(b, $), r.mul(E, x)), Z = r.eql(r.mul(y, $), r.mul(I, x));
            return L && Z;
        }
        negate() {
            return new h(this.px, r.neg(this.py), this.pz);
        }
        double() {
            const { a: g, b } = e, y = r.mul(b, Od), { px: x, py: E, pz: I } = this;
            let $ = r.ZERO, L = r.ZERO, Z = r.ZERO, B = r.mul(x, x), R = r.mul(E, E), N = r.mul(I, I), ee = r.mul(x, E);
            return ee = r.add(ee, ee), Z = r.mul(x, I), Z = r.add(Z, Z), $ = r.mul(g, Z), L = r.mul(y, N), L = r.add($, L), $ = r.sub(R, L), L = r.add(R, L), L = r.mul($, L), $ = r.mul(ee, $), Z = r.mul(y, Z), N = r.mul(g, N), ee = r.sub(B, N), ee = r.mul(g, ee), ee = r.add(ee, Z), Z = r.add(B, B), B = r.add(Z, B), B = r.add(B, N), B = r.mul(B, ee), L = r.add(L, B), N = r.mul(E, I), N = r.add(N, N), B = r.mul(N, ee), $ = r.sub($, B), Z = r.mul(N, R), Z = r.add(Z, Z), Z = r.add(Z, Z), new h($, L, Z);
        }
        add(g) {
            l(g);
            const { px: b, py: y, pz: x } = this, { px: E, py: I, pz: $ } = g;
            let L = r.ZERO, Z = r.ZERO, B = r.ZERO;
            const R = e.a, N = r.mul(e.b, Od);
            let ee = r.mul(b, E), pe = r.mul(y, I), _ = r.mul(x, $), S = r.add(b, y), A = r.add(E, I);
            S = r.mul(S, A), A = r.add(ee, pe), S = r.sub(S, A), A = r.add(b, x);
            let P = r.add(E, $);
            return A = r.mul(A, P), P = r.add(ee, _), A = r.sub(A, P), P = r.add(y, x), L = r.add(I, $), P = r.mul(P, L), L = r.add(pe, _), P = r.sub(P, L), B = r.mul(R, A), L = r.mul(N, _), B = r.add(L, B), L = r.sub(pe, B), B = r.add(pe, B), Z = r.mul(L, B), pe = r.add(ee, ee), pe = r.add(pe, ee), _ = r.mul(R, _), A = r.mul(N, A), pe = r.add(pe, _), _ = r.sub(ee, _), _ = r.mul(R, _), A = r.add(A, _), ee = r.mul(pe, A), Z = r.add(Z, ee), ee = r.mul(P, A), L = r.mul(S, L), L = r.sub(L, ee), ee = r.mul(S, pe), B = r.mul(P, B), B = r.add(B, ee), new h(L, Z, B);
        }
        subtract(g) {
            return this.add(g.negate());
        }
        is0() {
            return this.equals(h.ZERO);
        }
        wNAF(g) {
            return v.wNAFCached(this, g, h.normalizeZ);
        }
        multiplyUnsafe(g) {
            const { endo: b, n: y } = e;
            Pr("scalar", g, qt, y);
            const x = h.ZERO;
            if (g === qt) return x;
            if (this.is0() || g === Ue) return this;
            if (!b || v.hasPrecomputes(this)) return v.wNAFCachedUnsafe(this, g, h.normalizeZ);
            let { k1neg: E, k1: I, k2neg: $, k2: L } = b.splitScalar(g), Z = x, B = x, R = this;
            for(; I > qt || L > qt;)I & Ue && (Z = Z.add(R)), L & Ue && (B = B.add(R)), R = R.double(), I >>= Ue, L >>= Ue;
            return E && (Z = Z.negate()), $ && (B = B.negate()), B = new h(r.mul(B.px, b.beta), B.py, B.pz), Z.add(B);
        }
        multiply(g) {
            const { endo: b, n: y } = e;
            Pr("scalar", g, Ue, y);
            let x, E;
            if (b) {
                const { k1neg: I, k1: $, k2neg: L, k2: Z } = b.splitScalar(g);
                let { p: B, f: R } = this.wNAF($), { p: N, f: ee } = this.wNAF(Z);
                B = v.constTimeNegate(I, B), N = v.constTimeNegate(L, N), N = new h(r.mul(N.px, b.beta), N.py, N.pz), x = B.add(N), E = R.add(ee);
            } else {
                const { p: I, f: $ } = this.wNAF(g);
                x = I, E = $;
            }
            return h.normalizeZ([
                x,
                E
            ])[0];
        }
        multiplyAndAddUnsafe(g, b, y) {
            const x = h.BASE, E = ($, L)=>L === qt || L === Ue || !$.equals(x) ? $.multiplyUnsafe(L) : $.multiply(L), I = E(this, b).add(E(g, y));
            return I.is0() ? void 0 : I;
        }
        toAffine(g) {
            return d(this, g);
        }
        isTorsionFree() {
            const { h: g, isTorsionFree: b } = e;
            if (g === Ue) return !0;
            if (b) return b(h, this);
            throw new Error("isTorsionFree() has not been declared for the elliptic curve");
        }
        clearCofactor() {
            const { h: g, clearCofactor: b } = e;
            return g === Ue ? this : b ? b(h, this) : this.multiplyUnsafe(e.h);
        }
        toRawBytes(g = !0) {
            return hn("isCompressed", g), this.assertValidity(), i(h, this, g);
        }
        toHex(g = !0) {
            return hn("isCompressed", g), pn(this.toRawBytes(g));
        }
    }
    h.BASE = new h(e.Gx, e.Gy, r.ONE), h.ZERO = new h(r.ZERO, r.ONE, r.ZERO);
    const p = e.nBitLength, v = wf(h, e.endo ? Math.ceil(p / 2) : p);
    return {
        CURVE: e,
        ProjectivePoint: h,
        normPrivateKeyToScalar: c,
        weierstrassEquation: s,
        isWithinCurveOrder: a
    };
}
function Ef(t) {
    const e = kd(t);
    return ti(e, {
        hash: "hash",
        hmac: "function",
        randomBytes: "function"
    }, {
        bits2int: "function",
        bits2int_modN: "function",
        lowS: "boolean"
    }), Object.freeze({
        lowS: !0,
        ...e
    });
}
function Af(t) {
    const e = Ef(t), { Fp: r, n } = e, i = r.BYTES + 1, o = 2 * r.BYTES + 1;
    function s(_) {
        return Je(_, n);
    }
    function a(_) {
        return Fa(_, n);
    }
    const { ProjectivePoint: c, normPrivateKeyToScalar: l, weierstrassEquation: d, isWithinCurveOrder: u } = xf({
        ...e,
        toBytes (_, S, A) {
            const P = S.toAffine(), k = r.toBytes(P.x), K = ei;
            return hn("isCompressed", A), A ? K(Uint8Array.from([
                S.hasEvenY() ? 2 : 3
            ]), k) : K(Uint8Array.from([
                4
            ]), k, r.toBytes(P.y));
        },
        fromBytes (_) {
            const S = _.length, A = _[0], P = _.subarray(1);
            if (S === i && (A === 2 || A === 3)) {
                const k = $r(P);
                if (!Do(k, Ue, r.ORDER)) throw new Error("Point is not on curve");
                const K = d(k);
                let X;
                try {
                    X = r.sqrt(K);
                } catch (me) {
                    const ge = me instanceof Error ? ": " + me.message : "";
                    throw new Error("Point is not on curve" + ge);
                }
                const ae = (X & Ue) === Ue;
                return (A & 1) === 1 !== ae && (X = r.neg(X)), {
                    x: k,
                    y: X
                };
            } else if (S === o && A === 4) {
                const k = r.fromBytes(P.subarray(0, r.BYTES)), K = r.fromBytes(P.subarray(r.BYTES, 2 * r.BYTES));
                return {
                    x: k,
                    y: K
                };
            } else {
                const k = i, K = o;
                throw new Error("invalid Point, expected length of " + k + ", or uncompressed " + K + ", got " + S);
            }
        }
    }), h = (_)=>pn(wn(_, e.nByteLength));
    function p(_) {
        const S = n >> Ue;
        return _ > S;
    }
    function v(_) {
        return p(_) ? s(-_) : _;
    }
    const m = (_, S, A)=>$r(_.slice(S, A));
    class g {
        constructor(S, A, P){
            this.r = S, this.s = A, this.recovery = P, this.assertValidity();
        }
        static fromCompact(S) {
            const A = e.nByteLength;
            return S = xt("compactSignature", S, A * 2), new g(m(S, 0, A), m(S, A, 2 * A));
        }
        static fromDER(S) {
            const { r: A, s: P } = Gt.toSig(xt("DER", S));
            return new g(A, P);
        }
        assertValidity() {
            Pr("r", this.r, Ue, n), Pr("s", this.s, Ue, n);
        }
        addRecoveryBit(S) {
            return new g(this.r, this.s, S);
        }
        recoverPublicKey(S) {
            const { r: A, s: P, recovery: k } = this, K = $(xt("msgHash", S));
            if (k == null || ![
                0,
                1,
                2,
                3
            ].includes(k)) throw new Error("recovery id invalid");
            const X = k === 2 || k === 3 ? A + e.n : A;
            if (X >= r.ORDER) throw new Error("recovery id 2 or 3 invalid");
            const ae = (k & 1) === 0 ? "02" : "03", fe = c.fromHex(ae + h(X)), me = a(X), ge = s(-K * me), ke = s(P * me), Fe = c.BASE.multiplyAndAddUnsafe(fe, ge, ke);
            if (!Fe) throw new Error("point at infinify");
            return Fe.assertValidity(), Fe;
        }
        hasHighS() {
            return p(this.s);
        }
        normalizeS() {
            return this.hasHighS() ? new g(this.r, s(-this.s), this.recovery) : this;
        }
        toDERRawBytes() {
            return gn(this.toDERHex());
        }
        toDERHex() {
            return Gt.hexFromSig({
                r: this.r,
                s: this.s
            });
        }
        toCompactRawBytes() {
            return gn(this.toCompactHex());
        }
        toCompactHex() {
            return h(this.r) + h(this.s);
        }
    }
    const b = {
        isValidPrivateKey (_) {
            try {
                return l(_), !0;
            } catch  {
                return !1;
            }
        },
        normPrivateKeyToScalar: l,
        randomPrivateKey: ()=>{
            const _ = Sd(e.n);
            return pf(e.randomBytes(_), e.n);
        },
        precompute (_ = 8, S = c.BASE) {
            return S._setWindowSize(_), S.multiply(BigInt(3)), S;
        }
    };
    function y(_, S = !0) {
        return c.fromPrivateKey(_).toRawBytes(S);
    }
    function x(_) {
        const S = Or(_), A = typeof _ == "string", P = (S || A) && _.length;
        return S ? P === i || P === o : A ? P === 2 * i || P === 2 * o : _ instanceof c;
    }
    function E(_, S, A = !0) {
        if (x(_)) throw new Error("first arg must be private key");
        if (!x(S)) throw new Error("second arg must be public key");
        return c.fromHex(S).multiply(l(_)).toRawBytes(A);
    }
    const I = e.bits2int || function(_) {
        if (_.length > 8192) throw new Error("input is too large");
        const S = $r(_), A = _.length * 8 - e.nBitLength;
        return A > 0 ? S >> BigInt(A) : S;
    }, $ = e.bits2int_modN || function(_) {
        return s(I(_));
    }, L = Ba(e.nBitLength);
    function Z(_) {
        return Pr("num < 2^" + e.nBitLength, _, qt, L), wn(_, e.nByteLength);
    }
    function B(_, S, A = R) {
        if ([
            "recovered",
            "canonical"
        ].some((nt)=>nt in A)) throw new Error("sign() legacy options not supported");
        const { hash: P, randomBytes: k } = e;
        let { lowS: K, prehash: X, extraEntropy: ae } = A;
        K == null && (K = !0), _ = xt("msgHash", _), Td(A), X && (_ = xt("prehashed msgHash", P(_)));
        const fe = $(_), me = l(S), ge = [
            Z(me),
            Z(fe)
        ];
        if (ae != null && ae !== !1) {
            const nt = ae === !0 ? k(r.BYTES) : ae;
            ge.push(xt("extraEntropy", nt));
        }
        const ke = ei(...ge), Fe = fe;
        function yt(nt) {
            const qe = I(nt);
            if (!u(qe)) return;
            const Re = a(qe), Ke = c.BASE.multiply(qe).toAffine(), it = s(Ke.x);
            if (it === qt) return;
            const Nt = s(Re * s(Fe + it * me));
            if (Nt === qt) return;
            let tn = (Ke.x === it ? 0 : 2) | Number(Ke.y & Ue), Jc = Nt;
            return K && p(Nt) && (Jc = v(Nt), tn ^= 1), new g(it, Jc, tn);
        }
        return {
            seed: ke,
            k2sig: yt
        };
    }
    const R = {
        lowS: e.lowS,
        prehash: !1
    }, N = {
        lowS: e.lowS,
        prehash: !1
    };
    function ee(_, S, A = R) {
        const { seed: P, k2sig: k } = B(_, S, A), K = e;
        return ld(K.hash.outputLen, K.nByteLength, K.hmac)(P, k);
    }
    c.BASE._setWindowSize(8);
    function pe(_, S, A, P = N) {
        const k = _;
        S = xt("msgHash", S), A = xt("publicKey", A);
        const { lowS: K, prehash: X, format: ae } = P;
        if (Td(P), "strict" in P) throw new Error("options.strict was renamed to lowS");
        if (ae !== void 0 && ae !== "compact" && ae !== "der") throw new Error("format must be compact or der");
        const fe = typeof k == "string" || Or(k), me = !fe && !ae && typeof k == "object" && k !== null && typeof k.r == "bigint" && typeof k.s == "bigint";
        if (!fe && !me) throw new Error("invalid signature, expected Uint8Array, hex string or Signature instance");
        let ge, ke;
        try {
            if (me && (ge = new g(k.r, k.s)), fe) {
                try {
                    ae !== "compact" && (ge = g.fromDER(k));
                } catch (tn) {
                    if (!(tn instanceof Gt.Err)) throw tn;
                }
                !ge && ae !== "der" && (ge = g.fromCompact(k));
            }
            ke = c.fromHex(A);
        } catch  {
            return !1;
        }
        if (!ge || K && ge.hasHighS()) return !1;
        X && (S = e.hash(S));
        const { r: Fe, s: yt } = ge, nt = $(S), qe = a(yt), Re = s(nt * qe), Ke = s(Fe * qe), it = c.BASE.multiplyAndAddUnsafe(ke, Re, Ke)?.toAffine();
        return it ? s(it.x) === Fe : !1;
    }
    return {
        CURVE: e,
        getPublicKey: y,
        getSharedSecret: E,
        sign: ee,
        verify: pe,
        ProjectivePoint: c,
        Signature: g,
        utils: b
    };
}
function Sf(t) {
    return {
        hash: t,
        hmac: (e, ...r)=>vd(t, e, W1(...r)),
        randomBytes: j1
    };
}
function _f(t, e) {
    const r = (n)=>Af({
            ...t,
            ...Sf(n)
        });
    return {
        ...r(e),
        create: r
    };
}
const $d = BigInt("0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2f"), Pd = BigInt("0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141"), If = BigInt(1), qa = BigInt(2), Bd = (t, e)=>(t + e / qa) / e;
function Nf(t) {
    const e = $d, r = BigInt(3), n = BigInt(6), i = BigInt(11), o = BigInt(22), s = BigInt(23), a = BigInt(44), c = BigInt(88), l = t * t * t % e, d = l * l * t % e, u = pt(d, r, e) * d % e, h = pt(u, r, e) * d % e, p = pt(h, qa, e) * l % e, v = pt(p, i, e) * p % e, m = pt(v, o, e) * v % e, g = pt(m, a, e) * m % e, b = pt(g, c, e) * g % e, y = pt(b, a, e) * m % e, x = pt(y, r, e) * d % e, E = pt(x, s, e) * v % e, I = pt(E, n, e) * l % e, $ = pt(I, qa, e);
    if (!Ka.eql(Ka.sqr($), t)) throw new Error("Cannot find square root");
    return $;
}
const Ka = Ed($d, void 0, void 0, {
    sqrt: Nf
});
_f({
    a: BigInt(0),
    b: BigInt(7),
    Fp: Ka,
    n: Pd,
    Gx: BigInt("55066263022277343669578718895168534326250603453777594175500187360389116729240"),
    Gy: BigInt("32670510020758816978083085130507043184471273380659243275938904335757337482424"),
    h: BigInt(1),
    lowS: !0,
    endo: {
        beta: BigInt("0x7ae96a2b657c07106e64479eac3434e99cf0497512f58995c1396c28719501ee"),
        splitScalar: (t)=>{
            const e = Pd, r = BigInt("0x3086d221a7d46bcde86c90e49284eb15"), n = -If * BigInt("0xe4437ed6010e88286f547fa90abfe4c3"), i = BigInt("0x114ca50f7a8e2f3f657c1108d9d44cfd8"), o = r, s = BigInt("0x100000000000000000000000000000000"), a = Bd(o * t, e), c = Bd(-n * t, e);
            let l = Je(t - a * r - c * i, e), d = Je(-a * n - c * o, e);
            const u = l > s, h = d > s;
            if (u && (l = e - l), h && (d = e - d), l > s || d > s) throw new Error("splitScalar: Endomorphism failed, k=" + t);
            return {
                k1neg: u,
                k1: l,
                k2neg: h,
                k2: d
            };
        }
    }
}, ql), BigInt(0);
const Ya = {
    createBalance (t, e) {
        const r = {
            name: t.metadata.name || "",
            symbol: t.metadata.symbol || "",
            decimals: t.metadata.decimals || 0,
            value: t.metadata.value || 0,
            price: t.metadata.price || 0,
            iconUrl: t.metadata.iconUrl || ""
        };
        return {
            name: r.name,
            symbol: r.symbol,
            chainId: e,
            address: t.address === "native" ? void 0 : this.convertAddressToCAIP10Address(t.address, e),
            value: r.value,
            price: r.price,
            quantity: {
                decimals: r.decimals.toString(),
                numeric: this.convertHexToBalance({
                    hex: t.balance,
                    decimals: r.decimals
                })
            },
            iconUrl: r.iconUrl
        };
    },
    convertHexToBalance ({ hex: t, decimals: e }) {
        return Ml(BigInt(t), e);
    },
    convertAddressToCAIP10Address (t, e) {
        return `${e}:${t}`;
    },
    createCAIP2ChainId (t, e) {
        return `${e}:${parseInt(t, 16)}`;
    },
    getChainIdHexFromCAIP2ChainId (t) {
        const e = t.split(":");
        if (e.length < 2 || !e[1]) return "0x0";
        const r = e[1], n = parseInt(r, 10);
        return isNaN(n) ? "0x0" : `0x${n.toString(16)}`;
    },
    isWalletGetAssetsResponse (t) {
        return typeof t != "object" || t === null ? !1 : Object.values(t).every((e)=>Array.isArray(e) && e.every((r)=>this.isValidAsset(r)));
    },
    isValidAsset (t) {
        return typeof t == "object" && t !== null && typeof t.address == "string" && typeof t.balance == "string" && (t.type === "ERC20" || t.type === "NATIVE") && typeof t.metadata == "object" && t.metadata !== null && typeof t.metadata.name == "string" && typeof t.metadata.symbol == "string" && typeof t.metadata.decimals == "number" && typeof t.metadata.price == "number" && typeof t.metadata.iconUrl == "string";
    }
}, Rd = {
    async getMyTokensWithBalance (t) {
        const e = Q.state.address, r = f.state.activeCaipNetwork;
        if (!e || !r) return [];
        if (r.chainNamespace === "eip155") {
            const i = await this.getEIP155Balances(e, r);
            if (i) return this.filterLowQualityTokens(i);
        }
        const n = await oe.getBalance(e, r.caipNetworkId, t);
        return this.filterLowQualityTokens(n.balances);
    },
    async getEIP155Balances (t, e) {
        try {
            const r = Ya.getChainIdHexFromCAIP2ChainId(e.caipNetworkId);
            if (!(await Y.getCapabilities(t))?.[r]?.assetDiscovery?.supported) return null;
            const i = await Y.walletGetAssets({
                account: t,
                chainFilter: [
                    r
                ]
            });
            return Ya.isWalletGetAssetsResponse(i) ? (i[r] || []).map((s)=>Ya.createBalance(s, e.caipNetworkId)) : null;
        } catch  {
            return null;
        }
    },
    filterLowQualityTokens (t) {
        return t.filter((e)=>e.quantity.decimals !== "0");
    },
    mapBalancesToSwapTokens (t) {
        return t?.map((e)=>({
                ...e,
                address: e?.address ? e.address : f.getActiveNetworkTokenAddress(),
                decimals: parseInt(e.quantity.decimals, 10),
                logoUri: e.iconUrl,
                eip2612: !1
            })) || [];
    }
}, ue = xe({
    tokenBalances: [],
    loading: !1
}), Ld = {
    state: ue,
    subscribe (t) {
        return We(ue, ()=>t(ue));
    },
    subscribeKey (t, e) {
        return He(ue, t, e);
    },
    setToken (t) {
        t && (ue.token = Ir(t));
    },
    setTokenAmount (t) {
        ue.sendTokenAmount = t;
    },
    setReceiverAddress (t) {
        ue.receiverAddress = t;
    },
    setReceiverProfileImageUrl (t) {
        ue.receiverProfileImageUrl = t;
    },
    setReceiverProfileName (t) {
        ue.receiverProfileName = t;
    },
    setGasPrice (t) {
        ue.gasPrice = t;
    },
    setGasPriceInUsd (t) {
        ue.gasPriceInUSD = t;
    },
    setNetworkBalanceInUsd (t) {
        ue.networkBalanceInUSD = t;
    },
    setLoading (t) {
        ue.loading = t;
    },
    sendToken () {
        switch(f.state.activeCaipNetwork?.chainNamespace){
            case "eip155":
                this.sendEvmToken();
                return;
            case "solana":
                this.sendSolanaToken();
                return;
            default:
                throw new Error("Unsupported chain");
        }
    },
    sendEvmToken () {
        const t = f.state.activeChain, e = Q.state.preferredAccountTypes?.[t];
        this.state.token?.address && this.state.sendTokenAmount && this.state.receiverAddress ? (le.sendEvent({
            type: "track",
            event: "SEND_INITIATED",
            properties: {
                isSmartAccount: e === cr.ACCOUNT_TYPES.SMART_ACCOUNT,
                token: this.state.token.address,
                amount: this.state.sendTokenAmount,
                network: f.state.activeCaipNetwork?.caipNetworkId || ""
            }
        }), this.sendERC20Token({
            receiverAddress: this.state.receiverAddress,
            tokenAddress: this.state.token.address,
            sendTokenAmount: this.state.sendTokenAmount,
            decimals: this.state.token.quantity.decimals
        })) : this.state.receiverAddress && this.state.sendTokenAmount && this.state.gasPrice && this.state.token?.quantity.decimals && (le.sendEvent({
            type: "track",
            event: "SEND_INITIATED",
            properties: {
                isSmartAccount: e === cr.ACCOUNT_TYPES.SMART_ACCOUNT,
                token: this.state.token?.symbol,
                amount: this.state.sendTokenAmount,
                network: f.state.activeCaipNetwork?.caipNetworkId || ""
            }
        }), this.sendNativeToken({
            receiverAddress: this.state.receiverAddress,
            sendTokenAmount: this.state.sendTokenAmount,
            gasPrice: this.state.gasPrice,
            decimals: this.state.token.quantity.decimals
        }));
    },
    async fetchTokenBalance (t) {
        ue.loading = !0;
        const e = f.state.activeCaipNetwork?.caipNetworkId, r = f.state.activeCaipNetwork?.chainNamespace, n = f.state.activeCaipAddress, i = n ? U.getPlainAddress(n) : void 0;
        if (ue.lastRetry && !U.isAllowedRetry(ue.lastRetry, 30 * Te.ONE_SEC_MS)) return ue.loading = !1, [];
        try {
            if (i && e && r) {
                const o = await Rd.getMyTokensWithBalance();
                return ue.tokenBalances = o, ue.lastRetry = void 0, o;
            }
        } catch (o) {
            ue.lastRetry = Date.now(), t?.(o), Ee.showError("Token Balance Unavailable");
        } finally{
            ue.loading = !1;
        }
        return [];
    },
    fetchNetworkBalance () {
        if (ue.tokenBalances.length === 0) return;
        const t = Rd.mapBalancesToSwapTokens(ue.tokenBalances);
        if (!t) return;
        const e = t.find((r)=>r.address === f.getActiveNetworkTokenAddress());
        e && (ue.networkBalanceInUSD = e ? xo.multiply(e.quantity.numeric, e.price).toString() : "0");
    },
    isInsufficientNetworkTokenForGas (t, e) {
        const r = e || "0";
        return xo.bigNumber(t).eq(0) ? !0 : xo.bigNumber(xo.bigNumber(r)).gt(t);
    },
    hasInsufficientGasFunds () {
        const t = f.state.activeChain;
        let e = !0;
        return Q.state.preferredAccountTypes?.[t] === cr.ACCOUNT_TYPES.SMART_ACCOUNT ? e = !1 : ue.networkBalanceInUSD && (e = this.isInsufficientNetworkTokenForGas(ue.networkBalanceInUSD, ue.gasPriceInUSD)), e;
    },
    async sendNativeToken (t) {
        const e = f.state.activeChain;
        D.pushTransactionStack({
            view: "Account",
            goBack: !1
        });
        const r = t.receiverAddress, n = Q.state.address, i = Y.parseUnits(t.sendTokenAmount.toString(), Number(t.decimals)), o = "0x";
        try {
            await Y.sendTransaction({
                chainNamespace: "eip155",
                to: r,
                address: n,
                data: o,
                value: i ?? BigInt(0),
                gasPrice: t.gasPrice
            }), Ee.showSuccess("Transaction started"), le.sendEvent({
                type: "track",
                event: "SEND_SUCCESS",
                properties: {
                    isSmartAccount: Q.state.preferredAccountTypes?.[e] === cr.ACCOUNT_TYPES.SMART_ACCOUNT,
                    token: this.state.token?.symbol || "",
                    amount: t.sendTokenAmount,
                    network: f.state.activeCaipNetwork?.caipNetworkId || ""
                }
            }), this.resetSend();
        } catch (s) {
            console.error("SendController:sendERC20Token - failed to send native token", s);
            const a = s instanceof Error ? s.message : "Unknown error";
            le.sendEvent({
                type: "track",
                event: "SEND_ERROR",
                properties: {
                    message: a,
                    isSmartAccount: Q.state.preferredAccountTypes?.[e] === cr.ACCOUNT_TYPES.SMART_ACCOUNT,
                    token: this.state.token?.symbol || "",
                    amount: t.sendTokenAmount,
                    network: f.state.activeCaipNetwork?.caipNetworkId || ""
                }
            }), Ee.showError("Something went wrong");
        }
    },
    async sendERC20Token (t) {
        D.pushTransactionStack({
            view: "Account",
            goBack: !1
        });
        const e = Y.parseUnits(t.sendTokenAmount.toString(), Number(t.decimals));
        try {
            if (Q.state.address && t.sendTokenAmount && t.receiverAddress && t.tokenAddress) {
                const r = U.getPlainAddress(t.tokenAddress);
                await Y.writeContract({
                    fromAddress: Q.state.address,
                    tokenAddress: r,
                    args: [
                        t.receiverAddress,
                        e ?? BigInt(0)
                    ],
                    method: "transfer",
                    abi: Q0.getERC20Abi(r),
                    chainNamespace: "eip155"
                }), Ee.showSuccess("Transaction started"), this.resetSend();
            }
        } catch (r) {
            console.error("SendController:sendERC20Token - failed to send erc20 token", r);
            const n = r instanceof Error ? r.message : "Unknown error";
            le.sendEvent({
                type: "track",
                event: "SEND_ERROR",
                properties: {
                    message: n,
                    isSmartAccount: Q.state.preferredAccountTypes?.eip155 === cr.ACCOUNT_TYPES.SMART_ACCOUNT,
                    token: this.state.token?.symbol || "",
                    amount: t.sendTokenAmount,
                    network: f.state.activeCaipNetwork?.caipNetworkId || ""
                }
            }), Ee.showError("Something went wrong");
        }
    },
    sendSolanaToken () {
        if (!this.state.sendTokenAmount || !this.state.receiverAddress) {
            Ee.showError("Please enter a valid amount and receiver address");
            return;
        }
        D.pushTransactionStack({
            view: "Account",
            goBack: !1
        }), Y.sendTransaction({
            chainNamespace: "solana",
            to: this.state.receiverAddress,
            value: this.state.sendTokenAmount
        }).then(()=>{
            this.resetSend(), Q.fetchTokenBalance();
        }).catch((t)=>{
            Ee.showError("Failed to send transaction. Please try again."), console.error("SendController:sendToken - failed to send solana transaction", t);
        });
    },
    resetSend () {
        ue.token = void 0, ue.sendTokenAmount = void 0, ue.receiverAddress = void 0, ue.receiverProfileImageUrl = void 0, ue.receiverProfileName = void 0, ue.loading = !1, ue.tokenBalances = [];
    }
}, Xa = {
    currentTab: 0,
    tokenBalance: [],
    smartAccountDeployed: !1,
    addressLabels: new Map,
    allAccounts: [],
    user: void 0
}, jo = {
    caipNetwork: void 0,
    supportsAllNetworks: !0,
    smartAccountEnabledNetworks: []
}, z = xe({
    chains: o1(),
    activeCaipAddress: void 0,
    activeChain: void 0,
    activeCaipNetwork: void 0,
    noAdapters: !1,
    universalAdapter: {
        networkControllerClient: void 0,
        connectionControllerClient: void 0
    },
    isSwitchingNamespace: !1
}), f = {
    state: z,
    subscribe (t) {
        return We(z, ()=>{
            t(z);
        });
    },
    subscribeKey (t, e) {
        return He(z, t, e);
    },
    subscribeChainProp (t, e, r) {
        let n;
        return We(z.chains, ()=>{
            const i = r || z.activeChain;
            if (i) {
                const o = z.chains.get(i)?.[t];
                n !== o && (n = o, e(o));
            }
        });
    },
    initialize (t, e, r) {
        const { chainId: n, namespace: i } = q.getActiveNetworkProps(), o = e?.find((l)=>l.id.toString() === n?.toString()), a = t.find((l)=>l?.namespace === i) || t?.[0], c = new Set([
            ...e?.map((l)=>l.chainNamespace) ?? []
        ]);
        (t?.length === 0 || !a) && (z.noAdapters = !0), z.noAdapters || (z.activeChain = a?.namespace, z.activeCaipNetwork = o, this.setChainNetworkData(a?.namespace, {
            caipNetwork: o
        }), z.activeChain && zt.set({
            activeChain: a?.namespace
        })), c.forEach((l)=>{
            const d = e?.filter((u)=>u.chainNamespace === l);
            f.state.chains.set(l, {
                namespace: l,
                networkState: xe({
                    ...jo,
                    caipNetwork: d?.[0]
                }),
                accountState: xe(Xa),
                caipNetworks: d ?? [],
                ...r
            }), this.setRequestedCaipNetworks(d ?? [], l);
        });
    },
    removeAdapter (t) {
        if (z.activeChain === t) {
            const e = Array.from(z.chains.entries()).find(([r])=>r !== t);
            if (e) {
                const r = e[1]?.caipNetworks?.[0];
                r && this.setActiveCaipNetwork(r);
            }
        }
        z.chains.delete(t);
    },
    addAdapter (t, { networkControllerClient: e, connectionControllerClient: r }, n) {
        z.chains.set(t.namespace, {
            namespace: t.namespace,
            networkState: {
                ...jo,
                caipNetwork: n[0]
            },
            accountState: Xa,
            caipNetworks: n,
            connectionControllerClient: r,
            networkControllerClient: e
        }), this.setRequestedCaipNetworks(n?.filter((i)=>i.chainNamespace === t.namespace) ?? [], t.namespace);
    },
    addNetwork (t) {
        const e = z.chains.get(t.chainNamespace);
        if (e) {
            const r = [
                ...e.caipNetworks || []
            ];
            e.caipNetworks?.find((n)=>n.id === t.id) || r.push(t), z.chains.set(t.chainNamespace, {
                ...e,
                caipNetworks: r
            }), this.setRequestedCaipNetworks(r, t.chainNamespace);
        }
    },
    removeNetwork (t, e) {
        const r = z.chains.get(t);
        if (r) {
            const n = z.activeCaipNetwork?.id === e, i = [
                ...r.caipNetworks?.filter((o)=>o.id !== e) || []
            ];
            n && r?.caipNetworks?.[0] && this.setActiveCaipNetwork(r.caipNetworks[0]), z.chains.set(t, {
                ...r,
                caipNetworks: i
            }), this.setRequestedCaipNetworks(i || [], t);
        }
    },
    setAdapterNetworkState (t, e) {
        const r = z.chains.get(t);
        r && (r.networkState = {
            ...r.networkState || jo,
            ...e
        }, z.chains.set(t, r));
    },
    setChainAccountData (t, e, r = !0) {
        if (!t) throw new Error("Chain is required to update chain account data");
        const n = z.chains.get(t);
        if (n) {
            const i = {
                ...n.accountState || Xa,
                ...e
            };
            z.chains.set(t, {
                ...n,
                accountState: i
            }), (z.chains.size === 1 || z.activeChain === t) && (e.caipAddress && (z.activeCaipAddress = e.caipAddress), Q.replaceState(i));
        }
    },
    setChainNetworkData (t, e) {
        if (!t) return;
        const r = z.chains.get(t);
        if (r) {
            const n = {
                ...r.networkState || jo,
                ...e
            };
            z.chains.set(t, {
                ...r,
                networkState: n
            });
        }
    },
    setAccountProp (t, e, r, n = !0) {
        this.setChainAccountData(r, {
            [t]: e
        }, n), t === "status" && e === "disconnected" && r && j.removeConnectorId(r);
    },
    setActiveNamespace (t) {
        z.activeChain = t;
        const e = t ? z.chains.get(t) : void 0, r = e?.networkState?.caipNetwork;
        r?.id && t && (z.activeCaipAddress = e?.accountState?.caipAddress, z.activeCaipNetwork = r, this.setChainNetworkData(t, {
            caipNetwork: r
        }), q.setActiveCaipNetworkId(r?.caipNetworkId), zt.set({
            activeChain: t,
            selectedNetworkId: r?.caipNetworkId
        }));
    },
    setActiveCaipNetwork (t) {
        if (!t) return;
        z.activeChain !== t.chainNamespace && this.setIsSwitchingNamespace(!0);
        const e = z.chains.get(t.chainNamespace);
        z.activeChain = t.chainNamespace, z.activeCaipNetwork = t, this.setChainNetworkData(t.chainNamespace, {
            caipNetwork: t
        }), e?.accountState?.address ? z.activeCaipAddress = `${t.chainNamespace}:${t.id}:${e?.accountState?.address}` : z.activeCaipAddress = void 0, this.setAccountProp("caipAddress", z.activeCaipAddress, t.chainNamespace), e && Q.replaceState(e.accountState), Ld.resetSend(), zt.set({
            activeChain: z.activeChain,
            selectedNetworkId: z.activeCaipNetwork?.caipNetworkId
        }), q.setActiveCaipNetworkId(t.caipNetworkId), !this.checkIfSupportedNetwork(t.chainNamespace) && T.state.enableNetworkSwitch && !T.state.allowUnsupportedChain && !Y.state.wcBasic && this.showUnsupportedChainUI();
    },
    addCaipNetwork (t) {
        if (!t) return;
        const e = z.chains.get(t.chainNamespace);
        e && e?.caipNetworks?.push(t);
    },
    async switchActiveNamespace (t) {
        if (!t) return;
        const e = t !== f.state.activeChain, r = f.getNetworkData(t)?.caipNetwork, n = f.getCaipNetworkByNamespace(t, r?.id);
        e && n && await f.switchActiveNetwork(n);
    },
    async switchActiveNetwork (t) {
        !f.state.chains.get(f.state.activeChain)?.caipNetworks?.some((i)=>i.id === z.activeCaipNetwork?.id) && D.goBack();
        const n = this.getNetworkControllerClient(t.chainNamespace);
        n && (await n.switchCaipNetwork(t), le.sendEvent({
            type: "track",
            event: "SWITCH_NETWORK",
            properties: {
                network: t.caipNetworkId
            }
        }));
    },
    getNetworkControllerClient (t) {
        const e = t || z.activeChain, r = z.chains.get(e);
        if (!r) throw new Error("Chain adapter not found");
        if (!r.networkControllerClient) throw new Error("NetworkController client not set");
        return r.networkControllerClient;
    },
    getConnectionControllerClient (t) {
        const e = t || z.activeChain;
        if (!e) throw new Error("Chain is required to get connection controller client");
        const r = z.chains.get(e);
        if (!r?.connectionControllerClient) throw new Error("ConnectionController client not set");
        return r.connectionControllerClient;
    },
    getAccountProp (t, e) {
        let r = z.activeChain;
        if (e && (r = e), !r) return;
        const n = z.chains.get(r)?.accountState;
        if (n) return n[t];
    },
    getNetworkProp (t, e) {
        const r = z.chains.get(e)?.networkState;
        if (r) return r[t];
    },
    getRequestedCaipNetworks (t) {
        const e = z.chains.get(t), { approvedCaipNetworkIds: r = [], requestedCaipNetworks: n = [] } = e?.networkState || {};
        return U.sortRequestedNetworks(r, n);
    },
    getAllRequestedCaipNetworks () {
        const t = [];
        return z.chains.forEach((e)=>{
            const r = this.getRequestedCaipNetworks(e.namespace);
            t.push(...r);
        }), t;
    },
    setRequestedCaipNetworks (t, e) {
        this.setAdapterNetworkState(e, {
            requestedCaipNetworks: t
        });
    },
    getAllApprovedCaipNetworkIds () {
        const t = [];
        return z.chains.forEach((e)=>{
            const r = this.getApprovedCaipNetworkIds(e.namespace);
            t.push(...r);
        }), t;
    },
    getActiveCaipNetwork () {
        return z.activeCaipNetwork;
    },
    getActiveCaipAddress () {
        return z.activeCaipAddress;
    },
    getApprovedCaipNetworkIds (t) {
        return z.chains.get(t)?.networkState?.approvedCaipNetworkIds || [];
    },
    async setApprovedCaipNetworksData (t) {
        const r = await this.getNetworkControllerClient()?.getApprovedCaipNetworksData();
        this.setAdapterNetworkState(t, {
            approvedCaipNetworkIds: r?.approvedCaipNetworkIds,
            supportsAllNetworks: r?.supportsAllNetworks
        });
    },
    checkIfSupportedNetwork (t, e) {
        const r = e || z.activeCaipNetwork, n = this.getRequestedCaipNetworks(t);
        return n.length ? n?.some((i)=>i.id === r?.id) : !0;
    },
    checkIfSupportedChainId (t) {
        return z.activeChain ? this.getRequestedCaipNetworks(z.activeChain)?.some((r)=>r.id === t) : !0;
    },
    setSmartAccountEnabledNetworks (t, e) {
        this.setAdapterNetworkState(e, {
            smartAccountEnabledNetworks: t
        });
    },
    checkIfSmartAccountEnabled () {
        const t = al.caipNetworkIdToNumber(z.activeCaipNetwork?.caipNetworkId), e = z.activeChain;
        return !e || !t ? !1 : !!this.getNetworkProp("smartAccountEnabledNetworks", e)?.includes(Number(t));
    },
    getActiveNetworkTokenAddress () {
        const t = z.activeCaipNetwork?.chainNamespace || "eip155", e = z.activeCaipNetwork?.id || 1, r = Te.NATIVE_TOKEN_ADDRESS[t];
        return `${t}:${e}:${r}`;
    },
    showUnsupportedChainUI () {
        he.open({
            view: "UnsupportedChain"
        });
    },
    checkIfNamesSupported () {
        const t = z.activeCaipNetwork;
        return !!(t?.chainNamespace && Te.NAMES_SUPPORTED_CHAIN_NAMESPACES.includes(t.chainNamespace));
    },
    resetNetwork (t) {
        this.setAdapterNetworkState(t, {
            approvedCaipNetworkIds: void 0,
            supportsAllNetworks: !0,
            smartAccountEnabledNetworks: []
        });
    },
    resetAccount (t) {
        const e = t;
        if (!e) throw new Error("Chain is required to set account prop");
        z.activeCaipAddress = void 0, this.setChainAccountData(e, {
            smartAccountDeployed: !1,
            currentTab: 0,
            caipAddress: void 0,
            address: void 0,
            balance: void 0,
            balanceSymbol: void 0,
            profileName: void 0,
            profileImage: void 0,
            addressExplorerUrl: void 0,
            tokenBalance: [],
            connectedWalletInfo: void 0,
            preferredAccountTypes: void 0,
            socialProvider: void 0,
            socialWindow: void 0,
            farcasterUrl: void 0,
            allAccounts: [],
            user: void 0,
            status: "disconnected"
        }), j.removeConnectorId(e);
    },
    async disconnect (t) {
        const e = m1(t);
        try {
            Ld.resetSend();
            const r = await Promise.allSettled(e.map(async ([i, o])=>{
                try {
                    const { caipAddress: s } = this.getAccountData(i) || {};
                    s && o.connectionControllerClient?.disconnect && await o.connectionControllerClient.disconnect(i), this.resetAccount(i), this.resetNetwork(i);
                } catch (s) {
                    throw new Error(`Failed to disconnect chain ${i}: ${s.message}`);
                }
            }));
            Y.resetWcConnection();
            const n = r.filter((i)=>i.status === "rejected");
            if (n.length > 0) throw new Error(n.map((i)=>i.reason.message).join(", "));
            q.deleteConnectedSocialProvider(), t ? j.removeConnectorId(t) : j.resetConnectorIds(), le.sendEvent({
                type: "track",
                event: "DISCONNECT_SUCCESS",
                properties: {
                    namespace: t || "all"
                }
            });
        } catch (r) {
            console.error(r.message || "Failed to disconnect chains"), le.sendEvent({
                type: "track",
                event: "DISCONNECT_ERROR",
                properties: {
                    message: r.message || "Failed to disconnect chains"
                }
            });
        }
    },
    setIsSwitchingNamespace (t) {
        z.isSwitchingNamespace = t;
    },
    getFirstCaipNetworkSupportsAuthConnector () {
        const t = [];
        let e;
        if (z.chains.forEach((r)=>{
            G.AUTH_CONNECTOR_SUPPORTED_CHAINS.find((n)=>n === r.namespace) && r.namespace && t.push(r.namespace);
        }), t.length > 0) {
            const r = t[0];
            return e = r ? z.chains.get(r)?.caipNetworks?.[0] : void 0, e;
        }
    },
    getAccountData (t) {
        return t ? f.state.chains.get(t)?.accountState : Q.state;
    },
    getNetworkData (t) {
        const e = t || z.activeChain;
        if (e) return f.state.chains.get(e)?.networkState;
    },
    getCaipNetworkByNamespace (t, e) {
        if (!t) return;
        const r = f.state.chains.get(t), n = r?.caipNetworks?.find((i)=>i.id === e);
        return n || r?.networkState?.caipNetwork || r?.caipNetworks?.[0];
    },
    getRequestedCaipNetworkIds () {
        const t = j.state.filterByNamespace;
        return (t ? [
            z.chains.get(t)
        ] : Array.from(z.chains.values())).flatMap((r)=>r?.caipNetworks || []).map((r)=>r.caipNetworkId);
    },
    getCaipNetworks (t) {
        return t ? f.getRequestedCaipNetworks(t) : f.getAllRequestedCaipNetworks();
    }
}, kf = {
    purchaseCurrencies: [
        {
            id: "2b92315d-eab7-5bef-84fa-089a131333f5",
            name: "USD Coin",
            symbol: "USDC",
            networks: [
                {
                    name: "ethereum-mainnet",
                    display_name: "Ethereum",
                    chain_id: "1",
                    contract_address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"
                },
                {
                    name: "polygon-mainnet",
                    display_name: "Polygon",
                    chain_id: "137",
                    contract_address: "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174"
                }
            ]
        },
        {
            id: "2b92315d-eab7-5bef-84fa-089a131333f5",
            name: "Ether",
            symbol: "ETH",
            networks: [
                {
                    name: "ethereum-mainnet",
                    display_name: "Ethereum",
                    chain_id: "1",
                    contract_address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"
                },
                {
                    name: "polygon-mainnet",
                    display_name: "Polygon",
                    chain_id: "137",
                    contract_address: "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174"
                }
            ]
        }
    ],
    paymentCurrencies: [
        {
            id: "USD",
            payment_method_limits: [
                {
                    id: "card",
                    min: "10.00",
                    max: "7500.00"
                },
                {
                    id: "ach_bank_account",
                    min: "10.00",
                    max: "25000.00"
                }
            ]
        },
        {
            id: "EUR",
            payment_method_limits: [
                {
                    id: "card",
                    min: "10.00",
                    max: "7500.00"
                },
                {
                    id: "ach_bank_account",
                    min: "10.00",
                    max: "25000.00"
                }
            ]
        }
    ]
}, Ud = U.getBlockchainApiUrl(), ct = xe({
    clientId: null,
    api: new Eo({
        baseUrl: Ud,
        clientId: null
    }),
    supportedChains: {
        http: [],
        ws: []
    }
}), oe = {
    state: ct,
    async get (t) {
        const { st: e, sv: r } = oe.getSdkProperties(), n = T.state.projectId, i = {
            ...t.params || {},
            st: e,
            sv: r,
            projectId: n
        };
        return ct.api.get({
            ...t,
            params: i
        });
    },
    getSdkProperties () {
        const { sdkType: t, sdkVersion: e } = T.state;
        return {
            st: t || "unknown",
            sv: e || "unknown"
        };
    },
    async isNetworkSupported (t) {
        if (!t) return !1;
        try {
            ct.supportedChains.http.length || await oe.getSupportedNetworks();
        } catch  {
            return !1;
        }
        return ct.supportedChains.http.includes(t);
    },
    async getSupportedNetworks () {
        const t = await oe.get({
            path: "v1/supported-chains"
        });
        return ct.supportedChains = t, t;
    },
    async fetchIdentity ({ address: t, caipNetworkId: e }) {
        if (!await oe.isNetworkSupported(e)) return {
            avatar: "",
            name: ""
        };
        const n = q.getIdentityFromCacheForAddress(t);
        if (n) return n;
        const i = await oe.get({
            path: `/v1/identity/${t}`,
            params: {
                sender: f.state.activeCaipAddress ? U.getPlainAddress(f.state.activeCaipAddress) : void 0
            }
        });
        return q.updateIdentityCache({
            address: t,
            identity: i,
            timestamp: Date.now()
        }), i;
    },
    async fetchTransactions ({ account: t, cursor: e, onramp: r, signal: n, cache: i, chainId: o }) {
        return await oe.isNetworkSupported(f.state.activeCaipNetwork?.caipNetworkId) ? oe.get({
            path: `/v1/account/${t}/history`,
            params: {
                cursor: e,
                onramp: r,
                chainId: o
            },
            signal: n,
            cache: i
        }) : {
            data: [],
            next: void 0
        };
    },
    async fetchSwapQuote ({ amount: t, userAddress: e, from: r, to: n, gasPrice: i }) {
        return await oe.isNetworkSupported(f.state.activeCaipNetwork?.caipNetworkId) ? oe.get({
            path: "/v1/convert/quotes",
            headers: {
                "Content-Type": "application/json"
            },
            params: {
                amount: t,
                userAddress: e,
                from: r,
                to: n,
                gasPrice: i
            }
        }) : {
            quotes: []
        };
    },
    async fetchSwapTokens ({ chainId: t }) {
        return await oe.isNetworkSupported(f.state.activeCaipNetwork?.caipNetworkId) ? oe.get({
            path: "/v1/convert/tokens",
            params: {
                chainId: t
            }
        }) : {
            tokens: []
        };
    },
    async fetchTokenPrice ({ addresses: t }) {
        return await oe.isNetworkSupported(f.state.activeCaipNetwork?.caipNetworkId) ? ct.api.post({
            path: "/v1/fungible/price",
            body: {
                currency: "usd",
                addresses: t,
                projectId: T.state.projectId
            },
            headers: {
                "Content-Type": "application/json"
            }
        }) : {
            fungibles: []
        };
    },
    async fetchSwapAllowance ({ tokenAddress: t, userAddress: e }) {
        return await oe.isNetworkSupported(f.state.activeCaipNetwork?.caipNetworkId) ? oe.get({
            path: "/v1/convert/allowance",
            params: {
                tokenAddress: t,
                userAddress: e
            },
            headers: {
                "Content-Type": "application/json"
            }
        }) : {
            allowance: "0"
        };
    },
    async fetchGasPrice ({ chainId: t }) {
        const { st: e, sv: r } = oe.getSdkProperties();
        if (!await oe.isNetworkSupported(f.state.activeCaipNetwork?.caipNetworkId)) throw new Error("Network not supported for Gas Price");
        return oe.get({
            path: "/v1/convert/gas-price",
            headers: {
                "Content-Type": "application/json"
            },
            params: {
                chainId: t,
                st: e,
                sv: r
            }
        });
    },
    async generateSwapCalldata ({ amount: t, from: e, to: r, userAddress: n, disableEstimate: i }) {
        if (!await oe.isNetworkSupported(f.state.activeCaipNetwork?.caipNetworkId)) throw new Error("Network not supported for Swaps");
        return ct.api.post({
            path: "/v1/convert/build-transaction",
            headers: {
                "Content-Type": "application/json"
            },
            body: {
                amount: t,
                eip155: {
                    slippage: Te.CONVERT_SLIPPAGE_TOLERANCE
                },
                projectId: T.state.projectId,
                from: e,
                to: r,
                userAddress: n,
                disableEstimate: i
            }
        });
    },
    async generateApproveCalldata ({ from: t, to: e, userAddress: r }) {
        const { st: n, sv: i } = oe.getSdkProperties();
        if (!await oe.isNetworkSupported(f.state.activeCaipNetwork?.caipNetworkId)) throw new Error("Network not supported for Swaps");
        return oe.get({
            path: "/v1/convert/build-approve",
            headers: {
                "Content-Type": "application/json"
            },
            params: {
                userAddress: r,
                from: t,
                to: e,
                st: n,
                sv: i
            }
        });
    },
    async getBalance (t, e, r) {
        const { st: n, sv: i } = oe.getSdkProperties();
        if (!await oe.isNetworkSupported(f.state.activeCaipNetwork?.caipNetworkId)) return Ee.showError("Token Balance Unavailable"), {
            balances: []
        };
        const s = `${e}:${t}`, a = q.getBalanceCacheForCaipAddress(s);
        if (a) return a;
        const c = await oe.get({
            path: `/v1/account/${t}/balance`,
            params: {
                currency: "usd",
                chainId: e,
                forceUpdate: r,
                st: n,
                sv: i
            }
        });
        return q.updateBalanceCache({
            caipAddress: s,
            balance: c,
            timestamp: Date.now()
        }), c;
    },
    async lookupEnsName (t) {
        return await oe.isNetworkSupported(f.state.activeCaipNetwork?.caipNetworkId) ? oe.get({
            path: `/v1/profile/account/${t}`,
            params: {
                apiVersion: "2"
            }
        }) : {
            addresses: {},
            attributes: []
        };
    },
    async reverseLookupEnsName ({ address: t }) {
        return await oe.isNetworkSupported(f.state.activeCaipNetwork?.caipNetworkId) ? oe.get({
            path: `/v1/profile/reverse/${t}`,
            params: {
                sender: Q.state.address,
                apiVersion: "2"
            }
        }) : [];
    },
    async getEnsNameSuggestions (t) {
        return await oe.isNetworkSupported(f.state.activeCaipNetwork?.caipNetworkId) ? oe.get({
            path: `/v1/profile/suggestions/${t}`,
            params: {
                zone: "reown.id"
            }
        }) : {
            suggestions: []
        };
    },
    async registerEnsName ({ coinType: t, address: e, message: r, signature: n }) {
        return await oe.isNetworkSupported(f.state.activeCaipNetwork?.caipNetworkId) ? ct.api.post({
            path: "/v1/profile/account",
            body: {
                coin_type: t,
                address: e,
                message: r,
                signature: n
            },
            headers: {
                "Content-Type": "application/json"
            }
        }) : {
            success: !1
        };
    },
    async generateOnRampURL ({ destinationWallets: t, partnerUserId: e, defaultNetwork: r, purchaseAmount: n, paymentAmount: i }) {
        return await oe.isNetworkSupported(f.state.activeCaipNetwork?.caipNetworkId) ? (await ct.api.post({
            path: "/v1/generators/onrampurl",
            params: {
                projectId: T.state.projectId
            },
            body: {
                destinationWallets: t,
                defaultNetwork: r,
                partnerUserId: e,
                defaultExperience: "buy",
                presetCryptoAmount: n,
                presetFiatAmount: i
            }
        })).url : "";
    },
    async getOnrampOptions () {
        if (!await oe.isNetworkSupported(f.state.activeCaipNetwork?.caipNetworkId)) return {
            paymentCurrencies: [],
            purchaseCurrencies: []
        };
        try {
            return await oe.get({
                path: "/v1/onramp/options"
            });
        } catch  {
            return kf;
        }
    },
    async getOnrampQuote ({ purchaseCurrency: t, paymentCurrency: e, amount: r, network: n }) {
        try {
            return await oe.isNetworkSupported(f.state.activeCaipNetwork?.caipNetworkId) ? await ct.api.post({
                path: "/v1/onramp/quote",
                params: {
                    projectId: T.state.projectId
                },
                body: {
                    purchaseCurrency: t,
                    paymentCurrency: e,
                    amount: r,
                    network: n
                }
            }) : null;
        } catch  {
            return {
                coinbaseFee: {
                    amount: r,
                    currency: e.id
                },
                networkFee: {
                    amount: r,
                    currency: e.id
                },
                paymentSubtotal: {
                    amount: r,
                    currency: e.id
                },
                paymentTotal: {
                    amount: r,
                    currency: e.id
                },
                purchaseAmount: {
                    amount: r,
                    currency: e.id
                },
                quoteId: "mocked-quote-id"
            };
        }
    },
    async getSmartSessions (t) {
        return await oe.isNetworkSupported(f.state.activeCaipNetwork?.caipNetworkId) ? oe.get({
            path: `/v1/sessions/${t}`
        }) : [];
    },
    async revokeSmartSession (t, e, r) {
        return await oe.isNetworkSupported(f.state.activeCaipNetwork?.caipNetworkId) ? ct.api.post({
            path: `/v1/sessions/${t}/revoke`,
            params: {
                projectId: T.state.projectId
            },
            body: {
                pci: e,
                signature: r
            }
        }) : {
            success: !1
        };
    },
    setClientId (t) {
        ct.clientId = t, ct.api = new Eo({
            baseUrl: Ud,
            clientId: t
        });
    }
}, ft = xe({
    currentTab: 0,
    tokenBalance: [],
    smartAccountDeployed: !1,
    addressLabels: new Map,
    allAccounts: []
}), Q = {
    state: ft,
    replaceState (t) {
        t && Object.assign(ft, Ir(t));
    },
    subscribe (t) {
        return f.subscribeChainProp("accountState", (e)=>{
            if (e) return t(e);
        });
    },
    subscribeKey (t, e, r) {
        let n;
        return f.subscribeChainProp("accountState", (i)=>{
            if (i) {
                const o = i[t];
                n !== o && (n = o, e(o));
            }
        }, r);
    },
    setStatus (t, e) {
        f.setAccountProp("status", t, e);
    },
    getCaipAddress (t) {
        return f.getAccountProp("caipAddress", t);
    },
    setCaipAddress (t, e) {
        const r = t ? U.getPlainAddress(t) : void 0;
        e === f.state.activeChain && (f.state.activeCaipAddress = t), f.setAccountProp("caipAddress", t, e), f.setAccountProp("address", r, e);
    },
    setBalance (t, e, r) {
        f.setAccountProp("balance", t, r), f.setAccountProp("balanceSymbol", e, r);
    },
    setProfileName (t, e) {
        f.setAccountProp("profileName", t, e);
    },
    setProfileImage (t, e) {
        f.setAccountProp("profileImage", t, e);
    },
    setUser (t, e) {
        f.setAccountProp("user", t, e);
    },
    setAddressExplorerUrl (t, e) {
        f.setAccountProp("addressExplorerUrl", t, e);
    },
    setSmartAccountDeployed (t, e) {
        f.setAccountProp("smartAccountDeployed", t, e);
    },
    setCurrentTab (t) {
        f.setAccountProp("currentTab", t, f.state.activeChain);
    },
    setTokenBalance (t, e) {
        t && f.setAccountProp("tokenBalance", t, e);
    },
    setShouldUpdateToAddress (t, e) {
        f.setAccountProp("shouldUpdateToAddress", t, e);
    },
    setAllAccounts (t, e) {
        f.setAccountProp("allAccounts", t, e);
    },
    addAddressLabel (t, e, r) {
        const n = f.getAccountProp("addressLabels", r) || new Map;
        n.set(t, e), f.setAccountProp("addressLabels", n, r);
    },
    removeAddressLabel (t, e) {
        const r = f.getAccountProp("addressLabels", e) || new Map;
        r.delete(t), f.setAccountProp("addressLabels", r, e);
    },
    setConnectedWalletInfo (t, e) {
        f.setAccountProp("connectedWalletInfo", t, e, !1);
    },
    setPreferredAccountType (t, e) {
        f.setAccountProp("preferredAccountTypes", {
            ...ft.preferredAccountTypes,
            [e]: t
        }, e);
    },
    setPreferredAccountTypes (t) {
        ft.preferredAccountTypes = t;
    },
    setSocialProvider (t, e) {
        t && f.setAccountProp("socialProvider", t, e);
    },
    setSocialWindow (t, e) {
        f.setAccountProp("socialWindow", t ? Ir(t) : void 0, e);
    },
    setFarcasterUrl (t, e) {
        f.setAccountProp("farcasterUrl", t, e);
    },
    async fetchTokenBalance (t) {
        ft.balanceLoading = !0;
        const e = f.state.activeCaipNetwork?.caipNetworkId, r = f.state.activeCaipNetwork?.chainNamespace, n = f.state.activeCaipAddress, i = n ? U.getPlainAddress(n) : void 0;
        if (ft.lastRetry && !U.isAllowedRetry(ft.lastRetry, 30 * Te.ONE_SEC_MS)) return ft.balanceLoading = !1, [];
        try {
            if (i && e && r) {
                const s = (await oe.getBalance(i, e)).balances.filter((a)=>a.quantity.decimals !== "0");
                return this.setTokenBalance(s, r), ft.lastRetry = void 0, ft.balanceLoading = !1, s;
            }
        } catch (o) {
            ft.lastRetry = Date.now(), t?.(o), Ee.showError("Token Balance Unavailable");
        } finally{
            ft.balanceLoading = !1;
        }
        return [];
    },
    resetAccount (t) {
        f.resetAccount(t);
    }
}, Qe = xe({
    loading: !1,
    loadingNamespaceMap: new Map,
    open: !1,
    shake: !1,
    namespace: void 0
}), he = {
    state: Qe,
    subscribe (t) {
        return We(Qe, ()=>t(Qe));
    },
    subscribeKey (t, e) {
        return He(Qe, t, e);
    },
    async open (t) {
        const e = Q.state.status === "connected";
        Y.state.wcBasic ? W.prefetch({
            fetchNetworkImages: !1,
            fetchConnectorImages: !1
        }) : await W.prefetch({
            fetchConnectorImages: !e,
            fetchFeaturedWallets: !e,
            fetchRecommendedWallets: !e
        }), t?.namespace ? (await f.switchActiveNamespace(t.namespace), he.setLoading(!0, t.namespace)) : he.setLoading(!0), j.setFilterByNamespace(t?.namespace);
        const r = f.getAccountData(t?.namespace)?.caipAddress;
        f.state.noAdapters && !r ? U.isMobile() ? D.reset("AllWallets") : D.reset("ConnectingWalletConnectBasic") : t?.view ? D.reset(t.view, t.data) : r ? D.reset("Account") : D.reset("Connect"), Qe.open = !0, zt.set({
            open: !0
        }), le.sendEvent({
            type: "track",
            event: "MODAL_OPEN",
            properties: {
                connected: !!r
            }
        });
    },
    close () {
        const t = T.state.enableEmbedded, e = !!f.state.activeCaipAddress;
        Qe.open && le.sendEvent({
            type: "track",
            event: "MODAL_CLOSE",
            properties: {
                connected: e
            }
        }), Qe.open = !1, he.clearLoading(), t ? e ? D.replace("Account") : D.push("Connect") : zt.set({
            open: !1
        }), Y.resetUri();
    },
    setLoading (t, e) {
        e && Qe.loadingNamespaceMap.set(e, t), Qe.loading = t, zt.set({
            loading: t
        });
    },
    clearLoading () {
        Qe.loadingNamespaceMap.clear(), Qe.loading = !1;
    },
    shake () {
        Qe.shake || (Qe.shake = !0, setTimeout(()=>{
            Qe.shake = !1;
        }, 500));
    }
}, Md = {
    id: "2b92315d-eab7-5bef-84fa-089a131333f5",
    name: "USD Coin",
    symbol: "USDC",
    networks: [
        {
            name: "ethereum-mainnet",
            display_name: "Ethereum",
            chain_id: "1",
            contract_address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"
        },
        {
            name: "polygon-mainnet",
            display_name: "Polygon",
            chain_id: "137",
            contract_address: "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174"
        }
    ]
}, Tf = {
    id: "USD",
    payment_method_limits: [
        {
            id: "card",
            min: "10.00",
            max: "7500.00"
        },
        {
            id: "ach_bank_account",
            min: "10.00",
            max: "25000.00"
        }
    ]
}, Of = {
    providers: s1,
    selectedProvider: null,
    error: null,
    purchaseCurrency: Md,
    paymentCurrency: Tf,
    purchaseCurrencies: [
        Md
    ],
    paymentCurrencies: [],
    quotesLoading: !1
};
xe(Of);
const $f = {
    initializing: !1,
    initialized: !1,
    loadingPrices: !1,
    loadingQuote: !1,
    loadingApprovalTransaction: !1,
    loadingBuildTransaction: !1,
    loadingTransaction: !1,
    fetchError: !1,
    approvalTransaction: void 0,
    swapTransaction: void 0,
    transactionError: void 0,
    sourceToken: void 0,
    sourceTokenAmount: "",
    sourceTokenPriceInUSD: 0,
    toToken: void 0,
    toTokenAmount: "",
    toTokenPriceInUSD: 0,
    networkPrice: "0",
    networkBalanceInUSD: "0",
    networkTokenSymbol: "",
    inputError: void 0,
    slippage: Te.CONVERT_SLIPPAGE_TOLERANCE,
    tokens: void 0,
    popularTokens: void 0,
    suggestedTokens: void 0,
    foundTokens: void 0,
    myTokensWithBalance: void 0,
    tokensPriceMap: {},
    gasFee: "0",
    gasPriceInUSD: 0,
    priceImpact: void 0,
    maxSlippage: void 0,
    providerFee: void 0
};
xe($f);
const Et = xe({
    message: "",
    open: !1,
    triggerRect: {
        width: 0,
        height: 0,
        top: 0,
        left: 0
    },
    variant: "shade"
}), mn = {
    state: Et,
    subscribe (t) {
        return We(Et, ()=>t(Et));
    },
    subscribeKey (t, e) {
        return He(Et, t, e);
    },
    showTooltip ({ message: t, triggerRect: e, variant: r }) {
        Et.open = !0, Et.message = t, Et.triggerRect = e, Et.variant = r;
    },
    hide () {
        Et.open = !1, Et.message = "", Et.triggerRect = {
            width: 0,
            height: 0,
            top: 0,
            left: 0
        };
    }
}, Dd = 2147483648, Pf = {
    convertEVMChainIdToCoinType (t) {
        if (t >= Dd) throw new Error("Invalid chainId");
        return (Dd | t) >>> 0;
    }
}, gt = xe({
    suggestions: [],
    loading: !1
}), zd = {
    state: gt,
    subscribe (t) {
        return We(gt, ()=>t(gt));
    },
    subscribeKey (t, e) {
        return He(gt, t, e);
    },
    async resolveName (t) {
        try {
            return await oe.lookupEnsName(t);
        } catch (e) {
            const r = e;
            throw new Error(r?.reasons?.[0]?.description || "Error resolving name");
        }
    },
    async isNameRegistered (t) {
        try {
            return await oe.lookupEnsName(t), !0;
        } catch  {
            return !1;
        }
    },
    async getSuggestions (t) {
        try {
            gt.loading = !0, gt.suggestions = [];
            const e = await oe.getEnsNameSuggestions(t);
            return gt.suggestions = e.suggestions.map((r)=>({
                    ...r,
                    name: r.name
                })) || [], gt.suggestions;
        } catch (e) {
            const r = this.parseEnsApiError(e, "Error fetching name suggestions");
            throw new Error(r);
        } finally{
            gt.loading = !1;
        }
    },
    async getNamesForAddress (t) {
        try {
            if (!f.state.activeCaipNetwork) return [];
            const r = q.getEnsFromCacheForAddress(t);
            if (r) return r;
            const n = await oe.reverseLookupEnsName({
                address: t
            });
            return q.updateEnsCache({
                address: t,
                ens: n,
                timestamp: Date.now()
            }), n;
        } catch (e) {
            const r = this.parseEnsApiError(e, "Error fetching names for address");
            throw new Error(r);
        }
    },
    async registerName (t) {
        const e = f.state.activeCaipNetwork;
        if (!e) throw new Error("Network not found");
        const r = Q.state.address, n = j.getAuthConnector();
        if (!r || !n) throw new Error("Address or auth connector not found");
        gt.loading = !0;
        try {
            const i = JSON.stringify({
                name: t,
                attributes: {},
                timestamp: Math.floor(Date.now() / 1e3)
            });
            D.pushTransactionStack({
                view: "RegisterAccountNameSuccess",
                goBack: !1,
                replace: !0,
                onCancel () {
                    gt.loading = !1;
                }
            });
            const o = await Y.signMessage(i), s = e.id;
            if (!s) throw new Error("Network not found");
            const a = Pf.convertEVMChainIdToCoinType(Number(s));
            await oe.registerEnsName({
                coinType: a,
                address: r,
                signature: o,
                message: i
            }), Q.setProfileName(t, e.chainNamespace), D.replace("RegisterAccountNameSuccess");
        } catch (i) {
            const o = this.parseEnsApiError(i, `Error registering name ${t}`);
            throw D.replace("RegisterAccountName"), new Error(o);
        } finally{
            gt.loading = !1;
        }
    },
    validateName (t) {
        return /^[a-zA-Z0-9-]{4,}$/u.test(t);
    },
    parseEnsApiError (t, e) {
        return t?.reasons?.[0]?.description || e;
    }
};
xe({
    isLegalCheckboxChecked: !1
});
const Be = {
    METMASK_CONNECTOR_NAME: "MetaMask",
    TRUST_CONNECTOR_NAME: "Trust Wallet",
    SOLFLARE_CONNECTOR_NAME: "Solflare",
    PHANTOM_CONNECTOR_NAME: "Phantom",
    COIN98_CONNECTOR_NAME: "Coin98",
    MAGIC_EDEN_CONNECTOR_NAME: "Magic Eden",
    BACKPACK_CONNECTOR_NAME: "Backpack",
    BITGET_CONNECTOR_NAME: "Bitget Wallet",
    FRONTIER_CONNECTOR_NAME: "Frontier",
    XVERSE_CONNECTOR_NAME: "Xverse Wallet",
    LEATHER_CONNECTOR_NAME: "Leather",
    EIP155: "eip155",
    ADD_CHAIN_METHOD: "wallet_addEthereumChain",
    EIP6963_ANNOUNCE_EVENT: "eip6963:announceProvider",
    EIP6963_REQUEST_EVENT: "eip6963:requestProvider",
    CONNECTOR_RDNS_MAP: {
        coinbaseWallet: "com.coinbase.wallet",
        coinbaseWalletSDK: "com.coinbase.wallet"
    },
    CONNECTOR_TYPE_EXTERNAL: "EXTERNAL",
    CONNECTOR_TYPE_WALLET_CONNECT: "WALLET_CONNECT",
    CONNECTOR_TYPE_INJECTED: "INJECTED",
    CONNECTOR_TYPE_ANNOUNCED: "ANNOUNCED",
    CONNECTOR_TYPE_AUTH: "AUTH",
    CONNECTOR_TYPE_MULTI_CHAIN: "MULTI_CHAIN",
    CONNECTOR_TYPE_W3M_AUTH: "ID_AUTH"
}, Fo = {
    ConnectorExplorerIds: {
        [G.CONNECTOR_ID.COINBASE]: "fd20dc426fb37566d803205b19bbc1d4096b248ac04548e3cfb6b3a38bd033aa",
        [G.CONNECTOR_ID.COINBASE_SDK]: "fd20dc426fb37566d803205b19bbc1d4096b248ac04548e3cfb6b3a38bd033aa",
        [G.CONNECTOR_ID.SAFE]: "225affb176778569276e484e1b92637ad061b01e13a048b35a9d280c3b58970f",
        [G.CONNECTOR_ID.LEDGER]: "19177a98252e07ddfc9af2083ba8e07ef627cb6103467ffebb3f8f4205fd7927",
        [G.CONNECTOR_ID.OKX]: "971e689d0a5be527bac79629b4ee9b925e82208e5168b733496a09c0faed0709",
        [Be.METMASK_CONNECTOR_NAME]: "c57ca95b47569778a828d19178114f4db188b89b763c899ba0be274e97267d96",
        [Be.TRUST_CONNECTOR_NAME]: "4622a2b2d6af1c9844944291e5e7351a6aa24cd7b23099efac1b2fd875da31a0",
        [Be.SOLFLARE_CONNECTOR_NAME]: "1ca0bdd4747578705b1939af023d120677c64fe6ca76add81fda36e350605e79",
        [Be.PHANTOM_CONNECTOR_NAME]: "a797aa35c0fadbfc1a53e7f675162ed5226968b44a19ee3d24385c64d1d3c393",
        [Be.COIN98_CONNECTOR_NAME]: "2a3c89040ac3b723a1972a33a125b1db11e258a6975d3a61252cd64e6ea5ea01",
        [Be.MAGIC_EDEN_CONNECTOR_NAME]: "8b830a2b724a9c3fbab63af6f55ed29c9dfa8a55e732dc88c80a196a2ba136c6",
        [Be.BACKPACK_CONNECTOR_NAME]: "2bd8c14e035c2d48f184aaa168559e86b0e3433228d3c4075900a221785019b0",
        [Be.BITGET_CONNECTOR_NAME]: "38f5d18bd8522c244bdd70cb4a68e0e718865155811c043f052fb9f1c51de662",
        [Be.FRONTIER_CONNECTOR_NAME]: "85db431492aa2e8672e93f4ea7acf10c88b97b867b0d373107af63dc4880f041",
        [Be.XVERSE_CONNECTOR_NAME]: "2a87d74ae02e10bdd1f51f7ce6c4e1cc53cd5f2c0b6b5ad0d7b3007d2b13de7b",
        [Be.LEATHER_CONNECTOR_NAME]: "483afe1df1df63daf313109971ff3ef8356ddf1cc4e45877d205eee0b7893a13"
    },
    NetworkImageIds: {
        1: "ba0ba0cd-17c6-4806-ad93-f9d174f17900",
        42161: "3bff954d-5cb0-47a0-9a23-d20192e74600",
        43114: "30c46e53-e989-45fb-4549-be3bd4eb3b00",
        56: "93564157-2e8e-4ce7-81df-b264dbee9b00",
        250: "06b26297-fe0c-4733-5d6b-ffa5498aac00",
        10: "ab9c186a-c52f-464b-2906-ca59d760a400",
        137: "41d04d42-da3b-4453-8506-668cc0727900",
        5e3: "e86fae9b-b770-4eea-e520-150e12c81100",
        295: "6a97d510-cac8-4e58-c7ce-e8681b044c00",
        11155111: "e909ea0a-f92a-4512-c8fc-748044ea6800",
        84532: "a18a7ecd-e307-4360-4746-283182228e00",
        1301: "4eeea7ef-0014-4649-5d1d-07271a80f600",
        130: "2257980a-3463-48c6-cbac-a42d2a956e00",
        10143: "0a728e83-bacb-46db-7844-948f05434900",
        100: "02b53f6a-e3d4-479e-1cb4-21178987d100",
        9001: "f926ff41-260d-4028-635e-91913fc28e00",
        324: "b310f07f-4ef7-49f3-7073-2a0a39685800",
        314: "5a73b3dd-af74-424e-cae0-0de859ee9400",
        4689: "34e68754-e536-40da-c153-6ef2e7188a00",
        1088: "3897a66d-40b9-4833-162f-a2c90531c900",
        1284: "161038da-44ae-4ec7-1208-0ea569454b00",
        1285: "f1d73bb6-5450-4e18-38f7-fb6484264a00",
        7777777: "845c60df-d429-4991-e687-91ae45791600",
        42220: "ab781bbc-ccc6-418d-d32d-789b15da1f00",
        8453: "7289c336-3981-4081-c5f4-efc26ac64a00",
        1313161554: "3ff73439-a619-4894-9262-4470c773a100",
        2020: "b8101fc0-9c19-4b6f-ec65-f6dfff106e00",
        2021: "b8101fc0-9c19-4b6f-ec65-f6dfff106e00",
        80094: "e329c2c9-59b0-4a02-83e4-212ff3779900",
        2741: "fc2427d1-5af9-4a9c-8da5-6f94627cd900",
        "5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp": "a1b58899-f671-4276-6a5e-56ca5bd59700",
        "4uhcVJyU9pJkvQyS88uRDiswHXSCkY3z": "a1b58899-f671-4276-6a5e-56ca5bd59700",
        EtWTRABZaYq6iMfeYKouRu166VU2xqa1: "a1b58899-f671-4276-6a5e-56ca5bd59700",
        "000000000019d6689c085ae165831e93": "0b4838db-0161-4ffe-022d-532bf03dba00",
        "000000000933ea01ad0ee984209779ba": "39354064-d79b-420b-065d-f980c4b78200"
    },
    ConnectorImageIds: {
        [G.CONNECTOR_ID.COINBASE]: "0c2840c3-5b04-4c44-9661-fbd4b49e1800",
        [G.CONNECTOR_ID.COINBASE_SDK]: "0c2840c3-5b04-4c44-9661-fbd4b49e1800",
        [G.CONNECTOR_ID.SAFE]: "461db637-8616-43ce-035a-d89b8a1d5800",
        [G.CONNECTOR_ID.LEDGER]: "54a1aa77-d202-4f8d-0fb2-5d2bb6db0300",
        [G.CONNECTOR_ID.WALLET_CONNECT]: "ef1a1fcf-7fe8-4d69-bd6d-fda1345b4400",
        [G.CONNECTOR_ID.INJECTED]: "07ba87ed-43aa-4adf-4540-9e6a2b9cae00"
    },
    ConnectorNamesMap: {
        [G.CONNECTOR_ID.INJECTED]: "Browser Wallet",
        [G.CONNECTOR_ID.WALLET_CONNECT]: "WalletConnect",
        [G.CONNECTOR_ID.COINBASE]: "Coinbase",
        [G.CONNECTOR_ID.COINBASE_SDK]: "Coinbase",
        [G.CONNECTOR_ID.LEDGER]: "Ledger",
        [G.CONNECTOR_ID.SAFE]: "Safe"
    },
    ConnectorTypesMap: {
        [G.CONNECTOR_ID.INJECTED]: "INJECTED",
        [G.CONNECTOR_ID.WALLET_CONNECT]: "WALLET_CONNECT",
        [G.CONNECTOR_ID.EIP6963]: "ANNOUNCED",
        [G.CONNECTOR_ID.AUTH]: "AUTH"
    },
    WalletConnectRpcChainIds: [
        1,
        5,
        11155111,
        10,
        420,
        42161,
        421613,
        137,
        80001,
        42220,
        1313161554,
        1313161555,
        56,
        97,
        43114,
        43113,
        100,
        8453,
        84531,
        7777777,
        999,
        324,
        280
    ]
}, Ja = {
    getCaipTokens (t) {
        if (!t) return;
        const e = {};
        return Object.entries(t).forEach(([r, n])=>{
            e[`${Be.EIP155}:${r}`] = n;
        }), e;
    },
    isLowerCaseMatch (t, e) {
        return t?.toLowerCase() === e?.toLowerCase();
    }
}, Ho = {
    UniversalProviderErrors: {
        UNAUTHORIZED_DOMAIN_NOT_ALLOWED: {
            message: "Unauthorized: origin not allowed",
            alertErrorKey: "INVALID_APP_CONFIGURATION"
        },
        JWT_VALIDATION_ERROR: {
            message: "JWT validation error: JWT Token is not yet valid",
            alertErrorKey: "JWT_TOKEN_NOT_VALID"
        },
        INVALID_KEY: {
            message: "Unauthorized: invalid key",
            alertErrorKey: "INVALID_PROJECT_ID"
        }
    },
    ALERT_ERRORS: {
        SWITCH_NETWORK_NOT_FOUND: {
            shortMessage: "Network Not Found",
            longMessage: "Network not found - please make sure it is included in 'networks' array in createAppKit function"
        },
        INVALID_APP_CONFIGURATION: {
            shortMessage: "Invalid App Configuration",
            longMessage: ()=>`Origin ${Bf() ? window.origin : "unknown"} not found on Allowlist - update configuration on cloud.reown.com`
        },
        SOCIALS_TIMEOUT: {
            shortMessage: "Invalid App Configuration",
            longMessage: ()=>"There was an issue loading the embedded wallet. Please verify that your domain is allowed at cloud.reown.com"
        },
        JWT_TOKEN_NOT_VALID: {
            shortMessage: "Session Expired",
            longMessage: "Invalid session found on UniversalProvider - please check your time settings and connect again"
        },
        INVALID_PROJECT_ID: {
            shortMessage: "Invalid App Configuration",
            longMessage: "Invalid Project ID - update configuration"
        },
        PROJECT_ID_NOT_CONFIGURED: {
            shortMessage: "Project ID Not Configured",
            longMessage: "Project ID Not Configured - update configuration on cloud.reown.com"
        }
    }
};
function Bf() {
    return ("TURBOPACK compile-time value", "undefined") < "u";
}
function Rf(t) {
    try {
        return JSON.stringify(t);
    } catch  {
        return '"[Circular]"';
    }
}
var Lf = Uf;
function Uf(t, e, r) {
    var n = r && r.stringify || Rf, i = 1;
    if (typeof t == "object" && t !== null) {
        var o = e.length + i;
        if (o === 1) return t;
        var s = new Array(o);
        s[0] = n(t);
        for(var a = 1; a < o; a++)s[a] = n(e[a]);
        return s.join(" ");
    }
    if (typeof t != "string") return t;
    var c = e.length;
    if (c === 0) return t;
    for(var l = "", d = 1 - i, u = -1, h = t && t.length || 0, p = 0; p < h;){
        if (t.charCodeAt(p) === 37 && p + 1 < h) {
            switch(u = u > -1 ? u : 0, t.charCodeAt(p + 1)){
                case 100:
                case 102:
                    if (d >= c || e[d] == null) break;
                    u < p && (l += t.slice(u, p)), l += Number(e[d]), u = p + 2, p++;
                    break;
                case 105:
                    if (d >= c || e[d] == null) break;
                    u < p && (l += t.slice(u, p)), l += Math.floor(Number(e[d])), u = p + 2, p++;
                    break;
                case 79:
                case 111:
                case 106:
                    if (d >= c || e[d] === void 0) break;
                    u < p && (l += t.slice(u, p));
                    var v = typeof e[d];
                    if (v === "string") {
                        l += "'" + e[d] + "'", u = p + 2, p++;
                        break;
                    }
                    if (v === "function") {
                        l += e[d].name || "<anonymous>", u = p + 2, p++;
                        break;
                    }
                    l += n(e[d]), u = p + 2, p++;
                    break;
                case 115:
                    if (d >= c) break;
                    u < p && (l += t.slice(u, p)), l += String(e[d]), u = p + 2, p++;
                    break;
                case 37:
                    u < p && (l += t.slice(u, p)), l += "%", u = p + 2, p++, d--;
                    break;
            }
            ++d;
        }
        ++p;
    }
    return u === -1 ? t : (u < h && (l += t.slice(u)), l);
}
const Wd = Lf;
var Rr = Ot;
const ri = Gf().console || {}, Mf = {
    mapHttpRequest: Zo,
    mapHttpResponse: Zo,
    wrapRequestSerializer: ec,
    wrapResponseSerializer: ec,
    wrapErrorSerializer: ec,
    req: Zo,
    res: Zo,
    err: Ff
};
function Df(t, e) {
    return Array.isArray(t) ? t.filter(function(n) {
        return n !== "!stdSerializers.err";
    }) : t === !0 ? Object.keys(e) : !1;
}
function Ot(t) {
    t = t || {}, t.browser = t.browser || {};
    const e = t.browser.transmit;
    if (e && typeof e.send != "function") throw Error("pino: transmit option must have a send function");
    const r = t.browser.write || ri;
    t.browser.write && (t.browser.asObject = !0);
    const n = t.serializers || {}, i = Df(t.browser.serialize, n);
    let o = t.browser.serialize;
    Array.isArray(t.browser.serialize) && t.browser.serialize.indexOf("!stdSerializers.err") > -1 && (o = !1);
    const s = [
        "error",
        "fatal",
        "warn",
        "info",
        "debug",
        "trace"
    ];
    typeof r == "function" && (r.error = r.fatal = r.warn = r.info = r.debug = r.trace = r), t.enabled === !1 && (t.level = "silent");
    const a = t.level || "info", c = Object.create(r);
    c.log || (c.log = ni), Object.defineProperty(c, "levelVal", {
        get: d
    }), Object.defineProperty(c, "level", {
        get: u,
        set: h
    });
    const l = {
        transmit: e,
        serialize: i,
        asObject: t.browser.asObject,
        levels: s,
        timestamp: Hf(t)
    };
    c.levels = Ot.levels, c.level = a, c.setMaxListeners = c.getMaxListeners = c.emit = c.addListener = c.on = c.prependListener = c.once = c.prependOnceListener = c.removeListener = c.removeAllListeners = c.listeners = c.listenerCount = c.eventNames = c.write = c.flush = ni, c.serializers = n, c._serialize = i, c._stdErrSerialize = o, c.child = p, e && (c._logEvent = Qa());
    function d() {
        return this.level === "silent" ? 1 / 0 : this.levels.values[this.level];
    }
    function u() {
        return this._level;
    }
    function h(v) {
        if (v !== "silent" && !this.levels.values[v]) throw Error("unknown level " + v);
        this._level = v, bn(l, c, "error", "log"), bn(l, c, "fatal", "error"), bn(l, c, "warn", "error"), bn(l, c, "info", "log"), bn(l, c, "debug", "log"), bn(l, c, "trace", "log");
    }
    function p(v, m) {
        if (!v) throw new Error("missing bindings for child Pino");
        m = m || {}, i && v.serializers && (m.serializers = v.serializers);
        const g = m.serializers;
        if (i && g) {
            var b = Object.assign({}, n, g), y = t.browser.serialize === !0 ? Object.keys(b) : i;
            delete v.serializers, Vo([
                v
            ], y, b, this._stdErrSerialize);
        }
        function x(E) {
            this._childLevel = (E._childLevel | 0) + 1, this.error = vn(E, v, "error"), this.fatal = vn(E, v, "fatal"), this.warn = vn(E, v, "warn"), this.info = vn(E, v, "info"), this.debug = vn(E, v, "debug"), this.trace = vn(E, v, "trace"), b && (this.serializers = b, this._serialize = y), e && (this._logEvent = Qa([].concat(E._logEvent.bindings, v)));
        }
        return x.prototype = this, new x(this);
    }
    return c;
}
Ot.levels = {
    values: {
        fatal: 60,
        error: 50,
        warn: 40,
        info: 30,
        debug: 20,
        trace: 10
    },
    labels: {
        10: "trace",
        20: "debug",
        30: "info",
        40: "warn",
        50: "error",
        60: "fatal"
    }
}, Ot.stdSerializers = Mf, Ot.stdTimeFunctions = Object.assign({}, {
    nullTime: jd,
    epochTime: Fd,
    unixTime: Vf,
    isoTime: Zf
});
function bn(t, e, r, n) {
    const i = Object.getPrototypeOf(e);
    e[r] = e.levelVal > e.levels.values[r] ? ni : i[r] ? i[r] : ri[r] || ri[n] || ni, zf(t, e, r);
}
function zf(t, e, r) {
    !t.transmit && e[r] === ni || (e[r] = function(n) {
        return function() {
            const o = t.timestamp(), s = new Array(arguments.length), a = Object.getPrototypeOf && Object.getPrototypeOf(this) === ri ? ri : this;
            for(var c = 0; c < s.length; c++)s[c] = arguments[c];
            if (t.serialize && !t.asObject && Vo(s, this._serialize, this.serializers, this._stdErrSerialize), t.asObject ? n.call(a, Wf(this, r, s, o)) : n.apply(a, s), t.transmit) {
                const l = t.transmit.level || e.level, d = Ot.levels.values[l], u = Ot.levels.values[r];
                if (u < d) return;
                jf(this, {
                    ts: o,
                    methodLevel: r,
                    methodValue: u,
                    transmitLevel: l,
                    transmitValue: Ot.levels.values[t.transmit.level || e.level],
                    send: t.transmit.send,
                    val: e.levelVal
                }, s);
            }
        };
    }(e[r]));
}
function Wf(t, e, r, n) {
    t._serialize && Vo(r, t._serialize, t.serializers, t._stdErrSerialize);
    const i = r.slice();
    let o = i[0];
    const s = {};
    n && (s.time = n), s.level = Ot.levels.values[e];
    let a = (t._childLevel | 0) + 1;
    if (a < 1 && (a = 1), o !== null && typeof o == "object") {
        for(; a-- && typeof i[0] == "object";)Object.assign(s, i.shift());
        o = i.length ? Wd(i.shift(), i) : void 0;
    } else typeof o == "string" && (o = Wd(i.shift(), i));
    return o !== void 0 && (s.msg = o), s;
}
function Vo(t, e, r, n) {
    for(const i in t)if (n && t[i] instanceof Error) t[i] = Ot.stdSerializers.err(t[i]);
    else if (typeof t[i] == "object" && !Array.isArray(t[i])) for(const o in t[i])e && e.indexOf(o) > -1 && o in r && (t[i][o] = r[o](t[i][o]));
}
function vn(t, e, r) {
    return function() {
        const n = new Array(1 + arguments.length);
        n[0] = e;
        for(var i = 1; i < n.length; i++)n[i] = arguments[i - 1];
        return t[r].apply(this, n);
    };
}
function jf(t, e, r) {
    const n = e.send, i = e.ts, o = e.methodLevel, s = e.methodValue, a = e.val, c = t._logEvent.bindings;
    Vo(r, t._serialize || Object.keys(t.serializers), t.serializers, t._stdErrSerialize === void 0 ? !0 : t._stdErrSerialize), t._logEvent.ts = i, t._logEvent.messages = r.filter(function(l) {
        return c.indexOf(l) === -1;
    }), t._logEvent.level.label = o, t._logEvent.level.value = s, n(o, t._logEvent, a), t._logEvent = Qa(c);
}
function Qa(t) {
    return {
        ts: 0,
        messages: [],
        bindings: t || [],
        level: {
            label: "",
            value: 0
        }
    };
}
function Ff(t) {
    const e = {
        type: t.constructor.name,
        msg: t.message,
        stack: t.stack
    };
    for(const r in t)e[r] === void 0 && (e[r] = t[r]);
    return e;
}
function Hf(t) {
    return typeof t.timestamp == "function" ? t.timestamp : t.timestamp === !1 ? jd : Fd;
}
function Zo() {
    return {};
}
function ec(t) {
    return t;
}
function ni() {}
function jd() {
    return !1;
}
function Fd() {
    return Date.now();
}
function Vf() {
    return Math.round(Date.now() / 1e3);
}
function Zf() {
    return new Date(Date.now()).toISOString();
}
function Gf() {
    function t(e) {
        return typeof e < "u" && e;
    }
    try {
        return typeof globalThis < "u" || Object.defineProperty(Object.prototype, "globalThis", {
            get: function() {
                return delete Object.prototype.globalThis, this.globalThis = this;
            },
            configurable: !0
        }), globalThis;
    } catch  {
        return t(self) || t(window) || t(this) || {};
    }
}
const qf = (t)=>JSON.stringify(t, (e, r)=>typeof r == "bigint" ? r.toString() + "n" : r);
function Hd(t) {
    return typeof t == "string" ? t : qf(t) || "";
}
const Kf = {
    level: "info"
}, tc = 1e3 * 1024;
class Yf {
    constructor(e){
        this.nodeValue = e, this.sizeInBytes = new TextEncoder().encode(this.nodeValue).length, this.next = null;
    }
    get value() {
        return this.nodeValue;
    }
    get size() {
        return this.sizeInBytes;
    }
}
class Vd {
    constructor(e){
        this.head = null, this.tail = null, this.lengthInNodes = 0, this.maxSizeInBytes = e, this.sizeInBytes = 0;
    }
    append(e) {
        const r = new Yf(e);
        if (r.size > this.maxSizeInBytes) throw new Error(`[LinkedList] Value too big to insert into list: ${e} with size ${r.size}`);
        for(; this.size + r.size > this.maxSizeInBytes;)this.shift();
        this.head ? (this.tail && (this.tail.next = r), this.tail = r) : (this.head = r, this.tail = r), this.lengthInNodes++, this.sizeInBytes += r.size;
    }
    shift() {
        if (!this.head) return;
        const e = this.head;
        this.head = this.head.next, this.head || (this.tail = null), this.lengthInNodes--, this.sizeInBytes -= e.size;
    }
    toArray() {
        const e = [];
        let r = this.head;
        for(; r !== null;)e.push(r.value), r = r.next;
        return e;
    }
    get length() {
        return this.lengthInNodes;
    }
    get size() {
        return this.sizeInBytes;
    }
    toOrderedArray() {
        return Array.from(this);
    }
    [Symbol.iterator]() {
        let e = this.head;
        return {
            next: ()=>{
                if (!e) return {
                    done: !0,
                    value: null
                };
                const r = e.value;
                return e = e.next, {
                    done: !1,
                    value: r
                };
            }
        };
    }
}
class Zd {
    constructor(e, r = tc){
        this.level = e ?? "error", this.levelValue = Rr.levels.values[this.level], this.MAX_LOG_SIZE_IN_BYTES = r, this.logs = new Vd(this.MAX_LOG_SIZE_IN_BYTES);
    }
    forwardToConsole(e, r) {
        r === Rr.levels.values.error ? console.error(e) : r === Rr.levels.values.warn ? console.warn(e) : r === Rr.levels.values.debug ? console.debug(e) : r === Rr.levels.values.trace ? console.trace(e) : console.log(e);
    }
    appendToLogs(e) {
        this.logs.append(Hd({
            timestamp: new Date().toISOString(),
            log: e
        }));
        const r = typeof e == "string" ? JSON.parse(e).level : e.level;
        r >= this.levelValue && this.forwardToConsole(e, r);
    }
    getLogs() {
        return this.logs;
    }
    clearLogs() {
        this.logs = new Vd(this.MAX_LOG_SIZE_IN_BYTES);
    }
    getLogArray() {
        return Array.from(this.logs);
    }
    logsToBlob(e) {
        const r = this.getLogArray();
        return r.push(Hd({
            extraMetadata: e
        })), new Blob(r, {
            type: "application/json"
        });
    }
}
class Xf {
    constructor(e, r = tc){
        this.baseChunkLogger = new Zd(e, r);
    }
    write(e) {
        this.baseChunkLogger.appendToLogs(e);
    }
    getLogs() {
        return this.baseChunkLogger.getLogs();
    }
    clearLogs() {
        this.baseChunkLogger.clearLogs();
    }
    getLogArray() {
        return this.baseChunkLogger.getLogArray();
    }
    logsToBlob(e) {
        return this.baseChunkLogger.logsToBlob(e);
    }
    downloadLogsBlobInBrowser(e) {
        const r = URL.createObjectURL(this.logsToBlob(e)), n = document.createElement("a");
        n.href = r, n.download = `walletconnect-logs-${new Date().toISOString()}.txt`, document.body.appendChild(n), n.click(), document.body.removeChild(n), URL.revokeObjectURL(r);
    }
}
class Jf {
    constructor(e, r = tc){
        this.baseChunkLogger = new Zd(e, r);
    }
    write(e) {
        this.baseChunkLogger.appendToLogs(e);
    }
    getLogs() {
        return this.baseChunkLogger.getLogs();
    }
    clearLogs() {
        this.baseChunkLogger.clearLogs();
    }
    getLogArray() {
        return this.baseChunkLogger.getLogArray();
    }
    logsToBlob(e) {
        return this.baseChunkLogger.logsToBlob(e);
    }
}
var Qf = Object.defineProperty, eg = Object.defineProperties, tg = Object.getOwnPropertyDescriptors, Gd = Object.getOwnPropertySymbols, rg = Object.prototype.hasOwnProperty, ng = Object.prototype.propertyIsEnumerable, qd = (t, e, r)=>e in t ? Qf(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : t[e] = r, Go = (t, e)=>{
    for(var r in e || (e = {}))rg.call(e, r) && qd(t, r, e[r]);
    if (Gd) for (var r of Gd(e))ng.call(e, r) && qd(t, r, e[r]);
    return t;
}, qo = (t, e)=>eg(t, tg(e));
function ig(t) {
    return qo(Go({}, t), {
        level: t?.level || Kf.level
    });
}
function og(t) {
    var e, r;
    const n = new Xf((e = t.opts) == null ? void 0 : e.level, t.maxSizeInBytes);
    return {
        logger: Rr(qo(Go({}, t.opts), {
            level: "trace",
            browser: qo(Go({}, (r = t.opts) == null ? void 0 : r.browser), {
                write: (i)=>n.write(i)
            })
        })),
        chunkLoggerController: n
    };
}
function sg(t) {
    var e;
    const r = new Jf((e = t.opts) == null ? void 0 : e.level, t.maxSizeInBytes);
    return {
        logger: Rr(qo(Go({}, t.opts), {
            level: "trace"
        })),
        chunkLoggerController: r
    };
}
function ag(t) {
    return typeof t.loggerOverride < "u" && typeof t.loggerOverride != "string" ? {
        logger: t.loggerOverride,
        chunkLoggerController: null
    } : ("TURBOPACK compile-time value", "undefined") < "u" ? og(t) : sg(t);
}
const cg = {
    createLogger (t, e = "error") {
        const r = ig({
            level: e
        }), { logger: n } = ag({
            opts: r
        });
        return n.error = (...i)=>{
            for (const o of i)if (o instanceof Error) {
                t(o, ...i);
                return;
            }
            t(void 0, ...i);
        }, n;
    }
}, lg = "rpc.walletconnect.org";
function Kd(t, e) {
    const r = new URL("https://rpc.walletconnect.org/v1/");
    return r.searchParams.set("chainId", t), r.searchParams.set("projectId", e), r.toString();
}
const rc = [
    "near:mainnet",
    "solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp",
    "eip155:1101",
    "eip155:56",
    "eip155:42161",
    "eip155:7777777",
    "eip155:59144",
    "eip155:324",
    "solana:EtWTRABZaYq6iMfeYKouRu166VU2xqa1",
    "eip155:5000",
    "solana:4sgjmw1sunhzsxgspuhpqldx6wiyjntz",
    "eip155:80084",
    "eip155:5003",
    "eip155:100",
    "eip155:8453",
    "eip155:42220",
    "eip155:1313161555",
    "eip155:17000",
    "eip155:1",
    "eip155:300",
    "eip155:1313161554",
    "eip155:1329",
    "eip155:84532",
    "eip155:421614",
    "eip155:11155111",
    "eip155:8217",
    "eip155:43114",
    "solana:4uhcVJyU9pJkvQyS88uRDiswHXSCkY3z",
    "eip155:999999999",
    "eip155:11155420",
    "eip155:80002",
    "eip155:97",
    "eip155:43113",
    "eip155:137",
    "eip155:10",
    "eip155:1301",
    "bip122:000000000019d6689c085ae165831e93",
    "bip122:000000000933ea01ad0ee984209779ba"
], Cn = {
    extendRpcUrlWithProjectId (t, e) {
        let r = !1;
        try {
            r = new URL(t).host === lg;
        } catch  {
            r = !1;
        }
        if (r) {
            const n = new URL(t);
            return n.searchParams.has("projectId") || n.searchParams.set("projectId", e), n.toString();
        }
        return t;
    },
    isCaipNetwork (t) {
        return "chainNamespace" in t && "caipNetworkId" in t;
    },
    getChainNamespace (t) {
        return this.isCaipNetwork(t) ? t.chainNamespace : G.CHAIN.EVM;
    },
    getCaipNetworkId (t) {
        return this.isCaipNetwork(t) ? t.caipNetworkId : `${G.CHAIN.EVM}:${t.id}`;
    },
    getDefaultRpcUrl (t, e, r) {
        const n = t.rpcUrls?.default?.http?.[0];
        return rc.includes(e) ? Kd(e, r) : n || "";
    },
    extendCaipNetwork (t, { customNetworkImageUrls: e, projectId: r, customRpcUrls: n }) {
        const i = this.getChainNamespace(t), o = this.getCaipNetworkId(t), s = t.rpcUrls.default.http?.[0], a = this.getDefaultRpcUrl(t, o, r), c = t?.rpcUrls?.chainDefault?.http?.[0] || s, l = n?.[o]?.map((h)=>h.url) || [], d = [
            ...l,
            a
        ], u = [
            ...l
        ];
        return c && !u.includes(c) && u.push(c), {
            ...t,
            chainNamespace: i,
            caipNetworkId: o,
            assets: {
                imageId: Fo.NetworkImageIds[t.id],
                imageUrl: e?.[t.id]
            },
            rpcUrls: {
                ...t.rpcUrls,
                default: {
                    http: d
                },
                chainDefault: {
                    http: u
                }
            }
        };
    },
    extendCaipNetworks (t, { customNetworkImageUrls: e, projectId: r, customRpcUrls: n }) {
        return t.map((i)=>Cn.extendCaipNetwork(i, {
                customNetworkImageUrls: e,
                customRpcUrls: n,
                projectId: r
            }));
    },
    getViemTransport (t, e, r) {
        const n = [];
        return r?.forEach((i)=>{
            n.push(Lo(i.url, i.config));
        }), rc.includes(t.caipNetworkId) && n.push(Lo(Kd(t.caipNetworkId, e), {
            fetchOptions: {
                headers: {
                    "Content-Type": "text/plain"
                }
            }
        })), t?.rpcUrls?.default?.http?.forEach((i)=>{
            n.push(Lo(i));
        }), nd(n);
    },
    extendWagmiTransports (t, e, r) {
        if (rc.includes(t.caipNetworkId)) {
            const n = this.getDefaultRpcUrl(t, t.caipNetworkId, e);
            return nd([
                r,
                Lo(n)
            ]);
        }
        return r;
    },
    getUnsupportedNetwork (t) {
        return {
            id: t.split(":")[1],
            caipNetworkId: t,
            name: G.UNSUPPORTED_NETWORK_NAME,
            chainNamespace: t.split(":")[0],
            nativeCurrency: {
                name: "",
                decimals: 0,
                symbol: ""
            },
            rpcUrls: {
                default: {
                    http: []
                }
            }
        };
    },
    getCaipNetworkFromStorage (t) {
        const e = q.getActiveCaipNetworkId(), r = f.getAllRequestedCaipNetworks(), n = Array.from(f.state.chains?.keys() || []), i = e?.split(":")[0], o = i ? n.includes(i) : !1, s = r?.find((c)=>c.caipNetworkId === e);
        return o && !s && e ? this.getUnsupportedNetwork(e) : s || t || r?.[0];
    }
}, Ko = {
    eip155: void 0,
    solana: void 0,
    polkadot: void 0,
    bip122: void 0
}, et = xe({
    providers: {
        ...Ko
    },
    providerIds: {
        ...Ko
    }
}), _e = {
    state: et,
    subscribeKey (t, e) {
        return He(et, t, e);
    },
    subscribe (t) {
        return We(et, ()=>{
            t(et);
        });
    },
    subscribeProviders (t) {
        return We(et.providers, ()=>t(et.providers));
    },
    setProvider (t, e) {
        e && (et.providers[t] = Ir(e));
    },
    getProvider (t) {
        return et.providers[t];
    },
    setProviderId (t, e) {
        e && (et.providerIds[t] = e);
    },
    getProviderId (t) {
        if (t) return et.providerIds[t];
    },
    reset () {
        et.providers = {
            ...Ko
        }, et.providerIds = {
            ...Ko
        };
    },
    resetChain (t) {
        et.providers[t] = void 0, et.providerIds[t] = void 0;
    }
};
var Yd;
(function(t) {
    t.Google = "google", t.Github = "github", t.Apple = "apple", t.Facebook = "facebook", t.X = "x", t.Discord = "discord", t.Farcaster = "farcaster";
})(Yd || (Yd = {}));
const gr = {
    ACCOUNT_TABS: [
        {
            label: "Tokens"
        },
        {
            label: "NFTs"
        },
        {
            label: "Activity"
        }
    ],
    SECURE_SITE_ORIGIN: (typeof process < "u" && typeof process.env < "u" ? process.env.NEXT_PUBLIC_SECURE_SITE_ORIGIN : void 0) || "https://secure.walletconnect.org",
    VIEW_DIRECTION: {
        Next: "next",
        Prev: "prev"
    },
    DEFAULT_CONNECT_METHOD_ORDER: [
        "email",
        "social",
        "wallet"
    ],
    ANIMATION_DURATIONS: {
        HeaderText: 120,
        ModalHeight: 150,
        ViewTransition: 150
    }
}, Lr = {
    filterOutDuplicatesByRDNS (t) {
        const e = T.state.enableEIP6963 ? j.state.connectors : [], r = q.getRecentWallets(), n = e.map((a)=>a.info?.rdns).filter(Boolean), i = r.map((a)=>a.rdns).filter(Boolean), o = n.concat(i);
        if (o.includes("io.metamask.mobile") && U.isMobile()) {
            const a = o.indexOf("io.metamask.mobile");
            o[a] = "io.metamask";
        }
        return t.filter((a)=>!o.includes(String(a?.rdns)));
    },
    filterOutDuplicatesByIds (t) {
        const e = j.state.connectors.filter((a)=>a.type === "ANNOUNCED" || a.type === "INJECTED"), r = q.getRecentWallets(), n = e.map((a)=>a.explorerId), i = r.map((a)=>a.id), o = n.concat(i);
        return t.filter((a)=>!o.includes(a?.id));
    },
    filterOutDuplicateWallets (t) {
        const e = this.filterOutDuplicatesByRDNS(t);
        return this.filterOutDuplicatesByIds(e);
    },
    markWalletsAsInstalled (t) {
        const { connectors: e } = j.state, r = e.filter((o)=>o.type === "ANNOUNCED").reduce((o, s)=>(s.info?.rdns && (o[s.info.rdns] = !0), o), {});
        return t.map((o)=>({
                ...o,
                installed: !!o.rdns && !!r[o.rdns ?? ""]
            })).sort((o, s)=>Number(s.installed) - Number(o.installed));
    },
    getConnectOrderMethod (t, e) {
        const r = t?.connectMethodsOrder || T.state.features?.connectMethodsOrder, n = e || j.state.connectors;
        if (r) return r;
        const { injected: i, announced: o } = Kt.getConnectorsByType(n, W.state.recommended, W.state.featured), s = i.filter(Kt.showConnector), a = o.filter(Kt.showConnector);
        return s.length || a.length ? [
            "wallet",
            "email",
            "social"
        ] : gr.DEFAULT_CONNECT_METHOD_ORDER;
    },
    isExcluded (t) {
        const e = !!t.rdns && W.state.excludedWallets.some((n)=>n.rdns === t.rdns), r = !!t.name && W.state.excludedWallets.some((n)=>Ja.isLowerCaseMatch(n.name, t.name));
        return e || r;
    }
}, Kt = {
    getConnectorsByType (t, e, r) {
        const { customWallets: n } = T.state, i = q.getRecentWallets(), o = Lr.filterOutDuplicateWallets(e), s = Lr.filterOutDuplicateWallets(r), a = t.filter((u)=>u.type === "MULTI_CHAIN"), c = t.filter((u)=>u.type === "ANNOUNCED"), l = t.filter((u)=>u.type === "INJECTED"), d = t.filter((u)=>u.type === "EXTERNAL");
        return {
            custom: n,
            recent: i,
            external: d,
            multiChain: a,
            announced: c,
            injected: l,
            recommended: o,
            featured: s
        };
    },
    showConnector (t) {
        const e = t.info?.rdns, r = !!e && W.state.excludedWallets.some((i)=>!!i.rdns && i.rdns === e), n = !!t.name && W.state.excludedWallets.some((i)=>Ja.isLowerCaseMatch(i.name, t.name));
        return !(t.type === "INJECTED" && (!U.isMobile() && t.name === "Browser Wallet" || !e && !Y.checkInstalled() || r || n) || (t.type === "ANNOUNCED" || t.type === "EXTERNAL") && (r || n));
    },
    getIsConnectedWithWC () {
        return Array.from(f.state.chains.values()).some((r)=>j.getConnectorId(r.namespace) === G.CONNECTOR_ID.WALLET_CONNECT);
    },
    getConnectorTypeOrder ({ recommended: t, featured: e, custom: r, recent: n, announced: i, injected: o, multiChain: s, external: a, overriddenConnectors: c = T.state.features?.connectorTypeOrder ?? [] }) {
        const l = Kt.getIsConnectedWithWC(), h = [
            {
                type: "walletConnect",
                isEnabled: T.state.enableWalletConnect && !l
            },
            {
                type: "recent",
                isEnabled: n.length > 0
            },
            {
                type: "injected",
                isEnabled: [
                    ...o,
                    ...i,
                    ...s
                ].length > 0
            },
            {
                type: "featured",
                isEnabled: e.length > 0
            },
            {
                type: "custom",
                isEnabled: r && r.length > 0
            },
            {
                type: "external",
                isEnabled: a.length > 0
            },
            {
                type: "recommended",
                isEnabled: t.length > 0
            }
        ].filter((g)=>g.isEnabled), p = new Set(h.map((g)=>g.type)), v = c.filter((g)=>p.has(g)).map((g)=>({
                type: g,
                isEnabled: !0
            })), m = h.filter(({ type: g })=>!v.some(({ type: y })=>y === g));
        return Array.from(new Set([
            ...v,
            ...m
        ].map(({ type: g })=>g)));
    }
}; /**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ 
const Yo = globalThis, nc = Yo.ShadowRoot && (Yo.ShadyCSS === void 0 || Yo.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, ic = Symbol(), Xd = new WeakMap;
class Jd {
    constructor(e, r, n){
        if (this._$cssResult$ = !0, n !== ic) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
        this.cssText = e, this.t = r;
    }
    get styleSheet() {
        let e = this.o;
        const r = this.t;
        if (nc && e === void 0) {
            const n = r !== void 0 && r.length === 1;
            n && (e = Xd.get(r)), e === void 0 && ((this.o = e = new CSSStyleSheet).replaceSync(this.cssText), n && Xd.set(r, e));
        }
        return e;
    }
    toString() {
        return this.cssText;
    }
}
const wt = (t)=>new Jd(typeof t == "string" ? t : t + "", void 0, ic), te = (t, ...e)=>{
    const r = t.length === 1 ? t[0] : e.reduce((n, i, o)=>n + ((s)=>{
            if (s._$cssResult$ === !0) return s.cssText;
            if (typeof s == "number") return s;
            throw Error("Value passed to 'css' function must be a 'css' function result: " + s + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
        })(i) + t[o + 1], t[0]);
    return new Jd(r, t, ic);
}, dg = (t, e)=>{
    if (nc) t.adoptedStyleSheets = e.map((r)=>r instanceof CSSStyleSheet ? r : r.styleSheet);
    else for (const r of e){
        const n = document.createElement("style"), i = Yo.litNonce;
        i !== void 0 && n.setAttribute("nonce", i), n.textContent = r.cssText, t.appendChild(n);
    }
}, Qd = nc ? (t)=>t : (t)=>t instanceof CSSStyleSheet ? ((e)=>{
        let r = "";
        for (const n of e.cssRules)r += n.cssText;
        return wt(r);
    })(t) : t; /**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ 
const { is: ug, defineProperty: hg, getOwnPropertyDescriptor: pg, getOwnPropertyNames: fg, getOwnPropertySymbols: gg, getPrototypeOf: wg } = Object, Xo = globalThis, eu = Xo.trustedTypes, mg = eu ? eu.emptyScript : "", bg = Xo.reactiveElementPolyfillSupport, ii = (t, e)=>t, Jo = {
    toAttribute (t, e) {
        switch(e){
            case Boolean:
                t = t ? mg : null;
                break;
            case Object:
            case Array:
                t = t == null ? t : JSON.stringify(t);
        }
        return t;
    },
    fromAttribute (t, e) {
        let r = t;
        switch(e){
            case Boolean:
                r = t !== null;
                break;
            case Number:
                r = t === null ? null : Number(t);
                break;
            case Object:
            case Array:
                try {
                    r = JSON.parse(t);
                } catch  {
                    r = null;
                }
        }
        return r;
    }
}, oc = (t, e)=>!ug(t, e), tu = {
    attribute: !0,
    type: String,
    converter: Jo,
    reflect: !1,
    useDefault: !1,
    hasChanged: oc
};
Symbol.metadata ??= Symbol("metadata"), Xo.litPropertyMetadata ??= new WeakMap;
class yn extends HTMLElement {
    static addInitializer(e) {
        this._$Ei(), (this.l ??= []).push(e);
    }
    static get observedAttributes() {
        return this.finalize(), this._$Eh && [
            ...this._$Eh.keys()
        ];
    }
    static createProperty(e, r = tu) {
        if (r.state && (r.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(e) && ((r = Object.create(r)).wrapped = !0), this.elementProperties.set(e, r), !r.noAccessor) {
            const n = Symbol(), i = this.getPropertyDescriptor(e, n, r);
            i !== void 0 && hg(this.prototype, e, i);
        }
    }
    static getPropertyDescriptor(e, r, n) {
        const { get: i, set: o } = pg(this.prototype, e) ?? {
            get () {
                return this[r];
            },
            set (s) {
                this[r] = s;
            }
        };
        return {
            get: i,
            set (s) {
                const a = i?.call(this);
                o?.call(this, s), this.requestUpdate(e, a, n);
            },
            configurable: !0,
            enumerable: !0
        };
    }
    static getPropertyOptions(e) {
        return this.elementProperties.get(e) ?? tu;
    }
    static _$Ei() {
        if (this.hasOwnProperty(ii("elementProperties"))) return;
        const e = wg(this);
        e.finalize(), e.l !== void 0 && (this.l = [
            ...e.l
        ]), this.elementProperties = new Map(e.elementProperties);
    }
    static finalize() {
        if (this.hasOwnProperty(ii("finalized"))) return;
        if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(ii("properties"))) {
            const r = this.properties, n = [
                ...fg(r),
                ...gg(r)
            ];
            for (const i of n)this.createProperty(i, r[i]);
        }
        const e = this[Symbol.metadata];
        if (e !== null) {
            const r = litPropertyMetadata.get(e);
            if (r !== void 0) for (const [n, i] of r)this.elementProperties.set(n, i);
        }
        this._$Eh = new Map;
        for (const [r, n] of this.elementProperties){
            const i = this._$Eu(r, n);
            i !== void 0 && this._$Eh.set(i, r);
        }
        this.elementStyles = this.finalizeStyles(this.styles);
    }
    static finalizeStyles(e) {
        const r = [];
        if (Array.isArray(e)) {
            const n = new Set(e.flat(1 / 0).reverse());
            for (const i of n)r.unshift(Qd(i));
        } else e !== void 0 && r.push(Qd(e));
        return r;
    }
    static _$Eu(e, r) {
        const n = r.attribute;
        return n === !1 ? void 0 : typeof n == "string" ? n : typeof e == "string" ? e.toLowerCase() : void 0;
    }
    constructor(){
        super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
    }
    _$Ev() {
        this._$ES = new Promise((e)=>this.enableUpdating = e), this._$AL = new Map, this._$E_(), this.requestUpdate(), this.constructor.l?.forEach((e)=>e(this));
    }
    addController(e) {
        (this._$EO ??= new Set).add(e), this.renderRoot !== void 0 && this.isConnected && e.hostConnected?.();
    }
    removeController(e) {
        this._$EO?.delete(e);
    }
    _$E_() {
        const e = new Map, r = this.constructor.elementProperties;
        for (const n of r.keys())this.hasOwnProperty(n) && (e.set(n, this[n]), delete this[n]);
        e.size > 0 && (this._$Ep = e);
    }
    createRenderRoot() {
        const e = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
        return dg(e, this.constructor.elementStyles), e;
    }
    connectedCallback() {
        this.renderRoot ??= this.createRenderRoot(), this.enableUpdating(!0), this._$EO?.forEach((e)=>e.hostConnected?.());
    }
    enableUpdating(e) {}
    disconnectedCallback() {
        this._$EO?.forEach((e)=>e.hostDisconnected?.());
    }
    attributeChangedCallback(e, r, n) {
        this._$AK(e, n);
    }
    _$ET(e, r) {
        const n = this.constructor.elementProperties.get(e), i = this.constructor._$Eu(e, n);
        if (i !== void 0 && n.reflect === !0) {
            const o = (n.converter?.toAttribute !== void 0 ? n.converter : Jo).toAttribute(r, n.type);
            this._$Em = e, o == null ? this.removeAttribute(i) : this.setAttribute(i, o), this._$Em = null;
        }
    }
    _$AK(e, r) {
        const n = this.constructor, i = n._$Eh.get(e);
        if (i !== void 0 && this._$Em !== i) {
            const o = n.getPropertyOptions(i), s = typeof o.converter == "function" ? {
                fromAttribute: o.converter
            } : o.converter?.fromAttribute !== void 0 ? o.converter : Jo;
            this._$Em = i, this[i] = s.fromAttribute(r, o.type) ?? this._$Ej?.get(i) ?? null, this._$Em = null;
        }
    }
    requestUpdate(e, r, n) {
        if (e !== void 0) {
            const i = this.constructor, o = this[e];
            if (n ??= i.getPropertyOptions(e), !((n.hasChanged ?? oc)(o, r) || n.useDefault && n.reflect && o === this._$Ej?.get(e) && !this.hasAttribute(i._$Eu(e, n)))) return;
            this.C(e, r, n);
        }
        this.isUpdatePending === !1 && (this._$ES = this._$EP());
    }
    C(e, r, { useDefault: n, reflect: i, wrapped: o }, s) {
        n && !(this._$Ej ??= new Map).has(e) && (this._$Ej.set(e, s ?? r ?? this[e]), o !== !0 || s !== void 0) || (this._$AL.has(e) || (this.hasUpdated || n || (r = void 0), this._$AL.set(e, r)), i === !0 && this._$Em !== e && (this._$Eq ??= new Set).add(e));
    }
    async _$EP() {
        this.isUpdatePending = !0;
        try {
            await this._$ES;
        } catch (r) {
            Promise.reject(r);
        }
        const e = this.scheduleUpdate();
        return e != null && await e, !this.isUpdatePending;
    }
    scheduleUpdate() {
        return this.performUpdate();
    }
    performUpdate() {
        if (!this.isUpdatePending) return;
        if (!this.hasUpdated) {
            if (this.renderRoot ??= this.createRenderRoot(), this._$Ep) {
                for (const [i, o] of this._$Ep)this[i] = o;
                this._$Ep = void 0;
            }
            const n = this.constructor.elementProperties;
            if (n.size > 0) for (const [i, o] of n){
                const { wrapped: s } = o, a = this[i];
                s !== !0 || this._$AL.has(i) || a === void 0 || this.C(i, void 0, o, a);
            }
        }
        let e = !1;
        const r = this._$AL;
        try {
            e = this.shouldUpdate(r), e ? (this.willUpdate(r), this._$EO?.forEach((n)=>n.hostUpdate?.()), this.update(r)) : this._$EM();
        } catch (n) {
            throw e = !1, this._$EM(), n;
        }
        e && this._$AE(r);
    }
    willUpdate(e) {}
    _$AE(e) {
        this._$EO?.forEach((r)=>r.hostUpdated?.()), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(e)), this.updated(e);
    }
    _$EM() {
        this._$AL = new Map, this.isUpdatePending = !1;
    }
    get updateComplete() {
        return this.getUpdateComplete();
    }
    getUpdateComplete() {
        return this._$ES;
    }
    shouldUpdate(e) {
        return !0;
    }
    update(e) {
        this._$Eq &&= this._$Eq.forEach((r)=>this._$ET(r, this[r])), this._$EM();
    }
    updated(e) {}
    firstUpdated(e) {}
}
yn.elementStyles = [], yn.shadowRootOptions = {
    mode: "open"
}, yn[ii("elementProperties")] = new Map, yn[ii("finalized")] = new Map, bg?.({
    ReactiveElement: yn
}), (Xo.reactiveElementVersions ??= []).push("2.1.0"); /**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ 
const sc = globalThis, Qo = sc.trustedTypes, ru = Qo ? Qo.createPolicy("lit-html", {
    createHTML: (t)=>t
}) : void 0, nu = "$lit$", wr = `lit$${Math.random().toFixed(9).slice(2)}$`, iu = "?" + wr, vg = `<${iu}>`, Ur = document, oi = ()=>Ur.createComment(""), si = (t)=>t === null || typeof t != "object" && typeof t != "function", ac = Array.isArray, Cg = (t)=>ac(t) || typeof t?.[Symbol.iterator] == "function", cc = `[ 	
\f\r]`, ai = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, ou = /-->/g, su = />/g, Mr = RegExp(`>|${cc}(?:([^\\s"'>=/]+)(${cc}*=${cc}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), au = /'/g, cu = /"/g, lu = /^(?:script|style|textarea|title)$/i, du = (t)=>(e, ...r)=>({
            _$litType$: t,
            strings: e,
            values: r
        }), w = du(1), M = du(2), Yt = Symbol.for("lit-noChange"), Ne = Symbol.for("lit-nothing"), uu = new WeakMap, Dr = Ur.createTreeWalker(Ur, 129);
function hu(t, e) {
    if (!ac(t) || !t.hasOwnProperty("raw")) throw Error("invalid template strings array");
    return ru !== void 0 ? ru.createHTML(e) : e;
}
const yg = (t, e)=>{
    const r = t.length - 1, n = [];
    let i, o = e === 2 ? "<svg>" : e === 3 ? "<math>" : "", s = ai;
    for(let a = 0; a < r; a++){
        const c = t[a];
        let l, d, u = -1, h = 0;
        for(; h < c.length && (s.lastIndex = h, d = s.exec(c), d !== null);)h = s.lastIndex, s === ai ? d[1] === "!--" ? s = ou : d[1] !== void 0 ? s = su : d[2] !== void 0 ? (lu.test(d[2]) && (i = RegExp("</" + d[2], "g")), s = Mr) : d[3] !== void 0 && (s = Mr) : s === Mr ? d[0] === ">" ? (s = i ?? ai, u = -1) : d[1] === void 0 ? u = -2 : (u = s.lastIndex - d[2].length, l = d[1], s = d[3] === void 0 ? Mr : d[3] === '"' ? cu : au) : s === cu || s === au ? s = Mr : s === ou || s === su ? s = ai : (s = Mr, i = void 0);
        const p = s === Mr && t[a + 1].startsWith("/>") ? " " : "";
        o += s === ai ? c + vg : u >= 0 ? (n.push(l), c.slice(0, u) + nu + c.slice(u) + wr + p) : c + wr + (u === -2 ? a : p);
    }
    return [
        hu(t, o + (t[r] || "<?>") + (e === 2 ? "</svg>" : e === 3 ? "</math>" : "")),
        n
    ];
};
class fo {
    constructor({ strings: e, _$litType$: r }, n){
        let i;
        this.parts = [];
        let o = 0, s = 0;
        const a = e.length - 1, c = this.parts, [l, d] = yg(e, r);
        if (this.el = fo.createElement(l, n), Dr.currentNode = this.el.content, r === 2 || r === 3) {
            const u = this.el.content.firstChild;
            u.replaceWith(...u.childNodes);
        }
        for(; (i = Dr.nextNode()) !== null && c.length < a;){
            if (i.nodeType === 1) {
                if (i.hasAttributes()) for (const u of i.getAttributeNames())if (u.endsWith(nu)) {
                    const h = d[s++], p = i.getAttribute(u).split(wr), v = /([.?@])?(.*)/.exec(h);
                    c.push({
                        type: 1,
                        index: o,
                        name: v[2],
                        strings: p,
                        ctor: v[1] === "." ? Eg : v[1] === "?" ? Ag : v[1] === "@" ? Sg : es
                    }), i.removeAttribute(u);
                } else u.startsWith(wr) && (c.push({
                    type: 6,
                    index: o
                }), i.removeAttribute(u));
                if (lu.test(i.tagName)) {
                    const u = i.textContent.split(wr), h = u.length - 1;
                    if (h > 0) {
                        i.textContent = Qo ? Qo.emptyScript : "";
                        for(let p = 0; p < h; p++)i.append(u[p], oi()), Dr.nextNode(), c.push({
                            type: 2,
                            index: ++o
                        });
                        i.append(u[h], oi());
                    }
                }
            } else if (i.nodeType === 8) if (i.data === iu) c.push({
                type: 2,
                index: o
            });
            else {
                let u = -1;
                for(; (u = i.data.indexOf(wr, u + 1)) !== -1;)c.push({
                    type: 7,
                    index: o
                }), u += wr.length - 1;
            }
            o++;
        }
    }
    static createElement(e, r) {
        const n = Ur.createElement("template");
        return n.innerHTML = e, n;
    }
}
function xn(t, e, r = t, n) {
    if (e === Yt) return e;
    let i = n !== void 0 ? r._$Co?.[n] : r._$Cl;
    const o = si(e) ? void 0 : e._$litDirective$;
    return i?.constructor !== o && (i?._$AO?.(!1), o === void 0 ? i = void 0 : (i = new o(t), i._$AT(t, r, n)), n !== void 0 ? (r._$Co ??= [])[n] = i : r._$Cl = i), i !== void 0 && (e = xn(t, i._$AS(t, e.values), i, n)), e;
}
class xg {
    constructor(e, r){
        this._$AV = [], this._$AN = void 0, this._$AD = e, this._$AM = r;
    }
    get parentNode() {
        return this._$AM.parentNode;
    }
    get _$AU() {
        return this._$AM._$AU;
    }
    u(e) {
        const { el: { content: r }, parts: n } = this._$AD, i = (e?.creationScope ?? Ur).importNode(r, !0);
        Dr.currentNode = i;
        let o = Dr.nextNode(), s = 0, a = 0, c = n[0];
        for(; c !== void 0;){
            if (s === c.index) {
                let l;
                c.type === 2 ? l = new go(o, o.nextSibling, this, e) : c.type === 1 ? l = new c.ctor(o, c.name, c.strings, this, e) : c.type === 6 && (l = new _g(o, this, e)), this._$AV.push(l), c = n[++a];
            }
            s !== c?.index && (o = Dr.nextNode(), s++);
        }
        return Dr.currentNode = Ur, i;
    }
    p(e) {
        let r = 0;
        for (const n of this._$AV)n !== void 0 && (n.strings !== void 0 ? (n._$AI(e, n, r), r += n.strings.length - 2) : n._$AI(e[r])), r++;
    }
}
class go {
    get _$AU() {
        return this._$AM?._$AU ?? this._$Cv;
    }
    constructor(e, r, n, i){
        this.type = 2, this._$AH = Ne, this._$AN = void 0, this._$AA = e, this._$AB = r, this._$AM = n, this.options = i, this._$Cv = i?.isConnected ?? !0;
    }
    get parentNode() {
        let e = this._$AA.parentNode;
        const r = this._$AM;
        return r !== void 0 && e?.nodeType === 11 && (e = r.parentNode), e;
    }
    get startNode() {
        return this._$AA;
    }
    get endNode() {
        return this._$AB;
    }
    _$AI(e, r = this) {
        e = xn(this, e, r), si(e) ? e === Ne || e == null || e === "" ? (this._$AH !== Ne && this._$AR(), this._$AH = Ne) : e !== this._$AH && e !== Yt && this._(e) : e._$litType$ !== void 0 ? this.$(e) : e.nodeType !== void 0 ? this.T(e) : Cg(e) ? this.k(e) : this._(e);
    }
    O(e) {
        return this._$AA.parentNode.insertBefore(e, this._$AB);
    }
    T(e) {
        this._$AH !== e && (this._$AR(), this._$AH = this.O(e));
    }
    _(e) {
        this._$AH !== Ne && si(this._$AH) ? this._$AA.nextSibling.data = e : this.T(Ur.createTextNode(e)), this._$AH = e;
    }
    $(e) {
        const { values: r, _$litType$: n } = e, i = typeof n == "number" ? this._$AC(e) : (n.el === void 0 && (n.el = fo.createElement(hu(n.h, n.h[0]), this.options)), n);
        if (this._$AH?._$AD === i) this._$AH.p(r);
        else {
            const o = new xg(i, this), s = o.u(this.options);
            o.p(r), this.T(s), this._$AH = o;
        }
    }
    _$AC(e) {
        let r = uu.get(e.strings);
        return r === void 0 && uu.set(e.strings, r = new fo(e)), r;
    }
    k(e) {
        ac(this._$AH) || (this._$AH = [], this._$AR());
        const r = this._$AH;
        let n, i = 0;
        for (const o of e)i === r.length ? r.push(n = new go(this.O(oi()), this.O(oi()), this, this.options)) : n = r[i], n._$AI(o), i++;
        i < r.length && (this._$AR(n && n._$AB.nextSibling, i), r.length = i);
    }
    _$AR(e = this._$AA.nextSibling, r) {
        for(this._$AP?.(!1, !0, r); e && e !== this._$AB;){
            const n = e.nextSibling;
            e.remove(), e = n;
        }
    }
    setConnected(e) {
        this._$AM === void 0 && (this._$Cv = e, this._$AP?.(e));
    }
}
class es {
    get tagName() {
        return this.element.tagName;
    }
    get _$AU() {
        return this._$AM._$AU;
    }
    constructor(e, r, n, i, o){
        this.type = 1, this._$AH = Ne, this._$AN = void 0, this.element = e, this.name = r, this._$AM = i, this.options = o, n.length > 2 || n[0] !== "" || n[1] !== "" ? (this._$AH = Array(n.length - 1).fill(new String), this.strings = n) : this._$AH = Ne;
    }
    _$AI(e, r = this, n, i) {
        const o = this.strings;
        let s = !1;
        if (o === void 0) e = xn(this, e, r, 0), s = !si(e) || e !== this._$AH && e !== Yt, s && (this._$AH = e);
        else {
            const a = e;
            let c, l;
            for(e = o[0], c = 0; c < o.length - 1; c++)l = xn(this, a[n + c], r, c), l === Yt && (l = this._$AH[c]), s ||= !si(l) || l !== this._$AH[c], l === Ne ? e = Ne : e !== Ne && (e += (l ?? "") + o[c + 1]), this._$AH[c] = l;
        }
        s && !i && this.j(e);
    }
    j(e) {
        e === Ne ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, e ?? "");
    }
}
class Eg extends es {
    constructor(){
        super(...arguments), this.type = 3;
    }
    j(e) {
        this.element[this.name] = e === Ne ? void 0 : e;
    }
}
class Ag extends es {
    constructor(){
        super(...arguments), this.type = 4;
    }
    j(e) {
        this.element.toggleAttribute(this.name, !!e && e !== Ne);
    }
}
class Sg extends es {
    constructor(e, r, n, i, o){
        super(e, r, n, i, o), this.type = 5;
    }
    _$AI(e, r = this) {
        if ((e = xn(this, e, r, 0) ?? Ne) === Yt) return;
        const n = this._$AH, i = e === Ne && n !== Ne || e.capture !== n.capture || e.once !== n.once || e.passive !== n.passive, o = e !== Ne && (n === Ne || i);
        i && this.element.removeEventListener(this.name, this, n), o && this.element.addEventListener(this.name, this, e), this._$AH = e;
    }
    handleEvent(e) {
        typeof this._$AH == "function" ? this._$AH.call(this.options?.host ?? this.element, e) : this._$AH.handleEvent(e);
    }
}
class _g {
    constructor(e, r, n){
        this.element = e, this.type = 6, this._$AN = void 0, this._$AM = r, this.options = n;
    }
    get _$AU() {
        return this._$AM._$AU;
    }
    _$AI(e) {
        xn(this, e);
    }
}
const Ig = sc.litHtmlPolyfillSupport;
Ig?.(fo, go), (sc.litHtmlVersions ??= []).push("3.3.0");
const Ng = (t, e, r)=>{
    const n = r?.renderBefore ?? e;
    let i = n._$litPart$;
    if (i === void 0) {
        const o = r?.renderBefore ?? null;
        n._$litPart$ = i = new go(e.insertBefore(oi(), o), o, void 0, r ?? {});
    }
    return i._$AI(t), i;
}; /**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ 
const lc = globalThis;
class V extends yn {
    constructor(){
        super(...arguments), this.renderOptions = {
            host: this
        }, this._$Do = void 0;
    }
    createRenderRoot() {
        const e = super.createRenderRoot();
        return this.renderOptions.renderBefore ??= e.firstChild, e;
    }
    update(e) {
        const r = this.render();
        this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(e), this._$Do = Ng(r, this.renderRoot, this.renderOptions);
    }
    connectedCallback() {
        super.connectedCallback(), this._$Do?.setConnected(!0);
    }
    disconnectedCallback() {
        super.disconnectedCallback(), this._$Do?.setConnected(!1);
    }
    render() {
        return Yt;
    }
}
V._$litElement$ = !0, V.finalized = !0, lc.litElementHydrateSupport?.({
    LitElement: V
});
const kg = lc.litElementPolyfillSupport;
kg?.({
    LitElement: V
}), (lc.litElementVersions ??= []).push("4.2.0");
let ci, mr, br;
function Tg(t, e) {
    ci = document.createElement("style"), mr = document.createElement("style"), br = document.createElement("style"), ci.textContent = En(t).core.cssText, mr.textContent = En(t).dark.cssText, br.textContent = En(t).light.cssText, document.head.appendChild(ci), document.head.appendChild(mr), document.head.appendChild(br), pu(e);
}
function pu(t) {
    mr && br && (t === "light" ? (mr.removeAttribute("media"), br.media = "enabled") : (br.removeAttribute("media"), mr.media = "enabled"));
}
function Og(t) {
    ci && mr && br && (ci.textContent = En(t).core.cssText, mr.textContent = En(t).dark.cssText, br.textContent = En(t).light.cssText);
}
function En(t) {
    return {
        core: te`
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
      @keyframes w3m-shake {
        0% {
          transform: scale(1) rotate(0deg);
        }
        20% {
          transform: scale(1) rotate(-1deg);
        }
        40% {
          transform: scale(1) rotate(1.5deg);
        }
        60% {
          transform: scale(1) rotate(-1.5deg);
        }
        80% {
          transform: scale(1) rotate(1deg);
        }
        100% {
          transform: scale(1) rotate(0deg);
        }
      }
      @keyframes w3m-iframe-fade-out {
        0% {
          opacity: 1;
        }
        100% {
          opacity: 0;
        }
      }
      @keyframes w3m-iframe-zoom-in {
        0% {
          transform: translateY(50px);
          opacity: 0;
        }
        100% {
          transform: translateY(0px);
          opacity: 1;
        }
      }
      @keyframes w3m-iframe-zoom-in-mobile {
        0% {
          transform: scale(0.95);
          opacity: 0;
        }
        100% {
          transform: scale(1);
          opacity: 1;
        }
      }
      :root {
        --w3m-modal-width: 360px;
        --w3m-color-mix-strength: ${wt(t?.["--w3m-color-mix-strength"] ? `${t["--w3m-color-mix-strength"]}%` : "0%")};
        --w3m-font-family: ${wt(t?.["--w3m-font-family"] || "Inter, Segoe UI, Roboto, Oxygen, Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue, sans-serif;")};
        --w3m-font-size-master: ${wt(t?.["--w3m-font-size-master"] || "10px")};
        --w3m-border-radius-master: ${wt(t?.["--w3m-border-radius-master"] || "4px")};
        --w3m-z-index: ${wt(t?.["--w3m-z-index"] || 999)};

        --wui-font-family: var(--w3m-font-family);

        --wui-font-size-mini: calc(var(--w3m-font-size-master) * 0.8);
        --wui-font-size-micro: var(--w3m-font-size-master);
        --wui-font-size-tiny: calc(var(--w3m-font-size-master) * 1.2);
        --wui-font-size-small: calc(var(--w3m-font-size-master) * 1.4);
        --wui-font-size-paragraph: calc(var(--w3m-font-size-master) * 1.6);
        --wui-font-size-medium: calc(var(--w3m-font-size-master) * 1.8);
        --wui-font-size-large: calc(var(--w3m-font-size-master) * 2);
        --wui-font-size-title-6: calc(var(--w3m-font-size-master) * 2.2);
        --wui-font-size-medium-title: calc(var(--w3m-font-size-master) * 2.4);
        --wui-font-size-2xl: calc(var(--w3m-font-size-master) * 4);

        --wui-border-radius-5xs: var(--w3m-border-radius-master);
        --wui-border-radius-4xs: calc(var(--w3m-border-radius-master) * 1.5);
        --wui-border-radius-3xs: calc(var(--w3m-border-radius-master) * 2);
        --wui-border-radius-xxs: calc(var(--w3m-border-radius-master) * 3);
        --wui-border-radius-xs: calc(var(--w3m-border-radius-master) * 4);
        --wui-border-radius-s: calc(var(--w3m-border-radius-master) * 5);
        --wui-border-radius-m: calc(var(--w3m-border-radius-master) * 7);
        --wui-border-radius-l: calc(var(--w3m-border-radius-master) * 9);
        --wui-border-radius-3xl: calc(var(--w3m-border-radius-master) * 20);

        --wui-font-weight-light: 400;
        --wui-font-weight-regular: 500;
        --wui-font-weight-medium: 600;
        --wui-font-weight-bold: 700;

        --wui-letter-spacing-2xl: -1.6px;
        --wui-letter-spacing-medium-title: -0.96px;
        --wui-letter-spacing-title-6: -0.88px;
        --wui-letter-spacing-large: -0.8px;
        --wui-letter-spacing-medium: -0.72px;
        --wui-letter-spacing-paragraph: -0.64px;
        --wui-letter-spacing-small: -0.56px;
        --wui-letter-spacing-tiny: -0.48px;
        --wui-letter-spacing-micro: -0.2px;
        --wui-letter-spacing-mini: -0.16px;

        --wui-spacing-0: 0px;
        --wui-spacing-4xs: 2px;
        --wui-spacing-3xs: 4px;
        --wui-spacing-xxs: 6px;
        --wui-spacing-2xs: 7px;
        --wui-spacing-xs: 8px;
        --wui-spacing-1xs: 10px;
        --wui-spacing-s: 12px;
        --wui-spacing-m: 14px;
        --wui-spacing-l: 16px;
        --wui-spacing-2l: 18px;
        --wui-spacing-xl: 20px;
        --wui-spacing-xxl: 24px;
        --wui-spacing-2xl: 32px;
        --wui-spacing-3xl: 40px;
        --wui-spacing-4xl: 90px;
        --wui-spacing-5xl: 95px;

        --wui-icon-box-size-xxs: 14px;
        --wui-icon-box-size-xs: 20px;
        --wui-icon-box-size-sm: 24px;
        --wui-icon-box-size-md: 32px;
        --wui-icon-box-size-mdl: 36px;
        --wui-icon-box-size-lg: 40px;
        --wui-icon-box-size-2lg: 48px;
        --wui-icon-box-size-xl: 64px;

        --wui-icon-size-inherit: inherit;
        --wui-icon-size-xxs: 10px;
        --wui-icon-size-xs: 12px;
        --wui-icon-size-sm: 14px;
        --wui-icon-size-md: 16px;
        --wui-icon-size-mdl: 18px;
        --wui-icon-size-lg: 20px;
        --wui-icon-size-xl: 24px;
        --wui-icon-size-xxl: 28px;

        --wui-wallet-image-size-inherit: inherit;
        --wui-wallet-image-size-sm: 40px;
        --wui-wallet-image-size-md: 56px;
        --wui-wallet-image-size-lg: 80px;

        --wui-visual-size-size-inherit: inherit;
        --wui-visual-size-sm: 40px;
        --wui-visual-size-md: 55px;
        --wui-visual-size-lg: 80px;

        --wui-box-size-md: 100px;
        --wui-box-size-lg: 120px;

        --wui-ease-out-power-2: cubic-bezier(0, 0, 0.22, 1);
        --wui-ease-out-power-1: cubic-bezier(0, 0, 0.55, 1);

        --wui-ease-in-power-3: cubic-bezier(0.66, 0, 1, 1);
        --wui-ease-in-power-2: cubic-bezier(0.45, 0, 1, 1);
        --wui-ease-in-power-1: cubic-bezier(0.3, 0, 1, 1);

        --wui-ease-inout-power-1: cubic-bezier(0.45, 0, 0.55, 1);

        --wui-duration-lg: 200ms;
        --wui-duration-md: 125ms;
        --wui-duration-sm: 75ms;

        --wui-path-network-sm: path(
          'M15.4 2.1a5.21 5.21 0 0 1 5.2 0l11.61 6.7a5.21 5.21 0 0 1 2.61 4.52v13.4c0 1.87-1 3.59-2.6 4.52l-11.61 6.7c-1.62.93-3.6.93-5.22 0l-11.6-6.7a5.21 5.21 0 0 1-2.61-4.51v-13.4c0-1.87 1-3.6 2.6-4.52L15.4 2.1Z'
        );

        --wui-path-network-md: path(
          'M43.4605 10.7248L28.0485 1.61089C25.5438 0.129705 22.4562 0.129705 19.9515 1.61088L4.53951 10.7248C2.03626 12.2051 0.5 14.9365 0.5 17.886V36.1139C0.5 39.0635 2.03626 41.7949 4.53951 43.2752L19.9515 52.3891C22.4562 53.8703 25.5438 53.8703 28.0485 52.3891L43.4605 43.2752C45.9637 41.7949 47.5 39.0635 47.5 36.114V17.8861C47.5 14.9365 45.9637 12.2051 43.4605 10.7248Z'
        );

        --wui-path-network-lg: path(
          'M78.3244 18.926L50.1808 2.45078C45.7376 -0.150261 40.2624 -0.150262 35.8192 2.45078L7.6756 18.926C3.23322 21.5266 0.5 26.3301 0.5 31.5248V64.4752C0.5 69.6699 3.23322 74.4734 7.6756 77.074L35.8192 93.5492C40.2624 96.1503 45.7376 96.1503 50.1808 93.5492L78.3244 77.074C82.7668 74.4734 85.5 69.6699 85.5 64.4752V31.5248C85.5 26.3301 82.7668 21.5266 78.3244 18.926Z'
        );

        --wui-width-network-sm: 36px;
        --wui-width-network-md: 48px;
        --wui-width-network-lg: 86px;

        --wui-height-network-sm: 40px;
        --wui-height-network-md: 54px;
        --wui-height-network-lg: 96px;

        --wui-icon-size-network-xs: 12px;
        --wui-icon-size-network-sm: 16px;
        --wui-icon-size-network-md: 24px;
        --wui-icon-size-network-lg: 42px;

        --wui-color-inherit: inherit;

        --wui-color-inverse-100: #fff;
        --wui-color-inverse-000: #000;

        --wui-cover: rgba(20, 20, 20, 0.8);

        --wui-color-modal-bg: var(--wui-color-modal-bg-base);

        --wui-color-accent-100: var(--wui-color-accent-base-100);
        --wui-color-accent-090: var(--wui-color-accent-base-090);
        --wui-color-accent-080: var(--wui-color-accent-base-080);

        --wui-color-success-100: var(--wui-color-success-base-100);
        --wui-color-success-125: var(--wui-color-success-base-125);

        --wui-color-warning-100: var(--wui-color-warning-base-100);

        --wui-color-error-100: var(--wui-color-error-base-100);
        --wui-color-error-125: var(--wui-color-error-base-125);

        --wui-color-blue-100: var(--wui-color-blue-base-100);
        --wui-color-blue-90: var(--wui-color-blue-base-90);

        --wui-icon-box-bg-error-100: var(--wui-icon-box-bg-error-base-100);
        --wui-icon-box-bg-blue-100: var(--wui-icon-box-bg-blue-base-100);
        --wui-icon-box-bg-success-100: var(--wui-icon-box-bg-success-base-100);
        --wui-icon-box-bg-inverse-100: var(--wui-icon-box-bg-inverse-base-100);

        --wui-all-wallets-bg-100: var(--wui-all-wallets-bg-100);

        --wui-avatar-border: var(--wui-avatar-border-base);

        --wui-thumbnail-border: var(--wui-thumbnail-border-base);

        --wui-wallet-button-bg: var(--wui-wallet-button-bg-base);

        --wui-box-shadow-blue: var(--wui-color-accent-glass-020);
      }

      @supports (background: color-mix(in srgb, white 50%, black)) {
        :root {
          --wui-color-modal-bg: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-modal-bg-base)
          );

          --wui-box-shadow-blue: color-mix(in srgb, var(--wui-color-accent-100) 20%, transparent);

          --wui-color-accent-100: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 100%,
            transparent
          );
          --wui-color-accent-090: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 90%,
            transparent
          );
          --wui-color-accent-080: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 80%,
            transparent
          );
          --wui-color-accent-glass-090: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 90%,
            transparent
          );
          --wui-color-accent-glass-080: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 80%,
            transparent
          );
          --wui-color-accent-glass-020: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 20%,
            transparent
          );
          --wui-color-accent-glass-015: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 15%,
            transparent
          );
          --wui-color-accent-glass-010: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 10%,
            transparent
          );
          --wui-color-accent-glass-005: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 5%,
            transparent
          );
          --wui-color-accent-002: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 2%,
            transparent
          );

          --wui-color-fg-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-100)
          );
          --wui-color-fg-125: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-125)
          );
          --wui-color-fg-150: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-150)
          );
          --wui-color-fg-175: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-175)
          );
          --wui-color-fg-200: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-200)
          );
          --wui-color-fg-225: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-225)
          );
          --wui-color-fg-250: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-250)
          );
          --wui-color-fg-275: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-275)
          );
          --wui-color-fg-300: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-300)
          );
          --wui-color-fg-325: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-325)
          );
          --wui-color-fg-350: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-350)
          );

          --wui-color-bg-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-100)
          );
          --wui-color-bg-125: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-125)
          );
          --wui-color-bg-150: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-150)
          );
          --wui-color-bg-175: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-175)
          );
          --wui-color-bg-200: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-200)
          );
          --wui-color-bg-225: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-225)
          );
          --wui-color-bg-250: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-250)
          );
          --wui-color-bg-275: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-275)
          );
          --wui-color-bg-300: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-300)
          );
          --wui-color-bg-325: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-325)
          );
          --wui-color-bg-350: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-350)
          );

          --wui-color-success-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-success-base-100)
          );
          --wui-color-success-125: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-success-base-125)
          );

          --wui-color-warning-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-warning-base-100)
          );

          --wui-color-error-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-error-base-100)
          );
          --wui-color-blue-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-blue-base-100)
          );
          --wui-color-blue-90: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-blue-base-90)
          );
          --wui-color-error-125: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-error-base-125)
          );

          --wui-icon-box-bg-error-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-icon-box-bg-error-base-100)
          );
          --wui-icon-box-bg-accent-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-icon-box-bg-blue-base-100)
          );
          --wui-icon-box-bg-success-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-icon-box-bg-success-base-100)
          );
          --wui-icon-box-bg-inverse-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-icon-box-bg-inverse-base-100)
          );

          --wui-all-wallets-bg-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-all-wallets-bg-100)
          );

          --wui-avatar-border: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-avatar-border-base)
          );

          --wui-thumbnail-border: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-thumbnail-border-base)
          );

          --wui-wallet-button-bg: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-wallet-button-bg-base)
          );
        }
      }
    `,
        light: te`
      :root {
        --w3m-color-mix: ${wt(t?.["--w3m-color-mix"] || "#fff")};
        --w3m-accent: ${wt(ir(t, "dark")["--w3m-accent"])};
        --w3m-default: #fff;

        --wui-color-modal-bg-base: ${wt(ir(t, "dark")["--w3m-background"])};
        --wui-color-accent-base-100: var(--w3m-accent);

        --wui-color-blueberry-100: hsla(230, 100%, 67%, 1);
        --wui-color-blueberry-090: hsla(231, 76%, 61%, 1);
        --wui-color-blueberry-080: hsla(230, 59%, 55%, 1);
        --wui-color-blueberry-050: hsla(231, 100%, 70%, 0.1);

        --wui-color-fg-100: #e4e7e7;
        --wui-color-fg-125: #d0d5d5;
        --wui-color-fg-150: #a8b1b1;
        --wui-color-fg-175: #a8b0b0;
        --wui-color-fg-200: #949e9e;
        --wui-color-fg-225: #868f8f;
        --wui-color-fg-250: #788080;
        --wui-color-fg-275: #788181;
        --wui-color-fg-300: #6e7777;
        --wui-color-fg-325: #9a9a9a;
        --wui-color-fg-350: #363636;

        --wui-color-bg-100: #141414;
        --wui-color-bg-125: #191a1a;
        --wui-color-bg-150: #1e1f1f;
        --wui-color-bg-175: #222525;
        --wui-color-bg-200: #272a2a;
        --wui-color-bg-225: #2c3030;
        --wui-color-bg-250: #313535;
        --wui-color-bg-275: #363b3b;
        --wui-color-bg-300: #3b4040;
        --wui-color-bg-325: #252525;
        --wui-color-bg-350: #ffffff;

        --wui-color-success-base-100: #26d962;
        --wui-color-success-base-125: #30a46b;

        --wui-color-warning-base-100: #f3a13f;

        --wui-color-error-base-100: #f25a67;
        --wui-color-error-base-125: #df4a34;

        --wui-color-blue-base-100: rgba(102, 125, 255, 1);
        --wui-color-blue-base-90: rgba(102, 125, 255, 0.9);

        --wui-color-success-glass-001: rgba(38, 217, 98, 0.01);
        --wui-color-success-glass-002: rgba(38, 217, 98, 0.02);
        --wui-color-success-glass-005: rgba(38, 217, 98, 0.05);
        --wui-color-success-glass-010: rgba(38, 217, 98, 0.1);
        --wui-color-success-glass-015: rgba(38, 217, 98, 0.15);
        --wui-color-success-glass-020: rgba(38, 217, 98, 0.2);
        --wui-color-success-glass-025: rgba(38, 217, 98, 0.25);
        --wui-color-success-glass-030: rgba(38, 217, 98, 0.3);
        --wui-color-success-glass-060: rgba(38, 217, 98, 0.6);
        --wui-color-success-glass-080: rgba(38, 217, 98, 0.8);

        --wui-color-success-glass-reown-020: rgba(48, 164, 107, 0.2);

        --wui-color-warning-glass-reown-020: rgba(243, 161, 63, 0.2);

        --wui-color-error-glass-001: rgba(242, 90, 103, 0.01);
        --wui-color-error-glass-002: rgba(242, 90, 103, 0.02);
        --wui-color-error-glass-005: rgba(242, 90, 103, 0.05);
        --wui-color-error-glass-010: rgba(242, 90, 103, 0.1);
        --wui-color-error-glass-015: rgba(242, 90, 103, 0.15);
        --wui-color-error-glass-020: rgba(242, 90, 103, 0.2);
        --wui-color-error-glass-025: rgba(242, 90, 103, 0.25);
        --wui-color-error-glass-030: rgba(242, 90, 103, 0.3);
        --wui-color-error-glass-060: rgba(242, 90, 103, 0.6);
        --wui-color-error-glass-080: rgba(242, 90, 103, 0.8);

        --wui-color-error-glass-reown-020: rgba(223, 74, 52, 0.2);

        --wui-color-gray-glass-001: rgba(255, 255, 255, 0.01);
        --wui-color-gray-glass-002: rgba(255, 255, 255, 0.02);
        --wui-color-gray-glass-005: rgba(255, 255, 255, 0.05);
        --wui-color-gray-glass-010: rgba(255, 255, 255, 0.1);
        --wui-color-gray-glass-015: rgba(255, 255, 255, 0.15);
        --wui-color-gray-glass-020: rgba(255, 255, 255, 0.2);
        --wui-color-gray-glass-025: rgba(255, 255, 255, 0.25);
        --wui-color-gray-glass-030: rgba(255, 255, 255, 0.3);
        --wui-color-gray-glass-060: rgba(255, 255, 255, 0.6);
        --wui-color-gray-glass-080: rgba(255, 255, 255, 0.8);
        --wui-color-gray-glass-090: rgba(255, 255, 255, 0.9);

        --wui-color-dark-glass-100: rgba(42, 42, 42, 1);

        --wui-icon-box-bg-error-base-100: #3c2426;
        --wui-icon-box-bg-blue-base-100: #20303f;
        --wui-icon-box-bg-success-base-100: #1f3a28;
        --wui-icon-box-bg-inverse-base-100: #243240;

        --wui-all-wallets-bg-100: #222b35;

        --wui-avatar-border-base: #252525;

        --wui-thumbnail-border-base: #252525;

        --wui-wallet-button-bg-base: var(--wui-color-bg-125);

        --w3m-card-embedded-shadow-color: rgb(17 17 18 / 25%);
      }
    `,
        dark: te`
      :root {
        --w3m-color-mix: ${wt(t?.["--w3m-color-mix"] || "#000")};
        --w3m-accent: ${wt(ir(t, "light")["--w3m-accent"])};
        --w3m-default: #000;

        --wui-color-modal-bg-base: ${wt(ir(t, "light")["--w3m-background"])};
        --wui-color-accent-base-100: var(--w3m-accent);

        --wui-color-blueberry-100: hsla(231, 100%, 70%, 1);
        --wui-color-blueberry-090: hsla(231, 97%, 72%, 1);
        --wui-color-blueberry-080: hsla(231, 92%, 74%, 1);

        --wui-color-fg-100: #141414;
        --wui-color-fg-125: #2d3131;
        --wui-color-fg-150: #474d4d;
        --wui-color-fg-175: #636d6d;
        --wui-color-fg-200: #798686;
        --wui-color-fg-225: #828f8f;
        --wui-color-fg-250: #8b9797;
        --wui-color-fg-275: #95a0a0;
        --wui-color-fg-300: #9ea9a9;
        --wui-color-fg-325: #9a9a9a;
        --wui-color-fg-350: #d0d0d0;

        --wui-color-bg-100: #ffffff;
        --wui-color-bg-125: #f5fafa;
        --wui-color-bg-150: #f3f8f8;
        --wui-color-bg-175: #eef4f4;
        --wui-color-bg-200: #eaf1f1;
        --wui-color-bg-225: #e5eded;
        --wui-color-bg-250: #e1e9e9;
        --wui-color-bg-275: #dce7e7;
        --wui-color-bg-300: #d8e3e3;
        --wui-color-bg-325: #f3f3f3;
        --wui-color-bg-350: #202020;

        --wui-color-success-base-100: #26b562;
        --wui-color-success-base-125: #30a46b;

        --wui-color-warning-base-100: #f3a13f;

        --wui-color-error-base-100: #f05142;
        --wui-color-error-base-125: #df4a34;

        --wui-color-blue-base-100: rgba(102, 125, 255, 1);
        --wui-color-blue-base-90: rgba(102, 125, 255, 0.9);

        --wui-color-success-glass-001: rgba(38, 181, 98, 0.01);
        --wui-color-success-glass-002: rgba(38, 181, 98, 0.02);
        --wui-color-success-glass-005: rgba(38, 181, 98, 0.05);
        --wui-color-success-glass-010: rgba(38, 181, 98, 0.1);
        --wui-color-success-glass-015: rgba(38, 181, 98, 0.15);
        --wui-color-success-glass-020: rgba(38, 181, 98, 0.2);
        --wui-color-success-glass-025: rgba(38, 181, 98, 0.25);
        --wui-color-success-glass-030: rgba(38, 181, 98, 0.3);
        --wui-color-success-glass-060: rgba(38, 181, 98, 0.6);
        --wui-color-success-glass-080: rgba(38, 181, 98, 0.8);

        --wui-color-success-glass-reown-020: rgba(48, 164, 107, 0.2);

        --wui-color-warning-glass-reown-020: rgba(243, 161, 63, 0.2);

        --wui-color-error-glass-001: rgba(240, 81, 66, 0.01);
        --wui-color-error-glass-002: rgba(240, 81, 66, 0.02);
        --wui-color-error-glass-005: rgba(240, 81, 66, 0.05);
        --wui-color-error-glass-010: rgba(240, 81, 66, 0.1);
        --wui-color-error-glass-015: rgba(240, 81, 66, 0.15);
        --wui-color-error-glass-020: rgba(240, 81, 66, 0.2);
        --wui-color-error-glass-025: rgba(240, 81, 66, 0.25);
        --wui-color-error-glass-030: rgba(240, 81, 66, 0.3);
        --wui-color-error-glass-060: rgba(240, 81, 66, 0.6);
        --wui-color-error-glass-080: rgba(240, 81, 66, 0.8);

        --wui-color-error-glass-reown-020: rgba(223, 74, 52, 0.2);

        --wui-icon-box-bg-error-base-100: #f4dfdd;
        --wui-icon-box-bg-blue-base-100: #d9ecfb;
        --wui-icon-box-bg-success-base-100: #daf0e4;
        --wui-icon-box-bg-inverse-base-100: #dcecfc;

        --wui-all-wallets-bg-100: #e8f1fa;

        --wui-avatar-border-base: #f3f4f4;

        --wui-thumbnail-border-base: #eaefef;

        --wui-wallet-button-bg-base: var(--wui-color-bg-125);

        --wui-color-gray-glass-001: rgba(0, 0, 0, 0.01);
        --wui-color-gray-glass-002: rgba(0, 0, 0, 0.02);
        --wui-color-gray-glass-005: rgba(0, 0, 0, 0.05);
        --wui-color-gray-glass-010: rgba(0, 0, 0, 0.1);
        --wui-color-gray-glass-015: rgba(0, 0, 0, 0.15);
        --wui-color-gray-glass-020: rgba(0, 0, 0, 0.2);
        --wui-color-gray-glass-025: rgba(0, 0, 0, 0.25);
        --wui-color-gray-glass-030: rgba(0, 0, 0, 0.3);
        --wui-color-gray-glass-060: rgba(0, 0, 0, 0.6);
        --wui-color-gray-glass-080: rgba(0, 0, 0, 0.8);
        --wui-color-gray-glass-090: rgba(0, 0, 0, 0.9);

        --wui-color-dark-glass-100: rgba(233, 233, 233, 1);

        --w3m-card-embedded-shadow-color: rgb(224 225 233 / 25%);
      }
    `
    };
}
const we = te`
  *,
  *::after,
  *::before,
  :host {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-style: normal;
    text-rendering: optimizeSpeed;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-tap-highlight-color: transparent;
    font-family: var(--wui-font-family);
    backface-visibility: hidden;
  }
`, De = te`
  button,
  a {
    cursor: pointer;
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    transition:
      color var(--wui-duration-lg) var(--wui-ease-out-power-1),
      background-color var(--wui-duration-lg) var(--wui-ease-out-power-1),
      border var(--wui-duration-lg) var(--wui-ease-out-power-1),
      border-radius var(--wui-duration-lg) var(--wui-ease-out-power-1),
      box-shadow var(--wui-duration-lg) var(--wui-ease-out-power-1);
    will-change: background-color, color, border, box-shadow, border-radius;
    outline: none;
    border: none;
    column-gap: var(--wui-spacing-3xs);
    background-color: transparent;
    text-decoration: none;
  }

  wui-flex {
    transition: border-radius var(--wui-duration-lg) var(--wui-ease-out-power-1);
    will-change: border-radius;
  }

  button:disabled > wui-wallet-image,
  button:disabled > wui-all-wallets-image,
  button:disabled > wui-network-image,
  button:disabled > wui-image,
  button:disabled > wui-transaction-visual,
  button:disabled > wui-logo {
    filter: grayscale(1);
  }

  @media (hover: hover) and (pointer: fine) {
    button:hover:enabled {
      background-color: var(--wui-color-gray-glass-005);
    }

    button:active:enabled {
      background-color: var(--wui-color-gray-glass-010);
    }
  }

  button:disabled > wui-icon-box {
    opacity: 0.5;
  }

  input {
    border: none;
    outline: none;
    appearance: none;
  }
`, li = te`
  .wui-color-inherit {
    color: var(--wui-color-inherit);
  }

  .wui-color-accent-100 {
    color: var(--wui-color-accent-100);
  }

  .wui-color-error-100 {
    color: var(--wui-color-error-100);
  }

  .wui-color-blue-100 {
    color: var(--wui-color-blue-100);
  }

  .wui-color-blue-90 {
    color: var(--wui-color-blue-90);
  }

  .wui-color-error-125 {
    color: var(--wui-color-error-125);
  }

  .wui-color-success-100 {
    color: var(--wui-color-success-100);
  }

  .wui-color-success-125 {
    color: var(--wui-color-success-125);
  }

  .wui-color-inverse-100 {
    color: var(--wui-color-inverse-100);
  }

  .wui-color-inverse-000 {
    color: var(--wui-color-inverse-000);
  }

  .wui-color-fg-100 {
    color: var(--wui-color-fg-100);
  }

  .wui-color-fg-200 {
    color: var(--wui-color-fg-200);
  }

  .wui-color-fg-300 {
    color: var(--wui-color-fg-300);
  }

  .wui-color-fg-325 {
    color: var(--wui-color-fg-325);
  }

  .wui-color-fg-350 {
    color: var(--wui-color-fg-350);
  }

  .wui-bg-color-inherit {
    background-color: var(--wui-color-inherit);
  }

  .wui-bg-color-blue-100 {
    background-color: var(--wui-color-accent-100);
  }

  .wui-bg-color-error-100 {
    background-color: var(--wui-color-error-100);
  }

  .wui-bg-color-error-125 {
    background-color: var(--wui-color-error-125);
  }

  .wui-bg-color-success-100 {
    background-color: var(--wui-color-success-100);
  }

  .wui-bg-color-success-125 {
    background-color: var(--wui-color-success-100);
  }

  .wui-bg-color-inverse-100 {
    background-color: var(--wui-color-inverse-100);
  }

  .wui-bg-color-inverse-000 {
    background-color: var(--wui-color-inverse-000);
  }

  .wui-bg-color-fg-100 {
    background-color: var(--wui-color-fg-100);
  }

  .wui-bg-color-fg-200 {
    background-color: var(--wui-color-fg-200);
  }

  .wui-bg-color-fg-300 {
    background-color: var(--wui-color-fg-300);
  }

  .wui-color-fg-325 {
    background-color: var(--wui-color-fg-325);
  }

  .wui-color-fg-350 {
    background-color: var(--wui-color-fg-350);
  }
`, Me = {
    getSpacingStyles (t, e) {
        if (Array.isArray(t)) return t[e] ? `var(--wui-spacing-${t[e]})` : void 0;
        if (typeof t == "string") return `var(--wui-spacing-${t})`;
    },
    getFormattedDate (t) {
        return new Intl.DateTimeFormat("en-US", {
            month: "short",
            day: "numeric"
        }).format(t);
    },
    getHostName (t) {
        try {
            return new URL(t).hostname;
        } catch  {
            return "";
        }
    },
    getTruncateString ({ string: t, charsStart: e, charsEnd: r, truncate: n }) {
        return t.length <= e + r ? t : n === "end" ? `${t.substring(0, e)}...` : n === "start" ? `...${t.substring(t.length - r)}` : `${t.substring(0, Math.floor(e))}...${t.substring(t.length - Math.floor(r))}`;
    },
    generateAvatarColors (t) {
        const r = t.toLowerCase().replace(/^0x/iu, "").replace(/[^a-f0-9]/gu, "").substring(0, 6).padEnd(6, "0"), n = this.hexToRgb(r), i = getComputedStyle(document.documentElement).getPropertyValue("--w3m-border-radius-master"), s = 100 - 3 * Number(i?.replace("px", "")), a = `${s}% ${s}% at 65% 40%`, c = [];
        for(let l = 0; l < 5; l += 1){
            const d = this.tintColor(n, .15 * l);
            c.push(`rgb(${d[0]}, ${d[1]}, ${d[2]})`);
        }
        return `
    --local-color-1: ${c[0]};
    --local-color-2: ${c[1]};
    --local-color-3: ${c[2]};
    --local-color-4: ${c[3]};
    --local-color-5: ${c[4]};
    --local-radial-circle: ${a}
   `;
    },
    hexToRgb (t) {
        const e = parseInt(t, 16), r = e >> 16 & 255, n = e >> 8 & 255, i = e & 255;
        return [
            r,
            n,
            i
        ];
    },
    tintColor (t, e) {
        const [r, n, i] = t, o = Math.round(r + (255 - r) * e), s = Math.round(n + (255 - n) * e), a = Math.round(i + (255 - i) * e);
        return [
            o,
            s,
            a
        ];
    },
    isNumber (t) {
        return ({
            number: /^[0-9]+$/u
        }).number.test(t);
    },
    getColorTheme (t) {
        return t || (("TURBOPACK compile-time value", "undefined") < "u" && window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)")?.matches ? "dark" : "light" : "dark");
    },
    splitBalance (t) {
        const e = t.split(".");
        return e.length === 2 ? [
            e[0],
            e[1]
        ] : [
            "0",
            "00"
        ];
    },
    roundNumber (t, e, r) {
        return t.toString().length >= e ? Number(t).toFixed(r) : t;
    },
    formatNumberToLocalString (t, e = 2) {
        return t === void 0 ? "0.00" : typeof t == "number" ? t.toLocaleString("en-US", {
            maximumFractionDigits: e,
            minimumFractionDigits: e
        }) : parseFloat(t).toLocaleString("en-US", {
            maximumFractionDigits: e,
            minimumFractionDigits: e
        });
    }
};
function $g(t, e) {
    const { kind: r, elements: n } = e;
    return {
        kind: r,
        elements: n,
        finisher (i) {
            customElements.get(t) || customElements.define(t, i);
        }
    };
}
function Pg(t, e) {
    return customElements.get(t) || customElements.define(t, e), e;
}
function F(t) {
    return function(r) {
        return typeof r == "function" ? Pg(t, r) : $g(t, r);
    };
}
function Bg(t) {
    if (t.length >= 255) throw new TypeError("Alphabet too long");
    const e = new Uint8Array(256);
    for(let l = 0; l < e.length; l++)e[l] = 255;
    for(let l = 0; l < t.length; l++){
        const d = t.charAt(l), u = d.charCodeAt(0);
        if (e[u] !== 255) throw new TypeError(d + " is ambiguous");
        e[u] = l;
    }
    const r = t.length, n = t.charAt(0), i = Math.log(r) / Math.log(256), o = Math.log(256) / Math.log(r);
    function s(l) {
        if (l instanceof Uint8Array || (ArrayBuffer.isView(l) ? l = new Uint8Array(l.buffer, l.byteOffset, l.byteLength) : Array.isArray(l) && (l = Uint8Array.from(l))), !(l instanceof Uint8Array)) throw new TypeError("Expected Uint8Array");
        if (l.length === 0) return "";
        let d = 0, u = 0, h = 0;
        const p = l.length;
        for(; h !== p && l[h] === 0;)h++, d++;
        const v = (p - h) * o + 1 >>> 0, m = new Uint8Array(v);
        for(; h !== p;){
            let y = l[h], x = 0;
            for(let E = v - 1; (y !== 0 || x < u) && E !== -1; E--, x++)y += 256 * m[E] >>> 0, m[E] = y % r >>> 0, y = y / r >>> 0;
            if (y !== 0) throw new Error("Non-zero carry");
            u = x, h++;
        }
        let g = v - u;
        for(; g !== v && m[g] === 0;)g++;
        let b = n.repeat(d);
        for(; g < v; ++g)b += t.charAt(m[g]);
        return b;
    }
    function a(l) {
        if (typeof l != "string") throw new TypeError("Expected String");
        if (l.length === 0) return new Uint8Array;
        let d = 0, u = 0, h = 0;
        for(; l[d] === n;)u++, d++;
        const p = (l.length - d) * i + 1 >>> 0, v = new Uint8Array(p);
        for(; d < l.length;){
            const y = l.charCodeAt(d);
            if (y > 255) return;
            let x = e[y];
            if (x === 255) return;
            let E = 0;
            for(let I = p - 1; (x !== 0 || E < h) && I !== -1; I--, E++)x += r * v[I] >>> 0, v[I] = x % 256 >>> 0, x = x / 256 >>> 0;
            if (x !== 0) throw new Error("Non-zero carry");
            h = E, d++;
        }
        let m = p - h;
        for(; m !== p && v[m] === 0;)m++;
        const g = new Uint8Array(u + (p - m));
        let b = u;
        for(; m !== p;)g[b++] = v[m++];
        return g;
    }
    function c(l) {
        const d = a(l);
        if (d) return d;
        throw new Error("Non-base" + r + " character");
    }
    return {
        encode: s,
        decodeUnsafe: a,
        decode: c
    };
}
var Rg = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz", Lg = Bg(Rg);
const ts = {
    ERROR_CODE_UNRECOGNIZED_CHAIN_ID: 4902,
    ERROR_CODE_DEFAULT: 5e3,
    ERROR_INVALID_CHAIN_ID: 32603
}, fu = {
    gasPriceOracle: {
        address: "0x420000000000000000000000000000000000000F"
    },
    l1Block: {
        address: "0x4200000000000000000000000000000000000015"
    },
    l2CrossDomainMessenger: {
        address: "0x4200000000000000000000000000000000000007"
    },
    l2Erc721Bridge: {
        address: "0x4200000000000000000000000000000000000014"
    },
    l2StandardBridge: {
        address: "0x4200000000000000000000000000000000000010"
    },
    l2ToL1MessagePasser: {
        address: "0x4200000000000000000000000000000000000016"
    }
}, Ug = {
    block: Vl({
        format (t) {
            return {
                transactions: t.transactions?.map((r)=>{
                    if (typeof r == "string") return r;
                    const n = $o(r);
                    return n.typeHex === "0x7e" && (n.isSystemTx = r.isSystemTx, n.mint = r.mint ? Wt(r.mint) : void 0, n.sourceHash = r.sourceHash, n.type = "deposit"), n;
                }),
                stateRoot: t.stateRoot
            };
        }
    }),
    transaction: Hl({
        format (t) {
            const e = {};
            return t.type === "0x7e" && (e.isSystemTx = t.isSystemTx, e.mint = t.mint ? Wt(t.mint) : void 0, e.sourceHash = t.sourceHash, e.type = "deposit"), e;
        }
    }),
    transactionReceipt: dp({
        format (t) {
            return {
                l1GasPrice: t.l1GasPrice ? Wt(t.l1GasPrice) : null,
                l1GasUsed: t.l1GasUsed ? Wt(t.l1GasUsed) : null,
                l1Fee: t.l1Fee ? Wt(t.l1Fee) : null,
                l1FeeScalar: t.l1FeeScalar ? Number(t.l1FeeScalar) : null
            };
        }
    })
};
function gu(t, e) {
    return zg(t) ? Dg(t) : tp(t, e);
}
const Mg = {
    transaction: gu
};
function Dg(t) {
    Wg(t);
    const { sourceHash: e, data: r, from: n, gas: i, isSystemTx: o, mint: s, to: a, value: c } = t, l = [
        e,
        n,
        a ?? "0x",
        s ? ie(s) : "0x",
        c ? ie(c) : "0x",
        i ? ie(i) : "0x",
        o ? "0x1" : "0x",
        r ?? "0x"
    ];
    return dn([
        "0x7e",
        hr(l)
    ]);
}
function zg(t) {
    return t.type === "deposit" || typeof t.sourceHash < "u";
}
function Wg(t) {
    const { from: e, to: r } = t;
    if (e && !Ht(e)) throw new ur({
        address: e
    });
    if (r && !Ht(r)) throw new ur({
        address: r
    });
}
const O = {
    contracts: fu,
    formatters: Ug,
    serializers: Mg
}, rs = 1;
({
    ...O,
    contracts: {
        ...O.contracts,
        l2OutputOracle: rs + "",
        portal: rs + "",
        l1StandardBridge: rs + ""
    }
});
const ns = 11155111;
({
    ...O,
    contracts: {
        ...O.contracts,
        l2OutputOracle: ns + "",
        portal: ns + "",
        l1StandardBridge: ns + ""
    }
});
const di = 1;
({
    ...O,
    contracts: {
        ...O.contracts,
        disputeGameFactory: di + "",
        l2OutputOracle: di + "",
        portal: di + "",
        l1StandardBridge: di + ""
    }
});
const is = 5;
({
    ...O,
    contracts: {
        ...O.contracts,
        l2OutputOracle: is + "",
        portal: is + "",
        l1StandardBridge: is + ""
    }
});
const ui = 11155111;
({
    ...O,
    contracts: {
        ...O.contracts,
        disputeGameFactory: ui + "",
        l2OutputOracle: ui + "",
        portal: ui + "",
        l1StandardBridge: ui + ""
    }
}), J({
    id: 53456,
    name: "BirdLayer",
    nativeCurrency: {
        decimals: 18,
        name: "Ether",
        symbol: "ETH"
    },
    rpcUrls: {
        default: {
            http: [
                "https://rpc.birdlayer.xyz",
                "https://rpc1.birdlayer.xyz"
            ],
            webSocket: [
                "wss://rpc.birdlayer.xyz/ws"
            ]
        }
    },
    blockExplorers: {
        default: {
            name: "BirdLayer Explorer",
            url: "https://scan.birdlayer.xyz"
        }
    }
});
const jg = 1;
({
    ...O,
    contracts: {
        ...O.contracts
    }
});
const dc = 1;
J({
    ...O,
    id: 60808,
    name: "BOB",
    nativeCurrency: {
        decimals: 18,
        name: "ETH",
        symbol: "ETH"
    },
    rpcUrls: {
        default: {
            http: [
                "https://rpc.gobob.xyz"
            ],
            webSocket: [
                "wss://rpc.gobob.xyz"
            ]
        }
    },
    blockExplorers: {
        default: {
            name: "BOB Explorer",
            url: "https://explorer.gobob.xyz"
        }
    },
    contracts: {
        ...O.contracts,
        multicall3: {
            address: "0xcA11bde05977b3631167028862bE2a173976CA11",
            blockCreated: 23131
        },
        l2OutputOracle: {
            [dc]: {
                address: "0xdDa53E23f8a32640b04D7256e651C1db98dB11C1",
                blockCreated: 4462615
            }
        },
        portal: {
            [dc]: {
                address: "0x8AdeE124447435fE03e3CD24dF3f4cAE32E65a3E",
                blockCreated: 4462615
            }
        }
    },
    sourceId: dc
});
const uc = 11155111;
J({
    ...O,
    id: 808813,
    name: "BOB Sepolia",
    nativeCurrency: {
        decimals: 18,
        name: "ETH",
        symbol: "ETH"
    },
    rpcUrls: {
        default: {
            http: [
                "https://bob-sepolia.rpc.gobob.xyz"
            ],
            webSocket: [
                "wss://bob-sepolia.rpc.gobob.xyz"
            ]
        }
    },
    blockExplorers: {
        default: {
            name: "BOB Sepolia Explorer",
            url: "https://bob-sepolia.explorer.gobob.xyz"
        }
    },
    contracts: {
        ...O.contracts,
        multicall3: {
            address: "0xcA11bde05977b3631167028862bE2a173976CA11",
            blockCreated: 35677
        },
        l2OutputOracle: {
            [uc]: {
                address: "0x14D0069452b4AE2b250B395b8adAb771E4267d2f",
                blockCreated: 4462615
            }
        },
        portal: {
            [uc]: {
                address: "0x867B1Aa872b9C8cB5E9F7755feDC45BB24Ad0ae4",
                blockCreated: 4462615
            }
        }
    },
    testnet: !0,
    sourceId: uc
});
const Fg = {
    estimateFeesPerGas: async (t)=>{
        if (!t.request?.feeCurrency) return null;
        const [e, r] = await Promise.all([
            Hg(t.client, t.request.feeCurrency),
            Vg(t.client, t.request.feeCurrency)
        ]);
        return {
            maxFeePerGas: t.multiply(e - r) + r,
            maxPriorityFeePerGas: r
        };
    }
};
async function Hg(t, e) {
    const r = await t.request({
        method: "eth_gasPrice",
        params: [
            e
        ]
    });
    return BigInt(r);
}
async function Vg(t, e) {
    const r = await t.request({
        method: "eth_maxPriorityFeePerGas",
        params: [
            e
        ]
    });
    return BigInt(r);
}
function wu(t) {
    return t === 0 || t === 0n || t === void 0 || t === null || t === "0" || t === "" || typeof t == "string" && (sn(t).toLowerCase() === "0x" || sn(t).toLowerCase() === "0x00");
}
function hi(t) {
    return !wu(t);
}
function Zg(t) {
    return typeof t.maxFeePerGas < "u" && typeof t.maxPriorityFeePerGas < "u";
}
function mu(t) {
    return t.type === "cip64" ? !0 : Zg(t) && hi(t.feeCurrency);
}
const Gg = {
    block: Vl({
        format (t) {
            return {
                transactions: t.transactions?.map((r)=>typeof r == "string" ? r : {
                        ...$o(r),
                        ...r.gatewayFee ? {
                            gatewayFee: Wt(r.gatewayFee),
                            gatewayFeeRecipient: r.gatewayFeeRecipient
                        } : {},
                        feeCurrency: r.feeCurrency
                    }),
                ...t.randomness ? {
                    randomness: t.randomness
                } : {}
            };
        }
    }),
    transaction: Hl({
        format (t) {
            if (t.type === "0x7e") return {
                isSystemTx: t.isSystemTx,
                mint: t.mint ? Wt(t.mint) : void 0,
                sourceHash: t.sourceHash,
                type: "deposit"
            };
            const e = {
                feeCurrency: t.feeCurrency
            };
            return t.type === "0x7b" ? e.type = "cip64" : (t.type === "0x7c" && (e.type = "cip42"), e.gatewayFee = t.gatewayFee ? Wt(t.gatewayFee) : null, e.gatewayFeeRecipient = t.gatewayFeeRecipient), e;
        }
    }),
    transactionRequest: bh({
        format (t) {
            const e = {};
            return t.feeCurrency && (e.feeCurrency = t.feeCurrency), mu(t) && (e.type = "0x7b"), e;
        }
    })
};
function qg(t, e) {
    return mu(t) ? Yg(t, e) : gu(t, e);
}
const Kg = {
    transaction: qg
};
function Yg(t, e) {
    Jg(t);
    const { chainId: r, gas: n, nonce: i, to: o, value: s, maxFeePerGas: a, maxPriorityFeePerGas: c, accessList: l, feeCurrency: d, data: u } = t, h = [
        ie(r),
        i ? ie(i) : "0x",
        c ? ie(c) : "0x",
        a ? ie(a) : "0x",
        n ? ie(n) : "0x",
        o ?? "0x",
        s ? ie(s) : "0x",
        u ?? "0x",
        Jn(l),
        d,
        ...un(t, e)
    ];
    return dn([
        "0x7b",
        hr(h)
    ]);
}
const Xg = Oo;
function Jg(t) {
    const { chainId: e, maxPriorityFeePerGas: r, gasPrice: n, maxFeePerGas: i, to: o, feeCurrency: s } = t;
    if (e <= 0) throw new Xn({
        chainId: e
    });
    if (o && !Ht(o)) throw new ur({
        address: o
    });
    if (n) throw new de("`gasPrice` is not a valid CIP-64 Transaction attribute.");
    if (hi(i) && i > Xg) throw new Yn({
        maxFeePerGas: i
    });
    if (hi(r) && hi(i) && r > i) throw new Sa({
        maxFeePerGas: i,
        maxPriorityFeePerGas: r
    });
    if (hi(s) && !Ht(s)) throw new de("`feeCurrency` MUST be a token address for CIP-64 transactions.");
    if (wu(s)) throw new de("`feeCurrency` must be provided for CIP-64 transactions.");
}
const bu = {
    contracts: fu,
    formatters: Gg,
    serializers: Kg,
    fees: Fg
}, os = 17e3;
({
    ...bu,
    contracts: {
        ...bu.contracts,
        portal: os + "",
        disputeGameFactory: os + "",
        l2OutputOracle: os + "",
        l1StandardBridge: os + ""
    }
}), J({
    id: 44,
    name: "Crab Network",
    nativeCurrency: {
        decimals: 18,
        name: "Crab Network Native Token",
        symbol: "CRAB"
    },
    rpcUrls: {
        default: {
            http: [
                "https://crab-rpc.darwinia.network"
            ],
            webSocket: [
                "wss://crab-rpc.darwinia.network"
            ]
        }
    },
    blockExplorers: {
        default: {
            name: "Blockscout",
            url: "https://crab-scan.darwinia.network"
        }
    },
    contracts: {
        multicall3: {
            address: "0xca11bde05977b3631167028862be2a173976ca11",
            blockCreated: 3032593
        }
    }
}), J({
    id: 66665,
    name: "Creator",
    nativeCurrency: {
        decimals: 18,
        name: "Ether",
        symbol: "ETH"
    },
    rpcUrls: {
        default: {
            http: [
                "https://rpc.creatorchain.io"
            ]
        }
    },
    blockExplorers: {
        default: {
            name: "Explorer",
            url: "https://explorer.creatorchain.io"
        }
    },
    contracts: {
        multicall3: {
            address: "0xcA11bde05977b3631167028862bE2a173976CA11"
        }
    },
    testnet: !0
}), ({
    ...O,
    contracts: {
        ...O.contracts
    }
}), ({
    ...O,
    contracts: {
        ...O.contracts
    }
}), J({
    id: 53457,
    name: "DODOchain Testnet",
    nativeCurrency: {
        decimals: 18,
        name: "DODO",
        symbol: "DODO"
    },
    rpcUrls: {
        default: {
            http: [
                "https://dodochain-testnet.alt.technology"
            ],
            webSocket: [
                "wss://dodochain-testnet.alt.technology/ws"
            ]
        }
    },
    blockExplorers: {
        default: {
            name: "DODOchain Testnet (Sepolia) Explorer",
            url: "https://testnet-scan.dodochain.com"
        }
    },
    testnet: !0
});
const An = 1;
({
    ...O.contracts,
    addressManager: An + "",
    l1CrossDomainMessenger: An + "",
    l2OutputOracle: An + "",
    portal: An + "",
    l1StandardBridge: An + ""
});
const Sn = 11155111;
({
    ...O.contracts,
    addressManager: Sn + "",
    l1CrossDomainMessenger: Sn + "",
    l2OutputOracle: Sn + "",
    portal: Sn + "",
    l1StandardBridge: Sn + ""
});
const ss = 1;
({
    ...O,
    contracts: {
        ...O.contracts,
        l2OutputOracle: ss + "",
        portal: ss + "",
        l1StandardBridge: ss + ""
    }
});
const as = 17e3;
({
    ...O,
    contracts: {
        ...O.contracts,
        l2OutputOracle: as + "",
        portal: as + "",
        l1StandardBridge: as + ""
    }
});
const Qg = 1;
({
    ...O,
    contracts: {
        ...O.contracts
    }
});
const e2 = 11155111;
J({
    ...O,
    id: 3397901,
    network: "funkiSepolia",
    name: "Funki Sepolia Sandbox",
    nativeCurrency: {
        name: "Ether",
        symbol: "ETH",
        decimals: 18
    },
    rpcUrls: {
        default: {
            http: [
                "https://funki-testnet.alt.technology"
            ]
        }
    },
    blockExplorers: {
        default: {
            name: "Funki Sepolia Sandbox Explorer",
            url: "https://sepolia-sandbox.funkichain.com/"
        }
    },
    testnet: !0,
    contracts: {
        ...O.contracts,
        multicall3: {
            address: "0xca11bde05977b3631167028862be2a173976ca11",
            blockCreated: 1620204
        }
    },
    sourceId: e2
});
const cs = 17e3;
J({
    ...O,
    name: "Garnet Testnet",
    testnet: !0,
    id: 17069,
    sourceId: cs,
    nativeCurrency: {
        name: "Ether",
        symbol: "ETH",
        decimals: 18
    },
    rpcUrls: {
        default: {
            http: [
                "https://rpc.garnetchain.com"
            ],
            webSocket: [
                "wss://rpc.garnetchain.com"
            ]
        }
    },
    blockExplorers: {
        default: {
            name: "Blockscout",
            url: "https://explorer.garnetchain.com"
        }
    },
    contracts: {
        ...O.contracts,
        multicall3: {
            address: "0xca11bde05977b3631167028862be2a173976ca11"
        },
        portal: {
            [cs]: {
                address: "0x57ee40586fbE286AfC75E67cb69511A6D9aF5909",
                blockCreated: 1274684
            }
        },
        l2OutputOracle: {
            [cs]: {
                address: "0xCb8E7AC561b8EF04F2a15865e9fbc0766FEF569B",
                blockCreated: 1274684
            }
        },
        l1StandardBridge: {
            [cs]: {
                address: "0x09bcDd311FE398F80a78BE37E489f5D440DB95DE",
                blockCreated: 1274684
            }
        }
    }
});
const ls = 1;
({
    ...O,
    contracts: {
        ...O.contracts,
        disputeGameFactory: ls + "",
        portal: ls + "",
        l1StandardBridge: ls + ""
    }
});
const ds = 11155111;
({
    ...O,
    contracts: {
        ...O.contracts,
        disputeGameFactory: ds + "",
        portal: ds + "",
        l1StandardBridge: ds + ""
    }
}), J({
    id: 701,
    name: "Koi Network",
    nativeCurrency: {
        decimals: 18,
        name: "Koi Network Native Token",
        symbol: "KRING"
    },
    rpcUrls: {
        default: {
            http: [
                "https://koi-rpc.darwinia.network"
            ],
            webSocket: [
                "wss://koi-rpc.darwinia.network"
            ]
        }
    },
    blockExplorers: {
        default: {
            name: "Blockscout",
            url: "https://koi-scan.darwinia.network"
        }
    },
    contracts: {
        multicall3: {
            address: "0xca11bde05977b3631167028862be2a173976ca11",
            blockCreated: 180001
        }
    },
    testnet: !0
});
const us = 1;
({
    ...O,
    contracts: {
        ...O.contracts,
        l2OutputOracle: us + "",
        portal: us + "",
        l1StandardBridge: us + ""
    }
});
const hs = 11155111;
({
    ...O,
    contracts: {
        ...O.contracts,
        l2OutputOracle: hs + "",
        portal: hs + "",
        l1StandardBridge: hs + ""
    }
});
const ps = 1;
({
    ...O,
    contracts: {
        ...O.contracts,
        l2OutputOracle: ps + "",
        portal: ps + "",
        l1StandardBridge: ps + ""
    }
});
const fs = 1;
({
    ...O,
    contracts: {
        ...O.contracts,
        l2OutputOracle: fs + "",
        portal: fs + "",
        l1StandardBridge: fs + ""
    }
});
const gs = 11155111;
({
    ...O,
    contracts: {
        ...O.contracts,
        l2OutputOracle: gs + "",
        portal: gs + "",
        l1StandardBridge: gs + ""
    }
});
const ws = 56;
({
    ...O.contracts,
    l2OutputOracle: ws + "",
    portal: ws + "",
    l1StandardBridge: ws + ""
});
const ms = 97;
({
    ...O.contracts,
    l2OutputOracle: ms + "",
    portal: ms + "",
    l1StandardBridge: ms + ""
});
const pi = 1;
({
    ...O,
    contracts: {
        ...O.contracts,
        disputeGameFactory: pi + "",
        l2OutputOracle: pi + "",
        portal: pi + "",
        l1StandardBridge: pi + ""
    }
});
const bs = 5;
({
    ...O,
    contracts: {
        ...O.contracts,
        l2OutputOracle: bs + "",
        portal: bs + "",
        l1StandardBridge: bs + ""
    }
});
const fi = 11155111;
({
    ...O,
    contracts: {
        ...O.contracts,
        disputeGameFactory: fi + "",
        l2OutputOracle: fi + "",
        portal: fi + "",
        l1StandardBridge: fi + ""
    }
});
const vu = 11155111;
J({
    ...O,
    name: "Pyrope Testnet",
    testnet: !0,
    id: 695569,
    sourceId: vu,
    nativeCurrency: {
        name: "Ether",
        symbol: "ETH",
        decimals: 18
    },
    rpcUrls: {
        default: {
            http: [
                "https://rpc.pyropechain.com"
            ],
            webSocket: [
                "wss://rpc.pyropechain.com"
            ]
        }
    },
    blockExplorers: {
        default: {
            name: "Blockscout",
            url: "https://pyrope.blockscout.com"
        }
    },
    contracts: {
        ...O.contracts,
        l1StandardBridge: {
            [vu]: {
                address: "0xC24932c31D9621aE9e792576152B7ef010cFC2F8"
            }
        }
    }
});
const vs = 1;
J({
    ...O,
    name: "Redstone",
    id: 690,
    sourceId: vs,
    nativeCurrency: {
        decimals: 18,
        name: "Ether",
        symbol: "ETH"
    },
    rpcUrls: {
        default: {
            http: [
                "https://rpc.redstonechain.com"
            ],
            webSocket: [
                "wss://rpc.redstonechain.com"
            ]
        }
    },
    blockExplorers: {
        default: {
            name: "Blockscout",
            url: "https://explorer.redstone.xyz"
        }
    },
    contracts: {
        ...O.contracts,
        multicall3: {
            address: "0xca11bde05977b3631167028862be2a173976ca11"
        },
        portal: {
            [vs]: {
                address: "0xC7bCb0e8839a28A1cFadd1CF716de9016CdA51ae",
                blockCreated: 19578329
            }
        },
        l2OutputOracle: {
            [vs]: {
                address: "0xa426A052f657AEEefc298b3B5c35a470e4739d69",
                blockCreated: 19578337
            }
        },
        l1StandardBridge: {
            [vs]: {
                address: "0xc473ca7E02af24c129c2eEf51F2aDf0411c1Df69",
                blockCreated: 19578331
            }
        }
    }
});
const Cs = 1;
({
    ...O,
    contracts: {
        ...O.contracts,
        l2OutputOracle: Cs + "",
        portal: Cs + "",
        l1StandardBridge: Cs + ""
    }
});
const ys = 11155111;
({
    ...O,
    contracts: {
        ...O.contracts,
        l2OutputOracle: ys + "",
        portal: ys + "",
        l1StandardBridge: ys + ""
    }
});
const xs = 1;
({
    ...O,
    contracts: {
        ...O.contracts,
        l2OutputOracle: xs + "",
        portal: xs + "",
        l1StandardBridge: xs + ""
    }
});
const t2 = 11155111;
({
    ...O,
    contracts: {
        ...O.contracts
    }
});
const gi = 1;
({
    ...O,
    contracts: {
        ...O.contracts,
        disputeGameFactory: gi + "",
        l2OutputOracle: gi + "",
        portal: gi + "",
        l1StandardBridge: gi + ""
    }
});
const wi = 11155111;
({
    ...O,
    contracts: {
        ...O.contracts,
        disputeGameFactory: wi + "",
        l2OutputOracle: wi + "",
        portal: wi + "",
        l1StandardBridge: wi + ""
    }
});
const mi = 1;
({
    ...O,
    contracts: {
        ...O.contracts,
        disputeGameFactory: mi + "",
        l2OutputOracle: mi + "",
        portal: mi + "",
        l1StandardBridge: mi + ""
    }
});
const bi = 11155111;
({
    ...O,
    contracts: {
        ...O.contracts,
        disputeGameFactory: bi + "",
        l2OutputOracle: bi + "",
        portal: bi + "",
        l1StandardBridge: bi + ""
    }
});
const vi = 1;
({
    ...O,
    contracts: {
        ...O.contracts,
        disputeGameFactory: vi + "",
        l2OutputOracle: vi + "",
        portal: vi + "",
        l1StandardBridge: vi + ""
    }
});
const hc = 11155111;
({
    ...O,
    contracts: {
        ...O.contracts,
        portal: hc + "",
        l1StandardBridge: hc + ""
    }
}), ({
    ...O,
    contracts: {
        ...O.contracts
    }
}), {
    ...O,
    contracts: {
        ...O.contracts
    }
};
const Es = 1;
({
    ...O,
    contracts: {
        ...O.contracts,
        disputeGameFactory: Es + "",
        portal: Es + "",
        l1StandardBridge: Es + ""
    }
});
const As = 11155111;
({
    ...O,
    contracts: {
        ...O.contracts,
        portal: As + "",
        l1StandardBridge: As + "",
        disputeGameFactory: As + ""
    }
});
const Ci = 1;
({
    ...O,
    contracts: {
        ...O.contracts,
        disputeGameFactory: Ci + "",
        l2OutputOracle: Ci + "",
        portal: Ci + "",
        l1StandardBridge: Ci + ""
    }
});
const yi = 11155111;
({
    ...O,
    contracts: {
        ...O.contracts,
        disputeGameFactory: yi + "",
        l2OutputOracle: yi + "",
        portal: yi + "",
        l1StandardBridge: yi + ""
    }
});
const Ss = 1;
({
    ...O,
    contracts: {
        ...O.contracts,
        l2OutputOracle: Ss + "",
        portal: Ss + "",
        l1StandardBridge: Ss + ""
    }
});
const _s = 11155111;
({
    ...O,
    contracts: {
        ...O.contracts,
        l2OutputOracle: _s + "",
        portal: _s + "",
        l1StandardBridge: _s + ""
    }
});
const Cu = 5;
({
    ...O,
    contracts: {
        ...O.contracts,
        portal: Cu + ""
    }
});
function _n(t) {
    return {
        formatters: void 0,
        fees: void 0,
        serializers: void 0,
        ...t
    };
}
const yu = _n({
    id: "5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp",
    name: "Solana",
    network: "solana-mainnet",
    nativeCurrency: {
        name: "Solana",
        symbol: "SOL",
        decimals: 9
    },
    rpcUrls: {
        default: {
            http: [
                "https://rpc.walletconnect.org/v1"
            ]
        }
    },
    blockExplorers: {
        default: {
            name: "Solscan",
            url: "https://solscan.io"
        }
    },
    testnet: !1,
    chainNamespace: "solana",
    caipNetworkId: "solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp",
    deprecatedCaipNetworkId: "solana:4sGjMW1sUnHzSxGspuhpqLDx6wiyjNtZ"
}), xu = _n({
    id: "EtWTRABZaYq6iMfeYKouRu166VU2xqa1",
    name: "Solana Devnet",
    network: "solana-devnet",
    nativeCurrency: {
        name: "Solana",
        symbol: "SOL",
        decimals: 9
    },
    rpcUrls: {
        default: {
            http: [
                "https://rpc.walletconnect.org/v1"
            ]
        }
    },
    blockExplorers: {
        default: {
            name: "Solscan",
            url: "https://solscan.io"
        }
    },
    testnet: !0,
    chainNamespace: "solana",
    caipNetworkId: "solana:EtWTRABZaYq6iMfeYKouRu166VU2xqa1",
    deprecatedCaipNetworkId: "solana:8E9rvCKLFQia2Y35HXjjpWzj8weVo44K"
});
_n({
    id: "4uhcVJyU9pJkvQyS88uRDiswHXSCkY3z",
    name: "Solana Testnet",
    network: "solana-testnet",
    nativeCurrency: {
        name: "Solana",
        symbol: "SOL",
        decimals: 9
    },
    rpcUrls: {
        default: {
            http: [
                "https://rpc.walletconnect.org/v1"
            ]
        }
    },
    blockExplorers: {
        default: {
            name: "Solscan",
            url: "https://solscan.io"
        }
    },
    testnet: !0,
    chainNamespace: "solana",
    caipNetworkId: "solana:4uhcVJyU9pJkvQyS88uRDiswHXSCkY3z"
}), _n({
    id: "000000000019d6689c085ae165831e93",
    caipNetworkId: "bip122:000000000019d6689c085ae165831e93",
    chainNamespace: "bip122",
    name: "Bitcoin",
    nativeCurrency: {
        name: "Bitcoin",
        symbol: "BTC",
        decimals: 8
    },
    rpcUrls: {
        default: {
            http: [
                "https://rpc.walletconnect.org/v1"
            ]
        }
    }
}), _n({
    id: "000000000933ea01ad0ee984209779ba",
    caipNetworkId: "bip122:000000000933ea01ad0ee984209779ba",
    chainNamespace: "bip122",
    name: "Bitcoin Testnet",
    nativeCurrency: {
        name: "Bitcoin",
        symbol: "BTC",
        decimals: 8
    },
    rpcUrls: {
        default: {
            http: [
                "https://rpc.walletconnect.org/v1"
            ]
        }
    },
    testnet: !0
});
const r2 = {
    solana: [
        "solana_signMessage",
        "solana_signTransaction",
        "solana_requestAccounts",
        "solana_getAccounts",
        "solana_signAllTransactions",
        "solana_signAndSendTransaction"
    ],
    eip155: [
        "eth_accounts",
        "eth_requestAccounts",
        "eth_sendRawTransaction",
        "eth_sign",
        "eth_signTransaction",
        "eth_signTypedData",
        "eth_signTypedData_v3",
        "eth_signTypedData_v4",
        "eth_sendTransaction",
        "personal_sign",
        "wallet_switchEthereumChain",
        "wallet_addEthereumChain",
        "wallet_getPermissions",
        "wallet_requestPermissions",
        "wallet_registerOnboarding",
        "wallet_watchAsset",
        "wallet_scanQRCode",
        "wallet_getCallsStatus",
        "wallet_showCallsStatus",
        "wallet_sendCalls",
        "wallet_getCapabilities",
        "wallet_grantPermissions",
        "wallet_revokePermissions",
        "wallet_getAssets"
    ],
    bip122: [
        "sendTransfer",
        "signMessage",
        "signPsbt",
        "getAccountAddresses"
    ]
}, Eu = {
    getMethodsByChainNamespace (t) {
        return r2[t] || [];
    },
    createDefaultNamespace (t) {
        return {
            methods: this.getMethodsByChainNamespace(t),
            events: [
                "accountsChanged",
                "chainChanged"
            ],
            chains: [],
            rpcMap: {}
        };
    },
    applyNamespaceOverrides (t, e) {
        if (!e) return {
            ...t
        };
        const r = {
            ...t
        }, n = new Set;
        if (e.methods && Object.keys(e.methods).forEach((i)=>n.add(i)), e.chains && Object.keys(e.chains).forEach((i)=>n.add(i)), e.events && Object.keys(e.events).forEach((i)=>n.add(i)), e.rpcMap && Object.keys(e.rpcMap).forEach((i)=>{
            const [o] = i.split(":");
            o && n.add(o);
        }), n.forEach((i)=>{
            r[i] || (r[i] = this.createDefaultNamespace(i));
        }), e.methods && Object.entries(e.methods).forEach(([i, o])=>{
            r[i] && (r[i].methods = o);
        }), e.chains && Object.entries(e.chains).forEach(([i, o])=>{
            r[i] && (r[i].chains = o);
        }), e.events && Object.entries(e.events).forEach(([i, o])=>{
            r[i] && (r[i].events = o);
        }), e.rpcMap) {
            const i = new Set;
            Object.entries(e.rpcMap).forEach(([o, s])=>{
                const [a, c] = o.split(":");
                !a || !c || !r[a] || (r[a].rpcMap || (r[a].rpcMap = {}), i.has(a) || (r[a].rpcMap = {}, i.add(a)), r[a].rpcMap[c] = s);
            });
        }
        return r;
    },
    createNamespaces (t, e) {
        const r = t.reduce((n, i)=>{
            const { id: o, chainNamespace: s, rpcUrls: a } = i, c = a.default.http[0];
            n[s] || (n[s] = this.createDefaultNamespace(s));
            const l = `${s}:${o}`, d = n[s];
            switch(d.chains.push(l), l){
                case yu.caipNetworkId:
                    d.chains.push(yu.deprecatedCaipNetworkId);
                    break;
                case xu.caipNetworkId:
                    d.chains.push(xu.deprecatedCaipNetworkId);
                    break;
            }
            return d?.rpcMap && c && (d.rpcMap[o] = c), n;
        }, {});
        return this.applyNamespaceOverrides(r, e);
    },
    resolveReownName: async (t)=>{
        const e = await zd.resolveName(t);
        return (Object.values(e?.addresses) || [])[0]?.address || !1;
    },
    getChainsFromNamespaces (t = {}) {
        return Object.values(t).flatMap((e)=>{
            const r = e.chains || [], n = e.accounts.map((i)=>{
                const [o, s] = i.split(":");
                return `${o}:${s}`;
            });
            return Array.from(new Set([
                ...r,
                ...n
            ]));
        });
    },
    isSessionEventData (t) {
        return typeof t == "object" && t !== null && "id" in t && "topic" in t && "params" in t && typeof t.params == "object" && t.params !== null && "chainId" in t.params && "event" in t.params && typeof t.params.event == "object" && t.params.event !== null;
    }
};
class Au {
    constructor({ provider: e, namespace: r }){
        this.id = G.CONNECTOR_ID.WALLET_CONNECT, this.name = Fo.ConnectorNamesMap[G.CONNECTOR_ID.WALLET_CONNECT], this.type = "WALLET_CONNECT", this.imageId = Fo.ConnectorImageIds[G.CONNECTOR_ID.WALLET_CONNECT], this.getCaipNetworks = f.getCaipNetworks.bind(f), this.caipNetworks = this.getCaipNetworks(), this.provider = e, this.chain = r;
    }
    get chains() {
        return this.getCaipNetworks();
    }
    async connectWalletConnect() {
        if (!await this.authenticate()) {
            const r = this.getCaipNetworks(), n = T.state.universalProviderConfigOverride, i = Eu.createNamespaces(r, n);
            await this.provider.connect({
                optionalNamespaces: i
            });
        }
        return {
            clientId: await this.provider.client.core.crypto.getClientId(),
            session: this.provider.session
        };
    }
    async disconnect() {
        await this.provider.disconnect();
    }
    async authenticate() {
        const e = this.chains.map((r)=>r.caipNetworkId);
        return lr.universalProviderAuthenticate({
            universalProvider: this.provider,
            chains: e,
            methods: n2
        });
    }
}
const n2 = [
    "eth_accounts",
    "eth_requestAccounts",
    "eth_sendRawTransaction",
    "eth_sign",
    "eth_signTransaction",
    "eth_signTypedData",
    "eth_signTypedData_v3",
    "eth_signTypedData_v4",
    "eth_sendTransaction",
    "personal_sign",
    "wallet_switchEthereumChain",
    "wallet_addEthereumChain",
    "wallet_getPermissions",
    "wallet_requestPermissions",
    "wallet_registerOnboarding",
    "wallet_watchAsset",
    "wallet_scanQRCode",
    "wallet_getCallsStatus",
    "wallet_sendCalls",
    "wallet_getCapabilities",
    "wallet_grantPermissions",
    "wallet_revokePermissions",
    "wallet_getAssets"
];
class i2 {
    constructor(e){
        this.availableConnectors = [], this.eventListeners = new Map, this.getCaipNetworks = (r)=>f.getCaipNetworks(r), e && this.construct(e);
    }
    construct(e) {
        this.projectId = e.projectId, this.namespace = e.namespace, this.adapterType = e.adapterType;
    }
    get connectors() {
        return this.availableConnectors;
    }
    get networks() {
        return this.getCaipNetworks(this.namespace);
    }
    setAuthProvider(e) {
        this.addConnector({
            id: G.CONNECTOR_ID.AUTH,
            type: "AUTH",
            name: G.CONNECTOR_NAMES.AUTH,
            provider: e,
            imageId: Fo.ConnectorImageIds[G.CONNECTOR_ID.AUTH],
            chain: this.namespace,
            chains: []
        });
    }
    addConnector(...e) {
        const r = new Set;
        this.availableConnectors = [
            ...e,
            ...this.availableConnectors
        ].filter((n)=>r.has(n.id) ? !1 : (r.add(n.id), !0)), this.emit("connectors", this.availableConnectors);
    }
    setStatus(e, r) {
        Q.setStatus(e, r);
    }
    on(e, r) {
        this.eventListeners.has(e) || this.eventListeners.set(e, new Set), this.eventListeners.get(e)?.add(r);
    }
    off(e, r) {
        const n = this.eventListeners.get(e);
        n && n.delete(r);
    }
    removeAllEventListeners() {
        this.eventListeners.forEach((e)=>{
            e.clear();
        });
    }
    emit(e, r) {
        const n = this.eventListeners.get(e);
        n && n.forEach((i)=>i(r));
    }
    async connectWalletConnect(e) {
        return {
            clientId: (await this.getWalletConnectConnector().connectWalletConnect()).clientId
        };
    }
    async switchNetwork(e) {
        const { caipNetwork: r, providerType: n } = e;
        if (!e.provider) return;
        const i = "provider" in e.provider ? e.provider.provider : e.provider;
        if (n === "WALLET_CONNECT") {
            i.setDefaultChain(r.caipNetworkId);
            return;
        }
        if (i && n === "AUTH") {
            const o = i, s = Q.state.preferredAccountTypes?.[r.chainNamespace];
            await o.switchNetwork(r.caipNetworkId);
            const a = await o.getUser({
                chainId: r.caipNetworkId,
                preferredAccountType: s
            });
            this.emit("switchNetwork", a);
        }
    }
    getWalletConnectConnector() {
        const e = this.connectors.find((r)=>r instanceof Au);
        if (!e) throw new Error("WalletConnectConnector not found");
        return e;
    }
}
class o2 extends i2 {
    setUniversalProvider(e) {
        this.addConnector(new Au({
            provider: e,
            caipNetworks: this.getCaipNetworks(),
            namespace: this.namespace
        }));
    }
    async connect(e) {
        return Promise.resolve({
            id: "WALLET_CONNECT",
            type: "WALLET_CONNECT",
            chainId: Number(e.chainId),
            provider: this.provider,
            address: ""
        });
    }
    async disconnect() {
        try {
            await this.getWalletConnectConnector().disconnect();
        } catch (e) {
            console.warn("UniversalAdapter:disconnect - error", e);
        }
    }
    async getAccounts({ namespace: e }) {
        const n = this.provider?.session?.namespaces?.[e]?.accounts?.map((i)=>{
            const [, , o] = i.split(":");
            return o;
        }).filter((i, o, s)=>s.indexOf(i) === o) || [];
        return Promise.resolve({
            accounts: n.map((i)=>U.createAccount(e, i, e === "bip122" ? "payment" : "eoa"))
        });
    }
    async syncConnectors() {
        return Promise.resolve();
    }
    async getBalance(e) {
        if (!(e.caipNetwork && Te.BALANCE_SUPPORTED_CHAINS.includes(e.caipNetwork?.chainNamespace)) || e.caipNetwork?.testnet) return {
            balance: "0.00",
            symbol: e.caipNetwork?.nativeCurrency.symbol || ""
        };
        if (Q.state.balanceLoading && e.chainId === f.state.activeCaipNetwork?.id) return {
            balance: Q.state.balance || "0.00",
            symbol: Q.state.balanceSymbol || ""
        };
        const i = (await Q.fetchTokenBalance()).find((o)=>o.chainId === `${e.caipNetwork?.chainNamespace}:${e.chainId}` && o.symbol === e.caipNetwork?.nativeCurrency.symbol);
        return {
            balance: i?.quantity.numeric || "0.00",
            symbol: i?.symbol || e.caipNetwork?.nativeCurrency.symbol || ""
        };
    }
    async signMessage(e) {
        const { provider: r, message: n, address: i } = e;
        if (!r) throw new Error("UniversalAdapter:signMessage - provider is undefined");
        let o = "";
        return f.state.activeCaipNetwork?.chainNamespace === G.CHAIN.SOLANA ? o = (await r.request({
            method: "solana_signMessage",
            params: {
                message: Lg.encode(new TextEncoder().encode(n)),
                pubkey: i
            }
        }, f.state.activeCaipNetwork?.caipNetworkId)).signature : o = await r.request({
            method: "personal_sign",
            params: [
                n,
                i
            ]
        }, f.state.activeCaipNetwork?.caipNetworkId), {
            signature: o
        };
    }
    async estimateGas() {
        return Promise.resolve({
            gas: BigInt(0)
        });
    }
    async getProfile() {
        return Promise.resolve({
            profileImage: "",
            profileName: ""
        });
    }
    async sendTransaction() {
        return Promise.resolve({
            hash: ""
        });
    }
    walletGetAssets(e) {
        return Promise.resolve({});
    }
    async writeContract() {
        return Promise.resolve({
            hash: ""
        });
    }
    async getEnsAddress() {
        return Promise.resolve({
            address: !1
        });
    }
    parseUnits() {
        return 0n;
    }
    formatUnits() {
        return "0";
    }
    async getCapabilities() {
        return Promise.resolve({});
    }
    async grantPermissions() {
        return Promise.resolve({});
    }
    async revokePermissions() {
        return Promise.resolve("0x");
    }
    async syncConnection() {
        return Promise.resolve({
            id: "WALLET_CONNECT",
            type: "WALLET_CONNECT",
            chainId: 1,
            provider: this.provider,
            address: ""
        });
    }
    async switchNetwork(e) {
        const { caipNetwork: r } = e, n = this.getWalletConnectConnector();
        if (r.chainNamespace === G.CHAIN.EVM) try {
            await n.provider?.request({
                method: "wallet_switchEthereumChain",
                params: [
                    {
                        chainId: ie(r.id)
                    }
                ]
            });
        } catch (i) {
            if (i.code === ts.ERROR_CODE_UNRECOGNIZED_CHAIN_ID || i.code === ts.ERROR_INVALID_CHAIN_ID || i.code === ts.ERROR_CODE_DEFAULT || i?.data?.originalError?.code === ts.ERROR_CODE_UNRECOGNIZED_CHAIN_ID) try {
                await n.provider?.request({
                    method: "wallet_addEthereumChain",
                    params: [
                        {
                            chainId: ie(r.id),
                            rpcUrls: [
                                r?.rpcUrls.chainDefault?.http
                            ],
                            chainName: r.name,
                            nativeCurrency: r.nativeCurrency,
                            blockExplorerUrls: [
                                r.blockExplorers?.default.url
                            ]
                        }
                    ]
                });
            } catch  {
                throw new Error("Chain is not supported");
            }
        }
        n.provider.setDefaultChain(r.caipNetworkId);
    }
    getWalletConnectProvider() {
        return this.connectors.find((n)=>n.type === "WALLET_CONNECT")?.provider;
    }
}
class s2 {
    constructor(e){
        this.chainNamespaces = [], this.reportedAlertErrors = {}, this.getCaipNetwork = (r, n)=>{
            if (r) {
                const i = f.getNetworkData(r)?.requestedCaipNetworks?.find((s)=>s.id === n);
                if (i) return i;
                const o = f.getNetworkData(r)?.caipNetwork;
                return o || f.getRequestedCaipNetworks(r).filter((s)=>s.chainNamespace === r)?.[0];
            }
            return f.state.activeCaipNetwork || this.defaultCaipNetwork;
        }, this.getCaipNetworkId = ()=>{
            const r = this.getCaipNetwork();
            if (r) return r.id;
        }, this.getCaipNetworks = (r)=>f.getCaipNetworks(r), this.getActiveChainNamespace = ()=>f.state.activeChain, this.setRequestedCaipNetworks = (r, n)=>{
            f.setRequestedCaipNetworks(r, n);
        }, this.getApprovedCaipNetworkIds = ()=>f.getAllApprovedCaipNetworkIds(), this.getCaipAddress = (r)=>f.state.activeChain === r || !r ? f.state.activeCaipAddress : f.getAccountProp("caipAddress", r), this.setClientId = (r)=>{
            oe.setClientId(r);
        }, this.getProvider = (r)=>_e.getProvider(r), this.getProviderType = (r)=>_e.getProviderId(r), this.getPreferredAccountType = (r)=>Q.state.preferredAccountTypes?.[r], this.setCaipAddress = (r, n)=>{
            Q.setCaipAddress(r, n);
        }, this.setBalance = (r, n, i)=>{
            Q.setBalance(r, n, i);
        }, this.setProfileName = (r, n)=>{
            Q.setProfileName(r, n);
        }, this.setProfileImage = (r, n)=>{
            Q.setProfileImage(r, n);
        }, this.setUser = (r, n)=>{
            Q.setUser(r, n), T.state.enableEmbedded && he.close();
        }, this.resetAccount = (r)=>{
            Q.resetAccount(r);
        }, this.setCaipNetwork = (r)=>{
            f.setActiveCaipNetwork(r);
        }, this.setCaipNetworkOfNamespace = (r, n)=>{
            f.setChainNetworkData(n, {
                caipNetwork: r
            });
        }, this.setAllAccounts = (r, n)=>{
            Q.setAllAccounts(r, n), T.setHasMultipleAddresses(r?.length > 1);
        }, this.setStatus = (r, n)=>{
            Q.setStatus(r, n), j.isConnected() ? q.setConnectionStatus("connected") : q.setConnectionStatus("disconnected");
        }, this.getAddressByChainNamespace = (r)=>f.getAccountProp("address", r), this.setConnectors = (r)=>{
            const n = [
                ...j.state.allConnectors,
                ...r
            ];
            j.setConnectors(n);
        }, this.fetchIdentity = (r)=>oe.fetchIdentity(r), this.getReownName = (r)=>zd.getNamesForAddress(r), this.getConnectors = ()=>j.getConnectors(), this.getConnectorImage = (r)=>Oe.getConnectorImage(r), this.setConnectedWalletInfo = (r, n)=>{
            const i = _e.getProviderId(n), o = r ? {
                ...r,
                type: i
            } : void 0;
            Q.setConnectedWalletInfo(o, n);
        }, this.getIsConnectedState = ()=>!!f.state.activeCaipAddress, this.addAddressLabel = (r, n, i)=>{
            Q.addAddressLabel(r, n, i);
        }, this.removeAddressLabel = (r, n)=>{
            Q.removeAddressLabel(r, n);
        }, this.getAddress = (r)=>f.state.activeChain === r || !r ? Q.state.address : f.getAccountProp("address", r), this.setApprovedCaipNetworksData = (r)=>f.setApprovedCaipNetworksData(r), this.resetNetwork = (r)=>{
            f.resetNetwork(r);
        }, this.addConnector = (r)=>{
            j.addConnector(r);
        }, this.resetWcConnection = ()=>{
            Y.resetWcConnection();
        }, this.setAddressExplorerUrl = (r, n)=>{
            Q.setAddressExplorerUrl(r, n);
        }, this.setSmartAccountDeployed = (r, n)=>{
            Q.setSmartAccountDeployed(r, n);
        }, this.setSmartAccountEnabledNetworks = (r, n)=>{
            f.setSmartAccountEnabledNetworks(r, n);
        }, this.setPreferredAccountType = (r, n)=>{
            Q.setPreferredAccountType(r, n);
        }, this.setEIP6963Enabled = (r)=>{
            T.setEIP6963Enabled(r);
        }, this.handleUnsafeRPCRequest = ()=>{
            if (this.isOpen()) {
                if (this.isTransactionStackEmpty()) return;
                this.redirect("ApproveTransaction");
            } else this.open({
                view: "ApproveTransaction"
            });
        }, this.options = e, this.version = e.sdkVersion, this.caipNetworks = this.extendCaipNetworks(e), this.chainNamespaces = this.getChainNamespacesSet(e.adapters, this.caipNetworks), this.defaultCaipNetwork = this.extendDefaultCaipNetwork(e), this.chainAdapters = this.createAdapters(e.adapters), this.initialize(e);
    }
    getChainNamespacesSet(e, r) {
        const n = e?.map((o)=>o.namespace).filter((o)=>!!o);
        if (n?.length) return [
            ...new Set(n)
        ];
        const i = r?.map((o)=>o.chainNamespace);
        return [
            ...new Set(i)
        ];
    }
    async initialize(e) {
        this.initControllers(e), await this.initChainAdapters(), await this.injectModalUi(), this.sendInitializeEvent(e), zt.set({
            initialized: !0
        }), await this.syncExistingConnection();
    }
    sendInitializeEvent(e) {
        const { ...r } = e;
        delete r.adapters, delete r.universalProvider, le.sendEvent({
            type: "track",
            event: "INITIALIZE",
            properties: {
                ...r,
                networks: e.networks.map((n)=>n.id),
                siweConfig: {
                    options: e.siweConfig?.options || {}
                }
            }
        });
    }
    initControllers(e) {
        this.initializeOptionsController(e), this.initializeChainController(e), this.initializeThemeController(e), this.initializeConnectionController(e), this.initializeConnectorController();
    }
    initializeThemeController(e) {
        e.themeMode && $e.setThemeMode(e.themeMode), e.themeVariables && $e.setThemeVariables(e.themeVariables);
    }
    initializeChainController(e) {
        if (!this.connectionControllerClient || !this.networkControllerClient) throw new Error("ConnectionControllerClient and NetworkControllerClient must be set");
        f.initialize(e.adapters ?? [], this.caipNetworks, {
            connectionControllerClient: this.connectionControllerClient,
            networkControllerClient: this.networkControllerClient
        });
        const r = this.getDefaultNetwork();
        r && f.setActiveCaipNetwork(r);
    }
    initializeConnectionController(e) {
        Y.setWcBasic(e.basic ?? !1);
    }
    initializeConnectorController() {
        j.initialize(this.chainNamespaces);
    }
    initializeOptionsController(e) {
        T.setDebug(e.debug !== !1), T.setEnableWalletConnect(e.enableWalletConnect !== !1), T.setEnableWalletGuide(e.enableWalletGuide !== !1), T.setEnableWallets(e.enableWallets !== !1), T.setEIP6963Enabled(e.enableEIP6963 !== !1), T.setEnableNetworkSwitch(e.enableNetworkSwitch !== !1), T.setEnableAuthLogger(e.enableAuthLogger !== !1), T.setCustomRpcUrls(e.customRpcUrls), T.setSdkVersion(e.sdkVersion), T.setProjectId(e.projectId), T.setEnableEmbedded(e.enableEmbedded), T.setAllWallets(e.allWallets), T.setIncludeWalletIds(e.includeWalletIds), T.setExcludeWalletIds(e.excludeWalletIds), T.setFeaturedWalletIds(e.featuredWalletIds), T.setTokens(e.tokens), T.setTermsConditionsUrl(e.termsConditionsUrl), T.setPrivacyPolicyUrl(e.privacyPolicyUrl), T.setCustomWallets(e.customWallets), T.setFeatures(e.features), T.setAllowUnsupportedChain(e.allowUnsupportedChain), T.setUniversalProviderConfigOverride(e.universalProviderConfigOverride), T.setDefaultAccountTypes(e.defaultAccountTypes);
        const r = q.getPreferredAccountTypes(), n = {
            ...T.state.defaultAccountTypes,
            ...r
        };
        Q.setPreferredAccountTypes(n);
        const i = this.getDefaultMetaData();
        if (!e.metadata && i && (e.metadata = i), T.setMetadata(e.metadata), T.setDisableAppend(e.disableAppend), T.setEnableEmbedded(e.enableEmbedded), T.setSIWX(e.siwx), !e.projectId) {
            ar.open(Ho.ALERT_ERRORS.PROJECT_ID_NOT_CONFIGURED, "error");
            return;
        }
        if (e.adapters?.find((s)=>s.namespace === G.CHAIN.EVM) && e.siweConfig) {
            if (e.siwx) throw new Error("Cannot set both `siweConfig` and `siwx` options");
            T.setSIWX(e.siweConfig.mapToSIWX());
        }
    }
    getDefaultMetaData() {
        return ("TURBOPACK compile-time value", "undefined") < "u" && typeof document < "u" ? {
            name: document.getElementsByTagName("title")?.[0]?.textContent || "",
            description: document.querySelector('meta[property="og:description"]')?.content || "",
            url: window.location.origin,
            icons: [
                document.querySelector('link[rel~="icon"]')?.href || ""
            ]
        } : null;
    }
    setUnsupportedNetwork(e) {
        const r = this.getActiveChainNamespace();
        if (r) {
            const n = Cn.getUnsupportedNetwork(`${r}:${e}`);
            f.setActiveCaipNetwork(n);
        }
    }
    getDefaultNetwork() {
        return Cn.getCaipNetworkFromStorage(this.defaultCaipNetwork);
    }
    extendCaipNetwork(e, r) {
        return Cn.extendCaipNetwork(e, {
            customNetworkImageUrls: r.chainImages,
            projectId: r.projectId
        });
    }
    extendCaipNetworks(e) {
        return Cn.extendCaipNetworks(e.networks, {
            customNetworkImageUrls: e.chainImages,
            customRpcUrls: e.customRpcUrls,
            projectId: e.projectId
        });
    }
    extendDefaultCaipNetwork(e) {
        const r = e.networks.find((i)=>i.id === e.defaultNetwork?.id);
        return r ? Cn.extendCaipNetwork(r, {
            customNetworkImageUrls: e.chainImages,
            customRpcUrls: e.customRpcUrls,
            projectId: e.projectId
        }) : void 0;
    }
    createClients() {
        this.connectionControllerClient = {
            connectWalletConnect: async ()=>{
                const e = f.state.activeChain, r = this.getAdapter(e), n = this.getCaipNetwork(e)?.id;
                if (!r) throw new Error("Adapter not found");
                const i = await r.connectWalletConnect(n);
                this.close(), this.setClientId(i?.clientId || null), q.setConnectedNamespaces([
                    ...f.state.chains.keys()
                ]), this.chainNamespaces.forEach((o)=>{
                    j.setConnectorId(Be.CONNECTOR_TYPE_WALLET_CONNECT, o);
                }), await this.syncWalletConnectAccount();
            },
            connectExternal: async ({ id: e, info: r, type: n, provider: i, chain: o, caipNetwork: s })=>{
                const a = f.state.activeChain, c = o || a, l = this.getAdapter(c);
                if (o && o !== a && !s) {
                    const p = this.getCaipNetworks().find((v)=>v.chainNamespace === o);
                    p && this.setCaipNetwork(p);
                }
                if (!l) throw new Error("Adapter not found");
                const d = this.getCaipNetwork(c), u = await l.connect({
                    id: e,
                    info: r,
                    type: n,
                    provider: i,
                    chainId: s?.id || d?.id,
                    rpcUrl: s?.rpcUrls?.default?.http?.[0] || d?.rpcUrls?.default?.http?.[0]
                });
                if (!u) return;
                q.addConnectedNamespace(c), this.syncProvider({
                    ...u,
                    chainNamespace: c
                });
                const { accounts: h } = await l.getAccounts({
                    namespace: c,
                    id: e
                });
                this.setAllAccounts(h, c), this.setStatus("connected", c);
            },
            reconnectExternal: async ({ id: e, info: r, type: n, provider: i })=>{
                const o = f.state.activeChain, s = this.getAdapter(o);
                s?.reconnect && (await s?.reconnect({
                    id: e,
                    info: r,
                    type: n,
                    provider: i,
                    chainId: this.getCaipNetwork()?.id
                }), q.addConnectedNamespace(o));
            },
            disconnect: async (e)=>{
                const r = e || f.state.activeChain, n = this.getAdapter(r), i = _e.getProvider(r), o = _e.getProviderId(r);
                await n?.disconnect({
                    provider: i,
                    providerType: o
                }), q.removeConnectedNamespace(r), _e.resetChain(r), this.setUser(void 0, r), this.setStatus("disconnected", r);
            },
            checkInstalled: (e)=>e ? e.some((r)=>!!window.ethereum?.[String(r)]) : !!window.ethereum,
            signMessage: async (e)=>(await this.getAdapter(f.state.activeChain)?.signMessage({
                    message: e,
                    address: Q.state.address,
                    provider: _e.getProvider(f.state.activeChain)
                }))?.signature || "",
            sendTransaction: async (e)=>{
                if (e.chainNamespace === G.CHAIN.EVM) {
                    const r = this.getAdapter(f.state.activeChain), n = _e.getProvider(f.state.activeChain);
                    return (await r?.sendTransaction({
                        ...e,
                        caipNetwork: this.getCaipNetwork(),
                        provider: n
                    }))?.hash || "";
                }
                return "";
            },
            estimateGas: async (e)=>{
                if (e.chainNamespace === G.CHAIN.EVM) {
                    const r = this.getAdapter(f.state.activeChain), n = _e.getProvider(f.state.activeChain), i = this.getCaipNetwork();
                    if (!i) throw new Error("CaipNetwork is undefined");
                    return (await r?.estimateGas({
                        ...e,
                        provider: n,
                        caipNetwork: i
                    }))?.gas || 0n;
                }
                return 0n;
            },
            getEnsAvatar: async ()=>(await this.getAdapter(f.state.activeChain)?.getProfile({
                    address: Q.state.address,
                    chainId: Number(this.getCaipNetwork()?.id)
                }))?.profileImage || !1,
            getEnsAddress: async (e)=>{
                const r = this.getAdapter(f.state.activeChain), n = this.getCaipNetwork();
                return n && (await r?.getEnsAddress({
                    name: e,
                    caipNetwork: n
                }))?.address || !1;
            },
            writeContract: async (e)=>{
                const r = this.getAdapter(f.state.activeChain), n = this.getCaipNetwork(), i = this.getCaipAddress(), o = _e.getProvider(f.state.activeChain);
                if (!n || !i) throw new Error("CaipNetwork or CaipAddress is undefined");
                return (await r?.writeContract({
                    ...e,
                    caipNetwork: n,
                    provider: o,
                    caipAddress: i
                }))?.hash;
            },
            parseUnits: (e, r)=>this.getAdapter(f.state.activeChain)?.parseUnits({
                    value: e,
                    decimals: r
                }) ?? 0n,
            formatUnits: (e, r)=>this.getAdapter(f.state.activeChain)?.formatUnits({
                    value: e,
                    decimals: r
                }) ?? "0",
            getCapabilities: async (e)=>await this.getAdapter(f.state.activeChain)?.getCapabilities(e),
            grantPermissions: async (e)=>await this.getAdapter(f.state.activeChain)?.grantPermissions(e),
            revokePermissions: async (e)=>{
                const r = this.getAdapter(f.state.activeChain);
                return r?.revokePermissions ? await r.revokePermissions(e) : "0x";
            },
            walletGetAssets: async (e)=>await this.getAdapter(f.state.activeChain)?.walletGetAssets(e) ?? {}
        }, this.networkControllerClient = {
            switchCaipNetwork: async (e)=>await this.switchCaipNetwork(e),
            getApprovedCaipNetworksData: async ()=>this.getApprovedCaipNetworksData()
        }, Y.setClient(this.connectionControllerClient);
    }
    getApprovedCaipNetworksData() {
        if (_e.getProviderId(f.state.activeChain) === Be.CONNECTOR_TYPE_WALLET_CONNECT) {
            const r = this.universalProvider?.session?.namespaces;
            return {
                supportsAllNetworks: this.universalProvider?.session?.peer?.metadata.name === "MetaMask Wallet",
                approvedCaipNetworkIds: this.getChainsFromNamespaces(r)
            };
        }
        return {
            supportsAllNetworks: !0,
            approvedCaipNetworkIds: []
        };
    }
    async switchCaipNetwork(e) {
        if (!e) return;
        const r = e.chainNamespace;
        if (this.getAddressByChainNamespace(e.chainNamespace)) {
            const i = _e.getProvider(r), o = _e.getProviderId(r);
            if (e.chainNamespace === f.state.activeChain) await this.getAdapter(r)?.switchNetwork({
                caipNetwork: e,
                provider: i,
                providerType: o
            });
            else if (this.setCaipNetwork(e), o === Be.CONNECTOR_TYPE_WALLET_CONNECT) this.syncWalletConnectAccount();
            else {
                const s = this.getAddressByChainNamespace(r);
                s && this.syncAccount({
                    address: s,
                    chainId: e.id,
                    chainNamespace: r
                });
            }
        } else this.setCaipNetwork(e);
    }
    getChainsFromNamespaces(e = {}) {
        return Object.values(e).flatMap((r)=>{
            const n = r.chains || [], i = r.accounts.map((o)=>{
                const { chainId: s, chainNamespace: a } = nr.parseCaipAddress(o);
                return `${a}:${s}`;
            });
            return Array.from(new Set([
                ...n,
                ...i
            ]));
        });
    }
    createAdapters(e) {
        return this.createClients(), this.chainNamespaces.reduce((r, n)=>{
            const i = e?.find((o)=>o.namespace === n);
            return i ? (i.construct({
                namespace: n,
                projectId: this.options?.projectId,
                networks: this.getCaipNetworks()
            }), r[n] = i) : r[n] = new o2({
                namespace: n,
                networks: this.getCaipNetworks()
            }), r;
        }, {});
    }
    async initChainAdapter(e) {
        this.onConnectors(e), this.listenAdapter(e), this.chainAdapters?.[e].syncConnectors(this.options, this), await this.createUniversalProviderForAdapter(e);
    }
    async initChainAdapters() {
        await Promise.all(this.chainNamespaces.map(async (e)=>{
            await this.initChainAdapter(e);
        }));
    }
    onConnectors(e) {
        this.getAdapter(e)?.on("connectors", this.setConnectors.bind(this));
    }
    listenAdapter(e) {
        const r = this.getAdapter(e);
        if (!r) return;
        const n = q.getConnectionStatus();
        n === "connected" ? this.setStatus("connecting", e) : n === "disconnected" ? (q.clearAddressCache(), this.setStatus(n, e)) : this.setStatus(n, e), r.on("switchNetwork", ({ address: i, chainId: o })=>{
            const s = this.getCaipNetworks().find((l)=>l.id === o || l.caipNetworkId === o), a = f.state.activeChain === e, c = f.getAccountProp("address", e);
            if (s) {
                const l = a && i ? i : c;
                l && this.syncAccount({
                    address: l,
                    chainId: s.id,
                    chainNamespace: e
                });
            } else this.setUnsupportedNetwork(o);
        }), r.on("disconnect", this.disconnect.bind(this, e)), r.on("pendingTransactions", ()=>{
            const i = Q.state.address, o = f.state.activeCaipNetwork;
            !i || !o?.id || this.updateNativeBalance(i, o.id, o.chainNamespace);
        }), r.on("accountChanged", ({ address: i, chainId: o })=>{
            const s = f.state.activeChain === e;
            s && o ? this.syncAccount({
                address: i,
                chainId: o,
                chainNamespace: e
            }) : s && f.state.activeCaipNetwork?.id ? this.syncAccount({
                address: i,
                chainId: f.state.activeCaipNetwork?.id,
                chainNamespace: e
            }) : this.syncAccountInfo(i, o, e);
        });
    }
    async createUniversalProviderForAdapter(e) {
        await this.getUniversalProvider(), this.universalProvider && this.chainAdapters?.[e]?.setUniversalProvider?.(this.universalProvider);
    }
    async syncExistingConnection() {
        await Promise.allSettled(this.chainNamespaces.map((e)=>this.syncNamespaceConnection(e)));
    }
    async syncNamespaceConnection(e) {
        try {
            const r = j.getConnectorId(e);
            switch(this.setStatus("connecting", e), r){
                case G.CONNECTOR_ID.WALLET_CONNECT:
                    await this.syncWalletConnectAccount();
                    break;
                case G.CONNECTOR_ID.AUTH:
                    break;
                default:
                    await this.syncAdapterConnection(e);
            }
        } catch (r) {
            console.warn("AppKit couldn't sync existing connection", r), this.setStatus("disconnected", e);
        }
    }
    async syncAdapterConnection(e) {
        const r = this.getAdapter(e), n = j.getConnectorId(e), i = this.getCaipNetwork(e), o = j.getConnectors(e).find((s)=>s.id === n);
        try {
            if (!r || !o) throw new Error(`Adapter or connector not found for namespace ${e}`);
            if (!i?.id) throw new Error("CaipNetwork not found");
            const s = await r?.syncConnection({
                namespace: e,
                id: o.id,
                chainId: i.id,
                rpcUrl: i?.rpcUrls?.default?.http?.[0]
            });
            if (s) {
                const a = await r?.getAccounts({
                    namespace: e,
                    id: o.id
                });
                a && a.accounts.length > 0 ? this.setAllAccounts(a.accounts, e) : this.setAllAccounts([
                    U.createAccount(e, s.address, "eoa")
                ], e), this.syncProvider({
                    ...s,
                    chainNamespace: e
                }), await this.syncAccount({
                    ...s,
                    chainNamespace: e
                }), this.setStatus("connected", e);
            } else this.setStatus("disconnected", e);
        } catch  {
            this.setStatus("disconnected", e);
        }
    }
    async syncWalletConnectAccount() {
        const e = this.chainNamespaces.map(async (r)=>{
            const n = this.getAdapter(r), i = this.universalProvider?.session?.namespaces?.[r]?.accounts || [], o = f.state.activeCaipNetwork?.id, s = i.find((a)=>{
                const { chainId: c } = nr.parseCaipAddress(a);
                return c === o?.toString();
            }) || i[0];
            if (s) {
                const a = nr.validateCaipAddress(s), { chainId: c, address: l } = nr.parseCaipAddress(a);
                if (_e.setProviderId(r, Be.CONNECTOR_TYPE_WALLET_CONNECT), this.caipNetworks && f.state.activeCaipNetwork && n?.namespace !== G.CHAIN.EVM) {
                    const d = n?.getWalletConnectProvider({
                        caipNetworks: this.getCaipNetworks(),
                        provider: this.universalProvider,
                        activeCaipNetwork: f.state.activeCaipNetwork
                    });
                    _e.setProvider(r, d);
                } else _e.setProvider(r, this.universalProvider);
                j.setConnectorId(G.CONNECTOR_ID.WALLET_CONNECT, r), q.addConnectedNamespace(r), this.syncWalletConnectAccounts(r), await this.syncAccount({
                    address: l,
                    chainId: c,
                    chainNamespace: r
                });
            } else this.setStatus("disconnected", r);
            await f.setApprovedCaipNetworksData(r);
        });
        await Promise.all(e);
    }
    syncWalletConnectAccounts(e) {
        const r = this.universalProvider?.session?.namespaces?.[e]?.accounts?.map((n)=>{
            const { address: i } = nr.parseCaipAddress(n);
            return i;
        }).filter((n, i, o)=>o.indexOf(n) === i);
        r && this.setAllAccounts(r.map((n)=>U.createAccount(e, n, e === "bip122" ? "payment" : "eoa")), e);
    }
    syncProvider({ type: e, provider: r, id: n, chainNamespace: i }) {
        _e.setProviderId(i, e), _e.setProvider(i, r), j.setConnectorId(n, i);
    }
    async syncAccount(e) {
        const r = e.chainNamespace === f.state.activeChain, n = f.getCaipNetworkByNamespace(e.chainNamespace, e.chainId), { address: i, chainId: o, chainNamespace: s } = e, { chainId: a } = q.getActiveNetworkProps(), c = o || a, l = f.state.activeCaipNetwork?.name === G.UNSUPPORTED_NETWORK_NAME, d = f.getNetworkProp("supportsAllNetworks", s);
        if (this.setStatus("connected", s), !(l && !d) && c) {
            let u = this.getCaipNetworks().find((v)=>v.id.toString() === c.toString()), h = this.getCaipNetworks().find((v)=>v.chainNamespace === s);
            if (!d && !u && !h) {
                const v = this.getApprovedCaipNetworkIds() || [], m = v.find((b)=>nr.parseCaipNetworkId(b)?.chainId === c.toString()), g = v.find((b)=>nr.parseCaipNetworkId(b)?.chainNamespace === s);
                u = this.getCaipNetworks().find((b)=>b.caipNetworkId === m), h = this.getCaipNetworks().find((b)=>b.caipNetworkId === g || "deprecatedCaipNetworkId" in b && b.deprecatedCaipNetworkId === g);
            }
            const p = u || h;
            p?.chainNamespace === f.state.activeChain ? T.state.enableNetworkSwitch && !T.state.allowUnsupportedChain && f.state.activeCaipNetwork?.name === G.UNSUPPORTED_NETWORK_NAME ? f.showUnsupportedChainUI() : this.setCaipNetwork(p) : r || n && this.setCaipNetworkOfNamespace(n, s), this.syncConnectedWalletInfo(s), Ja.isLowerCaseMatch(i, Q.state.address) || this.syncAccountInfo(i, p?.id, s), r ? await this.syncBalance({
                address: i,
                chainId: p?.id,
                chainNamespace: s
            }) : await this.syncBalance({
                address: i,
                chainId: n?.id,
                chainNamespace: s
            });
        }
    }
    async syncAccountInfo(e, r, n) {
        const i = this.getCaipAddress(n), o = r || i?.split(":")[1];
        if (!o) return;
        const s = `${n}:${o}:${e}`;
        this.setCaipAddress(s, n), await this.syncIdentity({
            address: e,
            chainId: o,
            chainNamespace: n
        });
    }
    async syncReownName(e, r) {
        try {
            const n = await this.getReownName(e);
            if (n[0]) {
                const i = n[0];
                this.setProfileName(i.name, r);
            } else this.setProfileName(null, r);
        } catch  {
            this.setProfileName(null, r);
        }
    }
    syncConnectedWalletInfo(e) {
        const r = j.getConnectorId(e), n = _e.getProviderId(e);
        if (n === Be.CONNECTOR_TYPE_ANNOUNCED || n === Be.CONNECTOR_TYPE_INJECTED) {
            if (r) {
                const i = this.getConnectors().find((o)=>o.id === r);
                if (i) {
                    const { info: o, name: s, imageUrl: a } = i, c = a || this.getConnectorImage(i);
                    this.setConnectedWalletInfo({
                        name: s,
                        icon: c,
                        ...o
                    }, e);
                }
            }
        } else if (n === Be.CONNECTOR_TYPE_WALLET_CONNECT) {
            const i = _e.getProvider(e);
            i?.session && this.setConnectedWalletInfo({
                ...i.session.peer.metadata,
                name: i.session.peer.metadata.name,
                icon: i.session.peer.metadata.icons?.[0]
            }, e);
        } else if (r) if (r === G.CONNECTOR_ID.COINBASE) {
            const i = this.getConnectors().find((o)=>o.id === G.CONNECTOR_ID.COINBASE);
            this.setConnectedWalletInfo({
                name: "Coinbase Wallet",
                icon: this.getConnectorImage(i)
            }, e);
        } else this.setConnectedWalletInfo({
            name: r
        }, e);
    }
    async syncBalance(e) {
        !al.getNetworksByNamespace(this.getCaipNetworks(), e.chainNamespace).find((n)=>n.id.toString() === e.chainId?.toString()) || !e.chainId || await this.updateNativeBalance(e.address, e.chainId, e.chainNamespace);
    }
    async updateNativeBalance(e, r, n) {
        const i = this.getAdapter(n), o = f.getCaipNetworkByNamespace(n, r);
        if (i) {
            const s = await i.getBalance({
                address: e,
                chainId: r,
                caipNetwork: o,
                tokens: this.options.tokens
            });
            this.setBalance(s.balance, s.symbol, n);
        }
    }
    async initializeUniversalAdapter() {
        const e = cg.createLogger((n, ...i)=>{
            n && this.handleAlertError(n), console.error(...i);
        }), r = {
            projectId: this.options?.projectId,
            metadata: {
                name: this.options?.metadata ? this.options?.metadata.name : "",
                description: this.options?.metadata ? this.options?.metadata.description : "",
                url: this.options?.metadata ? this.options?.metadata.url : "",
                icons: this.options?.metadata ? this.options?.metadata.icons : [
                    ""
                ]
            },
            logger: e
        };
        T.setManualWCControl(!!this.options?.manualWCControl), this.universalProvider = this.options.universalProvider ?? await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$node_modules$2f40$walletconnect$2f$universal$2d$provider$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].init(r), this.listenWalletConnect();
    }
    listenWalletConnect() {
        this.universalProvider && (this.universalProvider.on("display_uri", (e)=>{
            Y.setUri(e);
        }), this.universalProvider.on("connect", Y.finalizeWcConnection), this.universalProvider.on("disconnect", ()=>{
            this.chainNamespaces.forEach((e)=>{
                this.resetAccount(e);
            }), Y.resetWcConnection();
        }), this.universalProvider.on("chainChanged", (e)=>{
            const r = this.getCaipNetworks().find((i)=>i.id == e), n = this.getCaipNetwork();
            if (!r) {
                this.setUnsupportedNetwork(e);
                return;
            }
            n?.id !== r?.id && this.setCaipNetwork(r);
        }), this.universalProvider.on("session_event", (e)=>{
            if (Eu.isSessionEventData(e)) {
                const { name: r, data: n } = e.params.event;
                r === "accountsChanged" && Array.isArray(n) && U.isCaipAddress(n[0]) && this.syncAccount(nr.parseCaipAddress(n[0]));
            }
        }));
    }
    createUniversalProvider() {
        return !this.universalProviderInitPromise && U.isClient() && this.options?.projectId && (this.universalProviderInitPromise = this.initializeUniversalAdapter()), this.universalProviderInitPromise;
    }
    async getUniversalProvider() {
        if (!this.universalProvider) try {
            await this.createUniversalProvider();
        } catch (e) {
            le.sendEvent({
                type: "error",
                event: "INTERNAL_SDK_ERROR",
                properties: {
                    errorType: "UniversalProviderInitError",
                    errorMessage: e instanceof Error ? e.message : "Unknown",
                    uncaught: !1
                }
            }), console.error("AppKit:getUniversalProvider - Cannot create provider", e);
        }
        return this.universalProvider;
    }
    handleAlertError(e) {
        const r = Object.entries(Ho.UniversalProviderErrors).find(([, { message: a }])=>e.message.includes(a)), [n, i] = r ?? [], { message: o, alertErrorKey: s } = i ?? {};
        if (n && o && !this.reportedAlertErrors[n]) {
            const a = Ho.ALERT_ERRORS[s];
            a && (ar.open(a, "error"), this.reportedAlertErrors[n] = !0);
        }
    }
    getAdapter(e) {
        if (e) return this.chainAdapters?.[e];
    }
    createAdapter(e) {
        if (!e) return;
        const r = e.namespace;
        if (!r) return;
        this.createClients();
        const n = e;
        n.namespace = r, n.construct({
            namespace: r,
            projectId: this.options?.projectId,
            networks: this.getCaipNetworks()
        }), this.chainNamespaces.includes(r) || this.chainNamespaces.push(r), this.chainAdapters && (this.chainAdapters[r] = n);
    }
    async open(e) {
        if (await this.injectModalUi(), e?.uri && Y.setUri(e.uri), e?.arguments) switch(e?.view){
            case "Swap":
                return he.open({
                    ...e,
                    data: {
                        swap: e.arguments
                    }
                });
        }
        return he.open(e);
    }
    async close() {
        await this.injectModalUi(), he.close();
    }
    setLoading(e, r) {
        he.setLoading(e, r);
    }
    async disconnect(e) {
        await Y.disconnect(e);
    }
    getError() {
        return "";
    }
    getChainId() {
        return f.state.activeCaipNetwork?.id;
    }
    async switchNetwork(e) {
        const r = this.getCaipNetworks().find((n)=>n.id === e.id);
        if (!r) {
            ar.open(Ho.ALERT_ERRORS.SWITCH_NETWORK_NOT_FOUND, "error");
            return;
        }
        await f.switchActiveNetwork(r);
    }
    getWalletProvider() {
        return f.state.activeChain ? _e.state.providers[f.state.activeChain] : null;
    }
    getWalletProviderType() {
        return _e.getProviderId(f.state.activeChain);
    }
    subscribeProviders(e) {
        return _e.subscribeProviders(e);
    }
    getThemeMode() {
        return $e.state.themeMode;
    }
    getThemeVariables() {
        return $e.state.themeVariables;
    }
    setThemeMode(e) {
        $e.setThemeMode(e), pu($e.state.themeMode);
    }
    setTermsConditionsUrl(e) {
        T.setTermsConditionsUrl(e);
    }
    setPrivacyPolicyUrl(e) {
        T.setPrivacyPolicyUrl(e);
    }
    setThemeVariables(e) {
        $e.setThemeVariables(e), Og($e.state.themeVariables);
    }
    subscribeTheme(e) {
        return $e.subscribe(e);
    }
    getWalletInfo() {
        return Q.state.connectedWalletInfo;
    }
    getAccount(e) {
        const r = j.getAuthConnector(e), n = f.getAccountData(e), i = f.state.activeChain;
        if (n) return {
            allAccounts: n.allAccounts,
            caipAddress: n.caipAddress,
            address: U.getPlainAddress(n.caipAddress),
            isConnected: !!n.caipAddress,
            status: n.status,
            embeddedWalletInfo: r ? {
                user: n.user ? {
                    ...n.user,
                    username: q.getConnectedSocialUsername()
                } : void 0,
                authProvider: n.socialProvider || "email",
                accountType: n.preferredAccountTypes?.[e || i],
                isSmartAccountDeployed: !!n.smartAccountDeployed
            } : void 0
        };
    }
    subscribeAccount(e, r) {
        const n = ()=>{
            const i = this.getAccount(r);
            i && e(i);
        };
        r ? f.subscribeChainProp("accountState", n, r) : f.subscribe(n), j.subscribe(n);
    }
    subscribeNetwork(e) {
        return f.subscribe(({ activeCaipNetwork: r })=>{
            e({
                caipNetwork: r,
                chainId: r?.id,
                caipNetworkId: r?.caipNetworkId
            });
        });
    }
    subscribeWalletInfo(e) {
        return Q.subscribeKey("connectedWalletInfo", e);
    }
    subscribeShouldUpdateToAddress(e) {
        Q.subscribeKey("shouldUpdateToAddress", e);
    }
    subscribeCaipNetworkChange(e) {
        f.subscribeKey("activeCaipNetwork", e);
    }
    getState() {
        return zt.state;
    }
    subscribeState(e) {
        return zt.subscribe(e);
    }
    showErrorMessage(e) {
        Ee.showError(e);
    }
    showSuccessMessage(e) {
        Ee.showSuccess(e);
    }
    getEvent() {
        return {
            ...le.state
        };
    }
    subscribeEvents(e) {
        return le.subscribe(e);
    }
    replace(e) {
        D.replace(e);
    }
    redirect(e) {
        D.push(e);
    }
    popTransactionStack(e) {
        D.popTransactionStack(e);
    }
    isOpen() {
        return he.state.open;
    }
    isTransactionStackEmpty() {
        return D.state.transactionStack.length === 0;
    }
    isTransactionShouldReplaceView() {
        return D.state.transactionStack[D.state.transactionStack.length - 1]?.replace;
    }
    static getInstance() {
        return this.instance;
    }
    updateFeatures(e) {
        T.setFeatures(e);
    }
    updateOptions(e) {
        const n = {
            ...T.state || {},
            ...e
        };
        T.setOptions(n);
    }
    setConnectMethodsOrder(e) {
        T.setConnectMethodsOrder(e);
    }
    setWalletFeaturesOrder(e) {
        T.setWalletFeaturesOrder(e);
    }
    setCollapseWallets(e) {
        T.setCollapseWallets(e);
    }
    setSocialsOrder(e) {
        T.setSocialsOrder(e);
    }
    getConnectMethodsOrder() {
        return Lr.getConnectOrderMethod(T.state.features, j.getConnectors());
    }
    addNetwork(e, r) {
        if (this.chainAdapters && !this.chainAdapters[e]) throw new Error(`Adapter for namespace ${e} doesn't exist`);
        const n = this.extendCaipNetwork(r, this.options);
        this.getCaipNetworks().find((i)=>i.id === n.id) || f.addNetwork(n);
    }
    removeNetwork(e, r) {
        if (this.chainAdapters && !this.chainAdapters[e]) throw new Error(`Adapter for namespace ${e} doesn't exist`);
        this.getCaipNetworks().find((i)=>i.id === r) && f.removeNetwork(e, r);
    }
}
let Su = !1;
class _u extends s2 {
    async open(e) {
        j.isConnected() || await super.open(e);
    }
    async close() {
        await super.close(), this.options.manualWCControl && Y.finalizeWcConnection();
    }
    async syncIdentity(e) {
        return Promise.resolve();
    }
    async syncBalance(e) {
        return Promise.resolve();
    }
    async injectModalUi() {
        if (!Su && U.isClient()) {
            if (await Promise.resolve().then(function() {
                return bm;
            }), await Promise.resolve().then(function() {
                return Bm;
            }), !document.querySelector("w3m-modal")) {
                const r = document.createElement("w3m-modal");
                !T.state.disableAppend && !T.state.enableEmbedded && document.body.insertAdjacentElement("beforeend", r);
            }
            Su = !0;
        }
    }
}
const a2 = "1.7.3";
function c2(t) {
    return new _u({
        ...t,
        basic: !0,
        sdkVersion: `html-core-${a2}`
    });
}
var l2 = Object.freeze({
    __proto__: null,
    createAppKit: c2,
    AppKit: _u
}), d2 = Object.defineProperty, u2 = Object.defineProperties, h2 = Object.getOwnPropertyDescriptors, Iu = Object.getOwnPropertySymbols, p2 = Object.prototype.hasOwnProperty, f2 = Object.prototype.propertyIsEnumerable, Nu = (t, e, r)=>e in t ? d2(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : t[e] = r, g2 = (t, e)=>{
    for(var r in e || (e = {}))p2.call(e, r) && Nu(t, r, e[r]);
    if (Iu) for (var r of Iu(e))f2.call(e, r) && Nu(t, r, e[r]);
    return t;
}, w2 = (t, e)=>u2(t, h2(e));
function m2(t) {
    if (t) return {
        "--w3m-font-family": t["--wcm-font-family"],
        "--w3m-accent": t["--wcm-accent-color"],
        "--w3m-color-mix": t["--wcm-background-color"],
        "--w3m-z-index": t["--wcm-z-index"] ? Number(t["--wcm-z-index"]) : void 0,
        "--w3m-qr-color": t["--wcm-accent-color"],
        "--w3m-font-size-master": t["--wcm-text-medium-regular-size"],
        "--w3m-border-radius-master": t["--wcm-container-border-radius"],
        "--w3m-color-mix-strength": 0
    };
}
const b2 = (t)=>{
    const [e, r] = t.split(":");
    return _n({
        id: r,
        caipNetworkId: t,
        chainNamespace: e,
        name: "",
        nativeCurrency: {
            name: "",
            symbol: "",
            decimals: 8
        },
        rpcUrls: {
            default: {
                http: [
                    "https://rpc.walletconnect.org/v1"
                ]
            }
        }
    });
};
function v2(t) {
    var e, r, n, i, o, s, a;
    const c = (e = t.chains) == null ? void 0 : e.map(b2).filter(Boolean);
    if (c.length === 0) throw new Error("At least one chain must be specified");
    const l = c.find((u)=>{
        var h;
        return u.id === ((h = t.defaultChain) == null ? void 0 : h.id);
    }), d = {
        projectId: t.projectId,
        networks: c,
        themeMode: t.themeMode,
        themeVariables: m2(t.themeVariables),
        chainImages: t.chainImages,
        connectorImages: t.walletImages,
        defaultNetwork: l,
        metadata: w2(g2({}, t.metadata), {
            name: ((r = t.metadata) == null ? void 0 : r.name) || "WalletConnect",
            description: ((n = t.metadata) == null ? void 0 : n.description) || "Connect to WalletConnect-compatible wallets",
            url: ((i = t.metadata) == null ? void 0 : i.url) || "https://walletconnect.org",
            icons: ((o = t.metadata) == null ? void 0 : o.icons) || [
                "https://walletconnect.org/walletconnect-logo.png"
            ]
        }),
        showWallets: !0,
        featuredWalletIds: t.explorerRecommendedWalletIds === "NONE" ? [] : Array.isArray(t.explorerRecommendedWalletIds) ? t.explorerRecommendedWalletIds : [],
        excludeWalletIds: t.explorerExcludedWalletIds === "ALL" ? [] : Array.isArray(t.explorerExcludedWalletIds) ? t.explorerExcludedWalletIds : [],
        enableEIP6963: !1,
        enableInjected: !1,
        enableCoinbase: !0,
        enableWalletConnect: !0,
        features: {
            email: !1,
            socials: !1
        }
    };
    if ((s = t.mobileWallets) != null && s.length || (a = t.desktopWallets) != null && a.length) {
        const u = [
            ...(t.mobileWallets || []).map((v)=>({
                    id: v.id,
                    name: v.name,
                    links: v.links
                })),
            ...(t.desktopWallets || []).map((v)=>({
                    id: v.id,
                    name: v.name,
                    links: {
                        native: v.links.native,
                        universal: v.links.universal
                    }
                }))
        ], h = [
            ...d.featuredWalletIds || [],
            ...d.excludeWalletIds || []
        ], p = u.filter((v)=>!h.includes(v.id));
        p.length && (d.customWallets = p);
    }
    return d;
}
var C2 = Object.freeze({
    __proto__: null,
    convertWCMToAppKitOptions: v2
}); /**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ 
const y2 = {
    attribute: !0,
    type: String,
    converter: Jo,
    reflect: !1,
    hasChanged: oc
}, x2 = (t = y2, e, r)=>{
    const { kind: n, metadata: i } = r;
    let o = globalThis.litPropertyMetadata.get(i);
    if (o === void 0 && globalThis.litPropertyMetadata.set(i, o = new Map), n === "setter" && ((t = Object.create(t)).wrapped = !0), o.set(r.name, t), n === "accessor") {
        const { name: s } = r;
        return {
            set (a) {
                const c = e.get.call(this);
                e.set.call(this, a), this.requestUpdate(s, c, t);
            },
            init (a) {
                return a !== void 0 && this.C(s, void 0, t, a), a;
            }
        };
    }
    if (n === "setter") {
        const { name: s } = r;
        return function(a) {
            const c = this[s];
            e.call(this, a), this.requestUpdate(s, c, t);
        };
    }
    throw Error("Unsupported decorator location: " + n);
};
function C(t) {
    return (e, r)=>typeof r == "object" ? x2(t, e, r) : ((n, i, o)=>{
            const s = i.hasOwnProperty(o);
            return i.constructor.createProperty(o, n), s ? Object.getOwnPropertyDescriptor(i, o) : void 0;
        })(t, e, r);
} /**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ 
function H(t) {
    return C({
        ...t,
        state: !0,
        attribute: !1
    });
}
var E2 = te`
  :host {
    display: flex;
    width: inherit;
    height: inherit;
  }
`, lt = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Ze = class extends V {
    render() {
        return this.style.cssText = `
      flex-direction: ${this.flexDirection};
      flex-wrap: ${this.flexWrap};
      flex-basis: ${this.flexBasis};
      flex-grow: ${this.flexGrow};
      flex-shrink: ${this.flexShrink};
      align-items: ${this.alignItems};
      justify-content: ${this.justifyContent};
      column-gap: ${this.columnGap && `var(--wui-spacing-${this.columnGap})`};
      row-gap: ${this.rowGap && `var(--wui-spacing-${this.rowGap})`};
      gap: ${this.gap && `var(--wui-spacing-${this.gap})`};
      padding-top: ${this.padding && Me.getSpacingStyles(this.padding, 0)};
      padding-right: ${this.padding && Me.getSpacingStyles(this.padding, 1)};
      padding-bottom: ${this.padding && Me.getSpacingStyles(this.padding, 2)};
      padding-left: ${this.padding && Me.getSpacingStyles(this.padding, 3)};
      margin-top: ${this.margin && Me.getSpacingStyles(this.margin, 0)};
      margin-right: ${this.margin && Me.getSpacingStyles(this.margin, 1)};
      margin-bottom: ${this.margin && Me.getSpacingStyles(this.margin, 2)};
      margin-left: ${this.margin && Me.getSpacingStyles(this.margin, 3)};
    `, w`<slot></slot>`;
    }
};
Ze.styles = [
    we,
    E2
], lt([
    C()
], Ze.prototype, "flexDirection", void 0), lt([
    C()
], Ze.prototype, "flexWrap", void 0), lt([
    C()
], Ze.prototype, "flexBasis", void 0), lt([
    C()
], Ze.prototype, "flexGrow", void 0), lt([
    C()
], Ze.prototype, "flexShrink", void 0), lt([
    C()
], Ze.prototype, "alignItems", void 0), lt([
    C()
], Ze.prototype, "justifyContent", void 0), lt([
    C()
], Ze.prototype, "columnGap", void 0), lt([
    C()
], Ze.prototype, "rowGap", void 0), lt([
    C()
], Ze.prototype, "gap", void 0), lt([
    C()
], Ze.prototype, "padding", void 0), lt([
    C()
], Ze.prototype, "margin", void 0), Ze = lt([
    F("wui-flex")
], Ze); /**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ 
const re = (t)=>t ?? Ne; /**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ 
const A2 = (t)=>t === null || typeof t != "object" && typeof t != "function", S2 = (t)=>t.strings === void 0; /**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ 
const ku = {
    ATTRIBUTE: 1,
    CHILD: 2,
    PROPERTY: 3,
    BOOLEAN_ATTRIBUTE: 4,
    EVENT: 5,
    ELEMENT: 6
}, pc = (t)=>(...e)=>({
            _$litDirective$: t,
            values: e
        });
class Tu {
    constructor(e){}
    get _$AU() {
        return this._$AM._$AU;
    }
    _$AT(e, r, n) {
        this._$Ct = e, this._$AM = r, this._$Ci = n;
    }
    _$AS(e, r) {
        return this.update(e, r);
    }
    update(e, r) {
        return this.render(...r);
    }
} /**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ 
const xi = (t, e)=>{
    const r = t._$AN;
    if (r === void 0) return !1;
    for (const n of r)n._$AO?.(e, !1), xi(n, e);
    return !0;
}, Is = (t)=>{
    let e, r;
    do {
        if ((e = t._$AM) === void 0) break;
        r = e._$AN, r.delete(t), t = e;
    }while (r?.size === 0)
}, Ou = (t)=>{
    for(let e; e = t._$AM; t = e){
        let r = e._$AN;
        if (r === void 0) e._$AN = r = new Set;
        else if (r.has(t)) break;
        r.add(t), N2(e);
    }
};
function _2(t) {
    this._$AN !== void 0 ? (Is(this), this._$AM = t, Ou(this)) : this._$AM = t;
}
function I2(t, e = !1, r = 0) {
    const n = this._$AH, i = this._$AN;
    if (i !== void 0 && i.size !== 0) if (e) if (Array.isArray(n)) for(let o = r; o < n.length; o++)xi(n[o], !1), Is(n[o]);
    else n != null && (xi(n, !1), Is(n));
    else xi(this, t);
}
const N2 = (t)=>{
    t.type == ku.CHILD && (t._$AP ??= I2, t._$AQ ??= _2);
};
class $u extends Tu {
    constructor(){
        super(...arguments), this._$AN = void 0;
    }
    _$AT(e, r, n) {
        super._$AT(e, r, n), Ou(this), this.isConnected = e._$AU;
    }
    _$AO(e, r = !0) {
        e !== this.isConnected && (this.isConnected = e, e ? this.reconnected?.() : this.disconnected?.()), r && (xi(this, e), Is(this));
    }
    setValue(e) {
        if (S2(this._$Ct)) this._$Ct._$AI(e, this);
        else {
            const r = [
                ...this._$Ct._$AH
            ];
            r[this._$Ci] = e, this._$Ct._$AI(r, this, 0);
        }
    }
    disconnected() {}
    reconnected() {}
} /**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ 
class k2 {
    constructor(e){
        this.G = e;
    }
    disconnect() {
        this.G = void 0;
    }
    reconnect(e) {
        this.G = e;
    }
    deref() {
        return this.G;
    }
}
class T2 {
    constructor(){
        this.Y = void 0, this.Z = void 0;
    }
    get() {
        return this.Y;
    }
    pause() {
        this.Y ??= new Promise((e)=>this.Z = e);
    }
    resume() {
        this.Z?.(), this.Y = this.Z = void 0;
    }
} /**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ 
const Pu = (t)=>!A2(t) && typeof t.then == "function", Bu = 1073741823;
class O2 extends $u {
    constructor(){
        super(...arguments), this._$Cwt = Bu, this._$Cbt = [], this._$CK = new k2(this), this._$CX = new T2;
    }
    render(...e) {
        return e.find((r)=>!Pu(r)) ?? Yt;
    }
    update(e, r) {
        const n = this._$Cbt;
        let i = n.length;
        this._$Cbt = r;
        const o = this._$CK, s = this._$CX;
        this.isConnected || this.disconnected();
        for(let a = 0; a < r.length && !(a > this._$Cwt); a++){
            const c = r[a];
            if (!Pu(c)) return this._$Cwt = a, c;
            a < i && c === n[a] || (this._$Cwt = Bu, i = 0, Promise.resolve(c).then(async (l)=>{
                for(; s.get();)await s.get();
                const d = o.deref();
                if (d !== void 0) {
                    const u = d._$Cbt.indexOf(c);
                    u > -1 && u < d._$Cwt && (d._$Cwt = u, d.setValue(l));
                }
            }));
        }
        return Yt;
    }
    disconnected() {
        this._$CK.disconnect(), this._$CX.pause();
    }
    reconnected() {
        this._$CK.reconnect(this), this._$CX.resume();
    }
}
const $2 = pc(O2);
class P2 {
    constructor(){
        this.cache = new Map;
    }
    set(e, r) {
        this.cache.set(e, r);
    }
    get(e) {
        return this.cache.get(e);
    }
    has(e) {
        return this.cache.has(e);
    }
    delete(e) {
        this.cache.delete(e);
    }
    clear() {
        this.cache.clear();
    }
}
const fc = new P2;
var B2 = te`
  :host {
    display: flex;
    aspect-ratio: var(--local-aspect-ratio);
    color: var(--local-color);
    width: var(--local-width);
  }

  svg {
    width: inherit;
    height: inherit;
    object-fit: contain;
    object-position: center;
  }

  .fallback {
    width: var(--local-width);
    height: var(--local-height);
  }
`, Ei = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
const Ru = {
    add: async ()=>(await Promise.resolve().then(function() {
            return Lm;
        })).addSvg,
    allWallets: async ()=>(await Promise.resolve().then(function() {
            return Mm;
        })).allWalletsSvg,
    arrowBottomCircle: async ()=>(await Promise.resolve().then(function() {
            return zm;
        })).arrowBottomCircleSvg,
    appStore: async ()=>(await Promise.resolve().then(function() {
            return jm;
        })).appStoreSvg,
    apple: async ()=>(await Promise.resolve().then(function() {
            return Hm;
        })).appleSvg,
    arrowBottom: async ()=>(await Promise.resolve().then(function() {
            return Zm;
        })).arrowBottomSvg,
    arrowLeft: async ()=>(await Promise.resolve().then(function() {
            return qm;
        })).arrowLeftSvg,
    arrowRight: async ()=>(await Promise.resolve().then(function() {
            return Ym;
        })).arrowRightSvg,
    arrowTop: async ()=>(await Promise.resolve().then(function() {
            return Jm;
        })).arrowTopSvg,
    bank: async ()=>(await Promise.resolve().then(function() {
            return e3;
        })).bankSvg,
    browser: async ()=>(await Promise.resolve().then(function() {
            return r3;
        })).browserSvg,
    card: async ()=>(await Promise.resolve().then(function() {
            return i3;
        })).cardSvg,
    checkmark: async ()=>(await Promise.resolve().then(function() {
            return s3;
        })).checkmarkSvg,
    checkmarkBold: async ()=>(await Promise.resolve().then(function() {
            return c3;
        })).checkmarkBoldSvg,
    chevronBottom: async ()=>(await Promise.resolve().then(function() {
            return d3;
        })).chevronBottomSvg,
    chevronLeft: async ()=>(await Promise.resolve().then(function() {
            return h3;
        })).chevronLeftSvg,
    chevronRight: async ()=>(await Promise.resolve().then(function() {
            return f3;
        })).chevronRightSvg,
    chevronTop: async ()=>(await Promise.resolve().then(function() {
            return w3;
        })).chevronTopSvg,
    chromeStore: async ()=>(await Promise.resolve().then(function() {
            return b3;
        })).chromeStoreSvg,
    clock: async ()=>(await Promise.resolve().then(function() {
            return C3;
        })).clockSvg,
    close: async ()=>(await Promise.resolve().then(function() {
            return x3;
        })).closeSvg,
    compass: async ()=>(await Promise.resolve().then(function() {
            return A3;
        })).compassSvg,
    coinPlaceholder: async ()=>(await Promise.resolve().then(function() {
            return _3;
        })).coinPlaceholderSvg,
    copy: async ()=>(await Promise.resolve().then(function() {
            return N3;
        })).copySvg,
    cursor: async ()=>(await Promise.resolve().then(function() {
            return T3;
        })).cursorSvg,
    cursorTransparent: async ()=>(await Promise.resolve().then(function() {
            return $3;
        })).cursorTransparentSvg,
    desktop: async ()=>(await Promise.resolve().then(function() {
            return B3;
        })).desktopSvg,
    disconnect: async ()=>(await Promise.resolve().then(function() {
            return L3;
        })).disconnectSvg,
    discord: async ()=>(await Promise.resolve().then(function() {
            return M3;
        })).discordSvg,
    etherscan: async ()=>(await Promise.resolve().then(function() {
            return z3;
        })).etherscanSvg,
    extension: async ()=>(await Promise.resolve().then(function() {
            return j3;
        })).extensionSvg,
    externalLink: async ()=>(await Promise.resolve().then(function() {
            return H3;
        })).externalLinkSvg,
    facebook: async ()=>(await Promise.resolve().then(function() {
            return Z3;
        })).facebookSvg,
    farcaster: async ()=>(await Promise.resolve().then(function() {
            return q3;
        })).farcasterSvg,
    filters: async ()=>(await Promise.resolve().then(function() {
            return Y3;
        })).filtersSvg,
    github: async ()=>(await Promise.resolve().then(function() {
            return J3;
        })).githubSvg,
    google: async ()=>(await Promise.resolve().then(function() {
            return e5;
        })).googleSvg,
    helpCircle: async ()=>(await Promise.resolve().then(function() {
            return r5;
        })).helpCircleSvg,
    image: async ()=>(await Promise.resolve().then(function() {
            return i5;
        })).imageSvg,
    id: async ()=>(await Promise.resolve().then(function() {
            return s5;
        })).idSvg,
    infoCircle: async ()=>(await Promise.resolve().then(function() {
            return c5;
        })).infoCircleSvg,
    lightbulb: async ()=>(await Promise.resolve().then(function() {
            return d5;
        })).lightbulbSvg,
    mail: async ()=>(await Promise.resolve().then(function() {
            return h5;
        })).mailSvg,
    mobile: async ()=>(await Promise.resolve().then(function() {
            return f5;
        })).mobileSvg,
    more: async ()=>(await Promise.resolve().then(function() {
            return w5;
        })).moreSvg,
    networkPlaceholder: async ()=>(await Promise.resolve().then(function() {
            return b5;
        })).networkPlaceholderSvg,
    nftPlaceholder: async ()=>(await Promise.resolve().then(function() {
            return C5;
        })).nftPlaceholderSvg,
    off: async ()=>(await Promise.resolve().then(function() {
            return x5;
        })).offSvg,
    playStore: async ()=>(await Promise.resolve().then(function() {
            return A5;
        })).playStoreSvg,
    plus: async ()=>(await Promise.resolve().then(function() {
            return _5;
        })).plusSvg,
    qrCode: async ()=>(await Promise.resolve().then(function() {
            return N5;
        })).qrCodeIcon,
    recycleHorizontal: async ()=>(await Promise.resolve().then(function() {
            return T5;
        })).recycleHorizontalSvg,
    refresh: async ()=>(await Promise.resolve().then(function() {
            return $5;
        })).refreshSvg,
    search: async ()=>(await Promise.resolve().then(function() {
            return B5;
        })).searchSvg,
    send: async ()=>(await Promise.resolve().then(function() {
            return L5;
        })).sendSvg,
    swapHorizontal: async ()=>(await Promise.resolve().then(function() {
            return M5;
        })).swapHorizontalSvg,
    swapHorizontalMedium: async ()=>(await Promise.resolve().then(function() {
            return z5;
        })).swapHorizontalMediumSvg,
    swapHorizontalBold: async ()=>(await Promise.resolve().then(function() {
            return j5;
        })).swapHorizontalBoldSvg,
    swapHorizontalRoundedBold: async ()=>(await Promise.resolve().then(function() {
            return H5;
        })).swapHorizontalRoundedBoldSvg,
    swapVertical: async ()=>(await Promise.resolve().then(function() {
            return Z5;
        })).swapVerticalSvg,
    telegram: async ()=>(await Promise.resolve().then(function() {
            return q5;
        })).telegramSvg,
    threeDots: async ()=>(await Promise.resolve().then(function() {
            return Y5;
        })).threeDotsSvg,
    twitch: async ()=>(await Promise.resolve().then(function() {
            return J5;
        })).twitchSvg,
    twitter: async ()=>(await Promise.resolve().then(function() {
            return x0;
        })).xSvg,
    twitterIcon: async ()=>(await Promise.resolve().then(function() {
            return tb;
        })).twitterIconSvg,
    verify: async ()=>(await Promise.resolve().then(function() {
            return nb;
        })).verifySvg,
    verifyFilled: async ()=>(await Promise.resolve().then(function() {
            return ob;
        })).verifyFilledSvg,
    wallet: async ()=>(await Promise.resolve().then(function() {
            return ab;
        })).walletSvg,
    walletConnect: async ()=>(await Promise.resolve().then(function() {
            return Yc;
        })).walletConnectSvg,
    walletConnectLightBrown: async ()=>(await Promise.resolve().then(function() {
            return Yc;
        })).walletConnectLightBrownSvg,
    walletConnectBrown: async ()=>(await Promise.resolve().then(function() {
            return Yc;
        })).walletConnectBrownSvg,
    walletPlaceholder: async ()=>(await Promise.resolve().then(function() {
            return hb;
        })).walletPlaceholderSvg,
    warningCircle: async ()=>(await Promise.resolve().then(function() {
            return fb;
        })).warningCircleSvg,
    x: async ()=>(await Promise.resolve().then(function() {
            return x0;
        })).xSvg,
    info: async ()=>(await Promise.resolve().then(function() {
            return wb;
        })).infoSvg,
    exclamationTriangle: async ()=>(await Promise.resolve().then(function() {
            return bb;
        })).exclamationTriangleSvg,
    reown: async ()=>(await Promise.resolve().then(function() {
            return Cb;
        })).reownSvg
};
async function R2(t) {
    if (fc.has(t)) return fc.get(t);
    const r = (Ru[t] ?? Ru.copy)();
    return fc.set(t, r), r;
}
let zr = class extends V {
    constructor(){
        super(...arguments), this.size = "md", this.name = "copy", this.color = "fg-300", this.aspectRatio = "1 / 1";
    }
    render() {
        return this.style.cssText = `
      --local-color: ${`var(--wui-color-${this.color});`}
      --local-width: ${`var(--wui-icon-size-${this.size});`}
      --local-aspect-ratio: ${this.aspectRatio}
    `, w`${$2(R2(this.name), w`<div class="fallback"></div>`)}`;
    }
};
zr.styles = [
    we,
    li,
    B2
], Ei([
    C()
], zr.prototype, "size", void 0), Ei([
    C()
], zr.prototype, "name", void 0), Ei([
    C()
], zr.prototype, "color", void 0), Ei([
    C()
], zr.prototype, "aspectRatio", void 0), zr = Ei([
    F("wui-icon")
], zr); /**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ 
const Lu = pc(class extends Tu {
    constructor(t){
        if (super(t), t.type !== ku.ATTRIBUTE || t.name !== "class" || t.strings?.length > 2) throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.");
    }
    render(t) {
        return " " + Object.keys(t).filter((e)=>t[e]).join(" ") + " ";
    }
    update(t, [e]) {
        if (this.st === void 0) {
            this.st = new Set, t.strings !== void 0 && (this.nt = new Set(t.strings.join(" ").split(/\s/).filter((n)=>n !== "")));
            for(const n in e)e[n] && !this.nt?.has(n) && this.st.add(n);
            return this.render(e);
        }
        const r = t.element.classList;
        for (const n of this.st)n in e || (r.remove(n), this.st.delete(n));
        for(const n in e){
            const i = !!e[n];
            i === this.st.has(n) || this.nt?.has(n) || (i ? (r.add(n), this.st.add(n)) : (r.remove(n), this.st.delete(n)));
        }
        return Yt;
    }
});
var L2 = te`
  :host {
    display: inline-flex !important;
  }

  slot {
    width: 100%;
    display: inline-block;
    font-style: normal;
    font-family: var(--wui-font-family);
    font-feature-settings:
      'tnum' on,
      'lnum' on,
      'case' on;
    line-height: 130%;
    font-weight: var(--wui-font-weight-regular);
    overflow: inherit;
    text-overflow: inherit;
    text-align: var(--local-align);
    color: var(--local-color);
  }

  .wui-line-clamp-1 {
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
  }

  .wui-line-clamp-2 {
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
  }

  .wui-font-medium-400 {
    font-size: var(--wui-font-size-medium);
    font-weight: var(--wui-font-weight-light);
    letter-spacing: var(--wui-letter-spacing-medium);
  }

  .wui-font-medium-600 {
    font-size: var(--wui-font-size-medium);
    letter-spacing: var(--wui-letter-spacing-medium);
  }

  .wui-font-title-600 {
    font-size: var(--wui-font-size-title);
    letter-spacing: var(--wui-letter-spacing-title);
  }

  .wui-font-title-6-600 {
    font-size: var(--wui-font-size-title-6);
    letter-spacing: var(--wui-letter-spacing-title-6);
  }

  .wui-font-mini-700 {
    font-size: var(--wui-font-size-mini);
    letter-spacing: var(--wui-letter-spacing-mini);
    text-transform: uppercase;
  }

  .wui-font-large-500,
  .wui-font-large-600,
  .wui-font-large-700 {
    font-size: var(--wui-font-size-large);
    letter-spacing: var(--wui-letter-spacing-large);
  }

  .wui-font-2xl-500,
  .wui-font-2xl-600,
  .wui-font-2xl-700 {
    font-size: var(--wui-font-size-2xl);
    letter-spacing: var(--wui-letter-spacing-2xl);
  }

  .wui-font-paragraph-400,
  .wui-font-paragraph-500,
  .wui-font-paragraph-600,
  .wui-font-paragraph-700 {
    font-size: var(--wui-font-size-paragraph);
    letter-spacing: var(--wui-letter-spacing-paragraph);
  }

  .wui-font-small-400,
  .wui-font-small-500,
  .wui-font-small-600 {
    font-size: var(--wui-font-size-small);
    letter-spacing: var(--wui-letter-spacing-small);
  }

  .wui-font-tiny-400,
  .wui-font-tiny-500,
  .wui-font-tiny-600 {
    font-size: var(--wui-font-size-tiny);
    letter-spacing: var(--wui-letter-spacing-tiny);
  }

  .wui-font-micro-700,
  .wui-font-micro-600 {
    font-size: var(--wui-font-size-micro);
    letter-spacing: var(--wui-letter-spacing-micro);
    text-transform: uppercase;
  }

  .wui-font-tiny-400,
  .wui-font-small-400,
  .wui-font-medium-400,
  .wui-font-paragraph-400 {
    font-weight: var(--wui-font-weight-light);
  }

  .wui-font-large-700,
  .wui-font-paragraph-700,
  .wui-font-micro-700,
  .wui-font-mini-700 {
    font-weight: var(--wui-font-weight-bold);
  }

  .wui-font-medium-600,
  .wui-font-medium-title-600,
  .wui-font-title-6-600,
  .wui-font-large-600,
  .wui-font-paragraph-600,
  .wui-font-small-600,
  .wui-font-tiny-600,
  .wui-font-micro-600 {
    font-weight: var(--wui-font-weight-medium);
  }

  :host([disabled]) {
    opacity: 0.4;
  }
`, Ai = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Wr = class extends V {
    constructor(){
        super(...arguments), this.variant = "paragraph-500", this.color = "fg-300", this.align = "left", this.lineClamp = void 0;
    }
    render() {
        const e = {
            [`wui-font-${this.variant}`]: !0,
            [`wui-color-${this.color}`]: !0,
            [`wui-line-clamp-${this.lineClamp}`]: !!this.lineClamp
        };
        return this.style.cssText = `
      --local-align: ${this.align};
      --local-color: var(--wui-color-${this.color});
    `, w`<slot class=${Lu(e)}></slot>`;
    }
};
Wr.styles = [
    we,
    L2
], Ai([
    C()
], Wr.prototype, "variant", void 0), Ai([
    C()
], Wr.prototype, "color", void 0), Ai([
    C()
], Wr.prototype, "align", void 0), Ai([
    C()
], Wr.prototype, "lineClamp", void 0), Wr = Ai([
    F("wui-text")
], Wr);
var U2 = te`
  :host {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    position: relative;
    overflow: hidden;
    background-color: var(--wui-color-gray-glass-020);
    border-radius: var(--local-border-radius);
    border: var(--local-border);
    box-sizing: content-box;
    width: var(--local-size);
    height: var(--local-size);
    min-height: var(--local-size);
    min-width: var(--local-size);
  }

  @supports (background: color-mix(in srgb, white 50%, black)) {
    :host {
      background-color: color-mix(in srgb, var(--local-bg-value) var(--local-bg-mix), transparent);
    }
  }
`, Xt = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let At = class extends V {
    constructor(){
        super(...arguments), this.size = "md", this.backgroundColor = "accent-100", this.iconColor = "accent-100", this.background = "transparent", this.border = !1, this.borderColor = "wui-color-bg-125", this.icon = "copy";
    }
    render() {
        const e = this.iconSize || this.size, r = this.size === "lg", n = this.size === "xl", i = r ? "12%" : "16%", o = r ? "xxs" : n ? "s" : "3xl", s = this.background === "gray", a = this.background === "opaque", c = this.backgroundColor === "accent-100" && a || this.backgroundColor === "success-100" && a || this.backgroundColor === "error-100" && a || this.backgroundColor === "inverse-100" && a;
        let l = `var(--wui-color-${this.backgroundColor})`;
        return c ? l = `var(--wui-icon-box-bg-${this.backgroundColor})` : s && (l = `var(--wui-color-gray-${this.backgroundColor})`), this.style.cssText = `
       --local-bg-value: ${l};
       --local-bg-mix: ${c || s ? "100%" : i};
       --local-border-radius: var(--wui-border-radius-${o});
       --local-size: var(--wui-icon-box-size-${this.size});
       --local-border: ${this.borderColor === "wui-color-bg-125" ? "2px" : "1px"} solid ${this.border ? `var(--${this.borderColor})` : "transparent"}
   `, w` <wui-icon color=${this.iconColor} size=${e} name=${this.icon}></wui-icon> `;
    }
};
At.styles = [
    we,
    De,
    U2
], Xt([
    C()
], At.prototype, "size", void 0), Xt([
    C()
], At.prototype, "backgroundColor", void 0), Xt([
    C()
], At.prototype, "iconColor", void 0), Xt([
    C()
], At.prototype, "iconSize", void 0), Xt([
    C()
], At.prototype, "background", void 0), Xt([
    C({
        type: Boolean
    })
], At.prototype, "border", void 0), Xt([
    C()
], At.prototype, "borderColor", void 0), Xt([
    C()
], At.prototype, "icon", void 0), At = Xt([
    F("wui-icon-box")
], At);
var M2 = te`
  :host {
    display: block;
    width: var(--local-width);
    height: var(--local-height);
  }

  img {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center center;
    border-radius: inherit;
  }
`, Ns = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let In = class extends V {
    constructor(){
        super(...arguments), this.src = "./path/to/image.jpg", this.alt = "Image", this.size = void 0;
    }
    render() {
        return this.style.cssText = `
      --local-width: ${this.size ? `var(--wui-icon-size-${this.size});` : "100%"};
      --local-height: ${this.size ? `var(--wui-icon-size-${this.size});` : "100%"};
      `, w`<img src=${this.src} alt=${this.alt} @error=${this.handleImageError} />`;
    }
    handleImageError() {
        this.dispatchEvent(new CustomEvent("onLoadError", {
            bubbles: !0,
            composed: !0
        }));
    }
};
In.styles = [
    we,
    li,
    M2
], Ns([
    C()
], In.prototype, "src", void 0), Ns([
    C()
], In.prototype, "alt", void 0), Ns([
    C()
], In.prototype, "size", void 0), In = Ns([
    F("wui-image")
], In);
var D2 = te`
  :host {
    position: relative;
    background-color: var(--wui-color-gray-glass-002);
    display: flex;
    justify-content: center;
    align-items: center;
    width: var(--local-size);
    height: var(--local-size);
    border-radius: inherit;
    border-radius: var(--local-border-radius);
  }

  :host > wui-flex {
    overflow: hidden;
    border-radius: inherit;
    border-radius: var(--local-border-radius);
  }

  :host::after {
    content: '';
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    border-radius: inherit;
    border: 1px solid var(--wui-color-gray-glass-010);
    pointer-events: none;
  }

  :host([name='Extension'])::after {
    border: 1px solid var(--wui-color-accent-glass-010);
  }

  :host([data-wallet-icon='allWallets']) {
    background-color: var(--wui-all-wallets-bg-100);
  }

  :host([data-wallet-icon='allWallets'])::after {
    border: 1px solid var(--wui-color-accent-glass-010);
  }

  wui-icon[data-parent-size='inherit'] {
    width: 75%;
    height: 75%;
    align-items: center;
  }

  wui-icon[data-parent-size='sm'] {
    width: 18px;
    height: 18px;
  }

  wui-icon[data-parent-size='md'] {
    width: 24px;
    height: 24px;
  }

  wui-icon[data-parent-size='lg'] {
    width: 42px;
    height: 42px;
  }

  wui-icon[data-parent-size='full'] {
    width: 100%;
    height: 100%;
  }

  :host > wui-icon-box {
    position: absolute;
    overflow: hidden;
    right: -1px;
    bottom: -2px;
    z-index: 1;
    border: 2px solid var(--wui-color-bg-150, #1e1f1f);
    padding: 1px;
  }
`, jr = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Jt = class extends V {
    constructor(){
        super(...arguments), this.size = "md", this.name = "", this.installed = !1, this.badgeSize = "xs";
    }
    render() {
        let e = "xxs";
        return this.size === "lg" ? e = "m" : this.size === "md" ? e = "xs" : e = "xxs", this.style.cssText = `
       --local-border-radius: var(--wui-border-radius-${e});
       --local-size: var(--wui-wallet-image-size-${this.size});
   `, this.walletIcon && (this.dataset.walletIcon = this.walletIcon), w`
      <wui-flex justifyContent="center" alignItems="center"> ${this.templateVisual()} </wui-flex>
    `;
    }
    templateVisual() {
        return this.imageSrc ? w`<wui-image src=${this.imageSrc} alt=${this.name}></wui-image>` : this.walletIcon ? w`<wui-icon
        data-parent-size="md"
        size="md"
        color="inherit"
        name=${this.walletIcon}
      ></wui-icon>` : w`<wui-icon
      data-parent-size=${this.size}
      size="inherit"
      color="inherit"
      name="walletPlaceholder"
    ></wui-icon>`;
    }
};
Jt.styles = [
    De,
    we,
    D2
], jr([
    C()
], Jt.prototype, "size", void 0), jr([
    C()
], Jt.prototype, "name", void 0), jr([
    C()
], Jt.prototype, "imageSrc", void 0), jr([
    C()
], Jt.prototype, "walletIcon", void 0), jr([
    C({
        type: Boolean
    })
], Jt.prototype, "installed", void 0), jr([
    C()
], Jt.prototype, "badgeSize", void 0), Jt = jr([
    F("wui-wallet-image")
], Jt);
var z2 = te`
  :host {
    position: relative;
    border-radius: var(--wui-border-radius-xxs);
    width: 40px;
    height: 40px;
    overflow: hidden;
    background: var(--wui-color-gray-glass-002);
    display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
    gap: var(--wui-spacing-4xs);
    padding: 3.75px !important;
  }

  :host::after {
    content: '';
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    border-radius: inherit;
    border: 1px solid var(--wui-color-gray-glass-010);
    pointer-events: none;
  }

  :host > wui-wallet-image {
    width: 14px;
    height: 14px;
    border-radius: var(--wui-border-radius-5xs);
  }

  :host > wui-flex {
    padding: 2px;
    position: fixed;
    overflow: hidden;
    left: 34px;
    bottom: 8px;
    background: var(--dark-background-150, #1e1f1f);
    border-radius: 50%;
    z-index: 2;
    display: flex;
  }
`, Uu = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
const gc = 4;
let ks = class extends V {
    constructor(){
        super(...arguments), this.walletImages = [];
    }
    render() {
        const e = this.walletImages.length < gc;
        return w`${this.walletImages.slice(0, gc).map(({ src: r, walletName: n })=>w`
            <wui-wallet-image
              size="inherit"
              imageSrc=${r}
              name=${re(n)}
            ></wui-wallet-image>
          `)}
      ${e ? [
            ...Array(gc - this.walletImages.length)
        ].map(()=>w` <wui-wallet-image size="inherit" name=""></wui-wallet-image>`) : null}
      <wui-flex>
        <wui-icon-box
          size="xxs"
          iconSize="xxs"
          iconcolor="success-100"
          backgroundcolor="success-100"
          icon="checkmark"
          background="opaque"
        ></wui-icon-box>
      </wui-flex>`;
    }
};
ks.styles = [
    we,
    z2
], Uu([
    C({
        type: Array
    })
], ks.prototype, "walletImages", void 0), ks = Uu([
    F("wui-all-wallets-image")
], ks);
var W2 = te`
  :host {
    display: flex;
    justify-content: center;
    align-items: center;
    height: var(--wui-spacing-m);
    padding: 0 var(--wui-spacing-3xs) !important;
    border-radius: var(--wui-border-radius-5xs);
    transition:
      border-radius var(--wui-duration-lg) var(--wui-ease-out-power-1),
      background-color var(--wui-duration-lg) var(--wui-ease-out-power-1);
    will-change: border-radius, background-color;
  }

  :host > wui-text {
    transform: translateY(5%);
  }

  :host([data-variant='main']) {
    background-color: var(--wui-color-accent-glass-015);
    color: var(--wui-color-accent-100);
  }

  :host([data-variant='shade']) {
    background-color: var(--wui-color-gray-glass-010);
    color: var(--wui-color-fg-200);
  }

  :host([data-variant='success']) {
    background-color: var(--wui-icon-box-bg-success-100);
    color: var(--wui-color-success-100);
  }

  :host([data-variant='error']) {
    background-color: var(--wui-icon-box-bg-error-100);
    color: var(--wui-color-error-100);
  }

  :host([data-size='lg']) {
    padding: 11px 5px !important;
  }

  :host([data-size='lg']) > wui-text {
    transform: translateY(2%);
  }
`, wc = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Si = class extends V {
    constructor(){
        super(...arguments), this.variant = "main", this.size = "lg";
    }
    render() {
        this.dataset.variant = this.variant, this.dataset.size = this.size;
        const e = this.size === "md" ? "mini-700" : "micro-700";
        return w`
      <wui-text data-variant=${this.variant} variant=${e} color="inherit">
        <slot></slot>
      </wui-text>
    `;
    }
};
Si.styles = [
    we,
    W2
], wc([
    C()
], Si.prototype, "variant", void 0), wc([
    C()
], Si.prototype, "size", void 0), Si = wc([
    F("wui-tag")
], Si);
var j2 = te`
  button {
    column-gap: var(--wui-spacing-s);
    padding: 7px var(--wui-spacing-l) 7px var(--wui-spacing-xs);
    width: 100%;
    background-color: var(--wui-color-gray-glass-002);
    border-radius: var(--wui-border-radius-xs);
    color: var(--wui-color-fg-100);
  }

  button > wui-text:nth-child(2) {
    display: flex;
    flex: 1;
  }

  button:disabled {
    background-color: var(--wui-color-gray-glass-015);
    color: var(--wui-color-gray-glass-015);
  }

  button:disabled > wui-tag {
    background-color: var(--wui-color-gray-glass-010);
    color: var(--wui-color-fg-300);
  }

  wui-icon {
    color: var(--wui-color-fg-200) !important;
  }
`, tt = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let je = class extends V {
    constructor(){
        super(...arguments), this.walletImages = [], this.imageSrc = "", this.name = "", this.tabIdx = void 0, this.installed = !1, this.disabled = !1, this.showAllWallets = !1, this.loading = !1, this.loadingSpinnerColor = "accent-100";
    }
    render() {
        return w`
      <button ?disabled=${this.disabled} tabindex=${re(this.tabIdx)}>
        ${this.templateAllWallets()} ${this.templateWalletImage()}
        <wui-text variant="paragraph-500" color="inherit">${this.name}</wui-text>
        ${this.templateStatus()}
      </button>
    `;
    }
    templateAllWallets() {
        return this.showAllWallets && this.imageSrc ? w` <wui-all-wallets-image .imageeSrc=${this.imageSrc}> </wui-all-wallets-image> ` : this.showAllWallets && this.walletIcon ? w` <wui-wallet-image .walletIcon=${this.walletIcon} size="sm"> </wui-wallet-image> ` : null;
    }
    templateWalletImage() {
        return !this.showAllWallets && this.imageSrc ? w`<wui-wallet-image
        size="sm"
        imageSrc=${this.imageSrc}
        name=${this.name}
        .installed=${this.installed}
      ></wui-wallet-image>` : !this.showAllWallets && !this.imageSrc ? w`<wui-wallet-image size="sm" name=${this.name}></wui-wallet-image>` : null;
    }
    templateStatus() {
        return this.loading ? w`<wui-loading-spinner
        size="lg"
        color=${this.loadingSpinnerColor}
      ></wui-loading-spinner>` : this.tagLabel && this.tagVariant ? w`<wui-tag variant=${this.tagVariant}>${this.tagLabel}</wui-tag>` : this.icon ? w`<wui-icon color="inherit" size="sm" name=${this.icon}></wui-icon>` : null;
    }
};
je.styles = [
    we,
    De,
    j2
], tt([
    C({
        type: Array
    })
], je.prototype, "walletImages", void 0), tt([
    C()
], je.prototype, "imageSrc", void 0), tt([
    C()
], je.prototype, "name", void 0), tt([
    C()
], je.prototype, "tagLabel", void 0), tt([
    C()
], je.prototype, "tagVariant", void 0), tt([
    C()
], je.prototype, "icon", void 0), tt([
    C()
], je.prototype, "walletIcon", void 0), tt([
    C()
], je.prototype, "tabIdx", void 0), tt([
    C({
        type: Boolean
    })
], je.prototype, "installed", void 0), tt([
    C({
        type: Boolean
    })
], je.prototype, "disabled", void 0), tt([
    C({
        type: Boolean
    })
], je.prototype, "showAllWallets", void 0), tt([
    C({
        type: Boolean
    })
], je.prototype, "loading", void 0), tt([
    C({
        type: String
    })
], je.prototype, "loadingSpinnerColor", void 0), je = tt([
    F("wui-list-wallet")
], je);
var _i = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Nn = class extends V {
    constructor(){
        super(), this.unsubscribe = [], this.tabIdx = void 0, this.connectors = j.state.connectors, this.count = W.state.count, this.isFetchingRecommendedWallets = W.state.isFetchingRecommendedWallets, this.unsubscribe.push(j.subscribeKey("connectors", (e)=>this.connectors = e), W.subscribeKey("count", (e)=>this.count = e), W.subscribeKey("isFetchingRecommendedWallets", (e)=>this.isFetchingRecommendedWallets = e));
    }
    disconnectedCallback() {
        this.unsubscribe.forEach((e)=>e());
    }
    render() {
        const e = this.connectors.find((a)=>a.id === "walletConnect"), { allWallets: r } = T.state;
        if (!e || r === "HIDE" || r === "ONLY_MOBILE" && !U.isMobile()) return null;
        const n = W.state.featured.length, i = this.count + n, o = i < 10 ? i : Math.floor(i / 10) * 10, s = o < i ? `${o}+` : `${o}`;
        return w`
      <wui-list-wallet
        name="All Wallets"
        walletIcon="allWallets"
        showAllWallets
        @click=${this.onAllWallets.bind(this)}
        tagLabel=${s}
        tagVariant="shade"
        data-testid="all-wallets"
        tabIdx=${re(this.tabIdx)}
        .loading=${this.isFetchingRecommendedWallets}
        loadingSpinnerColor=${this.isFetchingRecommendedWallets ? "fg-300" : "accent-100"}
      ></wui-list-wallet>
    `;
    }
    onAllWallets() {
        le.sendEvent({
            type: "track",
            event: "CLICK_ALL_WALLETS"
        }), D.push("AllWallets");
    }
};
_i([
    C()
], Nn.prototype, "tabIdx", void 0), _i([
    H()
], Nn.prototype, "connectors", void 0), _i([
    H()
], Nn.prototype, "count", void 0), _i([
    H()
], Nn.prototype, "isFetchingRecommendedWallets", void 0), Nn = _i([
    F("w3m-all-wallets-widget")
], Nn);
var mc = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Ts = class extends V {
    constructor(){
        super(), this.unsubscribe = [], this.tabIdx = void 0, this.connectors = j.state.connectors, this.unsubscribe.push(j.subscribeKey("connectors", (e)=>this.connectors = e));
    }
    disconnectedCallback() {
        this.unsubscribe.forEach((e)=>e());
    }
    render() {
        const e = this.connectors.filter((r)=>r.type === "ANNOUNCED");
        return e?.length ? w`
      <wui-flex flexDirection="column" gap="xs">
        ${e.filter(Kt.showConnector).map((r)=>w`
              <wui-list-wallet
                imageSrc=${re(Oe.getConnectorImage(r))}
                name=${r.name ?? "Unknown"}
                @click=${()=>this.onConnector(r)}
                tagVariant="success"
                tagLabel="installed"
                data-testid=${`wallet-selector-${r.id}`}
                .installed=${!0}
                tabIdx=${re(this.tabIdx)}
              >
              </wui-list-wallet>
            `)}
      </wui-flex>
    ` : (this.style.cssText = "display: none", null);
    }
    onConnector(e) {
        e.id === "walletConnect" ? U.isMobile() ? D.push("AllWallets") : D.push("ConnectingWalletConnect") : D.push("ConnectingExternal", {
            connector: e
        });
    }
};
mc([
    C()
], Ts.prototype, "tabIdx", void 0), mc([
    H()
], Ts.prototype, "connectors", void 0), Ts = mc([
    F("w3m-connect-announced-widget")
], Ts);
var Os = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Ii = class extends V {
    constructor(){
        super(), this.unsubscribe = [], this.tabIdx = void 0, this.connectors = j.state.connectors, this.loading = !1, this.unsubscribe.push(j.subscribeKey("connectors", (e)=>this.connectors = e)), U.isTelegram() && U.isIos() && (this.loading = !Y.state.wcUri, this.unsubscribe.push(Y.subscribeKey("wcUri", (e)=>this.loading = !e)));
    }
    disconnectedCallback() {
        this.unsubscribe.forEach((e)=>e());
    }
    render() {
        const { customWallets: e } = T.state;
        if (!e?.length) return this.style.cssText = "display: none", null;
        const r = this.filterOutDuplicateWallets(e);
        return w`<wui-flex flexDirection="column" gap="xs">
      ${r.map((n)=>w`
          <wui-list-wallet
            imageSrc=${re(Oe.getWalletImage(n))}
            name=${n.name ?? "Unknown"}
            @click=${()=>this.onConnectWallet(n)}
            data-testid=${`wallet-selector-${n.id}`}
            tabIdx=${re(this.tabIdx)}
            ?loading=${this.loading}
          >
          </wui-list-wallet>
        `)}
    </wui-flex>`;
    }
    filterOutDuplicateWallets(e) {
        const r = q.getRecentWallets(), n = this.connectors.map((a)=>a.info?.rdns).filter(Boolean), i = r.map((a)=>a.rdns).filter(Boolean), o = n.concat(i);
        if (o.includes("io.metamask.mobile") && U.isMobile()) {
            const a = o.indexOf("io.metamask.mobile");
            o[a] = "io.metamask";
        }
        return e.filter((a)=>!o.includes(String(a?.rdns)));
    }
    onConnectWallet(e) {
        this.loading || D.push("ConnectingWalletConnect", {
            wallet: e
        });
    }
};
Os([
    C()
], Ii.prototype, "tabIdx", void 0), Os([
    H()
], Ii.prototype, "connectors", void 0), Os([
    H()
], Ii.prototype, "loading", void 0), Ii = Os([
    F("w3m-connect-custom-widget")
], Ii);
var bc = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let $s = class extends V {
    constructor(){
        super(), this.unsubscribe = [], this.tabIdx = void 0, this.connectors = j.state.connectors, this.unsubscribe.push(j.subscribeKey("connectors", (e)=>this.connectors = e));
    }
    disconnectedCallback() {
        this.unsubscribe.forEach((e)=>e());
    }
    render() {
        const n = this.connectors.filter((i)=>i.type === "EXTERNAL").filter(Kt.showConnector).filter((i)=>i.id !== G.CONNECTOR_ID.COINBASE_SDK);
        return n?.length ? w`
      <wui-flex flexDirection="column" gap="xs">
        ${n.map((i)=>w`
            <wui-list-wallet
              imageSrc=${re(Oe.getConnectorImage(i))}
              .installed=${!0}
              name=${i.name ?? "Unknown"}
              data-testid=${`wallet-selector-external-${i.id}`}
              @click=${()=>this.onConnector(i)}
              tabIdx=${re(this.tabIdx)}
            >
            </wui-list-wallet>
          `)}
      </wui-flex>
    ` : (this.style.cssText = "display: none", null);
    }
    onConnector(e) {
        D.push("ConnectingExternal", {
            connector: e
        });
    }
};
bc([
    C()
], $s.prototype, "tabIdx", void 0), bc([
    H()
], $s.prototype, "connectors", void 0), $s = bc([
    F("w3m-connect-external-widget")
], $s);
var vc = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Ps = class extends V {
    constructor(){
        super(...arguments), this.tabIdx = void 0, this.wallets = [];
    }
    render() {
        return this.wallets.length ? w`
      <wui-flex flexDirection="column" gap="xs">
        ${this.wallets.map((e)=>w`
            <wui-list-wallet
              data-testid=${`wallet-selector-featured-${e.id}`}
              imageSrc=${re(Oe.getWalletImage(e))}
              name=${e.name ?? "Unknown"}
              @click=${()=>this.onConnectWallet(e)}
              tabIdx=${re(this.tabIdx)}
            >
            </wui-list-wallet>
          `)}
      </wui-flex>
    ` : (this.style.cssText = "display: none", null);
    }
    onConnectWallet(e) {
        j.selectWalletConnector(e);
    }
};
vc([
    C()
], Ps.prototype, "tabIdx", void 0), vc([
    C()
], Ps.prototype, "wallets", void 0), Ps = vc([
    F("w3m-connect-featured-widget")
], Ps);
var Cc = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Bs = class extends V {
    constructor(){
        super(...arguments), this.tabIdx = void 0, this.connectors = [];
    }
    render() {
        const e = this.connectors;
        return !e?.length || e.length === 1 && e[0]?.name === "Browser Wallet" && !U.isMobile() ? (this.style.cssText = "display: none", null) : w`
      <wui-flex flexDirection="column" gap="xs">
        ${e.map((r)=>{
            const n = r.info?.rdns;
            return !U.isMobile() && r.name === "Browser Wallet" ? null : !n && !Y.checkInstalled() ? (this.style.cssText = "display: none", null) : Kt.showConnector(r) ? w`
            <wui-list-wallet
              imageSrc=${re(Oe.getConnectorImage(r))}
              .installed=${!0}
              name=${r.name ?? "Unknown"}
              tagVariant="success"
              tagLabel="installed"
              data-testid=${`wallet-selector-${r.id}`}
              @click=${()=>this.onConnector(r)}
              tabIdx=${re(this.tabIdx)}
            >
            </wui-list-wallet>
          ` : null;
        })}
      </wui-flex>
    `;
    }
    onConnector(e) {
        j.setActiveConnector(e), D.push("ConnectingExternal", {
            connector: e
        });
    }
};
Cc([
    C()
], Bs.prototype, "tabIdx", void 0), Cc([
    C()
], Bs.prototype, "connectors", void 0), Bs = Cc([
    F("w3m-connect-injected-widget")
], Bs);
var yc = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Rs = class extends V {
    constructor(){
        super(), this.unsubscribe = [], this.tabIdx = void 0, this.connectors = j.state.connectors, this.unsubscribe.push(j.subscribeKey("connectors", (e)=>this.connectors = e));
    }
    disconnectedCallback() {
        this.unsubscribe.forEach((e)=>e());
    }
    render() {
        const e = this.connectors.filter((r)=>r.type === "MULTI_CHAIN" && r.name !== "WalletConnect");
        return e?.length ? w`
      <wui-flex flexDirection="column" gap="xs">
        ${e.map((r)=>w`
            <wui-list-wallet
              imageSrc=${re(Oe.getConnectorImage(r))}
              .installed=${!0}
              name=${r.name ?? "Unknown"}
              tagVariant="shade"
              tagLabel="multichain"
              data-testid=${`wallet-selector-${r.id}`}
              @click=${()=>this.onConnector(r)}
              tabIdx=${re(this.tabIdx)}
            >
            </wui-list-wallet>
          `)}
      </wui-flex>
    ` : (this.style.cssText = "display: none", null);
    }
    onConnector(e) {
        j.setActiveConnector(e), D.push("ConnectingMultiChain");
    }
};
yc([
    C()
], Rs.prototype, "tabIdx", void 0), yc([
    H()
], Rs.prototype, "connectors", void 0), Rs = yc([
    F("w3m-connect-multi-chain-widget")
], Rs);
var Ls = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Ni = class extends V {
    constructor(){
        super(), this.unsubscribe = [], this.tabIdx = void 0, this.connectors = j.state.connectors, this.loading = !1, this.unsubscribe.push(j.subscribeKey("connectors", (e)=>this.connectors = e)), U.isTelegram() && U.isIos() && (this.loading = !Y.state.wcUri, this.unsubscribe.push(Y.subscribeKey("wcUri", (e)=>this.loading = !e)));
    }
    render() {
        const r = q.getRecentWallets().filter((n)=>!Lr.isExcluded(n)).filter((n)=>!this.hasWalletConnector(n)).filter((n)=>this.isWalletCompatibleWithCurrentChain(n));
        return r.length ? w`
      <wui-flex flexDirection="column" gap="xs">
        ${r.map((n)=>w`
            <wui-list-wallet
              imageSrc=${re(Oe.getWalletImage(n))}
              name=${n.name ?? "Unknown"}
              @click=${()=>this.onConnectWallet(n)}
              tagLabel="recent"
              tagVariant="shade"
              tabIdx=${re(this.tabIdx)}
              ?loading=${this.loading}
            >
            </wui-list-wallet>
          `)}
      </wui-flex>
    ` : (this.style.cssText = "display: none", null);
    }
    onConnectWallet(e) {
        this.loading || j.selectWalletConnector(e);
    }
    hasWalletConnector(e) {
        return this.connectors.some((r)=>r.id === e.id || r.name === e.name);
    }
    isWalletCompatibleWithCurrentChain(e) {
        const r = f.state.activeChain;
        return r && e.chains ? e.chains.some((n)=>{
            const i = n.split(":")[0];
            return r === i;
        }) : !0;
    }
};
Ls([
    C()
], Ni.prototype, "tabIdx", void 0), Ls([
    H()
], Ni.prototype, "connectors", void 0), Ls([
    H()
], Ni.prototype, "loading", void 0), Ni = Ls([
    F("w3m-connect-recent-widget")
], Ni);
var Us = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let ki = class extends V {
    constructor(){
        super(), this.unsubscribe = [], this.tabIdx = void 0, this.wallets = [], this.loading = !1, U.isTelegram() && U.isIos() && (this.loading = !Y.state.wcUri, this.unsubscribe.push(Y.subscribeKey("wcUri", (e)=>this.loading = !e)));
    }
    render() {
        const { connectors: e } = j.state, { customWallets: r, featuredWalletIds: n } = T.state, i = q.getRecentWallets(), o = e.find((u)=>u.id === "walletConnect"), a = e.filter((u)=>u.type === "INJECTED" || u.type === "ANNOUNCED" || u.type === "MULTI_CHAIN").filter((u)=>u.name !== "Browser Wallet");
        if (!o) return null;
        if (n || r || !this.wallets.length) return this.style.cssText = "display: none", null;
        const c = a.length + i.length, l = Math.max(0, 2 - c), d = Lr.filterOutDuplicateWallets(this.wallets).slice(0, l);
        return d.length ? w`
      <wui-flex flexDirection="column" gap="xs">
        ${d.map((u)=>w`
            <wui-list-wallet
              imageSrc=${re(Oe.getWalletImage(u))}
              name=${u?.name ?? "Unknown"}
              @click=${()=>this.onConnectWallet(u)}
              tabIdx=${re(this.tabIdx)}
              ?loading=${this.loading}
            >
            </wui-list-wallet>
          `)}
      </wui-flex>
    ` : (this.style.cssText = "display: none", null);
    }
    onConnectWallet(e) {
        if (this.loading) return;
        const r = j.getConnector(e.id, e.rdns);
        r ? D.push("ConnectingExternal", {
            connector: r
        }) : D.push("ConnectingWalletConnect", {
            wallet: e
        });
    }
};
Us([
    C()
], ki.prototype, "tabIdx", void 0), Us([
    C()
], ki.prototype, "wallets", void 0), Us([
    H()
], ki.prototype, "loading", void 0), ki = Us([
    F("w3m-connect-recommended-widget")
], ki);
var Ms = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Ti = class extends V {
    constructor(){
        super(), this.unsubscribe = [], this.tabIdx = void 0, this.connectors = j.state.connectors, this.connectorImages = Ye.state.connectorImages, this.unsubscribe.push(j.subscribeKey("connectors", (e)=>this.connectors = e), Ye.subscribeKey("connectorImages", (e)=>this.connectorImages = e));
    }
    disconnectedCallback() {
        this.unsubscribe.forEach((e)=>e());
    }
    render() {
        if (U.isMobile()) return this.style.cssText = "display: none", null;
        const e = this.connectors.find((n)=>n.id === "walletConnect");
        if (!e) return this.style.cssText = "display: none", null;
        const r = e.imageUrl || this.connectorImages[e?.imageId ?? ""];
        return w`
      <wui-list-wallet
        imageSrc=${re(r)}
        name=${e.name ?? "Unknown"}
        @click=${()=>this.onConnector(e)}
        tagLabel="qr code"
        tagVariant="main"
        tabIdx=${re(this.tabIdx)}
        data-testid="wallet-selector-walletconnect"
      >
      </wui-list-wallet>
    `;
    }
    onConnector(e) {
        j.setActiveConnector(e), D.push("ConnectingWalletConnect");
    }
};
Ms([
    C()
], Ti.prototype, "tabIdx", void 0), Ms([
    H()
], Ti.prototype, "connectors", void 0), Ms([
    H()
], Ti.prototype, "connectorImages", void 0), Ti = Ms([
    F("w3m-connect-walletconnect-widget")
], Ti);
var F2 = te`
  :host {
    margin-top: var(--wui-spacing-3xs);
  }
  wui-separator {
    margin: var(--wui-spacing-m) calc(var(--wui-spacing-m) * -1) var(--wui-spacing-xs)
      calc(var(--wui-spacing-m) * -1);
    width: calc(100% + var(--wui-spacing-s) * 2);
  }
`, Oi = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Fr = class extends V {
    constructor(){
        super(), this.unsubscribe = [], this.tabIdx = void 0, this.connectors = j.state.connectors, this.recommended = W.state.recommended, this.featured = W.state.featured, this.unsubscribe.push(j.subscribeKey("connectors", (e)=>this.connectors = e), W.subscribeKey("recommended", (e)=>this.recommended = e), W.subscribeKey("featured", (e)=>this.featured = e));
    }
    disconnectedCallback() {
        this.unsubscribe.forEach((e)=>e());
    }
    render() {
        return w`
      <wui-flex flexDirection="column" gap="xs"> ${this.connectorListTemplate()} </wui-flex>
    `;
    }
    connectorListTemplate() {
        const { custom: e, recent: r, announced: n, injected: i, multiChain: o, recommended: s, featured: a, external: c } = Kt.getConnectorsByType(this.connectors, this.recommended, this.featured);
        return Kt.getConnectorTypeOrder({
            custom: e,
            recent: r,
            announced: n,
            injected: i,
            multiChain: o,
            recommended: s,
            featured: a,
            external: c
        }).map((d)=>{
            switch(d){
                case "injected":
                    return w`
            ${o.length ? w`<w3m-connect-multi-chain-widget
                  tabIdx=${re(this.tabIdx)}
                ></w3m-connect-multi-chain-widget>` : null}
            ${n.length ? w`<w3m-connect-announced-widget
                  tabIdx=${re(this.tabIdx)}
                ></w3m-connect-announced-widget>` : null}
            ${i.length ? w`<w3m-connect-injected-widget
                  .connectors=${i}
                  tabIdx=${re(this.tabIdx)}
                ></w3m-connect-injected-widget>` : null}
          `;
                case "walletConnect":
                    return w`<w3m-connect-walletconnect-widget
            tabIdx=${re(this.tabIdx)}
          ></w3m-connect-walletconnect-widget>`;
                case "recent":
                    return w`<w3m-connect-recent-widget
            tabIdx=${re(this.tabIdx)}
          ></w3m-connect-recent-widget>`;
                case "featured":
                    return w`<w3m-connect-featured-widget
            .wallets=${a}
            tabIdx=${re(this.tabIdx)}
          ></w3m-connect-featured-widget>`;
                case "custom":
                    return w`<w3m-connect-custom-widget
            tabIdx=${re(this.tabIdx)}
          ></w3m-connect-custom-widget>`;
                case "external":
                    return w`<w3m-connect-external-widget
            tabIdx=${re(this.tabIdx)}
          ></w3m-connect-external-widget>`;
                case "recommended":
                    return w`<w3m-connect-recommended-widget
            .wallets=${s}
            tabIdx=${re(this.tabIdx)}
          ></w3m-connect-recommended-widget>`;
                default:
                    return console.warn(`Unknown connector type: ${d}`), null;
            }
        });
    }
};
Fr.styles = F2, Oi([
    C()
], Fr.prototype, "tabIdx", void 0), Oi([
    H()
], Fr.prototype, "connectors", void 0), Oi([
    H()
], Fr.prototype, "recommended", void 0), Oi([
    H()
], Fr.prototype, "featured", void 0), Fr = Oi([
    F("w3m-connector-list")
], Fr);
var H2 = te`
  :host {
    display: inline-flex;
    background-color: var(--wui-color-gray-glass-002);
    border-radius: var(--wui-border-radius-3xl);
    padding: var(--wui-spacing-3xs);
    position: relative;
    height: 36px;
    min-height: 36px;
    overflow: hidden;
  }

  :host::before {
    content: '';
    position: absolute;
    pointer-events: none;
    top: 4px;
    left: 4px;
    display: block;
    width: var(--local-tab-width);
    height: 28px;
    border-radius: var(--wui-border-radius-3xl);
    background-color: var(--wui-color-gray-glass-002);
    box-shadow: inset 0 0 0 1px var(--wui-color-gray-glass-002);
    transform: translateX(calc(var(--local-tab) * var(--local-tab-width)));
    transition: transform var(--wui-ease-out-power-1) var(--wui-duration-md);
    will-change: background-color, opacity;
  }

  :host([data-type='flex'])::before {
    left: 3px;
    transform: translateX(calc((var(--local-tab) * 34px) + (var(--local-tab) * 4px)));
  }

  :host([data-type='flex']) {
    display: flex;
    padding: 0px 0px 0px 12px;
    gap: 4px;
  }

  :host([data-type='flex']) > button > wui-text {
    position: absolute;
    left: 18px;
    opacity: 0;
  }

  button[data-active='true'] > wui-icon,
  button[data-active='true'] > wui-text {
    color: var(--wui-color-fg-100);
  }

  button[data-active='false'] > wui-icon,
  button[data-active='false'] > wui-text {
    color: var(--wui-color-fg-200);
  }

  button[data-active='true']:disabled,
  button[data-active='false']:disabled {
    background-color: transparent;
    opacity: 0.5;
    cursor: not-allowed;
  }

  button[data-active='true']:disabled > wui-text {
    color: var(--wui-color-fg-200);
  }

  button[data-active='false']:disabled > wui-text {
    color: var(--wui-color-fg-300);
  }

  button > wui-icon,
  button > wui-text {
    pointer-events: none;
    transition: color var(--wui-e ase-out-power-1) var(--wui-duration-md);
    will-change: color;
  }

  button {
    width: var(--local-tab-width);
    transition: background-color var(--wui-ease-out-power-1) var(--wui-duration-md);
    will-change: background-color;
  }

  :host([data-type='flex']) > button {
    width: 34px;
    position: relative;
    display: flex;
    justify-content: flex-start;
  }

  button:hover:enabled,
  button:active:enabled {
    background-color: transparent !important;
  }

  button:hover:enabled > wui-icon,
  button:active:enabled > wui-icon {
    transition: all var(--wui-ease-out-power-1) var(--wui-duration-lg);
    color: var(--wui-color-fg-125);
  }

  button:hover:enabled > wui-text,
  button:active:enabled > wui-text {
    transition: all var(--wui-ease-out-power-1) var(--wui-duration-lg);
    color: var(--wui-color-fg-125);
  }

  button {
    border-radius: var(--wui-border-radius-3xl);
  }
`, vr = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let $t = class extends V {
    constructor(){
        super(...arguments), this.tabs = [], this.onTabChange = ()=>null, this.buttons = [], this.disabled = !1, this.localTabWidth = "100px", this.activeTab = 0, this.isDense = !1;
    }
    render() {
        return this.isDense = this.tabs.length > 3, this.style.cssText = `
      --local-tab: ${this.activeTab};
      --local-tab-width: ${this.localTabWidth};
    `, this.dataset.type = this.isDense ? "flex" : "block", this.tabs.map((e, r)=>{
            const n = r === this.activeTab;
            return w`
        <button
          ?disabled=${this.disabled}
          @click=${()=>this.onTabClick(r)}
          data-active=${n}
          data-testid="tab-${e.label?.toLowerCase()}"
        >
          ${this.iconTemplate(e)}
          <wui-text variant="small-600" color="inherit"> ${e.label} </wui-text>
        </button>
      `;
        });
    }
    firstUpdated() {
        this.shadowRoot && this.isDense && (this.buttons = [
            ...this.shadowRoot.querySelectorAll("button")
        ], setTimeout(()=>{
            this.animateTabs(0, !0);
        }, 0));
    }
    iconTemplate(e) {
        return e.icon ? w`<wui-icon size="xs" color="inherit" name=${e.icon}></wui-icon>` : null;
    }
    onTabClick(e) {
        this.buttons && this.animateTabs(e, !1), this.activeTab = e, this.onTabChange(e);
    }
    animateTabs(e, r) {
        const n = this.buttons[this.activeTab], i = this.buttons[e], o = n?.querySelector("wui-text"), s = i?.querySelector("wui-text"), a = i?.getBoundingClientRect(), c = s?.getBoundingClientRect();
        n && o && !r && e !== this.activeTab && (o.animate([
            {
                opacity: 0
            }
        ], {
            duration: 50,
            easing: "ease",
            fill: "forwards"
        }), n.animate([
            {
                width: "34px"
            }
        ], {
            duration: 500,
            easing: "ease",
            fill: "forwards"
        })), i && a && c && s && (e !== this.activeTab || r) && (this.localTabWidth = `${Math.round(a.width + c.width) + 6}px`, i.animate([
            {
                width: `${a.width + c.width}px`
            }
        ], {
            duration: r ? 0 : 500,
            fill: "forwards",
            easing: "ease"
        }), s.animate([
            {
                opacity: 1
            }
        ], {
            duration: r ? 0 : 125,
            delay: r ? 0 : 200,
            fill: "forwards",
            easing: "ease"
        }));
    }
};
$t.styles = [
    we,
    De,
    H2
], vr([
    C({
        type: Array
    })
], $t.prototype, "tabs", void 0), vr([
    C()
], $t.prototype, "onTabChange", void 0), vr([
    C({
        type: Array
    })
], $t.prototype, "buttons", void 0), vr([
    C({
        type: Boolean
    })
], $t.prototype, "disabled", void 0), vr([
    C()
], $t.prototype, "localTabWidth", void 0), vr([
    H()
], $t.prototype, "activeTab", void 0), vr([
    H()
], $t.prototype, "isDense", void 0), $t = vr([
    F("wui-tabs")
], $t);
var Ds = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let $i = class extends V {
    constructor(){
        super(), this.platformTabs = [], this.unsubscribe = [], this.platforms = [], this.onSelectPlatfrom = void 0, this.buffering = !1, this.unsubscribe.push(Y.subscribeKey("buffering", (e)=>this.buffering = e));
    }
    disconnectCallback() {
        this.unsubscribe.forEach((e)=>e());
    }
    render() {
        const e = this.generateTabs();
        return w`
      <wui-flex justifyContent="center" .padding=${[
            "0",
            "0",
            "l",
            "0"
        ]}>
        <wui-tabs
          ?disabled=${this.buffering}
          .tabs=${e}
          .onTabChange=${this.onTabChange.bind(this)}
        ></wui-tabs>
      </wui-flex>
    `;
    }
    generateTabs() {
        const e = this.platforms.map((r)=>r === "browser" ? {
                label: "Browser",
                icon: "extension",
                platform: "browser"
            } : r === "mobile" ? {
                label: "Mobile",
                icon: "mobile",
                platform: "mobile"
            } : r === "qrcode" ? {
                label: "Mobile",
                icon: "mobile",
                platform: "qrcode"
            } : r === "web" ? {
                label: "Webapp",
                icon: "browser",
                platform: "web"
            } : r === "desktop" ? {
                label: "Desktop",
                icon: "desktop",
                platform: "desktop"
            } : {
                label: "Browser",
                icon: "extension",
                platform: "unsupported"
            });
        return this.platformTabs = e.map(({ platform: r })=>r), e;
    }
    onTabChange(e) {
        const r = this.platformTabs[e];
        r && this.onSelectPlatfrom?.(r);
    }
};
Ds([
    C({
        type: Array
    })
], $i.prototype, "platforms", void 0), Ds([
    C()
], $i.prototype, "onSelectPlatfrom", void 0), Ds([
    H()
], $i.prototype, "buffering", void 0), $i = Ds([
    F("w3m-connecting-header")
], $i);
var V2 = te`
  :host {
    display: flex;
  }

  :host([data-size='sm']) > svg {
    width: 12px;
    height: 12px;
  }

  :host([data-size='md']) > svg {
    width: 16px;
    height: 16px;
  }

  :host([data-size='lg']) > svg {
    width: 24px;
    height: 24px;
  }

  :host([data-size='xl']) > svg {
    width: 32px;
    height: 32px;
  }

  svg {
    animation: rotate 2s linear infinite;
  }

  circle {
    fill: none;
    stroke: var(--local-color);
    stroke-width: 4px;
    stroke-dasharray: 1, 124;
    stroke-dashoffset: 0;
    stroke-linecap: round;
    animation: dash 1.5s ease-in-out infinite;
  }

  :host([data-size='md']) > svg > circle {
    stroke-width: 6px;
  }

  :host([data-size='sm']) > svg > circle {
    stroke-width: 8px;
  }

  @keyframes rotate {
    100% {
      transform: rotate(360deg);
    }
  }

  @keyframes dash {
    0% {
      stroke-dasharray: 1, 124;
      stroke-dashoffset: 0;
    }

    50% {
      stroke-dasharray: 90, 124;
      stroke-dashoffset: -35;
    }

    100% {
      stroke-dashoffset: -125;
    }
  }
`, xc = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Pi = class extends V {
    constructor(){
        super(...arguments), this.color = "accent-100", this.size = "lg";
    }
    render() {
        return this.style.cssText = `--local-color: ${this.color === "inherit" ? "inherit" : `var(--wui-color-${this.color})`}`, this.dataset.size = this.size, w`<svg viewBox="25 25 50 50">
      <circle r="20" cy="50" cx="50"></circle>
    </svg>`;
    }
};
Pi.styles = [
    we,
    V2
], xc([
    C()
], Pi.prototype, "color", void 0), xc([
    C()
], Pi.prototype, "size", void 0), Pi = xc([
    F("wui-loading-spinner")
], Pi);
var Z2 = te`
  :host {
    width: var(--local-width);
    position: relative;
  }

  button {
    border: none;
    border-radius: var(--local-border-radius);
    width: var(--local-width);
    white-space: nowrap;
  }

  /* -- Sizes --------------------------------------------------- */
  button[data-size='md'] {
    padding: 8.2px var(--wui-spacing-l) 9px var(--wui-spacing-l);
    height: 36px;
  }

  button[data-size='md'][data-icon-left='true'][data-icon-right='false'] {
    padding: 8.2px var(--wui-spacing-l) 9px var(--wui-spacing-s);
  }

  button[data-size='md'][data-icon-right='true'][data-icon-left='false'] {
    padding: 8.2px var(--wui-spacing-s) 9px var(--wui-spacing-l);
  }

  button[data-size='lg'] {
    padding: var(--wui-spacing-m) var(--wui-spacing-2l);
    height: 48px;
  }

  /* -- Variants --------------------------------------------------------- */
  button[data-variant='main'] {
    background-color: var(--wui-color-accent-100);
    color: var(--wui-color-inverse-100);
    border: none;
    box-shadow: inset 0 0 0 1px var(--wui-color-gray-glass-010);
  }

  button[data-variant='inverse'] {
    background-color: var(--wui-color-inverse-100);
    color: var(--wui-color-inverse-000);
    border: none;
    box-shadow: inset 0 0 0 1px var(--wui-color-gray-glass-010);
  }

  button[data-variant='accent'] {
    background-color: var(--wui-color-accent-glass-010);
    color: var(--wui-color-accent-100);
    border: none;
    box-shadow: inset 0 0 0 1px var(--wui-color-gray-glass-005);
  }

  button[data-variant='accent-error'] {
    background: var(--wui-color-error-glass-015);
    color: var(--wui-color-error-100);
    border: none;
    box-shadow: inset 0 0 0 1px var(--wui-color-error-glass-010);
  }

  button[data-variant='accent-success'] {
    background: var(--wui-color-success-glass-015);
    color: var(--wui-color-success-100);
    border: none;
    box-shadow: inset 0 0 0 1px var(--wui-color-success-glass-010);
  }

  button[data-variant='neutral'] {
    background: transparent;
    color: var(--wui-color-fg-100);
    border: none;
    box-shadow: inset 0 0 0 1px var(--wui-color-gray-glass-005);
  }

  /* -- Focus states --------------------------------------------------- */
  button[data-variant='main']:focus-visible:enabled {
    background-color: var(--wui-color-accent-090);
    box-shadow:
      inset 0 0 0 1px var(--wui-color-accent-100),
      0 0 0 4px var(--wui-color-accent-glass-020);
  }
  button[data-variant='inverse']:focus-visible:enabled {
    background-color: var(--wui-color-inverse-100);
    box-shadow:
      inset 0 0 0 1px var(--wui-color-gray-glass-010),
      0 0 0 4px var(--wui-color-accent-glass-020);
  }
  button[data-variant='accent']:focus-visible:enabled {
    background-color: var(--wui-color-accent-glass-010);
    box-shadow:
      inset 0 0 0 1px var(--wui-color-accent-100),
      0 0 0 4px var(--wui-color-accent-glass-020);
  }
  button[data-variant='accent-error']:focus-visible:enabled {
    background: var(--wui-color-error-glass-015);
    box-shadow:
      inset 0 0 0 1px var(--wui-color-error-100),
      0 0 0 4px var(--wui-color-error-glass-020);
  }
  button[data-variant='accent-success']:focus-visible:enabled {
    background: var(--wui-color-success-glass-015);
    box-shadow:
      inset 0 0 0 1px var(--wui-color-success-100),
      0 0 0 4px var(--wui-color-success-glass-020);
  }
  button[data-variant='neutral']:focus-visible:enabled {
    background: var(--wui-color-gray-glass-005);
    box-shadow:
      inset 0 0 0 1px var(--wui-color-gray-glass-010),
      0 0 0 4px var(--wui-color-gray-glass-002);
  }

  /* -- Hover & Active states ----------------------------------------------------------- */
  @media (hover: hover) and (pointer: fine) {
    button[data-variant='main']:hover:enabled {
      background-color: var(--wui-color-accent-090);
    }

    button[data-variant='main']:active:enabled {
      background-color: var(--wui-color-accent-080);
    }

    button[data-variant='accent']:hover:enabled {
      background-color: var(--wui-color-accent-glass-015);
    }

    button[data-variant='accent']:active:enabled {
      background-color: var(--wui-color-accent-glass-020);
    }

    button[data-variant='accent-error']:hover:enabled {
      background: var(--wui-color-error-glass-020);
      color: var(--wui-color-error-100);
    }

    button[data-variant='accent-error']:active:enabled {
      background: var(--wui-color-error-glass-030);
      color: var(--wui-color-error-100);
    }

    button[data-variant='accent-success']:hover:enabled {
      background: var(--wui-color-success-glass-020);
      color: var(--wui-color-success-100);
    }

    button[data-variant='accent-success']:active:enabled {
      background: var(--wui-color-success-glass-030);
      color: var(--wui-color-success-100);
    }

    button[data-variant='neutral']:hover:enabled {
      background: var(--wui-color-gray-glass-002);
    }

    button[data-variant='neutral']:active:enabled {
      background: var(--wui-color-gray-glass-005);
    }

    button[data-size='lg'][data-icon-left='true'][data-icon-right='false'] {
      padding-left: var(--wui-spacing-m);
    }

    button[data-size='lg'][data-icon-right='true'][data-icon-left='false'] {
      padding-right: var(--wui-spacing-m);
    }
  }

  /* -- Disabled state --------------------------------------------------- */
  button:disabled {
    background-color: var(--wui-color-gray-glass-002);
    box-shadow: inset 0 0 0 1px var(--wui-color-gray-glass-002);
    color: var(--wui-color-gray-glass-020);
    cursor: not-allowed;
  }

  button > wui-text {
    transition: opacity var(--wui-ease-out-power-1) var(--wui-duration-md);
    will-change: opacity;
    opacity: var(--local-opacity-100);
  }

  ::slotted(*) {
    transition: opacity var(--wui-ease-out-power-1) var(--wui-duration-md);
    will-change: opacity;
    opacity: var(--local-opacity-100);
  }

  wui-loading-spinner {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    opacity: var(--local-opacity-000);
  }
`, Pt = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
const Mu = {
    main: "inverse-100",
    inverse: "inverse-000",
    accent: "accent-100",
    "accent-error": "error-100",
    "accent-success": "success-100",
    neutral: "fg-100",
    disabled: "gray-glass-020"
}, G2 = {
    lg: "paragraph-600",
    md: "small-600"
}, q2 = {
    lg: "md",
    md: "md"
};
let mt = class extends V {
    constructor(){
        super(...arguments), this.size = "lg", this.disabled = !1, this.fullWidth = !1, this.loading = !1, this.variant = "main", this.hasIconLeft = !1, this.hasIconRight = !1, this.borderRadius = "m";
    }
    render() {
        this.style.cssText = `
    --local-width: ${this.fullWidth ? "100%" : "auto"};
    --local-opacity-100: ${this.loading ? 0 : 1};
    --local-opacity-000: ${this.loading ? 1 : 0};
    --local-border-radius: var(--wui-border-radius-${this.borderRadius});
    `;
        const e = this.textVariant ?? G2[this.size];
        return w`
      <button
        data-variant=${this.variant}
        data-icon-left=${this.hasIconLeft}
        data-icon-right=${this.hasIconRight}
        data-size=${this.size}
        ?disabled=${this.disabled}
      >
        ${this.loadingTemplate()}
        <slot name="iconLeft" @slotchange=${()=>this.handleSlotLeftChange()}></slot>
        <wui-text variant=${e} color="inherit">
          <slot></slot>
        </wui-text>
        <slot name="iconRight" @slotchange=${()=>this.handleSlotRightChange()}></slot>
      </button>
    `;
    }
    handleSlotLeftChange() {
        this.hasIconLeft = !0;
    }
    handleSlotRightChange() {
        this.hasIconRight = !0;
    }
    loadingTemplate() {
        if (this.loading) {
            const e = q2[this.size], r = this.disabled ? Mu.disabled : Mu[this.variant];
            return w`<wui-loading-spinner color=${r} size=${e}></wui-loading-spinner>`;
        }
        return w``;
    }
};
mt.styles = [
    we,
    De,
    Z2
], Pt([
    C()
], mt.prototype, "size", void 0), Pt([
    C({
        type: Boolean
    })
], mt.prototype, "disabled", void 0), Pt([
    C({
        type: Boolean
    })
], mt.prototype, "fullWidth", void 0), Pt([
    C({
        type: Boolean
    })
], mt.prototype, "loading", void 0), Pt([
    C()
], mt.prototype, "variant", void 0), Pt([
    C({
        type: Boolean
    })
], mt.prototype, "hasIconLeft", void 0), Pt([
    C({
        type: Boolean
    })
], mt.prototype, "hasIconRight", void 0), Pt([
    C()
], mt.prototype, "borderRadius", void 0), Pt([
    C()
], mt.prototype, "textVariant", void 0), mt = Pt([
    F("wui-button")
], mt);
var K2 = te`
  button {
    padding: var(--wui-spacing-4xs) var(--wui-spacing-xxs);
    border-radius: var(--wui-border-radius-3xs);
    background-color: transparent;
    color: var(--wui-color-accent-100);
  }

  button:disabled {
    background-color: transparent;
    color: var(--wui-color-gray-glass-015);
  }

  button:hover {
    background-color: var(--wui-color-gray-glass-005);
  }
`, zs = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let kn = class extends V {
    constructor(){
        super(...arguments), this.tabIdx = void 0, this.disabled = !1, this.color = "inherit";
    }
    render() {
        return w`
      <button ?disabled=${this.disabled} tabindex=${re(this.tabIdx)}>
        <slot name="iconLeft"></slot>
        <wui-text variant="small-600" color=${this.color}>
          <slot></slot>
        </wui-text>
        <slot name="iconRight"></slot>
      </button>
    `;
    }
};
kn.styles = [
    we,
    De,
    K2
], zs([
    C()
], kn.prototype, "tabIdx", void 0), zs([
    C({
        type: Boolean
    })
], kn.prototype, "disabled", void 0), zs([
    C()
], kn.prototype, "color", void 0), kn = zs([
    F("wui-link")
], kn);
var Y2 = te`
  :host {
    display: block;
    width: var(--wui-box-size-md);
    height: var(--wui-box-size-md);
  }

  svg {
    width: var(--wui-box-size-md);
    height: var(--wui-box-size-md);
  }

  rect {
    fill: none;
    stroke: var(--wui-color-accent-100);
    stroke-width: 4px;
    stroke-linecap: round;
    animation: dash 1s linear infinite;
  }

  @keyframes dash {
    to {
      stroke-dashoffset: 0px;
    }
  }
`, Du = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Ws = class extends V {
    constructor(){
        super(...arguments), this.radius = 36;
    }
    render() {
        return this.svgLoaderTemplate();
    }
    svgLoaderTemplate() {
        const e = this.radius > 50 ? 50 : this.radius, n = 36 - e, i = 116 + n, o = 245 + n, s = 360 + n * 1.75;
        return w`
      <svg viewBox="0 0 110 110" width="110" height="110">
        <rect
          x="2"
          y="2"
          width="106"
          height="106"
          rx=${e}
          stroke-dasharray="${i} ${o}"
          stroke-dashoffset=${s}
        />
      </svg>
    `;
    }
};
Ws.styles = [
    we,
    Y2
], Du([
    C({
        type: Number
    })
], Ws.prototype, "radius", void 0), Ws = Du([
    F("wui-loading-thumbnail")
], Ws);
var X2 = te`
  button {
    border: none;
    border-radius: var(--wui-border-radius-3xl);
  }

  button[data-variant='main'] {
    background-color: var(--wui-color-accent-100);
    color: var(--wui-color-inverse-100);
    box-shadow: inset 0 0 0 1px var(--wui-color-gray-glass-010);
  }

  button[data-variant='accent'] {
    background-color: var(--wui-color-accent-glass-010);
    color: var(--wui-color-accent-100);
    box-shadow: inset 0 0 0 1px var(--wui-color-gray-glass-005);
  }

  button[data-variant='gray'] {
    background-color: transparent;
    color: var(--wui-color-fg-200);
    box-shadow: inset 0 0 0 1px var(--wui-color-gray-glass-010);
  }

  button[data-variant='shade'] {
    background-color: transparent;
    color: var(--wui-color-accent-100);
    box-shadow: inset 0 0 0 1px var(--wui-color-gray-glass-010);
  }

  button[data-size='sm'] {
    height: 32px;
    padding: 0 var(--wui-spacing-s);
  }

  button[data-size='md'] {
    height: 40px;
    padding: 0 var(--wui-spacing-l);
  }

  button[data-size='sm'] > wui-image {
    width: 16px;
    height: 16px;
  }

  button[data-size='md'] > wui-image {
    width: 24px;
    height: 24px;
  }

  button[data-size='sm'] > wui-icon {
    width: 12px;
    height: 12px;
  }

  button[data-size='md'] > wui-icon {
    width: 14px;
    height: 14px;
  }

  wui-image {
    border-radius: var(--wui-border-radius-3xl);
    overflow: hidden;
  }

  button.disabled > wui-icon,
  button.disabled > wui-image {
    filter: grayscale(1);
  }

  button[data-variant='main'] > wui-image {
    box-shadow: inset 0 0 0 1px var(--wui-color-accent-090);
  }

  button[data-variant='shade'] > wui-image,
  button[data-variant='gray'] > wui-image {
    box-shadow: inset 0 0 0 1px var(--wui-color-gray-glass-010);
  }

  @media (hover: hover) and (pointer: fine) {
    button[data-variant='main']:focus-visible {
      background-color: var(--wui-color-accent-090);
    }

    button[data-variant='main']:hover:enabled {
      background-color: var(--wui-color-accent-090);
    }

    button[data-variant='main']:active:enabled {
      background-color: var(--wui-color-accent-080);
    }

    button[data-variant='accent']:hover:enabled {
      background-color: var(--wui-color-accent-glass-015);
    }

    button[data-variant='accent']:active:enabled {
      background-color: var(--wui-color-accent-glass-020);
    }

    button[data-variant='shade']:focus-visible,
    button[data-variant='gray']:focus-visible,
    button[data-variant='shade']:hover,
    button[data-variant='gray']:hover {
      background-color: var(--wui-color-gray-glass-002);
    }

    button[data-variant='gray']:active,
    button[data-variant='shade']:active {
      background-color: var(--wui-color-gray-glass-005);
    }
  }

  button.disabled {
    color: var(--wui-color-gray-glass-020);
    background-color: var(--wui-color-gray-glass-002);
    box-shadow: inset 0 0 0 1px var(--wui-color-gray-glass-002);
    pointer-events: none;
  }
`, Hr = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Qt = class extends V {
    constructor(){
        super(...arguments), this.variant = "accent", this.imageSrc = "", this.disabled = !1, this.icon = "externalLink", this.size = "md", this.text = "";
    }
    render() {
        const e = this.size === "sm" ? "small-600" : "paragraph-600";
        return w`
      <button
        class=${this.disabled ? "disabled" : ""}
        data-variant=${this.variant}
        data-size=${this.size}
      >
        ${this.imageSrc ? w`<wui-image src=${this.imageSrc}></wui-image>` : null}
        <wui-text variant=${e} color="inherit"> ${this.text} </wui-text>
        <wui-icon name=${this.icon} color="inherit" size="inherit"></wui-icon>
      </button>
    `;
    }
};
Qt.styles = [
    we,
    De,
    X2
], Hr([
    C()
], Qt.prototype, "variant", void 0), Hr([
    C()
], Qt.prototype, "imageSrc", void 0), Hr([
    C({
        type: Boolean
    })
], Qt.prototype, "disabled", void 0), Hr([
    C()
], Qt.prototype, "icon", void 0), Hr([
    C()
], Qt.prototype, "size", void 0), Hr([
    C()
], Qt.prototype, "text", void 0), Qt = Hr([
    F("wui-chip-button")
], Qt);
var J2 = te`
  wui-flex {
    width: 100%;
    background-color: var(--wui-color-gray-glass-002);
    border-radius: var(--wui-border-radius-xs);
  }
`, js = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Tn = class extends V {
    constructor(){
        super(...arguments), this.disabled = !1, this.label = "", this.buttonLabel = "";
    }
    render() {
        return w`
      <wui-flex
        justifyContent="space-between"
        alignItems="center"
        .padding=${[
            "1xs",
            "2l",
            "1xs",
            "2l"
        ]}
      >
        <wui-text variant="paragraph-500" color="fg-200">${this.label}</wui-text>
        <wui-chip-button size="sm" variant="shade" text=${this.buttonLabel} icon="chevronRight">
        </wui-chip-button>
      </wui-flex>
    `;
    }
};
Tn.styles = [
    we,
    De,
    J2
], js([
    C({
        type: Boolean
    })
], Tn.prototype, "disabled", void 0), js([
    C()
], Tn.prototype, "label", void 0), js([
    C()
], Tn.prototype, "buttonLabel", void 0), Tn = js([
    F("wui-cta-button")
], Tn);
var Q2 = te`
  :host {
    display: block;
    padding: 0 var(--wui-spacing-xl) var(--wui-spacing-xl);
  }
`, zu = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Fs = class extends V {
    constructor(){
        super(...arguments), this.wallet = void 0;
    }
    render() {
        if (!this.wallet) return this.style.display = "none", null;
        const { name: e, app_store: r, play_store: n, chrome_store: i, homepage: o } = this.wallet, s = U.isMobile(), a = U.isIos(), c = U.isAndroid(), l = [
            r,
            n,
            o,
            i
        ].filter(Boolean).length > 1, d = Me.getTruncateString({
            string: e,
            charsStart: 12,
            charsEnd: 0,
            truncate: "end"
        });
        return l && !s ? w`
        <wui-cta-button
          label=${`Don't have ${d}?`}
          buttonLabel="Get"
          @click=${()=>D.push("Downloads", {
                wallet: this.wallet
            })}
        ></wui-cta-button>
      ` : !l && o ? w`
        <wui-cta-button
          label=${`Don't have ${d}?`}
          buttonLabel="Get"
          @click=${this.onHomePage.bind(this)}
        ></wui-cta-button>
      ` : r && a ? w`
        <wui-cta-button
          label=${`Don't have ${d}?`}
          buttonLabel="Get"
          @click=${this.onAppStore.bind(this)}
        ></wui-cta-button>
      ` : n && c ? w`
        <wui-cta-button
          label=${`Don't have ${d}?`}
          buttonLabel="Get"
          @click=${this.onPlayStore.bind(this)}
        ></wui-cta-button>
      ` : (this.style.display = "none", null);
    }
    onAppStore() {
        this.wallet?.app_store && U.openHref(this.wallet.app_store, "_blank");
    }
    onPlayStore() {
        this.wallet?.play_store && U.openHref(this.wallet.play_store, "_blank");
    }
    onHomePage() {
        this.wallet?.homepage && U.openHref(this.wallet.homepage, "_blank");
    }
};
Fs.styles = [
    Q2
], zu([
    C({
        type: Object
    })
], Fs.prototype, "wallet", void 0), Fs = zu([
    F("w3m-mobile-download-links")
], Fs);
var ew = te`
  @keyframes shake {
    0% {
      transform: translateX(0);
    }
    25% {
      transform: translateX(3px);
    }
    50% {
      transform: translateX(-3px);
    }
    75% {
      transform: translateX(3px);
    }
    100% {
      transform: translateX(0);
    }
  }

  wui-flex:first-child:not(:only-child) {
    position: relative;
  }

  wui-loading-thumbnail {
    position: absolute;
  }

  wui-icon-box {
    position: absolute;
    right: calc(var(--wui-spacing-3xs) * -1);
    bottom: calc(var(--wui-spacing-3xs) * -1);
    opacity: 0;
    transform: scale(0.5);
    transition-property: opacity, transform;
    transition-duration: var(--wui-duration-lg);
    transition-timing-function: var(--wui-ease-out-power-2);
    will-change: opacity, transform;
  }

  wui-text[align='center'] {
    width: 100%;
    padding: 0px var(--wui-spacing-l);
  }

  [data-error='true'] wui-icon-box {
    opacity: 1;
    transform: scale(1);
  }

  [data-error='true'] > wui-flex:first-child {
    animation: shake 250ms cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
  }

  [data-retry='false'] wui-link {
    display: none;
  }

  [data-retry='true'] wui-link {
    display: block;
    opacity: 1;
  }
`, St = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
class ze extends V {
    constructor(){
        super(), this.wallet = D.state.data?.wallet, this.connector = D.state.data?.connector, this.timeout = void 0, this.secondaryBtnIcon = "refresh", this.onConnect = void 0, this.onRender = void 0, this.onAutoConnect = void 0, this.isWalletConnect = !0, this.unsubscribe = [], this.imageSrc = Oe.getWalletImage(this.wallet) ?? Oe.getConnectorImage(this.connector), this.name = this.wallet?.name ?? this.connector?.name ?? "Wallet", this.isRetrying = !1, this.uri = Y.state.wcUri, this.error = Y.state.wcError, this.ready = !1, this.showRetry = !1, this.secondaryBtnLabel = "Try again", this.secondaryLabel = "Accept connection request in the wallet", this.buffering = !1, this.isLoading = !1, this.isMobile = !1, this.onRetry = void 0, this.unsubscribe.push(Y.subscribeKey("wcUri", (e)=>{
            this.uri = e, this.isRetrying && this.onRetry && (this.isRetrying = !1, this.onConnect?.());
        }), Y.subscribeKey("wcError", (e)=>this.error = e), Y.subscribeKey("buffering", (e)=>this.buffering = e)), (U.isTelegram() || U.isSafari()) && U.isIos() && Y.state.wcUri && this.onConnect?.();
    }
    firstUpdated() {
        this.onAutoConnect?.(), this.showRetry = !this.onAutoConnect;
    }
    disconnectedCallback() {
        this.unsubscribe.forEach((e)=>e()), clearTimeout(this.timeout);
    }
    render() {
        this.onRender?.(), this.onShowRetry();
        const e = this.error ? "Connection can be declined if a previous request is still active" : this.secondaryLabel;
        let r = `Continue in ${this.name}`;
        return this.buffering && (r = "Connecting..."), this.error && (r = "Connection declined"), w`
      <wui-flex
        data-error=${re(this.error)}
        data-retry=${this.showRetry}
        flexDirection="column"
        alignItems="center"
        .padding=${[
            "3xl",
            "xl",
            "xl",
            "xl"
        ]}
        gap="xl"
      >
        <wui-flex justifyContent="center" alignItems="center">
          <wui-wallet-image size="lg" imageSrc=${re(this.imageSrc)}></wui-wallet-image>

          ${this.error ? null : this.loaderTemplate()}

          <wui-icon-box
            backgroundColor="error-100"
            background="opaque"
            iconColor="error-100"
            icon="close"
            size="sm"
            border
            borderColor="wui-color-bg-125"
          ></wui-icon-box>
        </wui-flex>

        <wui-flex flexDirection="column" alignItems="center" gap="xs">
          <wui-text variant="paragraph-500" color=${this.error ? "error-100" : "fg-100"}>
            ${r}
          </wui-text>
          <wui-text align="center" variant="small-500" color="fg-200">${e}</wui-text>
        </wui-flex>

        ${this.secondaryBtnLabel ? w`
              <wui-button
                variant="accent"
                size="md"
                ?disabled=${this.isRetrying || !this.error && this.buffering || this.isLoading}
                @click=${this.onTryAgain.bind(this)}
                data-testid="w3m-connecting-widget-secondary-button"
              >
                <wui-icon color="inherit" slot="iconLeft" name=${this.secondaryBtnIcon}></wui-icon>
                ${this.secondaryBtnLabel}
              </wui-button>
            ` : null}
      </wui-flex>

      ${this.isWalletConnect ? w`
            <wui-flex .padding=${[
            "0",
            "xl",
            "xl",
            "xl"
        ]} justifyContent="center">
              <wui-link @click=${this.onCopyUri} color="fg-200" data-testid="wui-link-copy">
                <wui-icon size="xs" color="fg-200" slot="iconLeft" name="copy"></wui-icon>
                Copy link
              </wui-link>
            </wui-flex>
          ` : null}

      <w3m-mobile-download-links .wallet=${this.wallet}></w3m-mobile-download-links>
    `;
    }
    onShowRetry() {
        this.error && !this.showRetry && (this.showRetry = !0, this.shadowRoot?.querySelector("wui-button")?.animate([
            {
                opacity: 0
            },
            {
                opacity: 1
            }
        ], {
            fill: "forwards",
            easing: "ease"
        }));
    }
    onTryAgain() {
        this.buffering || (Y.setWcError(!1), this.onRetry ? (this.isRetrying = !0, this.onRetry?.()) : this.onConnect?.());
    }
    loaderTemplate() {
        const e = $e.state.themeVariables["--w3m-border-radius-master"], r = e ? parseInt(e.replace("px", ""), 10) : 4;
        return w`<wui-loading-thumbnail radius=${r * 9}></wui-loading-thumbnail>`;
    }
    onCopyUri() {
        try {
            this.uri && (U.copyToClopboard(this.uri), Ee.showSuccess("Link copied"));
        } catch  {
            Ee.showError("Failed to copy");
        }
    }
}
ze.styles = ew, St([
    H()
], ze.prototype, "isRetrying", void 0), St([
    H()
], ze.prototype, "uri", void 0), St([
    H()
], ze.prototype, "error", void 0), St([
    H()
], ze.prototype, "ready", void 0), St([
    H()
], ze.prototype, "showRetry", void 0), St([
    H()
], ze.prototype, "secondaryBtnLabel", void 0), St([
    H()
], ze.prototype, "secondaryLabel", void 0), St([
    H()
], ze.prototype, "buffering", void 0), St([
    H()
], ze.prototype, "isLoading", void 0), St([
    C({
        type: Boolean
    })
], ze.prototype, "isMobile", void 0), St([
    C()
], ze.prototype, "onRetry", void 0);
var tw = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Wu = class extends ze {
    constructor(){
        if (super(), !this.wallet) throw new Error("w3m-connecting-wc-browser: No wallet provided");
        this.onConnect = this.onConnectProxy.bind(this), this.onAutoConnect = this.onConnectProxy.bind(this), le.sendEvent({
            type: "track",
            event: "SELECT_WALLET",
            properties: {
                name: this.wallet.name,
                platform: "browser"
            }
        });
    }
    async onConnectProxy() {
        try {
            this.error = !1;
            const { connectors: e } = j.state, r = e.find((n)=>n.type === "ANNOUNCED" && n.info?.rdns === this.wallet?.rdns || n.type === "INJECTED" || n.name === this.wallet?.name);
            if (r) await Y.connectExternal(r, r.chain);
            else throw new Error("w3m-connecting-wc-browser: No connector found");
            he.close(), le.sendEvent({
                type: "track",
                event: "CONNECT_SUCCESS",
                properties: {
                    method: "browser",
                    name: this.wallet?.name || "Unknown"
                }
            });
        } catch (e) {
            le.sendEvent({
                type: "track",
                event: "CONNECT_ERROR",
                properties: {
                    message: e?.message ?? "Unknown"
                }
            }), this.error = !0;
        }
    }
};
Wu = tw([
    F("w3m-connecting-wc-browser")
], Wu);
var rw = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let ju = class extends ze {
    constructor(){
        if (super(), !this.wallet) throw new Error("w3m-connecting-wc-desktop: No wallet provided");
        this.onConnect = this.onConnectProxy.bind(this), this.onRender = this.onRenderProxy.bind(this), le.sendEvent({
            type: "track",
            event: "SELECT_WALLET",
            properties: {
                name: this.wallet.name,
                platform: "desktop"
            }
        });
    }
    onRenderProxy() {
        !this.ready && this.uri && (this.ready = !0, this.onConnect?.());
    }
    onConnectProxy() {
        if (this.wallet?.desktop_link && this.uri) try {
            this.error = !1;
            const { desktop_link: e, name: r } = this.wallet, { redirect: n, href: i } = U.formatNativeUrl(e, this.uri);
            Y.setWcLinking({
                name: r,
                href: i
            }), Y.setRecentWallet(this.wallet), U.openHref(n, "_blank");
        } catch  {
            this.error = !0;
        }
    }
};
ju = rw([
    F("w3m-connecting-wc-desktop")
], ju);
var nw = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Fu = class extends ze {
    constructor(){
        if (super(), this.btnLabelTimeout = void 0, this.labelTimeout = void 0, this.onRender = ()=>{
            !this.ready && this.uri && (this.ready = !0, this.onConnect?.());
        }, this.onConnect = ()=>{
            if (this.wallet?.mobile_link && this.uri) try {
                this.error = !1;
                const { mobile_link: e, name: r } = this.wallet, { redirect: n, href: i } = U.formatNativeUrl(e, this.uri);
                Y.setWcLinking({
                    name: r,
                    href: i
                }), Y.setRecentWallet(this.wallet);
                const o = U.isIframe() ? "_top" : "_self";
                U.openHref(n, o), clearTimeout(this.labelTimeout), this.secondaryLabel = Te.CONNECT_LABELS.MOBILE;
            } catch (e) {
                le.sendEvent({
                    type: "track",
                    event: "CONNECT_PROXY_ERROR",
                    properties: {
                        message: e instanceof Error ? e.message : "Error parsing the deeplink",
                        uri: this.uri,
                        mobile_link: this.wallet.mobile_link,
                        name: this.wallet.name
                    }
                }), this.error = !0;
            }
        }, !this.wallet) throw new Error("w3m-connecting-wc-mobile: No wallet provided");
        this.initializeStateAndTimers(), document.addEventListener("visibilitychange", this.onBuffering.bind(this)), le.sendEvent({
            type: "track",
            event: "SELECT_WALLET",
            properties: {
                name: this.wallet.name,
                platform: "mobile"
            }
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback(), document.removeEventListener("visibilitychange", this.onBuffering.bind(this)), clearTimeout(this.btnLabelTimeout), clearTimeout(this.labelTimeout);
    }
    initializeStateAndTimers() {
        this.secondaryBtnLabel = void 0, this.secondaryLabel = Te.CONNECT_LABELS.MOBILE, this.btnLabelTimeout = setTimeout(()=>{
            this.secondaryBtnLabel = "Try again", this.secondaryLabel = Te.CONNECT_LABELS.MOBILE;
        }, Te.FIVE_SEC_MS), this.labelTimeout = setTimeout(()=>{
            this.secondaryLabel = "Hold tight... it's taking longer than expected";
        }, Te.THREE_SEC_MS);
    }
    onBuffering() {
        const e = U.isIos();
        document?.visibilityState === "visible" && !this.error && e && (Y.setBuffering(!0), setTimeout(()=>{
            Y.setBuffering(!1);
        }, 5e3));
    }
    onTryAgain() {
        this.buffering || (clearTimeout(this.btnLabelTimeout), clearTimeout(this.labelTimeout), this.initializeStateAndTimers(), Y.setWcError(!1), this.onConnect());
    }
};
Fu = nw([
    F("w3m-connecting-wc-mobile")
], Fu);
var Bi = {}, iw = function() {
    return typeof Promise == "function" && Promise.prototype && Promise.prototype.then;
}, Hu = {}, dt = {};
let Ec;
const ow = [
    0,
    26,
    44,
    70,
    100,
    134,
    172,
    196,
    242,
    292,
    346,
    404,
    466,
    532,
    581,
    655,
    733,
    815,
    901,
    991,
    1085,
    1156,
    1258,
    1364,
    1474,
    1588,
    1706,
    1828,
    1921,
    2051,
    2185,
    2323,
    2465,
    2611,
    2761,
    2876,
    3034,
    3196,
    3362,
    3532,
    3706
];
dt.getSymbolSize = function(e) {
    if (!e) throw new Error('"version" cannot be null or undefined');
    if (e < 1 || e > 40) throw new Error('"version" should be in range from 1 to 40');
    return e * 4 + 17;
}, dt.getSymbolTotalCodewords = function(e) {
    return ow[e];
}, dt.getBCHDigit = function(t) {
    let e = 0;
    for(; t !== 0;)e++, t >>>= 1;
    return e;
}, dt.setToSJISFunction = function(e) {
    if (typeof e != "function") throw new Error('"toSJISFunc" is not a valid function.');
    Ec = e;
}, dt.isKanjiModeEnabled = function() {
    return typeof Ec < "u";
}, dt.toSJIS = function(e) {
    return Ec(e);
};
var Hs = {};
(function(t) {
    t.L = {
        bit: 1
    }, t.M = {
        bit: 0
    }, t.Q = {
        bit: 3
    }, t.H = {
        bit: 2
    };
    function e(r) {
        if (typeof r != "string") throw new Error("Param is not a string");
        switch(r.toLowerCase()){
            case "l":
            case "low":
                return t.L;
            case "m":
            case "medium":
                return t.M;
            case "q":
            case "quartile":
                return t.Q;
            case "h":
            case "high":
                return t.H;
            default:
                throw new Error("Unknown EC Level: " + r);
        }
    }
    t.isValid = function(n) {
        return n && typeof n.bit < "u" && n.bit >= 0 && n.bit < 4;
    }, t.from = function(n, i) {
        if (t.isValid(n)) return n;
        try {
            return e(n);
        } catch  {
            return i;
        }
    };
})(Hs);
function Vu() {
    this.buffer = [], this.length = 0;
}
Vu.prototype = {
    get: function(t) {
        const e = Math.floor(t / 8);
        return (this.buffer[e] >>> 7 - t % 8 & 1) === 1;
    },
    put: function(t, e) {
        for(let r = 0; r < e; r++)this.putBit((t >>> e - r - 1 & 1) === 1);
    },
    getLengthInBits: function() {
        return this.length;
    },
    putBit: function(t) {
        const e = Math.floor(this.length / 8);
        this.buffer.length <= e && this.buffer.push(0), t && (this.buffer[e] |= 128 >>> this.length % 8), this.length++;
    }
};
var sw = Vu;
function Ri(t) {
    if (!t || t < 1) throw new Error("BitMatrix size must be defined and greater than 0");
    this.size = t, this.data = new Uint8Array(t * t), this.reservedBit = new Uint8Array(t * t);
}
Ri.prototype.set = function(t, e, r, n) {
    const i = t * this.size + e;
    this.data[i] = r, n && (this.reservedBit[i] = !0);
}, Ri.prototype.get = function(t, e) {
    return this.data[t * this.size + e];
}, Ri.prototype.xor = function(t, e, r) {
    this.data[t * this.size + e] ^= r;
}, Ri.prototype.isReserved = function(t, e) {
    return this.reservedBit[t * this.size + e];
};
var aw = Ri, Zu = {};
(function(t) {
    const e = dt.getSymbolSize;
    t.getRowColCoords = function(n) {
        if (n === 1) return [];
        const i = Math.floor(n / 7) + 2, o = e(n), s = o === 145 ? 26 : Math.ceil((o - 13) / (2 * i - 2)) * 2, a = [
            o - 7
        ];
        for(let c = 1; c < i - 1; c++)a[c] = a[c - 1] - s;
        return a.push(6), a.reverse();
    }, t.getPositions = function(n) {
        const i = [], o = t.getRowColCoords(n), s = o.length;
        for(let a = 0; a < s; a++)for(let c = 0; c < s; c++)a === 0 && c === 0 || a === 0 && c === s - 1 || a === s - 1 && c === 0 || i.push([
            o[a],
            o[c]
        ]);
        return i;
    };
})(Zu);
var Gu = {};
const cw = dt.getSymbolSize, qu = 7;
Gu.getPositions = function(e) {
    const r = cw(e);
    return [
        [
            0,
            0
        ],
        [
            r - qu,
            0
        ],
        [
            0,
            r - qu
        ]
    ];
};
var Ku = {};
(function(t) {
    t.Patterns = {
        PATTERN000: 0,
        PATTERN001: 1,
        PATTERN010: 2,
        PATTERN011: 3,
        PATTERN100: 4,
        PATTERN101: 5,
        PATTERN110: 6,
        PATTERN111: 7
    };
    const e = {
        N1: 3,
        N2: 3,
        N3: 40,
        N4: 10
    };
    t.isValid = function(i) {
        return i != null && i !== "" && !isNaN(i) && i >= 0 && i <= 7;
    }, t.from = function(i) {
        return t.isValid(i) ? parseInt(i, 10) : void 0;
    }, t.getPenaltyN1 = function(i) {
        const o = i.size;
        let s = 0, a = 0, c = 0, l = null, d = null;
        for(let u = 0; u < o; u++){
            a = c = 0, l = d = null;
            for(let h = 0; h < o; h++){
                let p = i.get(u, h);
                p === l ? a++ : (a >= 5 && (s += e.N1 + (a - 5)), l = p, a = 1), p = i.get(h, u), p === d ? c++ : (c >= 5 && (s += e.N1 + (c - 5)), d = p, c = 1);
            }
            a >= 5 && (s += e.N1 + (a - 5)), c >= 5 && (s += e.N1 + (c - 5));
        }
        return s;
    }, t.getPenaltyN2 = function(i) {
        const o = i.size;
        let s = 0;
        for(let a = 0; a < o - 1; a++)for(let c = 0; c < o - 1; c++){
            const l = i.get(a, c) + i.get(a, c + 1) + i.get(a + 1, c) + i.get(a + 1, c + 1);
            (l === 4 || l === 0) && s++;
        }
        return s * e.N2;
    }, t.getPenaltyN3 = function(i) {
        const o = i.size;
        let s = 0, a = 0, c = 0;
        for(let l = 0; l < o; l++){
            a = c = 0;
            for(let d = 0; d < o; d++)a = a << 1 & 2047 | i.get(l, d), d >= 10 && (a === 1488 || a === 93) && s++, c = c << 1 & 2047 | i.get(d, l), d >= 10 && (c === 1488 || c === 93) && s++;
        }
        return s * e.N3;
    }, t.getPenaltyN4 = function(i) {
        let o = 0;
        const s = i.data.length;
        for(let c = 0; c < s; c++)o += i.data[c];
        return Math.abs(Math.ceil(o * 100 / s / 5) - 10) * e.N4;
    };
    function r(n, i, o) {
        switch(n){
            case t.Patterns.PATTERN000:
                return (i + o) % 2 === 0;
            case t.Patterns.PATTERN001:
                return i % 2 === 0;
            case t.Patterns.PATTERN010:
                return o % 3 === 0;
            case t.Patterns.PATTERN011:
                return (i + o) % 3 === 0;
            case t.Patterns.PATTERN100:
                return (Math.floor(i / 2) + Math.floor(o / 3)) % 2 === 0;
            case t.Patterns.PATTERN101:
                return i * o % 2 + i * o % 3 === 0;
            case t.Patterns.PATTERN110:
                return (i * o % 2 + i * o % 3) % 2 === 0;
            case t.Patterns.PATTERN111:
                return (i * o % 3 + (i + o) % 2) % 2 === 0;
            default:
                throw new Error("bad maskPattern:" + n);
        }
    }
    t.applyMask = function(i, o) {
        const s = o.size;
        for(let a = 0; a < s; a++)for(let c = 0; c < s; c++)o.isReserved(c, a) || o.xor(c, a, r(i, c, a));
    }, t.getBestMask = function(i, o) {
        const s = Object.keys(t.Patterns).length;
        let a = 0, c = 1 / 0;
        for(let l = 0; l < s; l++){
            o(l), t.applyMask(l, i);
            const d = t.getPenaltyN1(i) + t.getPenaltyN2(i) + t.getPenaltyN3(i) + t.getPenaltyN4(i);
            t.applyMask(l, i), d < c && (c = d, a = l);
        }
        return a;
    };
})(Ku);
var Vs = {};
const Cr = Hs, Zs = [
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    2,
    1,
    2,
    2,
    4,
    1,
    2,
    4,
    4,
    2,
    4,
    4,
    4,
    2,
    4,
    6,
    5,
    2,
    4,
    6,
    6,
    2,
    5,
    8,
    8,
    4,
    5,
    8,
    8,
    4,
    5,
    8,
    11,
    4,
    8,
    10,
    11,
    4,
    9,
    12,
    16,
    4,
    9,
    16,
    16,
    6,
    10,
    12,
    18,
    6,
    10,
    17,
    16,
    6,
    11,
    16,
    19,
    6,
    13,
    18,
    21,
    7,
    14,
    21,
    25,
    8,
    16,
    20,
    25,
    8,
    17,
    23,
    25,
    9,
    17,
    23,
    34,
    9,
    18,
    25,
    30,
    10,
    20,
    27,
    32,
    12,
    21,
    29,
    35,
    12,
    23,
    34,
    37,
    12,
    25,
    34,
    40,
    13,
    26,
    35,
    42,
    14,
    28,
    38,
    45,
    15,
    29,
    40,
    48,
    16,
    31,
    43,
    51,
    17,
    33,
    45,
    54,
    18,
    35,
    48,
    57,
    19,
    37,
    51,
    60,
    19,
    38,
    53,
    63,
    20,
    40,
    56,
    66,
    21,
    43,
    59,
    70,
    22,
    45,
    62,
    74,
    24,
    47,
    65,
    77,
    25,
    49,
    68,
    81
], Gs = [
    7,
    10,
    13,
    17,
    10,
    16,
    22,
    28,
    15,
    26,
    36,
    44,
    20,
    36,
    52,
    64,
    26,
    48,
    72,
    88,
    36,
    64,
    96,
    112,
    40,
    72,
    108,
    130,
    48,
    88,
    132,
    156,
    60,
    110,
    160,
    192,
    72,
    130,
    192,
    224,
    80,
    150,
    224,
    264,
    96,
    176,
    260,
    308,
    104,
    198,
    288,
    352,
    120,
    216,
    320,
    384,
    132,
    240,
    360,
    432,
    144,
    280,
    408,
    480,
    168,
    308,
    448,
    532,
    180,
    338,
    504,
    588,
    196,
    364,
    546,
    650,
    224,
    416,
    600,
    700,
    224,
    442,
    644,
    750,
    252,
    476,
    690,
    816,
    270,
    504,
    750,
    900,
    300,
    560,
    810,
    960,
    312,
    588,
    870,
    1050,
    336,
    644,
    952,
    1110,
    360,
    700,
    1020,
    1200,
    390,
    728,
    1050,
    1260,
    420,
    784,
    1140,
    1350,
    450,
    812,
    1200,
    1440,
    480,
    868,
    1290,
    1530,
    510,
    924,
    1350,
    1620,
    540,
    980,
    1440,
    1710,
    570,
    1036,
    1530,
    1800,
    570,
    1064,
    1590,
    1890,
    600,
    1120,
    1680,
    1980,
    630,
    1204,
    1770,
    2100,
    660,
    1260,
    1860,
    2220,
    720,
    1316,
    1950,
    2310,
    750,
    1372,
    2040,
    2430
];
Vs.getBlocksCount = function(e, r) {
    switch(r){
        case Cr.L:
            return Zs[(e - 1) * 4 + 0];
        case Cr.M:
            return Zs[(e - 1) * 4 + 1];
        case Cr.Q:
            return Zs[(e - 1) * 4 + 2];
        case Cr.H:
            return Zs[(e - 1) * 4 + 3];
        default:
            return;
    }
}, Vs.getTotalCodewordsCount = function(e, r) {
    switch(r){
        case Cr.L:
            return Gs[(e - 1) * 4 + 0];
        case Cr.M:
            return Gs[(e - 1) * 4 + 1];
        case Cr.Q:
            return Gs[(e - 1) * 4 + 2];
        case Cr.H:
            return Gs[(e - 1) * 4 + 3];
        default:
            return;
    }
};
var Yu = {}, qs = {};
const Li = new Uint8Array(512), Ks = new Uint8Array(256);
(function() {
    let e = 1;
    for(let r = 0; r < 255; r++)Li[r] = e, Ks[e] = r, e <<= 1, e & 256 && (e ^= 285);
    for(let r = 255; r < 512; r++)Li[r] = Li[r - 255];
})(), qs.log = function(e) {
    if (e < 1) throw new Error("log(" + e + ")");
    return Ks[e];
}, qs.exp = function(e) {
    return Li[e];
}, qs.mul = function(e, r) {
    return e === 0 || r === 0 ? 0 : Li[Ks[e] + Ks[r]];
}, function(t) {
    const e = qs;
    t.mul = function(n, i) {
        const o = new Uint8Array(n.length + i.length - 1);
        for(let s = 0; s < n.length; s++)for(let a = 0; a < i.length; a++)o[s + a] ^= e.mul(n[s], i[a]);
        return o;
    }, t.mod = function(n, i) {
        let o = new Uint8Array(n);
        for(; o.length - i.length >= 0;){
            const s = o[0];
            for(let c = 0; c < i.length; c++)o[c] ^= e.mul(i[c], s);
            let a = 0;
            for(; a < o.length && o[a] === 0;)a++;
            o = o.slice(a);
        }
        return o;
    }, t.generateECPolynomial = function(n) {
        let i = new Uint8Array([
            1
        ]);
        for(let o = 0; o < n; o++)i = t.mul(i, new Uint8Array([
            1,
            e.exp(o)
        ]));
        return i;
    };
}(Yu);
const Xu = Yu;
function Ac(t) {
    this.genPoly = void 0, this.degree = t, this.degree && this.initialize(this.degree);
}
Ac.prototype.initialize = function(e) {
    this.degree = e, this.genPoly = Xu.generateECPolynomial(this.degree);
}, Ac.prototype.encode = function(e) {
    if (!this.genPoly) throw new Error("Encoder not initialized");
    const r = new Uint8Array(e.length + this.degree);
    r.set(e);
    const n = Xu.mod(r, this.genPoly), i = this.degree - n.length;
    if (i > 0) {
        const o = new Uint8Array(this.degree);
        return o.set(n, i), o;
    }
    return n;
};
var lw = Ac, Ju = {}, yr = {}, Sc = {};
Sc.isValid = function(e) {
    return !isNaN(e) && e >= 1 && e <= 40;
};
var Bt = {};
const Qu = "[0-9]+", dw = "[A-Z $%*+\\-./:]+";
let Ui = "(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+";
Ui = Ui.replace(/u/g, "\\u");
const uw = "(?:(?![A-Z0-9 $%*+\\-./:]|" + Ui + `)(?:.|[\r
]))+`;
Bt.KANJI = new RegExp(Ui, "g"), Bt.BYTE_KANJI = new RegExp("[^A-Z0-9 $%*+\\-./:]+", "g"), Bt.BYTE = new RegExp(uw, "g"), Bt.NUMERIC = new RegExp(Qu, "g"), Bt.ALPHANUMERIC = new RegExp(dw, "g");
const hw = new RegExp("^" + Ui + "$"), pw = new RegExp("^" + Qu + "$"), fw = new RegExp("^[A-Z0-9 $%*+\\-./:]+$");
Bt.testKanji = function(e) {
    return hw.test(e);
}, Bt.testNumeric = function(e) {
    return pw.test(e);
}, Bt.testAlphanumeric = function(e) {
    return fw.test(e);
}, function(t) {
    const e = Sc, r = Bt;
    t.NUMERIC = {
        id: "Numeric",
        bit: 1,
        ccBits: [
            10,
            12,
            14
        ]
    }, t.ALPHANUMERIC = {
        id: "Alphanumeric",
        bit: 2,
        ccBits: [
            9,
            11,
            13
        ]
    }, t.BYTE = {
        id: "Byte",
        bit: 4,
        ccBits: [
            8,
            16,
            16
        ]
    }, t.KANJI = {
        id: "Kanji",
        bit: 8,
        ccBits: [
            8,
            10,
            12
        ]
    }, t.MIXED = {
        bit: -1
    }, t.getCharCountIndicator = function(o, s) {
        if (!o.ccBits) throw new Error("Invalid mode: " + o);
        if (!e.isValid(s)) throw new Error("Invalid version: " + s);
        return s >= 1 && s < 10 ? o.ccBits[0] : s < 27 ? o.ccBits[1] : o.ccBits[2];
    }, t.getBestModeForData = function(o) {
        return r.testNumeric(o) ? t.NUMERIC : r.testAlphanumeric(o) ? t.ALPHANUMERIC : r.testKanji(o) ? t.KANJI : t.BYTE;
    }, t.toString = function(o) {
        if (o && o.id) return o.id;
        throw new Error("Invalid mode");
    }, t.isValid = function(o) {
        return o && o.bit && o.ccBits;
    };
    function n(i) {
        if (typeof i != "string") throw new Error("Param is not a string");
        switch(i.toLowerCase()){
            case "numeric":
                return t.NUMERIC;
            case "alphanumeric":
                return t.ALPHANUMERIC;
            case "kanji":
                return t.KANJI;
            case "byte":
                return t.BYTE;
            default:
                throw new Error("Unknown mode: " + i);
        }
    }
    t.from = function(o, s) {
        if (t.isValid(o)) return o;
        try {
            return n(o);
        } catch  {
            return s;
        }
    };
}(yr), function(t) {
    const e = dt, r = Vs, n = Hs, i = yr, o = Sc, s = 7973, a = e.getBCHDigit(s);
    function c(h, p, v) {
        for(let m = 1; m <= 40; m++)if (p <= t.getCapacity(m, v, h)) return m;
    }
    function l(h, p) {
        return i.getCharCountIndicator(h, p) + 4;
    }
    function d(h, p) {
        let v = 0;
        return h.forEach(function(m) {
            const g = l(m.mode, p);
            v += g + m.getBitsLength();
        }), v;
    }
    function u(h, p) {
        for(let v = 1; v <= 40; v++)if (d(h, v) <= t.getCapacity(v, p, i.MIXED)) return v;
    }
    t.from = function(p, v) {
        return o.isValid(p) ? parseInt(p, 10) : v;
    }, t.getCapacity = function(p, v, m) {
        if (!o.isValid(p)) throw new Error("Invalid QR Code version");
        typeof m > "u" && (m = i.BYTE);
        const g = e.getSymbolTotalCodewords(p), b = r.getTotalCodewordsCount(p, v), y = (g - b) * 8;
        if (m === i.MIXED) return y;
        const x = y - l(m, p);
        switch(m){
            case i.NUMERIC:
                return Math.floor(x / 10 * 3);
            case i.ALPHANUMERIC:
                return Math.floor(x / 11 * 2);
            case i.KANJI:
                return Math.floor(x / 13);
            case i.BYTE:
            default:
                return Math.floor(x / 8);
        }
    }, t.getBestVersionForData = function(p, v) {
        let m;
        const g = n.from(v, n.M);
        if (Array.isArray(p)) {
            if (p.length > 1) return u(p, g);
            if (p.length === 0) return 1;
            m = p[0];
        } else m = p;
        return c(m.mode, m.getLength(), g);
    }, t.getEncodedBits = function(p) {
        if (!o.isValid(p) || p < 7) throw new Error("Invalid QR Code version");
        let v = p << 12;
        for(; e.getBCHDigit(v) - a >= 0;)v ^= s << e.getBCHDigit(v) - a;
        return p << 12 | v;
    };
}(Ju);
var e0 = {};
const _c = dt, t0 = 1335, gw = 21522, r0 = _c.getBCHDigit(t0);
e0.getEncodedBits = function(e, r) {
    const n = e.bit << 3 | r;
    let i = n << 10;
    for(; _c.getBCHDigit(i) - r0 >= 0;)i ^= t0 << _c.getBCHDigit(i) - r0;
    return (n << 10 | i) ^ gw;
};
var n0 = {};
const ww = yr;
function On(t) {
    this.mode = ww.NUMERIC, this.data = t.toString();
}
On.getBitsLength = function(e) {
    return 10 * Math.floor(e / 3) + (e % 3 ? e % 3 * 3 + 1 : 0);
}, On.prototype.getLength = function() {
    return this.data.length;
}, On.prototype.getBitsLength = function() {
    return On.getBitsLength(this.data.length);
}, On.prototype.write = function(e) {
    let r, n, i;
    for(r = 0; r + 3 <= this.data.length; r += 3)n = this.data.substr(r, 3), i = parseInt(n, 10), e.put(i, 10);
    const o = this.data.length - r;
    o > 0 && (n = this.data.substr(r), i = parseInt(n, 10), e.put(i, o * 3 + 1));
};
var mw = On;
const bw = yr, Ic = [
    "0",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "J",
    "K",
    "L",
    "M",
    "N",
    "O",
    "P",
    "Q",
    "R",
    "S",
    "T",
    "U",
    "V",
    "W",
    "X",
    "Y",
    "Z",
    " ",
    "$",
    "%",
    "*",
    "+",
    "-",
    ".",
    "/",
    ":"
];
function $n(t) {
    this.mode = bw.ALPHANUMERIC, this.data = t;
}
$n.getBitsLength = function(e) {
    return 11 * Math.floor(e / 2) + 6 * (e % 2);
}, $n.prototype.getLength = function() {
    return this.data.length;
}, $n.prototype.getBitsLength = function() {
    return $n.getBitsLength(this.data.length);
}, $n.prototype.write = function(e) {
    let r;
    for(r = 0; r + 2 <= this.data.length; r += 2){
        let n = Ic.indexOf(this.data[r]) * 45;
        n += Ic.indexOf(this.data[r + 1]), e.put(n, 11);
    }
    this.data.length % 2 && e.put(Ic.indexOf(this.data[r]), 6);
};
var vw = $n, Cw = function(e) {
    for(var r = [], n = e.length, i = 0; i < n; i++){
        var o = e.charCodeAt(i);
        if (o >= 55296 && o <= 56319 && n > i + 1) {
            var s = e.charCodeAt(i + 1);
            s >= 56320 && s <= 57343 && (o = (o - 55296) * 1024 + s - 56320 + 65536, i += 1);
        }
        if (o < 128) {
            r.push(o);
            continue;
        }
        if (o < 2048) {
            r.push(o >> 6 | 192), r.push(o & 63 | 128);
            continue;
        }
        if (o < 55296 || o >= 57344 && o < 65536) {
            r.push(o >> 12 | 224), r.push(o >> 6 & 63 | 128), r.push(o & 63 | 128);
            continue;
        }
        if (o >= 65536 && o <= 1114111) {
            r.push(o >> 18 | 240), r.push(o >> 12 & 63 | 128), r.push(o >> 6 & 63 | 128), r.push(o & 63 | 128);
            continue;
        }
        r.push(239, 191, 189);
    }
    return new Uint8Array(r).buffer;
};
const yw = Cw, xw = yr;
function Pn(t) {
    this.mode = xw.BYTE, typeof t == "string" && (t = yw(t)), this.data = new Uint8Array(t);
}
Pn.getBitsLength = function(e) {
    return e * 8;
}, Pn.prototype.getLength = function() {
    return this.data.length;
}, Pn.prototype.getBitsLength = function() {
    return Pn.getBitsLength(this.data.length);
}, Pn.prototype.write = function(t) {
    for(let e = 0, r = this.data.length; e < r; e++)t.put(this.data[e], 8);
};
var Ew = Pn;
const Aw = yr, Sw = dt;
function Bn(t) {
    this.mode = Aw.KANJI, this.data = t;
}
Bn.getBitsLength = function(e) {
    return e * 13;
}, Bn.prototype.getLength = function() {
    return this.data.length;
}, Bn.prototype.getBitsLength = function() {
    return Bn.getBitsLength(this.data.length);
}, Bn.prototype.write = function(t) {
    let e;
    for(e = 0; e < this.data.length; e++){
        let r = Sw.toSJIS(this.data[e]);
        if (r >= 33088 && r <= 40956) r -= 33088;
        else if (r >= 57408 && r <= 60351) r -= 49472;
        else throw new Error("Invalid SJIS character: " + this.data[e] + `
Make sure your charset is UTF-8`);
        r = (r >>> 8 & 255) * 192 + (r & 255), t.put(r, 13);
    }
};
var _w = Bn, i0 = {
    exports: {}
};
(function(t) {
    var e = {
        single_source_shortest_paths: function(r, n, i) {
            var o = {}, s = {};
            s[n] = 0;
            var a = e.PriorityQueue.make();
            a.push(n, 0);
            for(var c, l, d, u, h, p, v, m, g; !a.empty();){
                c = a.pop(), l = c.value, u = c.cost, h = r[l] || {};
                for(d in h)h.hasOwnProperty(d) && (p = h[d], v = u + p, m = s[d], g = typeof s[d] > "u", (g || m > v) && (s[d] = v, a.push(d, v), o[d] = l));
            }
            if (typeof i < "u" && typeof s[i] > "u") {
                var b = [
                    "Could not find a path from ",
                    n,
                    " to ",
                    i,
                    "."
                ].join("");
                throw new Error(b);
            }
            return o;
        },
        extract_shortest_path_from_predecessor_list: function(r, n) {
            for(var i = [], o = n; o;)i.push(o), r[o], o = r[o];
            return i.reverse(), i;
        },
        find_path: function(r, n, i) {
            var o = e.single_source_shortest_paths(r, n, i);
            return e.extract_shortest_path_from_predecessor_list(o, i);
        },
        PriorityQueue: {
            make: function(r) {
                var n = e.PriorityQueue, i = {}, o;
                r = r || {};
                for(o in n)n.hasOwnProperty(o) && (i[o] = n[o]);
                return i.queue = [], i.sorter = r.sorter || n.default_sorter, i;
            },
            default_sorter: function(r, n) {
                return r.cost - n.cost;
            },
            push: function(r, n) {
                var i = {
                    value: r,
                    cost: n
                };
                this.queue.push(i), this.queue.sort(this.sorter);
            },
            pop: function() {
                return this.queue.shift();
            },
            empty: function() {
                return this.queue.length === 0;
            }
        }
    };
    t.exports = e;
})(i0), function(t) {
    const e = yr, r = mw, n = vw, i = Ew, o = _w, s = Bt, a = dt, c = i0.exports;
    function l(b) {
        return unescape(encodeURIComponent(b)).length;
    }
    function d(b, y, x) {
        const E = [];
        let I;
        for(; (I = b.exec(x)) !== null;)E.push({
            data: I[0],
            index: I.index,
            mode: y,
            length: I[0].length
        });
        return E;
    }
    function u(b) {
        const y = d(s.NUMERIC, e.NUMERIC, b), x = d(s.ALPHANUMERIC, e.ALPHANUMERIC, b);
        let E, I;
        return a.isKanjiModeEnabled() ? (E = d(s.BYTE, e.BYTE, b), I = d(s.KANJI, e.KANJI, b)) : (E = d(s.BYTE_KANJI, e.BYTE, b), I = []), y.concat(x, E, I).sort(function(L, Z) {
            return L.index - Z.index;
        }).map(function(L) {
            return {
                data: L.data,
                mode: L.mode,
                length: L.length
            };
        });
    }
    function h(b, y) {
        switch(y){
            case e.NUMERIC:
                return r.getBitsLength(b);
            case e.ALPHANUMERIC:
                return n.getBitsLength(b);
            case e.KANJI:
                return o.getBitsLength(b);
            case e.BYTE:
                return i.getBitsLength(b);
        }
    }
    function p(b) {
        return b.reduce(function(y, x) {
            const E = y.length - 1 >= 0 ? y[y.length - 1] : null;
            return E && E.mode === x.mode ? (y[y.length - 1].data += x.data, y) : (y.push(x), y);
        }, []);
    }
    function v(b) {
        const y = [];
        for(let x = 0; x < b.length; x++){
            const E = b[x];
            switch(E.mode){
                case e.NUMERIC:
                    y.push([
                        E,
                        {
                            data: E.data,
                            mode: e.ALPHANUMERIC,
                            length: E.length
                        },
                        {
                            data: E.data,
                            mode: e.BYTE,
                            length: E.length
                        }
                    ]);
                    break;
                case e.ALPHANUMERIC:
                    y.push([
                        E,
                        {
                            data: E.data,
                            mode: e.BYTE,
                            length: E.length
                        }
                    ]);
                    break;
                case e.KANJI:
                    y.push([
                        E,
                        {
                            data: E.data,
                            mode: e.BYTE,
                            length: l(E.data)
                        }
                    ]);
                    break;
                case e.BYTE:
                    y.push([
                        {
                            data: E.data,
                            mode: e.BYTE,
                            length: l(E.data)
                        }
                    ]);
            }
        }
        return y;
    }
    function m(b, y) {
        const x = {}, E = {
            start: {}
        };
        let I = [
            "start"
        ];
        for(let $ = 0; $ < b.length; $++){
            const L = b[$], Z = [];
            for(let B = 0; B < L.length; B++){
                const R = L[B], N = "" + $ + B;
                Z.push(N), x[N] = {
                    node: R,
                    lastCount: 0
                }, E[N] = {};
                for(let ee = 0; ee < I.length; ee++){
                    const pe = I[ee];
                    x[pe] && x[pe].node.mode === R.mode ? (E[pe][N] = h(x[pe].lastCount + R.length, R.mode) - h(x[pe].lastCount, R.mode), x[pe].lastCount += R.length) : (x[pe] && (x[pe].lastCount = R.length), E[pe][N] = h(R.length, R.mode) + 4 + e.getCharCountIndicator(R.mode, y));
                }
            }
            I = Z;
        }
        for(let $ = 0; $ < I.length; $++)E[I[$]].end = 0;
        return {
            map: E,
            table: x
        };
    }
    function g(b, y) {
        let x;
        const E = e.getBestModeForData(b);
        if (x = e.from(y, E), x !== e.BYTE && x.bit < E.bit) throw new Error('"' + b + '" cannot be encoded with mode ' + e.toString(x) + `.
 Suggested mode is: ` + e.toString(E));
        switch(x === e.KANJI && !a.isKanjiModeEnabled() && (x = e.BYTE), x){
            case e.NUMERIC:
                return new r(b);
            case e.ALPHANUMERIC:
                return new n(b);
            case e.KANJI:
                return new o(b);
            case e.BYTE:
                return new i(b);
        }
    }
    t.fromArray = function(y) {
        return y.reduce(function(x, E) {
            return typeof E == "string" ? x.push(g(E, null)) : E.data && x.push(g(E.data, E.mode)), x;
        }, []);
    }, t.fromString = function(y, x) {
        const E = u(y, a.isKanjiModeEnabled()), I = v(E), $ = m(I, x), L = c.find_path($.map, "start", "end"), Z = [];
        for(let B = 1; B < L.length - 1; B++)Z.push($.table[L[B]].node);
        return t.fromArray(p(Z));
    }, t.rawSplit = function(y) {
        return t.fromArray(u(y, a.isKanjiModeEnabled()));
    };
}(n0);
const Ys = dt, Nc = Hs, Iw = sw, Nw = aw, kw = Zu, Tw = Gu, kc = Ku, Tc = Vs, Ow = lw, Xs = Ju, $w = e0, Pw = yr, Oc = n0;
function Bw(t, e) {
    const r = t.size, n = Tw.getPositions(e);
    for(let i = 0; i < n.length; i++){
        const o = n[i][0], s = n[i][1];
        for(let a = -1; a <= 7; a++)if (!(o + a <= -1 || r <= o + a)) for(let c = -1; c <= 7; c++)s + c <= -1 || r <= s + c || (a >= 0 && a <= 6 && (c === 0 || c === 6) || c >= 0 && c <= 6 && (a === 0 || a === 6) || a >= 2 && a <= 4 && c >= 2 && c <= 4 ? t.set(o + a, s + c, !0, !0) : t.set(o + a, s + c, !1, !0));
    }
}
function Rw(t) {
    const e = t.size;
    for(let r = 8; r < e - 8; r++){
        const n = r % 2 === 0;
        t.set(r, 6, n, !0), t.set(6, r, n, !0);
    }
}
function Lw(t, e) {
    const r = kw.getPositions(e);
    for(let n = 0; n < r.length; n++){
        const i = r[n][0], o = r[n][1];
        for(let s = -2; s <= 2; s++)for(let a = -2; a <= 2; a++)s === -2 || s === 2 || a === -2 || a === 2 || s === 0 && a === 0 ? t.set(i + s, o + a, !0, !0) : t.set(i + s, o + a, !1, !0);
    }
}
function Uw(t, e) {
    const r = t.size, n = Xs.getEncodedBits(e);
    let i, o, s;
    for(let a = 0; a < 18; a++)i = Math.floor(a / 3), o = a % 3 + r - 8 - 3, s = (n >> a & 1) === 1, t.set(i, o, s, !0), t.set(o, i, s, !0);
}
function $c(t, e, r) {
    const n = t.size, i = $w.getEncodedBits(e, r);
    let o, s;
    for(o = 0; o < 15; o++)s = (i >> o & 1) === 1, o < 6 ? t.set(o, 8, s, !0) : o < 8 ? t.set(o + 1, 8, s, !0) : t.set(n - 15 + o, 8, s, !0), o < 8 ? t.set(8, n - o - 1, s, !0) : o < 9 ? t.set(8, 15 - o - 1 + 1, s, !0) : t.set(8, 15 - o - 1, s, !0);
    t.set(n - 8, 8, 1, !0);
}
function Mw(t, e) {
    const r = t.size;
    let n = -1, i = r - 1, o = 7, s = 0;
    for(let a = r - 1; a > 0; a -= 2)for(a === 6 && a--;;){
        for(let c = 0; c < 2; c++)if (!t.isReserved(i, a - c)) {
            let l = !1;
            s < e.length && (l = (e[s] >>> o & 1) === 1), t.set(i, a - c, l), o--, o === -1 && (s++, o = 7);
        }
        if (i += n, i < 0 || r <= i) {
            i -= n, n = -n;
            break;
        }
    }
}
function Dw(t, e, r) {
    const n = new Iw;
    r.forEach(function(c) {
        n.put(c.mode.bit, 4), n.put(c.getLength(), Pw.getCharCountIndicator(c.mode, t)), c.write(n);
    });
    const i = Ys.getSymbolTotalCodewords(t), o = Tc.getTotalCodewordsCount(t, e), s = (i - o) * 8;
    for(n.getLengthInBits() + 4 <= s && n.put(0, 4); n.getLengthInBits() % 8 !== 0;)n.putBit(0);
    const a = (s - n.getLengthInBits()) / 8;
    for(let c = 0; c < a; c++)n.put(c % 2 ? 17 : 236, 8);
    return zw(n, t, e);
}
function zw(t, e, r) {
    const n = Ys.getSymbolTotalCodewords(e), i = Tc.getTotalCodewordsCount(e, r), o = n - i, s = Tc.getBlocksCount(e, r), a = n % s, c = s - a, l = Math.floor(n / s), d = Math.floor(o / s), u = d + 1, h = l - d, p = new Ow(h);
    let v = 0;
    const m = new Array(s), g = new Array(s);
    let b = 0;
    const y = new Uint8Array(t.buffer);
    for(let L = 0; L < s; L++){
        const Z = L < c ? d : u;
        m[L] = y.slice(v, v + Z), g[L] = p.encode(m[L]), v += Z, b = Math.max(b, Z);
    }
    const x = new Uint8Array(n);
    let E = 0, I, $;
    for(I = 0; I < b; I++)for($ = 0; $ < s; $++)I < m[$].length && (x[E++] = m[$][I]);
    for(I = 0; I < h; I++)for($ = 0; $ < s; $++)x[E++] = g[$][I];
    return x;
}
function Ww(t, e, r, n) {
    let i;
    if (Array.isArray(t)) i = Oc.fromArray(t);
    else if (typeof t == "string") {
        let l = e;
        if (!l) {
            const d = Oc.rawSplit(t);
            l = Xs.getBestVersionForData(d, r);
        }
        i = Oc.fromString(t, l || 40);
    } else throw new Error("Invalid data");
    const o = Xs.getBestVersionForData(i, r);
    if (!o) throw new Error("The amount of data is too big to be stored in a QR Code");
    if (!e) e = o;
    else if (e < o) throw new Error(`
The chosen QR Code version cannot contain this amount of data.
Minimum version required to store current data is: ` + o + `.
`);
    const s = Dw(e, r, i), a = Ys.getSymbolSize(e), c = new Nw(a);
    return Bw(c, e), Rw(c), Lw(c, e), $c(c, r, 0), e >= 7 && Uw(c, e), Mw(c, s), isNaN(n) && (n = kc.getBestMask(c, $c.bind(null, c, r))), kc.applyMask(n, c), $c(c, r, n), {
        modules: c,
        version: e,
        errorCorrectionLevel: r,
        maskPattern: n,
        segments: i
    };
}
Hu.create = function(e, r) {
    if (typeof e > "u" || e === "") throw new Error("No input text");
    let n = Nc.M, i, o;
    return typeof r < "u" && (n = Nc.from(r.errorCorrectionLevel, Nc.M), i = Xs.from(r.version), o = kc.from(r.maskPattern), r.toSJISFunc && Ys.setToSJISFunction(r.toSJISFunc)), Ww(e, i, n, o);
};
var o0 = {}, Pc = {};
(function(t) {
    function e(r) {
        if (typeof r == "number" && (r = r.toString()), typeof r != "string") throw new Error("Color should be defined as hex string");
        let n = r.slice().replace("#", "").split("");
        if (n.length < 3 || n.length === 5 || n.length > 8) throw new Error("Invalid hex color: " + r);
        (n.length === 3 || n.length === 4) && (n = Array.prototype.concat.apply([], n.map(function(o) {
            return [
                o,
                o
            ];
        }))), n.length === 6 && n.push("F", "F");
        const i = parseInt(n.join(""), 16);
        return {
            r: i >> 24 & 255,
            g: i >> 16 & 255,
            b: i >> 8 & 255,
            a: i & 255,
            hex: "#" + n.slice(0, 6).join("")
        };
    }
    t.getOptions = function(n) {
        n || (n = {}), n.color || (n.color = {});
        const i = typeof n.margin > "u" || n.margin === null || n.margin < 0 ? 4 : n.margin, o = n.width && n.width >= 21 ? n.width : void 0, s = n.scale || 4;
        return {
            width: o,
            scale: o ? 4 : s,
            margin: i,
            color: {
                dark: e(n.color.dark || "#000000ff"),
                light: e(n.color.light || "#ffffffff")
            },
            type: n.type,
            rendererOpts: n.rendererOpts || {}
        };
    }, t.getScale = function(n, i) {
        return i.width && i.width >= n + i.margin * 2 ? i.width / (n + i.margin * 2) : i.scale;
    }, t.getImageWidth = function(n, i) {
        const o = t.getScale(n, i);
        return Math.floor((n + i.margin * 2) * o);
    }, t.qrToImageData = function(n, i, o) {
        const s = i.modules.size, a = i.modules.data, c = t.getScale(s, o), l = Math.floor((s + o.margin * 2) * c), d = o.margin * c, u = [
            o.color.light,
            o.color.dark
        ];
        for(let h = 0; h < l; h++)for(let p = 0; p < l; p++){
            let v = (h * l + p) * 4, m = o.color.light;
            if (h >= d && p >= d && h < l - d && p < l - d) {
                const g = Math.floor((h - d) / c), b = Math.floor((p - d) / c);
                m = u[a[g * s + b] ? 1 : 0];
            }
            n[v++] = m.r, n[v++] = m.g, n[v++] = m.b, n[v] = m.a;
        }
    };
})(Pc), function(t) {
    const e = Pc;
    function r(i, o, s) {
        i.clearRect(0, 0, o.width, o.height), o.style || (o.style = {}), o.height = s, o.width = s, o.style.height = s + "px", o.style.width = s + "px";
    }
    function n() {
        try {
            return document.createElement("canvas");
        } catch  {
            throw new Error("You need to specify a canvas element");
        }
    }
    t.render = function(o, s, a) {
        let c = a, l = s;
        typeof c > "u" && (!s || !s.getContext) && (c = s, s = void 0), s || (l = n()), c = e.getOptions(c);
        const d = e.getImageWidth(o.modules.size, c), u = l.getContext("2d"), h = u.createImageData(d, d);
        return e.qrToImageData(h.data, o, c), r(u, l, d), u.putImageData(h, 0, 0), l;
    }, t.renderToDataURL = function(o, s, a) {
        let c = a;
        typeof c > "u" && (!s || !s.getContext) && (c = s, s = void 0), c || (c = {});
        const l = t.render(o, s, c), d = c.type || "image/png", u = c.rendererOpts || {};
        return l.toDataURL(d, u.quality);
    };
}(o0);
var s0 = {};
const jw = Pc;
function a0(t, e) {
    const r = t.a / 255, n = e + '="' + t.hex + '"';
    return r < 1 ? n + " " + e + '-opacity="' + r.toFixed(2).slice(1) + '"' : n;
}
function Bc(t, e, r) {
    let n = t + e;
    return typeof r < "u" && (n += " " + r), n;
}
function Fw(t, e, r) {
    let n = "", i = 0, o = !1, s = 0;
    for(let a = 0; a < t.length; a++){
        const c = Math.floor(a % e), l = Math.floor(a / e);
        !c && !o && (o = !0), t[a] ? (s++, a > 0 && c > 0 && t[a - 1] || (n += o ? Bc("M", c + r, .5 + l + r) : Bc("m", i, 0), i = 0, o = !1), c + 1 < e && t[a + 1] || (n += Bc("h", s), s = 0)) : i++;
    }
    return n;
}
s0.render = function(e, r, n) {
    const i = jw.getOptions(r), o = e.modules.size, s = e.modules.data, a = o + i.margin * 2, c = i.color.light.a ? "<path " + a0(i.color.light, "fill") + ' d="M0 0h' + a + "v" + a + 'H0z"/>' : "", l = "<path " + a0(i.color.dark, "stroke") + ' d="' + Fw(s, o, i.margin) + '"/>', d = 'viewBox="0 0 ' + a + " " + a + '"', h = '<svg xmlns="http://www.w3.org/2000/svg" ' + (i.width ? 'width="' + i.width + '" height="' + i.width + '" ' : "") + d + ' shape-rendering="crispEdges">' + c + l + `</svg>
`;
    return typeof n == "function" && n(null, h), h;
};
const Hw = iw, Rc = Hu, c0 = o0, Vw = s0;
function Lc(t, e, r, n, i) {
    const o = [].slice.call(arguments, 1), s = o.length, a = typeof o[s - 1] == "function";
    if (!a && !Hw()) throw new Error("Callback required as last argument");
    if (a) {
        if (s < 2) throw new Error("Too few arguments provided");
        s === 2 ? (i = r, r = e, e = n = void 0) : s === 3 && (e.getContext && typeof i > "u" ? (i = n, n = void 0) : (i = n, n = r, r = e, e = void 0));
    } else {
        if (s < 1) throw new Error("Too few arguments provided");
        return s === 1 ? (r = e, e = n = void 0) : s === 2 && !e.getContext && (n = r, r = e, e = void 0), new Promise(function(c, l) {
            try {
                const d = Rc.create(r, n);
                c(t(d, e, n));
            } catch (d) {
                l(d);
            }
        });
    }
    try {
        const c = Rc.create(r, n);
        i(null, t(c, e, n));
    } catch (c) {
        i(c);
    }
}
Bi.create = Rc.create, Bi.toCanvas = Lc.bind(null, c0.render), Bi.toDataURL = Lc.bind(null, c0.renderToDataURL), Bi.toString = Lc.bind(null, function(t, e, r) {
    return Vw.render(t, r);
});
const Zw = .1, l0 = 2.5, er = 7;
function Uc(t, e, r) {
    return t === e ? !1 : (t - e < 0 ? e - t : t - e) <= r + Zw;
}
function Gw(t, e) {
    const r = Array.prototype.slice.call(Bi.create(t, {
        errorCorrectionLevel: e
    }).modules.data, 0), n = Math.sqrt(r.length);
    return r.reduce((i, o, s)=>(s % n === 0 ? i.push([
            o
        ]) : i[i.length - 1].push(o)) && i, []);
}
const qw = {
    generate ({ uri: t, size: e, logoSize: r, dotColor: n = "#141414" }) {
        const i = "transparent", s = [], a = Gw(t, "Q"), c = e / a.length, l = [
            {
                x: 0,
                y: 0
            },
            {
                x: 1,
                y: 0
            },
            {
                x: 0,
                y: 1
            }
        ];
        l.forEach(({ x: m, y: g })=>{
            const b = (a.length - er) * c * m, y = (a.length - er) * c * g, x = .45;
            for(let E = 0; E < l.length; E += 1){
                const I = c * (er - E * 2);
                s.push(M`
            <rect
              fill=${E === 2 ? n : i}
              width=${E === 0 ? I - 5 : I}
              rx= ${E === 0 ? (I - 5) * x : I * x}
              ry= ${E === 0 ? (I - 5) * x : I * x}
              stroke=${n}
              stroke-width=${E === 0 ? 5 : 0}
              height=${E === 0 ? I - 5 : I}
              x= ${E === 0 ? y + c * E + 5 / 2 : y + c * E}
              y= ${E === 0 ? b + c * E + 5 / 2 : b + c * E}
            />
          `);
            }
        });
        const d = Math.floor((r + 25) / c), u = a.length / 2 - d / 2, h = a.length / 2 + d / 2 - 1, p = [];
        a.forEach((m, g)=>{
            m.forEach((b, y)=>{
                if (a[g][y] && !(g < er && y < er || g > a.length - (er + 1) && y < er || g < er && y > a.length - (er + 1)) && !(g > u && g < h && y > u && y < h)) {
                    const x = g * c + c / 2, E = y * c + c / 2;
                    p.push([
                        x,
                        E
                    ]);
                }
            });
        });
        const v = {};
        return p.forEach(([m, g])=>{
            v[m] ? v[m]?.push(g) : v[m] = [
                g
            ];
        }), Object.entries(v).map(([m, g])=>{
            const b = g.filter((y)=>g.every((x)=>!Uc(y, x, c)));
            return [
                Number(m),
                b
            ];
        }).forEach(([m, g])=>{
            g.forEach((b)=>{
                s.push(M`<circle cx=${m} cy=${b} fill=${n} r=${c / l0} />`);
            });
        }), Object.entries(v).filter(([m, g])=>g.length > 1).map(([m, g])=>{
            const b = g.filter((y)=>g.some((x)=>Uc(y, x, c)));
            return [
                Number(m),
                b
            ];
        }).map(([m, g])=>{
            g.sort((y, x)=>y < x ? -1 : 1);
            const b = [];
            for (const y of g){
                const x = b.find((E)=>E.some((I)=>Uc(y, I, c)));
                x ? x.push(y) : b.push([
                    y
                ]);
            }
            return [
                m,
                b.map((y)=>[
                        y[0],
                        y[y.length - 1]
                    ])
            ];
        }).forEach(([m, g])=>{
            g.forEach(([b, y])=>{
                s.push(M`
              <line
                x1=${m}
                x2=${m}
                y1=${b}
                y2=${y}
                stroke=${n}
                stroke-width=${c / (l0 / 2)}
                stroke-linecap="round"
              />
            `);
            });
        }), s;
    }
};
var Kw = te`
  :host {
    position: relative;
    user-select: none;
    display: block;
    overflow: hidden;
    aspect-ratio: 1 / 1;
    width: var(--local-size);
  }

  :host([data-theme='dark']) {
    border-radius: clamp(0px, var(--wui-border-radius-l), 40px);
    background-color: var(--wui-color-inverse-100);
    padding: var(--wui-spacing-l);
  }

  :host([data-theme='light']) {
    box-shadow: 0 0 0 1px var(--wui-color-bg-125);
    background-color: var(--wui-color-bg-125);
  }

  :host([data-clear='true']) > wui-icon {
    display: none;
  }

  svg:first-child,
  wui-image,
  wui-icon {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translateY(-50%) translateX(-50%);
  }

  wui-image {
    width: 25%;
    height: 25%;
    border-radius: var(--wui-border-radius-xs);
  }

  wui-icon {
    width: 100%;
    height: 100%;
    color: var(--local-icon-color) !important;
    transform: translateY(-50%) translateX(-50%) scale(0.25);
  }
`, tr = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
const Yw = "#3396ff";
let _t = class extends V {
    constructor(){
        super(...arguments), this.uri = "", this.size = 0, this.theme = "dark", this.imageSrc = void 0, this.alt = void 0, this.arenaClear = void 0, this.farcaster = void 0;
    }
    render() {
        return this.dataset.theme = this.theme, this.dataset.clear = String(this.arenaClear), this.style.cssText = `
     --local-size: ${this.size}px;
     --local-icon-color: ${this.color ?? Yw}
    `, w`${this.templateVisual()} ${this.templateSvg()}`;
    }
    templateSvg() {
        const e = this.theme === "light" ? this.size : this.size - 32;
        return M`
      <svg height=${e} width=${e}>
        ${qw.generate({
            uri: this.uri,
            size: e,
            logoSize: this.arenaClear ? 0 : e / 4,
            dotColor: this.color
        })}
      </svg>
    `;
    }
    templateVisual() {
        return this.imageSrc ? w`<wui-image src=${this.imageSrc} alt=${this.alt ?? "logo"}></wui-image>` : this.farcaster ? w`<wui-icon
        class="farcaster"
        size="inherit"
        color="inherit"
        name="farcaster"
      ></wui-icon>` : w`<wui-icon size="inherit" color="inherit" name="walletConnect"></wui-icon>`;
    }
};
_t.styles = [
    we,
    Kw
], tr([
    C()
], _t.prototype, "uri", void 0), tr([
    C({
        type: Number
    })
], _t.prototype, "size", void 0), tr([
    C()
], _t.prototype, "theme", void 0), tr([
    C()
], _t.prototype, "imageSrc", void 0), tr([
    C()
], _t.prototype, "alt", void 0), tr([
    C()
], _t.prototype, "color", void 0), tr([
    C({
        type: Boolean
    })
], _t.prototype, "arenaClear", void 0), tr([
    C({
        type: Boolean
    })
], _t.prototype, "farcaster", void 0), _t = tr([
    F("wui-qr-code")
], _t);
var Xw = te`
  :host {
    display: block;
    box-shadow: inset 0 0 0 1px var(--wui-color-gray-glass-005);
    background: linear-gradient(
      120deg,
      var(--wui-color-bg-200) 5%,
      var(--wui-color-bg-200) 48%,
      var(--wui-color-bg-300) 55%,
      var(--wui-color-bg-300) 60%,
      var(--wui-color-bg-300) calc(60% + 10px),
      var(--wui-color-bg-200) calc(60% + 12px),
      var(--wui-color-bg-200) 100%
    );
    background-size: 250%;
    animation: shimmer 3s linear infinite reverse;
  }

  :host([variant='light']) {
    background: linear-gradient(
      120deg,
      var(--wui-color-bg-150) 5%,
      var(--wui-color-bg-150) 48%,
      var(--wui-color-bg-200) 55%,
      var(--wui-color-bg-200) 60%,
      var(--wui-color-bg-200) calc(60% + 10px),
      var(--wui-color-bg-150) calc(60% + 12px),
      var(--wui-color-bg-150) 100%
    );
    background-size: 250%;
  }

  @keyframes shimmer {
    from {
      background-position: -250% 0;
    }
    to {
      background-position: 250% 0;
    }
  }
`, Mi = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Vr = class extends V {
    constructor(){
        super(...arguments), this.width = "", this.height = "", this.borderRadius = "m", this.variant = "default";
    }
    render() {
        return this.style.cssText = `
      width: ${this.width};
      height: ${this.height};
      border-radius: ${`clamp(0px,var(--wui-border-radius-${this.borderRadius}), 40px)`};
    `, w`<slot></slot>`;
    }
};
Vr.styles = [
    Xw
], Mi([
    C()
], Vr.prototype, "width", void 0), Mi([
    C()
], Vr.prototype, "height", void 0), Mi([
    C()
], Vr.prototype, "borderRadius", void 0), Mi([
    C()
], Vr.prototype, "variant", void 0), Vr = Mi([
    F("wui-shimmer")
], Vr);
var Jw = te`
  .reown-logo {
    height: var(--wui-spacing-xxl);
  }
`, Qw = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Mc = class extends V {
    render() {
        return w`
      <wui-flex
        justifyContent="center"
        alignItems="center"
        gap="xs"
        .padding=${[
            "0",
            "0",
            "l",
            "0"
        ]}
      >
        <wui-text variant="small-500" color="fg-100"> UX by </wui-text>
        <wui-icon name="reown" size="xxxl" class="reown-logo"></wui-icon>
      </wui-flex>
    `;
    }
};
Mc.styles = [
    we,
    De,
    Jw
], Mc = Qw([
    F("wui-ux-by-reown")
], Mc);
var em = te`
  @keyframes fadein {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }

  wui-shimmer {
    width: 100%;
    aspect-ratio: 1 / 1;
    border-radius: clamp(0px, var(--wui-border-radius-l), 40px) !important;
  }

  wui-qr-code {
    opacity: 0;
    animation-duration: 200ms;
    animation-timing-function: ease;
    animation-name: fadein;
    animation-fill-mode: forwards;
  }
`, tm = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Dc = class extends ze {
    constructor(){
        super(), this.forceUpdate = ()=>{
            this.requestUpdate();
        }, window.addEventListener("resize", this.forceUpdate), le.sendEvent({
            type: "track",
            event: "SELECT_WALLET",
            properties: {
                name: this.wallet?.name ?? "WalletConnect",
                platform: "qrcode"
            }
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback(), this.unsubscribe?.forEach((e)=>e()), window.removeEventListener("resize", this.forceUpdate);
    }
    render() {
        return this.onRenderProxy(), w`
      <wui-flex
        flexDirection="column"
        alignItems="center"
        .padding=${[
            "0",
            "xl",
            "xl",
            "xl"
        ]}
        gap="xl"
      >
        <wui-shimmer borderRadius="l" width="100%"> ${this.qrCodeTemplate()} </wui-shimmer>

        <wui-text variant="paragraph-500" color="fg-100">
          Scan this QR Code with your phone
        </wui-text>
        ${this.copyTemplate()}
      </wui-flex>
      <w3m-mobile-download-links .wallet=${this.wallet}></w3m-mobile-download-links>
    `;
    }
    onRenderProxy() {
        !this.ready && this.uri && (this.timeout = setTimeout(()=>{
            this.ready = !0;
        }, 200));
    }
    qrCodeTemplate() {
        if (!this.uri || !this.ready) return null;
        const e = this.getBoundingClientRect().width - 40, r = this.wallet ? this.wallet.name : void 0;
        return Y.setWcLinking(void 0), Y.setRecentWallet(this.wallet), w` <wui-qr-code
      size=${e}
      theme=${$e.state.themeMode}
      uri=${this.uri}
      imageSrc=${re(Oe.getWalletImage(this.wallet))}
      color=${re($e.state.themeVariables["--w3m-qr-color"])}
      alt=${re(r)}
      data-testid="wui-qr-code"
    ></wui-qr-code>`;
    }
    copyTemplate() {
        const e = !this.uri || !this.ready;
        return w`<wui-link
      .disabled=${e}
      @click=${this.onCopyUri}
      color="fg-200"
      data-testid="copy-wc2-uri"
    >
      <wui-icon size="xs" color="fg-200" slot="iconLeft" name="copy"></wui-icon>
      Copy link
    </wui-link>`;
    }
};
Dc.styles = em, Dc = tm([
    F("w3m-connecting-wc-qrcode")
], Dc);
var rm = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let d0 = class extends V {
    constructor(){
        if (super(), this.wallet = D.state.data?.wallet, !this.wallet) throw new Error("w3m-connecting-wc-unsupported: No wallet provided");
        le.sendEvent({
            type: "track",
            event: "SELECT_WALLET",
            properties: {
                name: this.wallet.name,
                platform: "browser"
            }
        });
    }
    render() {
        return w`
      <wui-flex
        flexDirection="column"
        alignItems="center"
        .padding=${[
            "3xl",
            "xl",
            "xl",
            "xl"
        ]}
        gap="xl"
      >
        <wui-wallet-image
          size="lg"
          imageSrc=${re(Oe.getWalletImage(this.wallet))}
        ></wui-wallet-image>

        <wui-text variant="paragraph-500" color="fg-100">Not Detected</wui-text>
      </wui-flex>

      <w3m-mobile-download-links .wallet=${this.wallet}></w3m-mobile-download-links>
    `;
    }
};
d0 = rm([
    F("w3m-connecting-wc-unsupported")
], d0);
var u0 = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let zc = class extends ze {
    constructor(){
        if (super(), this.isLoading = !0, !this.wallet) throw new Error("w3m-connecting-wc-web: No wallet provided");
        this.onConnect = this.onConnectProxy.bind(this), this.secondaryBtnLabel = "Open", this.secondaryLabel = "Open and continue in a new browser tab", this.secondaryBtnIcon = "externalLink", this.updateLoadingState(), this.unsubscribe.push(Y.subscribeKey("wcUri", ()=>{
            this.updateLoadingState();
        })), le.sendEvent({
            type: "track",
            event: "SELECT_WALLET",
            properties: {
                name: this.wallet.name,
                platform: "web"
            }
        });
    }
    updateLoadingState() {
        this.isLoading = !this.uri;
    }
    onConnectProxy() {
        if (this.wallet?.webapp_link && this.uri) try {
            this.error = !1;
            const { webapp_link: e, name: r } = this.wallet, { redirect: n, href: i } = U.formatUniversalUrl(e, this.uri);
            Y.setWcLinking({
                name: r,
                href: i
            }), Y.setRecentWallet(this.wallet), U.openHref(n, "_blank");
        } catch  {
            this.error = !0;
        }
    }
};
u0([
    H()
], zc.prototype, "isLoading", void 0), zc = u0([
    F("w3m-connecting-wc-web")
], zc);
var Js = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Di = class extends V {
    constructor(){
        super(), this.wallet = D.state.data?.wallet, this.platform = void 0, this.platforms = [], this.isSiwxEnabled = !!T.state.siwx, this.determinePlatforms(), this.initializeConnection();
    }
    render() {
        return w`
      ${this.headerTemplate()}
      <div>${this.platformTemplate()}</div>
      <wui-ux-by-reown></wui-ux-by-reown>
    `;
    }
    async initializeConnection(e = !1) {
        if (!(this.platform === "browser" || T.state.manualWCControl && !e)) try {
            const { wcPairingExpiry: r, status: n } = Y.state;
            (e || T.state.enableEmbedded || U.isPairingExpired(r) || n === "connecting") && (await Y.connectWalletConnect(), this.isSiwxEnabled || he.close());
        } catch (r) {
            le.sendEvent({
                type: "track",
                event: "CONNECT_ERROR",
                properties: {
                    message: r?.message ?? "Unknown"
                }
            }), Y.setWcError(!0), Ee.showError(r.message ?? "Connection error"), Y.resetWcConnection(), D.goBack();
        }
    }
    determinePlatforms() {
        if (!this.wallet) {
            this.platforms.push("qrcode"), this.platform = "qrcode";
            return;
        }
        if (this.platform) return;
        const { mobile_link: e, desktop_link: r, webapp_link: n, injected: i, rdns: o } = this.wallet, s = i?.map(({ injected_id: v })=>v).filter(Boolean), a = [
            ...o ? [
                o
            ] : s ?? []
        ], c = T.state.isUniversalProvider ? !1 : a.length, l = e, d = n, u = Y.checkInstalled(a), h = c && u, p = r && !U.isMobile();
        h && !f.state.noAdapters && this.platforms.push("browser"), l && this.platforms.push(U.isMobile() ? "mobile" : "qrcode"), d && this.platforms.push("web"), p && this.platforms.push("desktop"), !h && c && !f.state.noAdapters && this.platforms.push("unsupported"), this.platform = this.platforms[0];
    }
    platformTemplate() {
        switch(this.platform){
            case "browser":
                return w`<w3m-connecting-wc-browser></w3m-connecting-wc-browser>`;
            case "web":
                return w`<w3m-connecting-wc-web></w3m-connecting-wc-web>`;
            case "desktop":
                return w`
          <w3m-connecting-wc-desktop .onRetry=${()=>this.initializeConnection(!0)}>
          </w3m-connecting-wc-desktop>
        `;
            case "mobile":
                return w`
          <w3m-connecting-wc-mobile isMobile .onRetry=${()=>this.initializeConnection(!0)}>
          </w3m-connecting-wc-mobile>
        `;
            case "qrcode":
                return w`<w3m-connecting-wc-qrcode></w3m-connecting-wc-qrcode>`;
            default:
                return w`<w3m-connecting-wc-unsupported></w3m-connecting-wc-unsupported>`;
        }
    }
    headerTemplate() {
        return this.platforms.length > 1 ? w`
      <w3m-connecting-header
        .platforms=${this.platforms}
        .onSelectPlatfrom=${this.onSelectPlatform.bind(this)}
      >
      </w3m-connecting-header>
    ` : null;
    }
    async onSelectPlatform(e) {
        const r = this.shadowRoot?.querySelector("div");
        r && (await r.animate([
            {
                opacity: 1
            },
            {
                opacity: 0
            }
        ], {
            duration: 200,
            fill: "forwards",
            easing: "ease"
        }).finished, this.platform = e, r.animate([
            {
                opacity: 0
            },
            {
                opacity: 1
            }
        ], {
            duration: 200,
            fill: "forwards",
            easing: "ease"
        }));
    }
};
Js([
    H()
], Di.prototype, "platform", void 0), Js([
    H()
], Di.prototype, "platforms", void 0), Js([
    H()
], Di.prototype, "isSiwxEnabled", void 0), Di = Js([
    F("w3m-connecting-wc-view")
], Di);
var h0 = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Qs = class extends V {
    constructor(){
        super(...arguments), this.isMobile = U.isMobile();
    }
    render() {
        if (this.isMobile) {
            const { featured: e, recommended: r } = W.state, { customWallets: n } = T.state, i = q.getRecentWallets(), o = e.length || r.length || n?.length || i.length;
            return w`<wui-flex
        flexDirection="column"
        gap="xs"
        .margin=${[
                "3xs",
                "s",
                "s",
                "s"
            ]}
      >
        ${o ? w`<w3m-connector-list></w3m-connector-list>` : null}
        <w3m-all-wallets-widget></w3m-all-wallets-widget>
      </wui-flex>`;
        }
        return w`<wui-flex flexDirection="column" .padding=${[
            "0",
            "0",
            "l",
            "0"
        ]}>
      <w3m-connecting-wc-view></w3m-connecting-wc-view>
      <wui-flex flexDirection="column" .padding=${[
            "0",
            "m",
            "0",
            "m"
        ]}>
        <w3m-all-wallets-widget></w3m-all-wallets-widget> </wui-flex
    ></wui-flex>`;
    }
};
h0([
    H()
], Qs.prototype, "isMobile", void 0), Qs = h0([
    F("w3m-connecting-wc-basic-view")
], Qs); /**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ 
const Wc = ()=>new nm;
class nm {
}
const jc = new WeakMap, Fc = pc(class extends $u {
    render(t) {
        return Ne;
    }
    update(t, [e]) {
        const r = e !== this.G;
        return r && this.G !== void 0 && this.rt(void 0), (r || this.lt !== this.ct) && (this.G = e, this.ht = t.options?.host, this.rt(this.ct = t.element)), Ne;
    }
    rt(t) {
        if (this.isConnected || (t = void 0), typeof this.G == "function") {
            const e = this.ht ?? globalThis;
            let r = jc.get(e);
            r === void 0 && (r = new WeakMap, jc.set(e, r)), r.get(this.G) !== void 0 && this.G.call(this.ht, void 0), r.set(this.G, t), t !== void 0 && this.G.call(this.ht, t);
        } else this.G.value = t;
    }
    get lt() {
        return typeof this.G == "function" ? jc.get(this.ht ?? globalThis)?.get(this.G) : this.G?.value;
    }
    disconnected() {
        this.lt === this.ct && this.rt(void 0);
    }
    reconnected() {
        this.rt(this.ct);
    }
});
var im = te`
  :host {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  label {
    position: relative;
    display: inline-block;
    width: 32px;
    height: 22px;
  }

  input {
    width: 0;
    height: 0;
    opacity: 0;
  }

  span {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: var(--wui-color-blue-100);
    border-width: 1px;
    border-style: solid;
    border-color: var(--wui-color-gray-glass-002);
    border-radius: 999px;
    transition:
      background-color var(--wui-ease-inout-power-1) var(--wui-duration-md),
      border-color var(--wui-ease-inout-power-1) var(--wui-duration-md);
    will-change: background-color, border-color;
  }

  span:before {
    position: absolute;
    content: '';
    height: 16px;
    width: 16px;
    left: 3px;
    top: 2px;
    background-color: var(--wui-color-inverse-100);
    transition: transform var(--wui-ease-inout-power-1) var(--wui-duration-lg);
    will-change: transform;
    border-radius: 50%;
  }

  input:checked + span {
    border-color: var(--wui-color-gray-glass-005);
    background-color: var(--wui-color-blue-100);
  }

  input:not(:checked) + span {
    background-color: var(--wui-color-gray-glass-010);
  }

  input:checked + span:before {
    transform: translateX(calc(100% - 7px));
  }
`, p0 = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let ea = class extends V {
    constructor(){
        super(...arguments), this.inputElementRef = Wc(), this.checked = void 0;
    }
    render() {
        return w`
      <label>
        <input
          ${Fc(this.inputElementRef)}
          type="checkbox"
          ?checked=${re(this.checked)}
          @change=${this.dispatchChangeEvent.bind(this)}
        />
        <span></span>
      </label>
    `;
    }
    dispatchChangeEvent() {
        this.dispatchEvent(new CustomEvent("switchChange", {
            detail: this.inputElementRef.value?.checked,
            bubbles: !0,
            composed: !0
        }));
    }
};
ea.styles = [
    we,
    De,
    li,
    im
], p0([
    C({
        type: Boolean
    })
], ea.prototype, "checked", void 0), ea = p0([
    F("wui-switch")
], ea);
var om = te`
  :host {
    height: 100%;
  }

  button {
    display: flex;
    align-items: center;
    justify-content: center;
    column-gap: var(--wui-spacing-1xs);
    padding: var(--wui-spacing-xs) var(--wui-spacing-s);
    background-color: var(--wui-color-gray-glass-002);
    border-radius: var(--wui-border-radius-xs);
    box-shadow: inset 0 0 0 1px var(--wui-color-gray-glass-002);
    transition: background-color var(--wui-ease-out-power-1) var(--wui-duration-md);
    will-change: background-color;
    cursor: pointer;
  }

  wui-switch {
    pointer-events: none;
  }
`, f0 = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let ta = class extends V {
    constructor(){
        super(...arguments), this.checked = void 0;
    }
    render() {
        return w`
      <button>
        <wui-icon size="xl" name="walletConnectBrown"></wui-icon>
        <wui-switch ?checked=${re(this.checked)}></wui-switch>
      </button>
    `;
    }
};
ta.styles = [
    we,
    De,
    om
], f0([
    C({
        type: Boolean
    })
], ta.prototype, "checked", void 0), ta = f0([
    F("wui-certified-switch")
], ta);
var sm = te`
  button {
    background-color: var(--wui-color-fg-300);
    border-radius: var(--wui-border-radius-4xs);
    width: 16px;
    height: 16px;
  }

  button:disabled {
    background-color: var(--wui-color-bg-300);
  }

  wui-icon {
    color: var(--wui-color-bg-200) !important;
  }

  button:focus-visible {
    background-color: var(--wui-color-fg-250);
    border: 1px solid var(--wui-color-accent-100);
  }

  @media (hover: hover) and (pointer: fine) {
    button:hover:enabled {
      background-color: var(--wui-color-fg-250);
    }

    button:active:enabled {
      background-color: var(--wui-color-fg-225);
    }
  }
`, g0 = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let ra = class extends V {
    constructor(){
        super(...arguments), this.icon = "copy";
    }
    render() {
        return w`
      <button>
        <wui-icon color="inherit" size="xxs" name=${this.icon}></wui-icon>
      </button>
    `;
    }
};
ra.styles = [
    we,
    De,
    sm
], g0([
    C()
], ra.prototype, "icon", void 0), ra = g0([
    F("wui-input-element")
], ra);
var am = te`
  :host {
    position: relative;
    width: 100%;
    display: inline-block;
    color: var(--wui-color-fg-275);
  }

  input {
    width: 100%;
    border-radius: var(--wui-border-radius-xs);
    box-shadow: inset 0 0 0 1px var(--wui-color-gray-glass-002);
    background: var(--wui-color-gray-glass-002);
    font-size: var(--wui-font-size-paragraph);
    letter-spacing: var(--wui-letter-spacing-paragraph);
    color: var(--wui-color-fg-100);
    transition:
      background-color var(--wui-ease-inout-power-1) var(--wui-duration-md),
      border-color var(--wui-ease-inout-power-1) var(--wui-duration-md),
      box-shadow var(--wui-ease-inout-power-1) var(--wui-duration-md);
    will-change: background-color, border-color, box-shadow;
    caret-color: var(--wui-color-accent-100);
  }

  input:disabled {
    cursor: not-allowed;
    border: 1px solid var(--wui-color-gray-glass-010);
  }

  input:disabled::placeholder,
  input:disabled + wui-icon {
    color: var(--wui-color-fg-300);
  }

  input::placeholder {
    color: var(--wui-color-fg-275);
  }

  input:focus:enabled {
    background-color: var(--wui-color-gray-glass-005);
    -webkit-box-shadow:
      inset 0 0 0 1px var(--wui-color-accent-100),
      0px 0px 0px 4px var(--wui-box-shadow-blue);
    -moz-box-shadow:
      inset 0 0 0 1px var(--wui-color-accent-100),
      0px 0px 0px 4px var(--wui-box-shadow-blue);
    box-shadow:
      inset 0 0 0 1px var(--wui-color-accent-100),
      0px 0px 0px 4px var(--wui-box-shadow-blue);
  }

  input:hover:enabled {
    background-color: var(--wui-color-gray-glass-005);
  }

  wui-icon {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    pointer-events: none;
  }

  .wui-size-sm {
    padding: 9px var(--wui-spacing-m) 10px var(--wui-spacing-s);
  }

  wui-icon + .wui-size-sm {
    padding: 9px var(--wui-spacing-m) 10px 36px;
  }

  wui-icon[data-input='sm'] {
    left: var(--wui-spacing-s);
  }

  .wui-size-md {
    padding: 15px var(--wui-spacing-m) var(--wui-spacing-l) var(--wui-spacing-m);
  }

  wui-icon + .wui-size-md,
  wui-loading-spinner + .wui-size-md {
    padding: 10.5px var(--wui-spacing-3xl) 10.5px var(--wui-spacing-3xl);
  }

  wui-icon[data-input='md'] {
    left: var(--wui-spacing-l);
  }

  .wui-size-lg {
    padding: var(--wui-spacing-s) var(--wui-spacing-s) var(--wui-spacing-s) var(--wui-spacing-l);
    letter-spacing: var(--wui-letter-spacing-medium-title);
    font-size: var(--wui-font-size-medium-title);
    font-weight: var(--wui-font-weight-light);
    line-height: 130%;
    color: var(--wui-color-fg-100);
    height: 64px;
  }

  .wui-padding-right-xs {
    padding-right: var(--wui-spacing-xs);
  }

  .wui-padding-right-s {
    padding-right: var(--wui-spacing-s);
  }

  .wui-padding-right-m {
    padding-right: var(--wui-spacing-m);
  }

  .wui-padding-right-l {
    padding-right: var(--wui-spacing-l);
  }

  .wui-padding-right-xl {
    padding-right: var(--wui-spacing-xl);
  }

  .wui-padding-right-2xl {
    padding-right: var(--wui-spacing-2xl);
  }

  .wui-padding-right-3xl {
    padding-right: var(--wui-spacing-3xl);
  }

  .wui-padding-right-4xl {
    padding-right: var(--wui-spacing-4xl);
  }

  .wui-padding-right-5xl {
    padding-right: var(--wui-spacing-5xl);
  }

  wui-icon + .wui-size-lg,
  wui-loading-spinner + .wui-size-lg {
    padding-left: 50px;
  }

  wui-icon[data-input='lg'] {
    left: var(--wui-spacing-l);
  }

  .wui-size-mdl {
    padding: 17.25px var(--wui-spacing-m) 17.25px var(--wui-spacing-m);
  }
  wui-icon + .wui-size-mdl,
  wui-loading-spinner + .wui-size-mdl {
    padding: 17.25px var(--wui-spacing-3xl) 17.25px 40px;
  }
  wui-icon[data-input='mdl'] {
    left: var(--wui-spacing-m);
  }

  input:placeholder-shown ~ ::slotted(wui-input-element),
  input:placeholder-shown ~ ::slotted(wui-icon) {
    opacity: 0;
    pointer-events: none;
  }

  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }

  input[type='number'] {
    -moz-appearance: textfield;
  }

  ::slotted(wui-input-element),
  ::slotted(wui-icon) {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
  }

  ::slotted(wui-input-element) {
    right: var(--wui-spacing-m);
  }

  ::slotted(wui-icon) {
    right: 0px;
  }
`, Rt = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let bt = class extends V {
    constructor(){
        super(...arguments), this.inputElementRef = Wc(), this.size = "md", this.disabled = !1, this.placeholder = "", this.type = "text", this.value = "";
    }
    render() {
        const e = `wui-padding-right-${this.inputRightPadding}`, n = {
            [`wui-size-${this.size}`]: !0,
            [e]: !!this.inputRightPadding
        };
        return w`${this.templateIcon()}
      <input
        data-testid="wui-input-text"
        ${Fc(this.inputElementRef)}
        class=${Lu(n)}
        type=${this.type}
        enterkeyhint=${re(this.enterKeyHint)}
        ?disabled=${this.disabled}
        placeholder=${this.placeholder}
        @input=${this.dispatchInputChangeEvent.bind(this)}
        .value=${this.value || ""}
        tabindex=${re(this.tabIdx)}
      />
      <slot></slot>`;
    }
    templateIcon() {
        return this.icon ? w`<wui-icon
        data-input=${this.size}
        size=${this.size}
        color="inherit"
        name=${this.icon}
      ></wui-icon>` : null;
    }
    dispatchInputChangeEvent() {
        this.dispatchEvent(new CustomEvent("inputChange", {
            detail: this.inputElementRef.value?.value,
            bubbles: !0,
            composed: !0
        }));
    }
};
bt.styles = [
    we,
    De,
    am
], Rt([
    C()
], bt.prototype, "size", void 0), Rt([
    C()
], bt.prototype, "icon", void 0), Rt([
    C({
        type: Boolean
    })
], bt.prototype, "disabled", void 0), Rt([
    C()
], bt.prototype, "placeholder", void 0), Rt([
    C()
], bt.prototype, "type", void 0), Rt([
    C()
], bt.prototype, "keyHint", void 0), Rt([
    C()
], bt.prototype, "value", void 0), Rt([
    C()
], bt.prototype, "inputRightPadding", void 0), Rt([
    C()
], bt.prototype, "tabIdx", void 0), bt = Rt([
    F("wui-input-text")
], bt);
var cm = te`
  :host {
    position: relative;
    display: inline-block;
    width: 100%;
  }
`, lm = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Hc = class extends V {
    constructor(){
        super(...arguments), this.inputComponentRef = Wc();
    }
    render() {
        return w`
      <wui-input-text
        ${Fc(this.inputComponentRef)}
        placeholder="Search wallet"
        icon="search"
        type="search"
        enterKeyHint="search"
        size="sm"
      >
        <wui-input-element @click=${this.clearValue} icon="close"></wui-input-element>
      </wui-input-text>
    `;
    }
    clearValue() {
        const r = this.inputComponentRef.value?.inputElementRef.value;
        r && (r.value = "", r.focus(), r.dispatchEvent(new Event("input")));
    }
};
Hc.styles = [
    we,
    cm
], Hc = lm([
    F("wui-search-bar")
], Hc);
const dm = M`<svg  viewBox="0 0 48 54" fill="none">
  <path
    d="M43.4605 10.7248L28.0485 1.61089C25.5438 0.129705 22.4562 0.129705 19.9515 1.61088L4.53951 10.7248C2.03626 12.2051 0.5 14.9365 0.5 17.886V36.1139C0.5 39.0635 2.03626 41.7949 4.53951 43.2752L19.9515 52.3891C22.4562 53.8703 25.5438 53.8703 28.0485 52.3891L43.4605 43.2752C45.9637 41.7949 47.5 39.0635 47.5 36.114V17.8861C47.5 14.9365 45.9637 12.2051 43.4605 10.7248Z"
  />
</svg>`;
var um = te`
  :host {
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 104px;
    row-gap: var(--wui-spacing-xs);
    padding: var(--wui-spacing-xs) 10px;
    background-color: var(--wui-color-gray-glass-002);
    border-radius: clamp(0px, var(--wui-border-radius-xs), 20px);
    position: relative;
  }

  wui-shimmer[data-type='network'] {
    border: none;
    -webkit-clip-path: var(--wui-path-network);
    clip-path: var(--wui-path-network);
  }

  svg {
    position: absolute;
    width: 48px;
    height: 54px;
    z-index: 1;
  }

  svg > path {
    stroke: var(--wui-color-gray-glass-010);
    stroke-width: 1px;
  }

  @media (max-width: 350px) {
    :host {
      width: 100%;
    }
  }
`, w0 = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let na = class extends V {
    constructor(){
        super(...arguments), this.type = "wallet";
    }
    render() {
        return w`
      ${this.shimmerTemplate()}
      <wui-shimmer width="56px" height="20px" borderRadius="xs"></wui-shimmer>
    `;
    }
    shimmerTemplate() {
        return this.type === "network" ? w` <wui-shimmer
          data-type=${this.type}
          width="48px"
          height="54px"
          borderRadius="xs"
        ></wui-shimmer>
        ${dm}` : w`<wui-shimmer width="56px" height="56px" borderRadius="xs"></wui-shimmer>`;
    }
};
na.styles = [
    we,
    De,
    um
], w0([
    C()
], na.prototype, "type", void 0), na = w0([
    F("wui-card-select-loader")
], na);
var hm = te`
  :host {
    display: grid;
    width: inherit;
    height: inherit;
  }
`, vt = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let rt = class extends V {
    render() {
        return this.style.cssText = `
      grid-template-rows: ${this.gridTemplateRows};
      grid-template-columns: ${this.gridTemplateColumns};
      justify-items: ${this.justifyItems};
      align-items: ${this.alignItems};
      justify-content: ${this.justifyContent};
      align-content: ${this.alignContent};
      column-gap: ${this.columnGap && `var(--wui-spacing-${this.columnGap})`};
      row-gap: ${this.rowGap && `var(--wui-spacing-${this.rowGap})`};
      gap: ${this.gap && `var(--wui-spacing-${this.gap})`};
      padding-top: ${this.padding && Me.getSpacingStyles(this.padding, 0)};
      padding-right: ${this.padding && Me.getSpacingStyles(this.padding, 1)};
      padding-bottom: ${this.padding && Me.getSpacingStyles(this.padding, 2)};
      padding-left: ${this.padding && Me.getSpacingStyles(this.padding, 3)};
      margin-top: ${this.margin && Me.getSpacingStyles(this.margin, 0)};
      margin-right: ${this.margin && Me.getSpacingStyles(this.margin, 1)};
      margin-bottom: ${this.margin && Me.getSpacingStyles(this.margin, 2)};
      margin-left: ${this.margin && Me.getSpacingStyles(this.margin, 3)};
    `, w`<slot></slot>`;
    }
};
rt.styles = [
    we,
    hm
], vt([
    C()
], rt.prototype, "gridTemplateRows", void 0), vt([
    C()
], rt.prototype, "gridTemplateColumns", void 0), vt([
    C()
], rt.prototype, "justifyItems", void 0), vt([
    C()
], rt.prototype, "alignItems", void 0), vt([
    C()
], rt.prototype, "justifyContent", void 0), vt([
    C()
], rt.prototype, "alignContent", void 0), vt([
    C()
], rt.prototype, "columnGap", void 0), vt([
    C()
], rt.prototype, "rowGap", void 0), vt([
    C()
], rt.prototype, "gap", void 0), vt([
    C()
], rt.prototype, "padding", void 0), vt([
    C()
], rt.prototype, "margin", void 0), rt = vt([
    F("wui-grid")
], rt);
var pm = te`
  button {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    width: 104px;
    row-gap: var(--wui-spacing-xs);
    padding: var(--wui-spacing-s) var(--wui-spacing-0);
    background-color: var(--wui-color-gray-glass-002);
    border-radius: clamp(0px, var(--wui-border-radius-xs), 20px);
    transition:
      color var(--wui-duration-lg) var(--wui-ease-out-power-1),
      background-color var(--wui-duration-lg) var(--wui-ease-out-power-1),
      border-radius var(--wui-duration-lg) var(--wui-ease-out-power-1);
    will-change: background-color, color, border-radius;
    outline: none;
    border: none;
  }

  button > wui-flex > wui-text {
    color: var(--wui-color-fg-100);
    max-width: 86px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    justify-content: center;
  }

  button > wui-flex > wui-text.certified {
    max-width: 66px;
  }

  button:hover:enabled {
    background-color: var(--wui-color-gray-glass-005);
  }

  button:disabled > wui-flex > wui-text {
    color: var(--wui-color-gray-glass-015);
  }

  [data-selected='true'] {
    background-color: var(--wui-color-accent-glass-020);
  }

  @media (hover: hover) and (pointer: fine) {
    [data-selected='true']:hover:enabled {
      background-color: var(--wui-color-accent-glass-015);
    }
  }

  [data-selected='true']:active:enabled {
    background-color: var(--wui-color-accent-glass-010);
  }

  @media (max-width: 350px) {
    button {
      width: 100%;
    }
  }
`, zi = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Zr = class extends V {
    constructor(){
        super(), this.observer = new IntersectionObserver(()=>{}), this.visible = !1, this.imageSrc = void 0, this.imageLoading = !1, this.wallet = void 0, this.observer = new IntersectionObserver((e)=>{
            e.forEach((r)=>{
                r.isIntersecting ? (this.visible = !0, this.fetchImageSrc()) : this.visible = !1;
            });
        }, {
            threshold: .01
        });
    }
    firstUpdated() {
        this.observer.observe(this);
    }
    disconnectedCallback() {
        this.observer.disconnect();
    }
    render() {
        const e = this.wallet?.badge_type === "certified";
        return w`
      <button>
        ${this.imageTemplate()}
        <wui-flex flexDirection="row" alignItems="center" justifyContent="center" gap="3xs">
          <wui-text
            variant="tiny-500"
            color="inherit"
            class=${re(e ? "certified" : void 0)}
            >${this.wallet?.name}</wui-text
          >
          ${e ? w`<wui-icon size="sm" name="walletConnectBrown"></wui-icon>` : null}
        </wui-flex>
      </button>
    `;
    }
    imageTemplate() {
        return !this.visible && !this.imageSrc || this.imageLoading ? this.shimmerTemplate() : w`
      <wui-wallet-image
        size="md"
        imageSrc=${re(this.imageSrc)}
        name=${this.wallet?.name}
        .installed=${this.wallet?.installed}
        badgeSize="sm"
      >
      </wui-wallet-image>
    `;
    }
    shimmerTemplate() {
        return w`<wui-shimmer width="56px" height="56px" borderRadius="xs"></wui-shimmer>`;
    }
    async fetchImageSrc() {
        this.wallet && (this.imageSrc = Oe.getWalletImage(this.wallet), !this.imageSrc && (this.imageLoading = !0, this.imageSrc = await Oe.fetchWalletImage(this.wallet.image_id), this.imageLoading = !1));
    }
};
Zr.styles = pm, zi([
    H()
], Zr.prototype, "visible", void 0), zi([
    H()
], Zr.prototype, "imageSrc", void 0), zi([
    H()
], Zr.prototype, "imageLoading", void 0), zi([
    C()
], Zr.prototype, "wallet", void 0), Zr = zi([
    F("w3m-all-wallets-list-item")
], Zr);
var fm = te`
  wui-grid {
    max-height: clamp(360px, 400px, 80vh);
    overflow: scroll;
    scrollbar-width: none;
    grid-auto-rows: min-content;
    grid-template-columns: repeat(auto-fill, 104px);
  }

  @media (max-width: 350px) {
    wui-grid {
      grid-template-columns: repeat(2, 1fr);
    }
  }

  wui-grid[data-scroll='false'] {
    overflow: hidden;
  }

  wui-grid::-webkit-scrollbar {
    display: none;
  }

  wui-loading-spinner {
    padding-top: var(--wui-spacing-l);
    padding-bottom: var(--wui-spacing-l);
    justify-content: center;
    grid-column: 1 / span 4;
  }
`, Wi = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
const m0 = "local-paginator";
let Gr = class extends V {
    constructor(){
        super(), this.unsubscribe = [], this.paginationObserver = void 0, this.loading = !W.state.wallets.length, this.wallets = W.state.wallets, this.recommended = W.state.recommended, this.featured = W.state.featured, this.unsubscribe.push(W.subscribeKey("wallets", (e)=>this.wallets = e), W.subscribeKey("recommended", (e)=>this.recommended = e), W.subscribeKey("featured", (e)=>this.featured = e));
    }
    firstUpdated() {
        this.initialFetch(), this.createPaginationObserver();
    }
    disconnectedCallback() {
        this.unsubscribe.forEach((e)=>e()), this.paginationObserver?.disconnect();
    }
    render() {
        return w`
      <wui-grid
        data-scroll=${!this.loading}
        .padding=${[
            "0",
            "s",
            "s",
            "s"
        ]}
        columnGap="xxs"
        rowGap="l"
        justifyContent="space-between"
      >
        ${this.loading ? this.shimmerTemplate(16) : this.walletsTemplate()}
        ${this.paginationLoaderTemplate()}
      </wui-grid>
    `;
    }
    async initialFetch() {
        this.loading = !0;
        const e = this.shadowRoot?.querySelector("wui-grid");
        e && (await W.fetchWalletsByPage({
            page: 1
        }), await e.animate([
            {
                opacity: 1
            },
            {
                opacity: 0
            }
        ], {
            duration: 200,
            fill: "forwards",
            easing: "ease"
        }).finished, this.loading = !1, e.animate([
            {
                opacity: 0
            },
            {
                opacity: 1
            }
        ], {
            duration: 200,
            fill: "forwards",
            easing: "ease"
        }));
    }
    shimmerTemplate(e, r) {
        return [
            ...Array(e)
        ].map(()=>w`
        <wui-card-select-loader type="wallet" id=${re(r)}></wui-card-select-loader>
      `);
    }
    walletsTemplate() {
        const e = U.uniqueBy([
            ...this.featured,
            ...this.recommended,
            ...this.wallets
        ], "id");
        return Lr.markWalletsAsInstalled(e).map((n)=>w`
        <w3m-all-wallets-list-item
          @click=${()=>this.onConnectWallet(n)}
          .wallet=${n}
        ></w3m-all-wallets-list-item>
      `);
    }
    paginationLoaderTemplate() {
        const { wallets: e, recommended: r, featured: n, count: i } = W.state, o = window.innerWidth < 352 ? 3 : 4, s = e.length + r.length;
        let c = Math.ceil(s / o) * o - s + o;
        return c -= e.length ? n.length % o : 0, i === 0 && n.length > 0 ? null : i === 0 || [
            ...n,
            ...e,
            ...r
        ].length < i ? this.shimmerTemplate(c, m0) : null;
    }
    createPaginationObserver() {
        const e = this.shadowRoot?.querySelector(`#${m0}`);
        e && (this.paginationObserver = new IntersectionObserver(([r])=>{
            if (r?.isIntersecting && !this.loading) {
                const { page: n, count: i, wallets: o } = W.state;
                o.length < i && W.fetchWalletsByPage({
                    page: n + 1
                });
            }
        }), this.paginationObserver.observe(e));
    }
    onConnectWallet(e) {
        j.selectWalletConnector(e);
    }
};
Gr.styles = fm, Wi([
    H()
], Gr.prototype, "loading", void 0), Wi([
    H()
], Gr.prototype, "wallets", void 0), Wi([
    H()
], Gr.prototype, "recommended", void 0), Wi([
    H()
], Gr.prototype, "featured", void 0), Gr = Wi([
    F("w3m-all-wallets-list")
], Gr);
var gm = te`
  wui-grid,
  wui-loading-spinner,
  wui-flex {
    height: 360px;
  }

  wui-grid {
    overflow: scroll;
    scrollbar-width: none;
    grid-auto-rows: min-content;
    grid-template-columns: repeat(auto-fill, 104px);
  }

  wui-grid[data-scroll='false'] {
    overflow: hidden;
  }

  wui-grid::-webkit-scrollbar {
    display: none;
  }

  wui-loading-spinner {
    justify-content: center;
    align-items: center;
  }

  @media (max-width: 350px) {
    wui-grid {
      grid-template-columns: repeat(2, 1fr);
    }
  }
`, ia = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Rn = class extends V {
    constructor(){
        super(...arguments), this.prevQuery = "", this.prevBadge = void 0, this.loading = !0, this.query = "";
    }
    render() {
        return this.onSearch(), this.loading ? w`<wui-loading-spinner color="accent-100"></wui-loading-spinner>` : this.walletsTemplate();
    }
    async onSearch() {
        (this.query.trim() !== this.prevQuery.trim() || this.badge !== this.prevBadge) && (this.prevQuery = this.query, this.prevBadge = this.badge, this.loading = !0, await W.searchWallet({
            search: this.query,
            badge: this.badge
        }), this.loading = !1);
    }
    walletsTemplate() {
        const { search: e } = W.state, r = Lr.markWalletsAsInstalled(e);
        return e.length ? w`
      <wui-grid
        data-testid="wallet-list"
        .padding=${[
            "0",
            "s",
            "s",
            "s"
        ]}
        rowGap="l"
        columnGap="xs"
        justifyContent="space-between"
      >
        ${r.map((n)=>w`
            <w3m-all-wallets-list-item
              @click=${()=>this.onConnectWallet(n)}
              .wallet=${n}
              data-testid="wallet-search-item-${n.id}"
            ></w3m-all-wallets-list-item>
          `)}
      </wui-grid>
    ` : w`
        <wui-flex
          data-testid="no-wallet-found"
          justifyContent="center"
          alignItems="center"
          gap="s"
          flexDirection="column"
        >
          <wui-icon-box
            size="lg"
            iconColor="fg-200"
            backgroundColor="fg-300"
            icon="wallet"
            background="transparent"
          ></wui-icon-box>
          <wui-text data-testid="no-wallet-found-text" color="fg-200" variant="paragraph-500">
            No Wallet found
          </wui-text>
        </wui-flex>
      `;
    }
    onConnectWallet(e) {
        j.selectWalletConnector(e);
    }
};
Rn.styles = gm, ia([
    H()
], Rn.prototype, "loading", void 0), ia([
    C()
], Rn.prototype, "query", void 0), ia([
    C()
], Rn.prototype, "badge", void 0), Rn = ia([
    F("w3m-all-wallets-search")
], Rn);
var Vc = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let ji = class extends V {
    constructor(){
        super(...arguments), this.search = "", this.onDebouncedSearch = U.debounce((e)=>{
            this.search = e;
        });
    }
    render() {
        const e = this.search.length >= 2;
        return w`
      <wui-flex .padding=${[
            "0",
            "s",
            "s",
            "s"
        ]} gap="xs">
        <wui-search-bar @inputChange=${this.onInputChange.bind(this)}></wui-search-bar>
        <wui-certified-switch
          ?checked=${this.badge}
          @click=${this.onClick.bind(this)}
          data-testid="wui-certified-switch"
        ></wui-certified-switch>
        ${this.qrButtonTemplate()}
      </wui-flex>
      ${e || this.badge ? w`<w3m-all-wallets-search
            query=${this.search}
            badge=${re(this.badge)}
          ></w3m-all-wallets-search>` : w`<w3m-all-wallets-list badge=${re(this.badge)}></w3m-all-wallets-list>`}
    `;
    }
    onInputChange(e) {
        this.onDebouncedSearch(e.detail);
    }
    onClick() {
        if (this.badge === "certified") {
            this.badge = void 0;
            return;
        }
        this.badge = "certified", Ee.showSvg("Only WalletConnect certified", {
            icon: "walletConnectBrown",
            iconColor: "accent-100"
        });
    }
    qrButtonTemplate() {
        return U.isMobile() ? w`
        <wui-icon-box
          size="lg"
          iconSize="xl"
          iconColor="accent-100"
          backgroundColor="accent-100"
          icon="qrCode"
          background="transparent"
          border
          borderColor="wui-accent-glass-010"
          @click=${this.onWalletConnectQr.bind(this)}
        ></wui-icon-box>
      ` : null;
    }
    onWalletConnectQr() {
        D.push("ConnectingWalletConnect");
    }
};
Vc([
    H()
], ji.prototype, "search", void 0), Vc([
    H()
], ji.prototype, "badge", void 0), ji = Vc([
    F("w3m-all-wallets-view")
], ji);
var wm = te`
  button {
    column-gap: var(--wui-spacing-s);
    padding: 11px 18px 11px var(--wui-spacing-s);
    width: 100%;
    background-color: var(--wui-color-gray-glass-002);
    border-radius: var(--wui-border-radius-xs);
    color: var(--wui-color-fg-250);
    transition:
      color var(--wui-ease-out-power-1) var(--wui-duration-md),
      background-color var(--wui-ease-out-power-1) var(--wui-duration-md);
    will-change: color, background-color;
  }

  button[data-iconvariant='square'],
  button[data-iconvariant='square-blue'] {
    padding: 6px 18px 6px 9px;
  }

  button > wui-flex {
    flex: 1;
  }

  button > wui-image {
    width: 32px;
    height: 32px;
    box-shadow: 0 0 0 2px var(--wui-color-gray-glass-005);
    border-radius: var(--wui-border-radius-3xl);
  }

  button > wui-icon {
    width: 36px;
    height: 36px;
    transition: opacity var(--wui-ease-out-power-1) var(--wui-duration-md);
    will-change: opacity;
  }

  button > wui-icon-box[data-variant='blue'] {
    box-shadow: 0 0 0 2px var(--wui-color-accent-glass-005);
  }

  button > wui-icon-box[data-variant='overlay'] {
    box-shadow: 0 0 0 2px var(--wui-color-gray-glass-005);
  }

  button > wui-icon-box[data-variant='square-blue'] {
    border-radius: var(--wui-border-radius-3xs);
    position: relative;
    border: none;
    width: 36px;
    height: 36px;
  }

  button > wui-icon-box[data-variant='square-blue']::after {
    content: '';
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    border-radius: inherit;
    border: 1px solid var(--wui-color-accent-glass-010);
    pointer-events: none;
  }

  button > wui-icon:last-child {
    width: 14px;
    height: 14px;
  }

  button:disabled {
    color: var(--wui-color-gray-glass-020);
  }

  button[data-loading='true'] > wui-icon {
    opacity: 0;
  }

  wui-loading-spinner {
    position: absolute;
    right: 18px;
    top: 50%;
    transform: translateY(-50%);
  }
`, It = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let ut = class extends V {
    constructor(){
        super(...arguments), this.tabIdx = void 0, this.variant = "icon", this.disabled = !1, this.imageSrc = void 0, this.alt = void 0, this.chevron = !1, this.loading = !1;
    }
    render() {
        return w`
      <button
        ?disabled=${this.loading ? !0 : !!this.disabled}
        data-loading=${this.loading}
        data-iconvariant=${re(this.iconVariant)}
        tabindex=${re(this.tabIdx)}
      >
        ${this.loadingTemplate()} ${this.visualTemplate()}
        <wui-flex gap="3xs">
          <slot></slot>
        </wui-flex>
        ${this.chevronTemplate()}
      </button>
    `;
    }
    visualTemplate() {
        if (this.variant === "image" && this.imageSrc) return w`<wui-image src=${this.imageSrc} alt=${this.alt ?? "list item"}></wui-image>`;
        if (this.iconVariant === "square" && this.icon && this.variant === "icon") return w`<wui-icon name=${this.icon}></wui-icon>`;
        if (this.variant === "icon" && this.icon && this.iconVariant) {
            const e = [
                "blue",
                "square-blue"
            ].includes(this.iconVariant) ? "accent-100" : "fg-200", r = this.iconVariant === "square-blue" ? "mdl" : "md", n = this.iconSize ? this.iconSize : r;
            return w`
        <wui-icon-box
          data-variant=${this.iconVariant}
          icon=${this.icon}
          iconSize=${n}
          background="transparent"
          iconColor=${e}
          backgroundColor=${e}
          size=${r}
        ></wui-icon-box>
      `;
        }
        return null;
    }
    loadingTemplate() {
        return this.loading ? w`<wui-loading-spinner
        data-testid="wui-list-item-loading-spinner"
        color="fg-300"
      ></wui-loading-spinner>` : w``;
    }
    chevronTemplate() {
        return this.chevron ? w`<wui-icon size="inherit" color="fg-200" name="chevronRight"></wui-icon>` : null;
    }
};
ut.styles = [
    we,
    De,
    wm
], It([
    C()
], ut.prototype, "icon", void 0), It([
    C()
], ut.prototype, "iconSize", void 0), It([
    C()
], ut.prototype, "tabIdx", void 0), It([
    C()
], ut.prototype, "variant", void 0), It([
    C()
], ut.prototype, "iconVariant", void 0), It([
    C({
        type: Boolean
    })
], ut.prototype, "disabled", void 0), It([
    C()
], ut.prototype, "imageSrc", void 0), It([
    C()
], ut.prototype, "alt", void 0), It([
    C({
        type: Boolean
    })
], ut.prototype, "chevron", void 0), It([
    C({
        type: Boolean
    })
], ut.prototype, "loading", void 0), ut = It([
    F("wui-list-item")
], ut);
var mm = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Zc = class extends V {
    constructor(){
        super(...arguments), this.wallet = D.state.data?.wallet;
    }
    render() {
        if (!this.wallet) throw new Error("w3m-downloads-view");
        return w`
      <wui-flex gap="xs" flexDirection="column" .padding=${[
            "s",
            "s",
            "l",
            "s"
        ]}>
        ${this.chromeTemplate()} ${this.iosTemplate()} ${this.androidTemplate()}
        ${this.homepageTemplate()}
      </wui-flex>
    `;
    }
    chromeTemplate() {
        return this.wallet?.chrome_store ? w`<wui-list-item
      variant="icon"
      icon="chromeStore"
      iconVariant="square"
      @click=${this.onChromeStore.bind(this)}
      chevron
    >
      <wui-text variant="paragraph-500" color="fg-100">Chrome Extension</wui-text>
    </wui-list-item>` : null;
    }
    iosTemplate() {
        return this.wallet?.app_store ? w`<wui-list-item
      variant="icon"
      icon="appStore"
      iconVariant="square"
      @click=${this.onAppStore.bind(this)}
      chevron
    >
      <wui-text variant="paragraph-500" color="fg-100">iOS App</wui-text>
    </wui-list-item>` : null;
    }
    androidTemplate() {
        return this.wallet?.play_store ? w`<wui-list-item
      variant="icon"
      icon="playStore"
      iconVariant="square"
      @click=${this.onPlayStore.bind(this)}
      chevron
    >
      <wui-text variant="paragraph-500" color="fg-100">Android App</wui-text>
    </wui-list-item>` : null;
    }
    homepageTemplate() {
        return this.wallet?.homepage ? w`
      <wui-list-item
        variant="icon"
        icon="browser"
        iconVariant="square-blue"
        @click=${this.onHomePage.bind(this)}
        chevron
      >
        <wui-text variant="paragraph-500" color="fg-100">Website</wui-text>
      </wui-list-item>
    ` : null;
    }
    onChromeStore() {
        this.wallet?.chrome_store && U.openHref(this.wallet.chrome_store, "_blank");
    }
    onAppStore() {
        this.wallet?.app_store && U.openHref(this.wallet.app_store, "_blank");
    }
    onPlayStore() {
        this.wallet?.play_store && U.openHref(this.wallet.play_store, "_blank");
    }
    onHomePage() {
        this.wallet?.homepage && U.openHref(this.wallet.homepage, "_blank");
    }
};
Zc = mm([
    F("w3m-downloads-view")
], Zc);
var bm = Object.freeze({
    __proto__: null,
    get W3mConnectingWcBasicView () {
        return Qs;
    },
    get W3mAllWalletsView () {
        return ji;
    },
    get W3mDownloadsView () {
        return Zc;
    }
}), vm = te`
  :host {
    display: block;
    border-radius: clamp(0px, var(--wui-border-radius-l), 44px);
    box-shadow: 0 0 0 1px var(--wui-color-gray-glass-005);
    background-color: var(--wui-color-modal-bg);
    overflow: hidden;
  }

  :host([data-embedded='true']) {
    box-shadow:
      0 0 0 1px var(--wui-color-gray-glass-005),
      0px 4px 12px 4px var(--w3m-card-embedded-shadow-color);
  }
`, Cm = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Gc = class extends V {
    render() {
        return w`<slot></slot>`;
    }
};
Gc.styles = [
    we,
    vm
], Gc = Cm([
    F("wui-card")
], Gc);
var ym = te`
  :host {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: var(--wui-spacing-s);
    border-radius: var(--wui-border-radius-s);
    border: 1px solid var(--wui-color-dark-glass-100);
    box-sizing: border-box;
    background-color: var(--wui-color-bg-325);
    box-shadow: 0px 0px 16px 0px rgba(0, 0, 0, 0.25);
  }

  wui-flex {
    width: 100%;
  }

  wui-text {
    word-break: break-word;
    flex: 1;
  }

  .close {
    cursor: pointer;
  }

  .icon-box {
    height: 40px;
    width: 40px;
    border-radius: var(--wui-border-radius-3xs);
    background-color: var(--local-icon-bg-value);
  }
`, Fi = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let qr = class extends V {
    constructor(){
        super(...arguments), this.message = "", this.backgroundColor = "accent-100", this.iconColor = "accent-100", this.icon = "info";
    }
    render() {
        return this.style.cssText = `
      --local-icon-bg-value: var(--wui-color-${this.backgroundColor});
   `, w`
      <wui-flex flexDirection="row" justifyContent="space-between" alignItems="center">
        <wui-flex columnGap="xs" flexDirection="row" alignItems="center">
          <wui-flex
            flexDirection="row"
            alignItems="center"
            justifyContent="center"
            class="icon-box"
          >
            <wui-icon color=${this.iconColor} size="md" name=${this.icon}></wui-icon>
          </wui-flex>
          <wui-text variant="small-500" color="bg-350" data-testid="wui-alertbar-text"
            >${this.message}</wui-text
          >
        </wui-flex>
        <wui-icon
          class="close"
          color="bg-350"
          size="sm"
          name="close"
          @click=${this.onClose}
        ></wui-icon>
      </wui-flex>
    `;
    }
    onClose() {
        ar.close();
    }
};
qr.styles = [
    we,
    ym
], Fi([
    C()
], qr.prototype, "message", void 0), Fi([
    C()
], qr.prototype, "backgroundColor", void 0), Fi([
    C()
], qr.prototype, "iconColor", void 0), Fi([
    C()
], qr.prototype, "icon", void 0), qr = Fi([
    F("wui-alertbar")
], qr);
var xm = te`
  :host {
    display: block;
    position: absolute;
    top: var(--wui-spacing-s);
    left: var(--wui-spacing-l);
    right: var(--wui-spacing-l);
    opacity: 0;
    pointer-events: none;
  }
`, b0 = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
const Em = {
    info: {
        backgroundColor: "fg-350",
        iconColor: "fg-325",
        icon: "info"
    },
    success: {
        backgroundColor: "success-glass-reown-020",
        iconColor: "success-125",
        icon: "checkmark"
    },
    warning: {
        backgroundColor: "warning-glass-reown-020",
        iconColor: "warning-100",
        icon: "warningCircle"
    },
    error: {
        backgroundColor: "error-glass-reown-020",
        iconColor: "error-125",
        icon: "exclamationTriangle"
    }
};
let oa = class extends V {
    constructor(){
        super(), this.unsubscribe = [], this.open = ar.state.open, this.onOpen(!0), this.unsubscribe.push(ar.subscribeKey("open", (e)=>{
            this.open = e, this.onOpen(!1);
        }));
    }
    disconnectedCallback() {
        this.unsubscribe.forEach((e)=>e());
    }
    render() {
        const { message: e, variant: r } = ar.state, n = Em[r];
        return w`
      <wui-alertbar
        message=${e}
        backgroundColor=${n?.backgroundColor}
        iconColor=${n?.iconColor}
        icon=${n?.icon}
      ></wui-alertbar>
    `;
    }
    onOpen(e) {
        this.open ? (this.animate([
            {
                opacity: 0,
                transform: "scale(0.85)"
            },
            {
                opacity: 1,
                transform: "scale(1)"
            }
        ], {
            duration: 150,
            fill: "forwards",
            easing: "ease"
        }), this.style.cssText = "pointer-events: auto") : e || (this.animate([
            {
                opacity: 1,
                transform: "scale(1)"
            },
            {
                opacity: 0,
                transform: "scale(0.85)"
            }
        ], {
            duration: 150,
            fill: "forwards",
            easing: "ease"
        }), this.style.cssText = "pointer-events: none");
    }
};
oa.styles = xm, b0([
    H()
], oa.prototype, "open", void 0), oa = b0([
    F("w3m-alertbar")
], oa);
var Am = te`
  button {
    border-radius: var(--local-border-radius);
    color: var(--wui-color-fg-100);
    padding: var(--local-padding);
  }

  @media (max-width: 700px) {
    button {
      padding: var(--wui-spacing-s);
    }
  }

  button > wui-icon {
    pointer-events: none;
  }

  button:disabled > wui-icon {
    color: var(--wui-color-bg-300) !important;
  }

  button:disabled {
    background-color: transparent;
  }
`, Hi = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Kr = class extends V {
    constructor(){
        super(...arguments), this.size = "md", this.disabled = !1, this.icon = "copy", this.iconColor = "inherit";
    }
    render() {
        const e = this.size === "lg" ? "--wui-border-radius-xs" : "--wui-border-radius-xxs", r = this.size === "lg" ? "--wui-spacing-1xs" : "--wui-spacing-2xs";
        return this.style.cssText = `
    --local-border-radius: var(${e});
    --local-padding: var(${r});
`, w`
      <button ?disabled=${this.disabled}>
        <wui-icon color=${this.iconColor} size=${this.size} name=${this.icon}></wui-icon>
      </button>
    `;
    }
};
Kr.styles = [
    we,
    De,
    li,
    Am
], Hi([
    C()
], Kr.prototype, "size", void 0), Hi([
    C({
        type: Boolean
    })
], Kr.prototype, "disabled", void 0), Hi([
    C()
], Kr.prototype, "icon", void 0), Hi([
    C()
], Kr.prototype, "iconColor", void 0), Kr = Hi([
    F("wui-icon-link")
], Kr);
var Sm = te`
  button {
    display: block;
    display: flex;
    align-items: center;
    padding: var(--wui-spacing-xxs);
    gap: var(--wui-spacing-xxs);
    transition: all var(--wui-ease-out-power-1) var(--wui-duration-md);
    border-radius: var(--wui-border-radius-xxs);
  }

  wui-image {
    border-radius: 100%;
    width: var(--wui-spacing-xl);
    height: var(--wui-spacing-xl);
  }

  wui-icon-box {
    width: var(--wui-spacing-xl);
    height: var(--wui-spacing-xl);
  }

  button:hover {
    background-color: var(--wui-color-gray-glass-002);
  }

  button:active {
    background-color: var(--wui-color-gray-glass-005);
  }
`, v0 = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let sa = class extends V {
    constructor(){
        super(...arguments), this.imageSrc = "";
    }
    render() {
        return w`<button>
      ${this.imageTemplate()}
      <wui-icon size="xs" color="fg-200" name="chevronBottom"></wui-icon>
    </button>`;
    }
    imageTemplate() {
        return this.imageSrc ? w`<wui-image src=${this.imageSrc} alt="select visual"></wui-image>` : w`<wui-icon-box
      size="xxs"
      iconColor="fg-200"
      backgroundColor="fg-100"
      background="opaque"
      icon="networkPlaceholder"
    ></wui-icon-box>`;
    }
};
sa.styles = [
    we,
    De,
    li,
    Sm
], v0([
    C()
], sa.prototype, "imageSrc", void 0), sa = v0([
    F("wui-select")
], sa);
var _m = te`
  :host {
    height: 64px;
  }

  wui-text {
    text-transform: capitalize;
  }

  wui-flex.w3m-header-title {
    transform: translateY(0);
    opacity: 1;
  }

  wui-flex.w3m-header-title[view-direction='prev'] {
    animation:
      slide-down-out 120ms forwards var(--wui-ease-out-power-2),
      slide-down-in 120ms forwards var(--wui-ease-out-power-2);
    animation-delay: 0ms, 200ms;
  }

  wui-flex.w3m-header-title[view-direction='next'] {
    animation:
      slide-up-out 120ms forwards var(--wui-ease-out-power-2),
      slide-up-in 120ms forwards var(--wui-ease-out-power-2);
    animation-delay: 0ms, 200ms;
  }

  wui-icon-link[data-hidden='true'] {
    opacity: 0 !important;
    pointer-events: none;
  }

  @keyframes slide-up-out {
    from {
      transform: translateY(0px);
      opacity: 1;
    }
    to {
      transform: translateY(3px);
      opacity: 0;
    }
  }

  @keyframes slide-up-in {
    from {
      transform: translateY(-3px);
      opacity: 0;
    }
    to {
      transform: translateY(0);
      opacity: 1;
    }
  }

  @keyframes slide-down-out {
    from {
      transform: translateY(0px);
      opacity: 1;
    }
    to {
      transform: translateY(-3px);
      opacity: 0;
    }
  }

  @keyframes slide-down-in {
    from {
      transform: translateY(3px);
      opacity: 0;
    }
    to {
      transform: translateY(0);
      opacity: 1;
    }
  }
`, Lt = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
const Im = [
    "SmartSessionList"
];
function qc() {
    const t = D.state.data?.connector?.name, e = D.state.data?.wallet?.name, r = D.state.data?.network?.name, n = e ?? t, i = j.getConnectors();
    return {
        Connect: `Connect ${i.length === 1 && i[0]?.id === "w3m-email" ? "Email" : ""} Wallet`,
        Create: "Create Wallet",
        ChooseAccountName: void 0,
        Account: void 0,
        AccountSettings: void 0,
        AllWallets: "All Wallets",
        ApproveTransaction: "Approve Transaction",
        BuyInProgress: "Buy",
        ConnectingExternal: n ?? "Connect Wallet",
        ConnectingWalletConnect: n ?? "WalletConnect",
        ConnectingWalletConnectBasic: "WalletConnect",
        ConnectingSiwe: "Sign In",
        Convert: "Convert",
        ConvertSelectToken: "Select token",
        ConvertPreview: "Preview convert",
        Downloads: n ? `Get ${n}` : "Downloads",
        EmailLogin: "Email Login",
        EmailVerifyOtp: "Confirm Email",
        EmailVerifyDevice: "Register Device",
        GetWallet: "Get a wallet",
        Networks: "Choose Network",
        OnRampProviders: "Choose Provider",
        OnRampActivity: "Activity",
        OnRampTokenSelect: "Select Token",
        OnRampFiatSelect: "Select Currency",
        Profile: void 0,
        SwitchNetwork: r ?? "Switch Network",
        SwitchAddress: "Switch Address",
        Transactions: "Activity",
        UnsupportedChain: "Switch Network",
        UpgradeEmailWallet: "Upgrade your Wallet",
        UpdateEmailWallet: "Edit Email",
        UpdateEmailPrimaryOtp: "Confirm Current Email",
        UpdateEmailSecondaryOtp: "Confirm New Email",
        WhatIsABuy: "What is Buy?",
        RegisterAccountName: "Choose name",
        RegisterAccountNameSuccess: "",
        WalletReceive: "Receive",
        WalletCompatibleNetworks: "Compatible Networks",
        Swap: "Swap",
        SwapSelectToken: "Select token",
        SwapPreview: "Preview swap",
        WalletSend: "Send",
        WalletSendPreview: "Review send",
        WalletSendSelectToken: "Select Token",
        WhatIsANetwork: "What is a network?",
        WhatIsAWallet: "What is a wallet?",
        ConnectWallets: "Connect wallet",
        ConnectSocials: "All socials",
        ConnectingSocial: Q.state.socialProvider ? Q.state.socialProvider : "Connect Social",
        ConnectingMultiChain: "Select chain",
        ConnectingFarcaster: "Farcaster",
        SwitchActiveChain: "Switch chain",
        SmartSessionCreated: void 0,
        SmartSessionList: "Smart Sessions",
        SIWXSignMessage: "Sign In"
    };
}
let Ct = class extends V {
    constructor(){
        super(), this.unsubscribe = [], this.heading = qc()[D.state.view], this.network = f.state.activeCaipNetwork, this.networkImage = Oe.getNetworkImage(this.network), this.buffering = !1, this.showBack = !1, this.prevHistoryLength = 1, this.view = D.state.view, this.viewDirection = "", this.headerText = qc()[D.state.view], this.unsubscribe.push(Ye.subscribeNetworkImages(()=>{
            this.networkImage = Oe.getNetworkImage(this.network);
        }), D.subscribeKey("view", (e)=>{
            setTimeout(()=>{
                this.view = e, this.headerText = qc()[e];
            }, gr.ANIMATION_DURATIONS.HeaderText), this.onViewChange(), this.onHistoryChange();
        }), Y.subscribeKey("buffering", (e)=>this.buffering = e), f.subscribeKey("activeCaipNetwork", (e)=>{
            this.network = e, this.networkImage = Oe.getNetworkImage(this.network);
        }));
    }
    disconnectCallback() {
        this.unsubscribe.forEach((e)=>e());
    }
    render() {
        return w`
      <wui-flex .padding=${this.getPadding()} justifyContent="space-between" alignItems="center">
        ${this.leftHeaderTemplate()} ${this.titleTemplate()} ${this.rightHeaderTemplate()}
      </wui-flex>
    `;
    }
    onWalletHelp() {
        le.sendEvent({
            type: "track",
            event: "CLICK_WALLET_HELP"
        }), D.push("WhatIsAWallet");
    }
    async onClose() {
        D.state.view === "UnsupportedChain" || await lr.isSIWXCloseDisabled() ? he.shake() : he.close();
    }
    rightHeaderTemplate() {
        const e = T?.state?.features?.smartSessions;
        return D.state.view !== "Account" || !e ? this.closeButtonTemplate() : w`<wui-flex>
      <wui-icon-link
        icon="clock"
        @click=${()=>D.push("SmartSessionList")}
        data-testid="w3m-header-smart-sessions"
      ></wui-icon-link>
      ${this.closeButtonTemplate()}
    </wui-flex> `;
    }
    closeButtonTemplate() {
        return w`
      <wui-icon-link
        ?disabled=${this.buffering}
        icon="close"
        @click=${this.onClose.bind(this)}
        data-testid="w3m-header-close"
      ></wui-icon-link>
    `;
    }
    titleTemplate() {
        const e = Im.includes(this.view);
        return w`
      <wui-flex
        view-direction="${this.viewDirection}"
        class="w3m-header-title"
        alignItems="center"
        gap="xs"
      >
        <wui-text variant="paragraph-700" color="fg-100" data-testid="w3m-header-text"
          >${this.headerText}</wui-text
        >
        ${e ? w`<wui-tag variant="main">Beta</wui-tag>` : null}
      </wui-flex>
    `;
    }
    leftHeaderTemplate() {
        const { view: e } = D.state, r = e === "Connect", n = T.state.enableEmbedded, i = e === "ApproveTransaction", o = e === "ConnectingSiwe", s = e === "Account", a = T.state.enableNetworkSwitch, c = i || o || r && n;
        return s && a ? w`<wui-select
        id="dynamic"
        data-testid="w3m-account-select-network"
        active-network=${re(this.network?.name)}
        @click=${this.onNetworks.bind(this)}
        imageSrc=${re(this.networkImage)}
      ></wui-select>` : this.showBack && !c ? w`<wui-icon-link
        data-testid="header-back"
        id="dynamic"
        icon="chevronLeft"
        ?disabled=${this.buffering}
        @click=${this.onGoBack.bind(this)}
      ></wui-icon-link>` : w`<wui-icon-link
      data-hidden=${!r}
      id="dynamic"
      icon="helpCircle"
      @click=${this.onWalletHelp.bind(this)}
    ></wui-icon-link>`;
    }
    onNetworks() {
        this.isAllowedNetworkSwitch() && (le.sendEvent({
            type: "track",
            event: "CLICK_NETWORKS"
        }), D.push("Networks"));
    }
    isAllowedNetworkSwitch() {
        const e = f.getAllRequestedCaipNetworks(), r = e ? e.length > 1 : !1, n = e?.find(({ id: i })=>i === this.network?.id);
        return r || !n;
    }
    getPadding() {
        return this.heading ? [
            "l",
            "2l",
            "l",
            "2l"
        ] : [
            "0",
            "2l",
            "0",
            "2l"
        ];
    }
    onViewChange() {
        const { history: e } = D.state;
        let r = gr.VIEW_DIRECTION.Next;
        e.length < this.prevHistoryLength && (r = gr.VIEW_DIRECTION.Prev), this.prevHistoryLength = e.length, this.viewDirection = r;
    }
    async onHistoryChange() {
        const { history: e } = D.state, r = this.shadowRoot?.querySelector("#dynamic");
        e.length > 1 && !this.showBack && r ? (await r.animate([
            {
                opacity: 1
            },
            {
                opacity: 0
            }
        ], {
            duration: 200,
            fill: "forwards",
            easing: "ease"
        }).finished, this.showBack = !0, r.animate([
            {
                opacity: 0
            },
            {
                opacity: 1
            }
        ], {
            duration: 200,
            fill: "forwards",
            easing: "ease"
        })) : e.length <= 1 && this.showBack && r && (await r.animate([
            {
                opacity: 1
            },
            {
                opacity: 0
            }
        ], {
            duration: 200,
            fill: "forwards",
            easing: "ease"
        }).finished, this.showBack = !1, r.animate([
            {
                opacity: 0
            },
            {
                opacity: 1
            }
        ], {
            duration: 200,
            fill: "forwards",
            easing: "ease"
        }));
    }
    onGoBack() {
        D.goBack();
    }
};
Ct.styles = _m, Lt([
    H()
], Ct.prototype, "heading", void 0), Lt([
    H()
], Ct.prototype, "network", void 0), Lt([
    H()
], Ct.prototype, "networkImage", void 0), Lt([
    H()
], Ct.prototype, "buffering", void 0), Lt([
    H()
], Ct.prototype, "showBack", void 0), Lt([
    H()
], Ct.prototype, "prevHistoryLength", void 0), Lt([
    H()
], Ct.prototype, "view", void 0), Lt([
    H()
], Ct.prototype, "viewDirection", void 0), Lt([
    H()
], Ct.prototype, "headerText", void 0), Ct = Lt([
    F("w3m-header")
], Ct);
var Nm = te`
  :host {
    display: flex;
    column-gap: var(--wui-spacing-s);
    align-items: center;
    padding: var(--wui-spacing-xs) var(--wui-spacing-m) var(--wui-spacing-xs) var(--wui-spacing-xs);
    border-radius: var(--wui-border-radius-s);
    border: 1px solid var(--wui-color-gray-glass-005);
    box-sizing: border-box;
    background-color: var(--wui-color-bg-175);
    box-shadow:
      0px 14px 64px -4px rgba(0, 0, 0, 0.15),
      0px 8px 22px -6px rgba(0, 0, 0, 0.15);

    max-width: 300px;
  }

  :host wui-loading-spinner {
    margin-left: var(--wui-spacing-3xs);
  }
`, Yr = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let rr = class extends V {
    constructor(){
        super(...arguments), this.backgroundColor = "accent-100", this.iconColor = "accent-100", this.icon = "checkmark", this.message = "", this.loading = !1, this.iconType = "default";
    }
    render() {
        return w`
      ${this.templateIcon()}
      <wui-text variant="paragraph-500" color="fg-100" data-testid="wui-snackbar-message"
        >${this.message}</wui-text
      >
    `;
    }
    templateIcon() {
        return this.loading ? w`<wui-loading-spinner size="md" color="accent-100"></wui-loading-spinner>` : this.iconType === "default" ? w`<wui-icon size="xl" color=${this.iconColor} name=${this.icon}></wui-icon>` : w`<wui-icon-box
      size="sm"
      iconSize="xs"
      iconColor=${this.iconColor}
      backgroundColor=${this.backgroundColor}
      icon=${this.icon}
      background="opaque"
    ></wui-icon-box>`;
    }
};
rr.styles = [
    we,
    Nm
], Yr([
    C()
], rr.prototype, "backgroundColor", void 0), Yr([
    C()
], rr.prototype, "iconColor", void 0), Yr([
    C()
], rr.prototype, "icon", void 0), Yr([
    C()
], rr.prototype, "message", void 0), Yr([
    C()
], rr.prototype, "loading", void 0), Yr([
    C()
], rr.prototype, "iconType", void 0), rr = Yr([
    F("wui-snackbar")
], rr);
var km = te`
  :host {
    display: block;
    position: absolute;
    opacity: 0;
    pointer-events: none;
    top: 11px;
    left: 50%;
    width: max-content;
  }
`, C0 = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
const Tm = {
    loading: void 0,
    success: {
        backgroundColor: "success-100",
        iconColor: "success-100",
        icon: "checkmark"
    },
    error: {
        backgroundColor: "error-100",
        iconColor: "error-100",
        icon: "close"
    }
};
let aa = class extends V {
    constructor(){
        super(), this.unsubscribe = [], this.timeout = void 0, this.open = Ee.state.open, this.unsubscribe.push(Ee.subscribeKey("open", (e)=>{
            this.open = e, this.onOpen();
        }));
    }
    disconnectedCallback() {
        clearTimeout(this.timeout), this.unsubscribe.forEach((e)=>e());
    }
    render() {
        const { message: e, variant: r, svg: n } = Ee.state, i = Tm[r], { icon: o, iconColor: s } = n ?? i ?? {};
        return w`
      <wui-snackbar
        message=${e}
        backgroundColor=${i?.backgroundColor}
        iconColor=${s}
        icon=${o}
        .loading=${r === "loading"}
      ></wui-snackbar>
    `;
    }
    onOpen() {
        clearTimeout(this.timeout), this.open ? (this.animate([
            {
                opacity: 0,
                transform: "translateX(-50%) scale(0.85)"
            },
            {
                opacity: 1,
                transform: "translateX(-50%) scale(1)"
            }
        ], {
            duration: 150,
            fill: "forwards",
            easing: "ease"
        }), this.timeout && clearTimeout(this.timeout), Ee.state.autoClose && (this.timeout = setTimeout(()=>Ee.hide(), 2500))) : this.animate([
            {
                opacity: 1,
                transform: "translateX(-50%) scale(1)"
            },
            {
                opacity: 0,
                transform: "translateX(-50%) scale(0.85)"
            }
        ], {
            duration: 150,
            fill: "forwards",
            easing: "ease"
        });
    }
};
aa.styles = km, C0([
    H()
], aa.prototype, "open", void 0), aa = C0([
    F("w3m-snackbar")
], aa);
var Om = te`
  :host {
    pointer-events: none;
  }

  :host > wui-flex {
    display: var(--w3m-tooltip-display);
    opacity: var(--w3m-tooltip-opacity);
    padding: 9px var(--wui-spacing-s) 10px var(--wui-spacing-s);
    border-radius: var(--wui-border-radius-xxs);
    color: var(--wui-color-bg-100);
    position: fixed;
    top: var(--w3m-tooltip-top);
    left: var(--w3m-tooltip-left);
    transform: translate(calc(-50% + var(--w3m-tooltip-parent-width)), calc(-100% - 8px));
    max-width: calc(var(--w3m-modal-width) - var(--wui-spacing-xl));
    transition: opacity 0.2s var(--wui-ease-out-power-2);
    will-change: opacity;
  }

  :host([data-variant='shade']) > wui-flex {
    background-color: var(--wui-color-bg-150);
    border: 1px solid var(--wui-color-gray-glass-005);
  }

  :host([data-variant='shade']) > wui-flex > wui-text {
    color: var(--wui-color-fg-150);
  }

  :host([data-variant='fill']) > wui-flex {
    background-color: var(--wui-color-fg-100);
    border: none;
  }

  wui-icon {
    position: absolute;
    width: 12px !important;
    height: 4px !important;
    color: var(--wui-color-bg-150);
  }

  wui-icon[data-placement='top'] {
    bottom: 0px;
    left: 50%;
    transform: translate(-50%, 95%);
  }

  wui-icon[data-placement='bottom'] {
    top: 0;
    left: 50%;
    transform: translate(-50%, -95%) rotate(180deg);
  }

  wui-icon[data-placement='right'] {
    top: 50%;
    left: 0;
    transform: translate(-65%, -50%) rotate(90deg);
  }

  wui-icon[data-placement='left'] {
    top: 50%;
    right: 0%;
    transform: translate(65%, -50%) rotate(270deg);
  }
`, Vi = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Xr = class extends V {
    constructor(){
        super(), this.unsubscribe = [], this.open = mn.state.open, this.message = mn.state.message, this.triggerRect = mn.state.triggerRect, this.variant = mn.state.variant, this.unsubscribe.push(mn.subscribe((e)=>{
            this.open = e.open, this.message = e.message, this.triggerRect = e.triggerRect, this.variant = e.variant;
        }));
    }
    disconnectedCallback() {
        this.unsubscribe.forEach((e)=>e());
    }
    render() {
        this.dataset.variant = this.variant;
        const e = this.triggerRect.top, r = this.triggerRect.left;
        return this.style.cssText = `
    --w3m-tooltip-top: ${e}px;
    --w3m-tooltip-left: ${r}px;
    --w3m-tooltip-parent-width: ${this.triggerRect.width / 2}px;
    --w3m-tooltip-display: ${this.open ? "flex" : "none"};
    --w3m-tooltip-opacity: ${this.open ? 1 : 0};
    `, w`<wui-flex>
      <wui-icon data-placement="top" color="fg-100" size="inherit" name="cursor"></wui-icon>
      <wui-text color="inherit" variant="small-500">${this.message}</wui-text>
    </wui-flex>`;
    }
};
Xr.styles = [
    Om
], Vi([
    H()
], Xr.prototype, "open", void 0), Vi([
    H()
], Xr.prototype, "message", void 0), Vi([
    H()
], Xr.prototype, "triggerRect", void 0), Vi([
    H()
], Xr.prototype, "variant", void 0), Xr = Vi([
    F("w3m-tooltip"),
    F("w3m-tooltip")
], Xr);
var $m = te`
  :host {
    --prev-height: 0px;
    --new-height: 0px;
    display: block;
  }

  div.w3m-router-container {
    transform: translateY(0);
    opacity: 1;
  }

  div.w3m-router-container[view-direction='prev'] {
    animation:
      slide-left-out 150ms forwards ease,
      slide-left-in 150ms forwards ease;
    animation-delay: 0ms, 200ms;
  }

  div.w3m-router-container[view-direction='next'] {
    animation:
      slide-right-out 150ms forwards ease,
      slide-right-in 150ms forwards ease;
    animation-delay: 0ms, 200ms;
  }

  @keyframes slide-left-out {
    from {
      transform: translateX(0px);
      opacity: 1;
    }
    to {
      transform: translateX(10px);
      opacity: 0;
    }
  }

  @keyframes slide-left-in {
    from {
      transform: translateX(-10px);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }

  @keyframes slide-right-out {
    from {
      transform: translateX(0px);
      opacity: 1;
    }
    to {
      transform: translateX(-10px);
      opacity: 0;
    }
  }

  @keyframes slide-right-in {
    from {
      transform: translateX(10px);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }
`, Kc = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
let Zi = class extends V {
    constructor(){
        super(), this.resizeObserver = void 0, this.prevHeight = "0px", this.prevHistoryLength = 1, this.unsubscribe = [], this.view = D.state.view, this.viewDirection = "", this.unsubscribe.push(D.subscribeKey("view", (e)=>this.onViewChange(e)));
    }
    firstUpdated() {
        this.resizeObserver = new ResizeObserver(([e])=>{
            const r = `${e?.contentRect.height}px`;
            this.prevHeight !== "0px" && (this.style.setProperty("--prev-height", this.prevHeight), this.style.setProperty("--new-height", r), this.style.animation = "w3m-view-height 150ms forwards ease", this.style.height = "auto"), setTimeout(()=>{
                this.prevHeight = r, this.style.animation = "unset";
            }, gr.ANIMATION_DURATIONS.ModalHeight);
        }), this.resizeObserver?.observe(this.getWrapper());
    }
    disconnectedCallback() {
        this.resizeObserver?.unobserve(this.getWrapper()), this.unsubscribe.forEach((e)=>e());
    }
    render() {
        return w`<div class="w3m-router-container" view-direction="${this.viewDirection}">
      ${this.viewTemplate()}
    </div>`;
    }
    viewTemplate() {
        switch(this.view){
            case "AccountSettings":
                return w`<w3m-account-settings-view></w3m-account-settings-view>`;
            case "Account":
                return w`<w3m-account-view></w3m-account-view>`;
            case "AllWallets":
                return w`<w3m-all-wallets-view></w3m-all-wallets-view>`;
            case "ApproveTransaction":
                return w`<w3m-approve-transaction-view></w3m-approve-transaction-view>`;
            case "BuyInProgress":
                return w`<w3m-buy-in-progress-view></w3m-buy-in-progress-view>`;
            case "ChooseAccountName":
                return w`<w3m-choose-account-name-view></w3m-choose-account-name-view>`;
            case "Connect":
                return w`<w3m-connect-view></w3m-connect-view>`;
            case "Create":
                return w`<w3m-connect-view walletGuide="explore"></w3m-connect-view>`;
            case "ConnectingWalletConnect":
                return w`<w3m-connecting-wc-view></w3m-connecting-wc-view>`;
            case "ConnectingWalletConnectBasic":
                return w`<w3m-connecting-wc-basic-view></w3m-connecting-wc-basic-view>`;
            case "ConnectingExternal":
                return w`<w3m-connecting-external-view></w3m-connecting-external-view>`;
            case "ConnectingSiwe":
                return w`<w3m-connecting-siwe-view></w3m-connecting-siwe-view>`;
            case "ConnectWallets":
                return w`<w3m-connect-wallets-view></w3m-connect-wallets-view>`;
            case "ConnectSocials":
                return w`<w3m-connect-socials-view></w3m-connect-socials-view>`;
            case "ConnectingSocial":
                return w`<w3m-connecting-social-view></w3m-connecting-social-view>`;
            case "Downloads":
                return w`<w3m-downloads-view></w3m-downloads-view>`;
            case "EmailLogin":
                return w`<w3m-email-login-view></w3m-email-login-view>`;
            case "EmailVerifyOtp":
                return w`<w3m-email-verify-otp-view></w3m-email-verify-otp-view>`;
            case "EmailVerifyDevice":
                return w`<w3m-email-verify-device-view></w3m-email-verify-device-view>`;
            case "GetWallet":
                return w`<w3m-get-wallet-view></w3m-get-wallet-view>`;
            case "Networks":
                return w`<w3m-networks-view></w3m-networks-view>`;
            case "SwitchNetwork":
                return w`<w3m-network-switch-view></w3m-network-switch-view>`;
            case "Profile":
                return w`<w3m-profile-view></w3m-profile-view>`;
            case "SwitchAddress":
                return w`<w3m-switch-address-view></w3m-switch-address-view>`;
            case "Transactions":
                return w`<w3m-transactions-view></w3m-transactions-view>`;
            case "OnRampProviders":
                return w`<w3m-onramp-providers-view></w3m-onramp-providers-view>`;
            case "OnRampActivity":
                return w`<w3m-onramp-activity-view></w3m-onramp-activity-view>`;
            case "OnRampTokenSelect":
                return w`<w3m-onramp-token-select-view></w3m-onramp-token-select-view>`;
            case "OnRampFiatSelect":
                return w`<w3m-onramp-fiat-select-view></w3m-onramp-fiat-select-view>`;
            case "UpgradeEmailWallet":
                return w`<w3m-upgrade-wallet-view></w3m-upgrade-wallet-view>`;
            case "UpdateEmailWallet":
                return w`<w3m-update-email-wallet-view></w3m-update-email-wallet-view>`;
            case "UpdateEmailPrimaryOtp":
                return w`<w3m-update-email-primary-otp-view></w3m-update-email-primary-otp-view>`;
            case "UpdateEmailSecondaryOtp":
                return w`<w3m-update-email-secondary-otp-view></w3m-update-email-secondary-otp-view>`;
            case "UnsupportedChain":
                return w`<w3m-unsupported-chain-view></w3m-unsupported-chain-view>`;
            case "Swap":
                return w`<w3m-swap-view></w3m-swap-view>`;
            case "SwapSelectToken":
                return w`<w3m-swap-select-token-view></w3m-swap-select-token-view>`;
            case "SwapPreview":
                return w`<w3m-swap-preview-view></w3m-swap-preview-view>`;
            case "WalletSend":
                return w`<w3m-wallet-send-view></w3m-wallet-send-view>`;
            case "WalletSendSelectToken":
                return w`<w3m-wallet-send-select-token-view></w3m-wallet-send-select-token-view>`;
            case "WalletSendPreview":
                return w`<w3m-wallet-send-preview-view></w3m-wallet-send-preview-view>`;
            case "WhatIsABuy":
                return w`<w3m-what-is-a-buy-view></w3m-what-is-a-buy-view>`;
            case "WalletReceive":
                return w`<w3m-wallet-receive-view></w3m-wallet-receive-view>`;
            case "WalletCompatibleNetworks":
                return w`<w3m-wallet-compatible-networks-view></w3m-wallet-compatible-networks-view>`;
            case "WhatIsAWallet":
                return w`<w3m-what-is-a-wallet-view></w3m-what-is-a-wallet-view>`;
            case "ConnectingMultiChain":
                return w`<w3m-connecting-multi-chain-view></w3m-connecting-multi-chain-view>`;
            case "WhatIsANetwork":
                return w`<w3m-what-is-a-network-view></w3m-what-is-a-network-view>`;
            case "ConnectingFarcaster":
                return w`<w3m-connecting-farcaster-view></w3m-connecting-farcaster-view>`;
            case "SwitchActiveChain":
                return w`<w3m-switch-active-chain-view></w3m-switch-active-chain-view>`;
            case "RegisterAccountName":
                return w`<w3m-register-account-name-view></w3m-register-account-name-view>`;
            case "RegisterAccountNameSuccess":
                return w`<w3m-register-account-name-success-view></w3m-register-account-name-success-view>`;
            case "SmartSessionCreated":
                return w`<w3m-smart-session-created-view></w3m-smart-session-created-view>`;
            case "SmartSessionList":
                return w`<w3m-smart-session-list-view></w3m-smart-session-list-view>`;
            case "SIWXSignMessage":
                return w`<w3m-siwx-sign-message-view></w3m-siwx-sign-message-view>`;
            default:
                return w`<w3m-connect-view></w3m-connect-view>`;
        }
    }
    onViewChange(e) {
        mn.hide();
        let r = gr.VIEW_DIRECTION.Next;
        const { history: n } = D.state;
        n.length < this.prevHistoryLength && (r = gr.VIEW_DIRECTION.Prev), this.prevHistoryLength = n.length, this.viewDirection = r, setTimeout(()=>{
            this.view = e;
        }, gr.ANIMATION_DURATIONS.ViewTransition);
    }
    getWrapper() {
        return this.shadowRoot?.querySelector("div");
    }
};
Zi.styles = $m, Kc([
    H()
], Zi.prototype, "view", void 0), Kc([
    H()
], Zi.prototype, "viewDirection", void 0), Zi = Kc([
    F("w3m-router")
], Zi);
var Pm = te`
  :host {
    z-index: var(--w3m-z-index);
    display: block;
    backface-visibility: hidden;
    will-change: opacity;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    pointer-events: none;
    opacity: 0;
    background-color: var(--wui-cover);
    transition: opacity 0.2s var(--wui-ease-out-power-2);
    will-change: opacity;
  }

  :host(.open) {
    opacity: 1;
  }

  :host(.embedded) {
    position: relative;
    pointer-events: unset;
    background: none;
    width: 100%;
    opacity: 1;
  }

  wui-card {
    max-width: var(--w3m-modal-width);
    width: 100%;
    position: relative;
    animation: zoom-in 0.2s var(--wui-ease-out-power-2);
    animation-fill-mode: backwards;
    outline: none;
    transition:
      border-radius var(--wui-duration-lg) var(--wui-ease-out-power-1),
      background-color var(--wui-duration-lg) var(--wui-ease-out-power-1);
    will-change: border-radius, background-color;
  }

  :host(.embedded) wui-card {
    max-width: 400px;
  }

  wui-card[shake='true'] {
    animation:
      zoom-in 0.2s var(--wui-ease-out-power-2),
      w3m-shake 0.5s var(--wui-ease-out-power-2);
  }

  wui-flex {
    overflow-x: hidden;
    overflow-y: auto;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
  }

  @media (max-height: 700px) and (min-width: 431px) {
    wui-flex {
      align-items: flex-start;
    }

    wui-card {
      margin: var(--wui-spacing-xxl) 0px;
    }
  }

  @media (max-width: 430px) {
    wui-flex {
      align-items: flex-end;
    }

    wui-card {
      max-width: 100%;
      border-bottom-left-radius: var(--local-border-bottom-mobile-radius);
      border-bottom-right-radius: var(--local-border-bottom-mobile-radius);
      border-bottom: none;
      animation: slide-in 0.2s var(--wui-ease-out-power-2);
    }

    wui-card[shake='true'] {
      animation:
        slide-in 0.2s var(--wui-ease-out-power-2),
        w3m-shake 0.5s var(--wui-ease-out-power-2);
    }
  }

  @keyframes zoom-in {
    0% {
      transform: scale(0.95) translateY(0);
    }
    100% {
      transform: scale(1) translateY(0);
    }
  }

  @keyframes slide-in {
    0% {
      transform: scale(1) translateY(50px);
    }
    100% {
      transform: scale(1) translateY(0);
    }
  }

  @keyframes w3m-shake {
    0% {
      transform: scale(1) rotate(0deg);
    }
    20% {
      transform: scale(1) rotate(-1deg);
    }
    40% {
      transform: scale(1) rotate(1.5deg);
    }
    60% {
      transform: scale(1) rotate(-1.5deg);
    }
    80% {
      transform: scale(1) rotate(1deg);
    }
    100% {
      transform: scale(1) rotate(0deg);
    }
  }

  @keyframes w3m-view-height {
    from {
      height: var(--prev-height);
    }
    to {
      height: var(--new-height);
    }
  }
`, Jr = function(t, e, r, n) {
    var i = arguments.length, o = i < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, n);
    else for(var a = t.length - 1; a >= 0; a--)(s = t[a]) && (o = (i < 3 ? s(o) : i > 3 ? s(e, r, o) : s(e, r)) || o);
    return i > 3 && o && Object.defineProperty(e, r, o), o;
};
const y0 = "scroll-lock";
let Ut = class extends V {
    constructor(){
        super(), this.unsubscribe = [], this.abortController = void 0, this.hasPrefetched = !1, this.enableEmbedded = T.state.enableEmbedded, this.open = he.state.open, this.caipAddress = f.state.activeCaipAddress, this.caipNetwork = f.state.activeCaipNetwork, this.shake = he.state.shake, this.filterByNamespace = j.state.filterByNamespace, this.initializeTheming(), W.prefetchAnalyticsConfig(), this.unsubscribe.push(he.subscribeKey("open", (e)=>e ? this.onOpen() : this.onClose()), he.subscribeKey("shake", (e)=>this.shake = e), f.subscribeKey("activeCaipNetwork", (e)=>this.onNewNetwork(e)), f.subscribeKey("activeCaipAddress", (e)=>this.onNewAddress(e)), T.subscribeKey("enableEmbedded", (e)=>this.enableEmbedded = e), j.subscribeKey("filterByNamespace", (e)=>{
            this.filterByNamespace !== e && !f.getAccountData(e)?.caipAddress && (W.fetchRecommendedWallets(), this.filterByNamespace = e);
        }));
    }
    firstUpdated() {
        if (this.caipAddress) {
            if (this.enableEmbedded) {
                he.close(), this.prefetch();
                return;
            }
            this.onNewAddress(this.caipAddress);
        }
        this.open && this.onOpen(), this.enableEmbedded && this.prefetch();
    }
    disconnectedCallback() {
        this.unsubscribe.forEach((e)=>e()), this.onRemoveKeyboardListener();
    }
    render() {
        return this.style.cssText = `
      --local-border-bottom-mobile-radius: ${this.enableEmbedded ? "clamp(0px, var(--wui-border-radius-l), 44px)" : "0px"};
    `, this.enableEmbedded ? w`${this.contentTemplate()}
        <w3m-tooltip></w3m-tooltip> ` : this.open ? w`
          <wui-flex @click=${this.onOverlayClick.bind(this)} data-testid="w3m-modal-overlay">
            ${this.contentTemplate()}
          </wui-flex>
          <w3m-tooltip></w3m-tooltip>
        ` : null;
    }
    contentTemplate() {
        return w` <wui-card
      shake="${this.shake}"
      data-embedded="${re(this.enableEmbedded)}"
      role="alertdialog"
      aria-modal="true"
      tabindex="0"
      data-testid="w3m-modal-card"
    >
      <w3m-header></w3m-header>
      <w3m-router></w3m-router>
      <w3m-snackbar></w3m-snackbar>
      <w3m-alertbar></w3m-alertbar>
    </wui-card>`;
    }
    async onOverlayClick(e) {
        e.target === e.currentTarget && await this.handleClose();
    }
    async handleClose() {
        D.state.view === "UnsupportedChain" || await lr.isSIWXCloseDisabled() ? he.shake() : he.close();
    }
    initializeTheming() {
        const { themeVariables: e, themeMode: r } = $e.state, n = Me.getColorTheme(r);
        Tg(e, n);
    }
    onClose() {
        this.open = !1, this.classList.remove("open"), this.onScrollUnlock(), Ee.hide(), this.onRemoveKeyboardListener();
    }
    onOpen() {
        this.open = !0, this.classList.add("open"), this.onScrollLock(), this.onAddKeyboardListener();
    }
    onScrollLock() {
        const e = document.createElement("style");
        e.dataset.w3m = y0, e.textContent = `
      body {
        touch-action: none;
        overflow: hidden;
        overscroll-behavior: contain;
      }
      w3m-modal {
        pointer-events: auto;
      }
    `, document.head.appendChild(e);
    }
    onScrollUnlock() {
        const e = document.head.querySelector(`style[data-w3m="${y0}"]`);
        e && e.remove();
    }
    onAddKeyboardListener() {
        this.abortController = new AbortController;
        const e = this.shadowRoot?.querySelector("wui-card");
        e?.focus(), window.addEventListener("keydown", (r)=>{
            if (r.key === "Escape") this.handleClose();
            else if (r.key === "Tab") {
                const { tagName: n } = r.target;
                n && !n.includes("W3M-") && !n.includes("WUI-") && e?.focus();
            }
        }, this.abortController);
    }
    onRemoveKeyboardListener() {
        this.abortController?.abort(), this.abortController = void 0;
    }
    async onNewAddress(e) {
        const r = f.state.isSwitchingNamespace, n = U.getPlainAddress(e);
        !n && !r ? he.close() : r && n && D.goBack(), await lr.initializeIfEnabled(), this.caipAddress = e, f.setIsSwitchingNamespace(!1);
    }
    onNewNetwork(e) {
        const r = this.caipNetwork, n = r?.caipNetworkId?.toString(), i = r?.chainNamespace, o = e?.caipNetworkId?.toString(), s = e?.chainNamespace, a = n !== o, l = a && !(i !== s), d = r?.name === G.UNSUPPORTED_NETWORK_NAME, u = D.state.view === "ConnectingExternal", h = !this.caipAddress, p = D.state.view === "UnsupportedChain", v = he.state.open;
        let m = !1;
        v && !u && (h ? a && (m = !0) : (p || l && !d) && (m = !0)), m && D.state.view !== "SIWXSignMessage" && D.goBack(), this.caipNetwork = e;
    }
    prefetch() {
        this.hasPrefetched || (W.prefetch(), W.fetchWalletsByPage({
            page: 1
        }), this.hasPrefetched = !0);
    }
};
Ut.styles = Pm, Jr([
    C({
        type: Boolean
    })
], Ut.prototype, "enableEmbedded", void 0), Jr([
    H()
], Ut.prototype, "open", void 0), Jr([
    H()
], Ut.prototype, "caipAddress", void 0), Jr([
    H()
], Ut.prototype, "caipNetwork", void 0), Jr([
    H()
], Ut.prototype, "shake", void 0), Jr([
    H()
], Ut.prototype, "filterByNamespace", void 0), Ut = Jr([
    F("w3m-modal")
], Ut);
var Bm = Object.freeze({
    __proto__: null,
    get W3mModal () {
        return Ut;
    }
});
const Rm = M`<svg
  width="14"
  height="14"
  viewBox="0 0 14 14"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill="currentColor"
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M7.0023 0.875C7.48571 0.875 7.8776 1.26675 7.8776 1.75V6.125H12.2541C12.7375 6.125 13.1294 6.51675 13.1294 7C13.1294 7.48325 12.7375 7.875 12.2541 7.875H7.8776V12.25C7.8776 12.7332 7.48571 13.125 7.0023 13.125C6.51889 13.125 6.12701 12.7332 6.12701 12.25V7.875H1.75054C1.26713 7.875 0.875244 7.48325 0.875244 7C0.875244 6.51675 1.26713 6.125 1.75054 6.125H6.12701V1.75C6.12701 1.26675 6.51889 0.875 7.0023 0.875Z"
    fill="#667dff"
  /></svg
>`;
var Lm = Object.freeze({
    __proto__: null,
    addSvg: Rm
});
const Um = M`<svg fill="none" viewBox="0 0 24 24">
  <path
    style="fill: var(--wui-color-accent-100);"
    d="M10.2 6.6a3.6 3.6 0 1 1-7.2 0 3.6 3.6 0 0 1 7.2 0ZM21 6.6a3.6 3.6 0 1 1-7.2 0 3.6 3.6 0 0 1 7.2 0ZM10.2 17.4a3.6 3.6 0 1 1-7.2 0 3.6 3.6 0 0 1 7.2 0ZM21 17.4a3.6 3.6 0 1 1-7.2 0 3.6 3.6 0 0 1 7.2 0Z"
  />
</svg>`;
var Mm = Object.freeze({
    __proto__: null,
    allWalletsSvg: Um
});
const Dm = M`<svg
  fill="none"
  viewBox="0 0 21 20"
>
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M10.5 2.42908C6.31875 2.42908 2.92859 5.81989 2.92859 10.0034C2.92859 14.1869 6.31875 17.5777 10.5 17.5777C14.6813 17.5777 18.0714 14.1869 18.0714 10.0034C18.0714 5.81989 14.6813 2.42908 10.5 2.42908ZM0.928589 10.0034C0.928589 4.71596 5.21355 0.429077 10.5 0.429077C15.7865 0.429077 20.0714 4.71596 20.0714 10.0034C20.0714 15.2908 15.7865 19.5777 10.5 19.5777C5.21355 19.5777 0.928589 15.2908 0.928589 10.0034ZM10.5 5.75003C11.0523 5.75003 11.5 6.19774 11.5 6.75003L11.5 10.8343L12.7929 9.54137C13.1834 9.15085 13.8166 9.15085 14.2071 9.54137C14.5976 9.9319 14.5976 10.5651 14.2071 10.9556L11.2071 13.9556C10.8166 14.3461 10.1834 14.3461 9.79291 13.9556L6.79291 10.9556C6.40239 10.5651 6.40239 9.9319 6.79291 9.54137C7.18343 9.15085 7.8166 9.15085 8.20712 9.54137L9.50002 10.8343L9.50002 6.75003C9.50002 6.19774 9.94773 5.75003 10.5 5.75003Z"
    clip-rule="evenodd"
  /></svg
>`;
var zm = Object.freeze({
    __proto__: null,
    arrowBottomCircleSvg: Dm
});
const Wm = M`
<svg width="36" height="36">
  <path
    d="M28.724 0H7.271A7.269 7.269 0 0 0 0 7.272v21.46A7.268 7.268 0 0 0 7.271 36H28.73A7.272 7.272 0 0 0 36 28.728V7.272A7.275 7.275 0 0 0 28.724 0Z"
    fill="url(#a)"
  />
  <path
    d="m17.845 8.271.729-1.26a1.64 1.64 0 1 1 2.843 1.638l-7.023 12.159h5.08c1.646 0 2.569 1.935 1.853 3.276H6.434a1.632 1.632 0 0 1-1.638-1.638c0-.909.73-1.638 1.638-1.638h4.176l5.345-9.265-1.67-2.898a1.642 1.642 0 0 1 2.844-1.638l.716 1.264Zm-6.317 17.5-1.575 2.732a1.64 1.64 0 1 1-2.844-1.638l1.17-2.025c1.323-.41 2.398-.095 3.249.931Zm13.56-4.954h4.262c.909 0 1.638.729 1.638 1.638 0 .909-.73 1.638-1.638 1.638h-2.367l1.597 2.772c.45.788.185 1.782-.602 2.241a1.642 1.642 0 0 1-2.241-.603c-2.69-4.666-4.711-8.159-6.052-10.485-1.372-2.367-.391-4.743.576-5.549 1.075 1.846 2.682 4.631 4.828 8.348Z"
    fill="#fff"
  />
  <defs>
    <linearGradient id="a" x1="18" y1="0" x2="18" y2="36" gradientUnits="userSpaceOnUse">
      <stop stop-color="#18BFFB" />
      <stop offset="1" stop-color="#2072F3" />
    </linearGradient>
  </defs>
</svg>`;
var jm = Object.freeze({
    __proto__: null,
    appStoreSvg: Wm
});
const Fm = M`<svg fill="none" viewBox="0 0 40 40">
  <g clip-path="url(#a)">
    <g clip-path="url(#b)">
      <circle cx="20" cy="19.89" r="20" fill="#000" />
      <g clip-path="url(#c)">
        <path
          fill="#fff"
          d="M28.77 23.3c-.69 1.99-2.75 5.52-4.87 5.56-1.4.03-1.86-.84-3.46-.84-1.61 0-2.12.81-3.45.86-2.25.1-5.72-5.1-5.72-9.62 0-4.15 2.9-6.2 5.42-6.25 1.36-.02 2.64.92 3.47.92.83 0 2.38-1.13 4.02-.97.68.03 2.6.28 3.84 2.08-3.27 2.14-2.76 6.61.75 8.25ZM24.2 7.88c-2.47.1-4.49 2.69-4.2 4.84 2.28.17 4.47-2.39 4.2-4.84Z"
        />
      </g>
    </g>
  </g>
  <defs>
    <clipPath id="a"><rect width="40" height="40" fill="#fff" rx="20" /></clipPath>
    <clipPath id="b"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
    <clipPath id="c"><path fill="#fff" d="M8 7.89h24v24H8z" /></clipPath>
  </defs>
</svg>`;
var Hm = Object.freeze({
    __proto__: null,
    appleSvg: Fm
});
const Vm = M`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M7 1.99a1 1 0 0 1 1 1v7.58l2.46-2.46a1 1 0 0 1 1.41 1.42L7.7 13.69a1 1 0 0 1-1.41 0L2.12 9.53A1 1 0 0 1 3.54 8.1L6 10.57V3a1 1 0 0 1 1-1Z"
    clip-rule="evenodd"
  />
</svg>`;
var Zm = Object.freeze({
    __proto__: null,
    arrowBottomSvg: Vm
});
const Gm = M`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M13 7.99a1 1 0 0 1-1 1H4.4l2.46 2.46a1 1 0 1 1-1.41 1.41L1.29 8.7a1 1 0 0 1 0-1.41L5.46 3.1a1 1 0 0 1 1.41 1.42L4.41 6.99H12a1 1 0 0 1 1 1Z"
    clip-rule="evenodd"
  />
</svg>`;
var qm = Object.freeze({
    __proto__: null,
    arrowLeftSvg: Gm
});
const Km = M`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M1 7.99a1 1 0 0 1 1-1h7.58L7.12 4.53A1 1 0 1 1 8.54 3.1l4.16 4.17a1 1 0 0 1 0 1.41l-4.16 4.17a1 1 0 1 1-1.42-1.41l2.46-2.46H2a1 1 0 0 1-1-1Z"
    clip-rule="evenodd"
  />
</svg>`;
var Ym = Object.freeze({
    __proto__: null,
    arrowRightSvg: Km
});
const Xm = M`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M7 13.99a1 1 0 0 1-1-1V5.4L3.54 7.86a1 1 0 0 1-1.42-1.41L6.3 2.28a1 1 0 0 1 1.41 0l4.17 4.17a1 1 0 1 1-1.41 1.41L8 5.4v7.59a1 1 0 0 1-1 1Z"
    clip-rule="evenodd"
  />
</svg>`;
var Jm = Object.freeze({
    __proto__: null,
    arrowTopSvg: Xm
});
const Qm = M`<svg
  xmlns="http://www.w3.org/2000/svg"
  width="12"
  height="13"
  viewBox="0 0 12 13"
  fill="none"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M5.61391 1.57124C5.85142 1.42873 6.14813 1.42873 6.38564 1.57124L11.0793 4.38749C11.9179 4.89067 11.5612 6.17864 10.5832 6.17864H9.96398V10.0358H10.2854C10.6996 10.0358 11.0354 10.3716 11.0354 10.7858C11.0354 11.2 10.6996 11.5358 10.2854 11.5358H1.71416C1.29995 11.5358 0.964172 11.2 0.964172 10.7858C0.964172 10.3716 1.29995 10.0358 1.71416 10.0358H2.03558L2.03558 6.17864H1.41637C0.438389 6.17864 0.0816547 4.89066 0.920263 4.38749L5.61391 1.57124ZM3.53554 6.17864V10.0358H5.24979V6.17864H3.53554ZM6.74976 6.17864V10.0358H8.46401V6.17864H6.74976ZM8.64913 4.67864H3.35043L5.99978 3.089L8.64913 4.67864Z"
    fill="currentColor"
  /></svg
>`;
var e3 = Object.freeze({
    __proto__: null,
    bankSvg: Qm
});
const t3 = M`<svg fill="none" viewBox="0 0 20 20">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M4 6.4a1 1 0 0 1-.46.89 6.98 6.98 0 0 0 .38 6.18A7 7 0 0 0 16.46 7.3a1 1 0 0 1-.47-.92 7 7 0 0 0-12 .03Zm-2.02-.5a9 9 0 1 1 16.03 8.2A9 9 0 0 1 1.98 5.9Z"
    clip-rule="evenodd"
  />
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M6.03 8.63c-1.46-.3-2.72-.75-3.6-1.35l-.02-.01-.14-.11a1 1 0 0 1 1.2-1.6l.1.08c.6.4 1.52.74 2.69 1 .16-.99.39-1.88.67-2.65.3-.79.68-1.5 1.15-2.02A2.58 2.58 0 0 1 9.99 1c.8 0 1.45.44 1.92.97.47.52.84 1.23 1.14 2.02.29.77.52 1.66.68 2.64a8 8 0 0 0 2.7-1l.26-.18h.48a1 1 0 0 1 .12 2c-.86.51-2.01.91-3.34 1.18a22.24 22.24 0 0 1-.03 3.19c1.45.29 2.7.73 3.58 1.31a1 1 0 0 1-1.1 1.68c-.6-.4-1.56-.76-2.75-1-.15.8-.36 1.55-.6 2.2-.3.79-.67 1.5-1.14 2.02-.47.53-1.12.97-1.92.97-.8 0-1.45-.44-1.91-.97a6.51 6.51 0 0 1-1.15-2.02c-.24-.65-.44-1.4-.6-2.2-1.18.24-2.13.6-2.73.99a1 1 0 1 1-1.1-1.67c.88-.58 2.12-1.03 3.57-1.31a22.03 22.03 0 0 1-.04-3.2Zm2.2-1.7c.15-.86.34-1.61.58-2.24.24-.65.51-1.12.76-1.4.25-.28.4-.29.42-.29.03 0 .17.01.42.3.25.27.52.74.77 1.4.23.62.43 1.37.57 2.22a19.96 19.96 0 0 1-3.52 0Zm-.18 4.6a20.1 20.1 0 0 1-.03-2.62 21.95 21.95 0 0 0 3.94 0 20.4 20.4 0 0 1-.03 2.63 21.97 21.97 0 0 0-3.88 0Zm.27 2c.13.66.3 1.26.49 1.78.24.65.51 1.12.76 1.4.25.28.4.29.42.29.03 0 .17-.01.42-.3.25-.27.52-.74.77-1.4.19-.5.36-1.1.49-1.78a20.03 20.03 0 0 0-3.35 0Z"
    clip-rule="evenodd"
  />
</svg>`;
var r3 = Object.freeze({
    __proto__: null,
    browserSvg: t3
});
const n3 = M`<svg
  xmlns="http://www.w3.org/2000/svg"
  width="12"
  height="13"
  viewBox="0 0 12 13"
  fill="none"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M4.16072 2C4.17367 2 4.18665 2 4.19968 2L7.83857 2C8.36772 1.99998 8.82398 1.99996 9.19518 2.04018C9.5895 2.0829 9.97577 2.17811 10.3221 2.42971C10.5131 2.56849 10.6811 2.73647 10.8198 2.92749C11.0714 3.27379 11.1666 3.66007 11.2094 4.0544C11.2496 4.42561 11.2496 4.88188 11.2495 5.41105V7.58896C11.2496 8.11812 11.2496 8.57439 11.2094 8.94561C11.1666 9.33994 11.0714 9.72621 10.8198 10.0725C10.6811 10.2635 10.5131 10.4315 10.3221 10.5703C9.97577 10.8219 9.5895 10.9171 9.19518 10.9598C8.82398 11 8.36772 11 7.83856 11H4.16073C3.63157 11 3.17531 11 2.80411 10.9598C2.40979 10.9171 2.02352 10.8219 1.67722 10.5703C1.48621 10.4315 1.31824 10.2635 1.17946 10.0725C0.927858 9.72621 0.832652 9.33994 0.78993 8.94561C0.749713 8.5744 0.749733 8.11813 0.749757 7.58896L0.749758 5.45C0.749758 5.43697 0.749758 5.42399 0.749757 5.41104C0.749733 4.88188 0.749713 4.42561 0.78993 4.0544C0.832652 3.66007 0.927858 3.27379 1.17946 2.92749C1.31824 2.73647 1.48621 2.56849 1.67722 2.42971C2.02352 2.17811 2.40979 2.0829 2.80411 2.04018C3.17531 1.99996 3.63157 1.99998 4.16072 2ZM2.96567 3.53145C2.69897 3.56034 2.60687 3.60837 2.55888 3.64324C2.49521 3.6895 2.43922 3.74549 2.39296 3.80916C2.35809 3.85715 2.31007 3.94926 2.28117 4.21597C2.26629 4.35335 2.25844 4.51311 2.25431 4.70832H9.74498C9.74085 4.51311 9.733 4.35335 9.71812 4.21597C9.68922 3.94926 9.6412 3.85715 9.60633 3.80916C9.56007 3.74549 9.50408 3.6895 9.44041 3.64324C9.39242 3.60837 9.30031 3.56034 9.03362 3.53145C8.75288 3.50103 8.37876 3.5 7.79961 3.5H4.19968C3.62053 3.5 3.24641 3.50103 2.96567 3.53145ZM9.74956 6.20832H2.24973V7.55C2.24973 8.12917 2.25076 8.5033 2.28117 8.78404C2.31007 9.05074 2.35809 9.14285 2.39296 9.19084C2.43922 9.25451 2.49521 9.31051 2.55888 9.35677C2.60687 9.39163 2.69897 9.43966 2.96567 9.46856C3.24641 9.49897 3.62053 9.5 4.19968 9.5H7.79961C8.37876 9.5 8.75288 9.49897 9.03362 9.46856C9.30032 9.43966 9.39242 9.39163 9.44041 9.35677C9.50408 9.31051 9.56007 9.25451 9.60633 9.19084C9.6412 9.14285 9.68922 9.05075 9.71812 8.78404C9.74854 8.5033 9.74956 8.12917 9.74956 7.55V6.20832ZM6.74963 8C6.74963 7.58579 7.08541 7.25 7.49961 7.25H8.2496C8.6638 7.25 8.99958 7.58579 8.99958 8C8.99958 8.41422 8.6638 8.75 8.2496 8.75H7.49961C7.08541 8.75 6.74963 8.41422 6.74963 8Z"
    fill="currentColor"
  /></svg
>`;
var i3 = Object.freeze({
    __proto__: null,
    cardSvg: n3
});
const o3 = M`<svg
  width="28"
  height="28"
  viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M25.5297 4.92733C26.1221 5.4242 26.1996 6.30724 25.7027 6.89966L12.2836 22.8997C12.0316 23.2001 11.6652 23.3811 11.2735 23.3986C10.8817 23.4161 10.5006 23.2686 10.2228 22.9919L2.38218 15.1815C1.83439 14.6358 1.83268 13.7494 2.37835 13.2016C2.92403 12.6538 3.81046 12.6521 4.35825 13.1978L11.1183 19.9317L23.5573 5.10036C24.0542 4.50794 24.9372 4.43047 25.5297 4.92733Z"
    fill="currentColor"/>
</svg>
`;
var s3 = Object.freeze({
    __proto__: null,
    checkmarkSvg: o3
});
const a3 = M`<svg fill="none" viewBox="0 0 14 14">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M12.9576 2.23383C13.3807 2.58873 13.4361 3.21947 13.0812 3.64263L6.37159 11.6426C6.19161 11.8572 5.92989 11.9865 5.65009 11.999C5.3703 12.0115 5.09808 11.9062 4.89965 11.7085L0.979321 7.80331C0.588042 7.41354 0.586817 6.78038 0.976585 6.3891C1.36635 5.99782 1.99952 5.99659 2.3908 6.38636L5.53928 9.52268L11.5488 2.35742C11.9037 1.93426 12.5344 1.87893 12.9576 2.23383Z"
    clip-rule="evenodd"
  />
</svg>`;
var c3 = Object.freeze({
    __proto__: null,
    checkmarkBoldSvg: a3
});
const l3 = M`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M1.46 4.96a1 1 0 0 1 1.41 0L8 10.09l5.13-5.13a1 1 0 1 1 1.41 1.41l-5.83 5.84a1 1 0 0 1-1.42 0L1.46 6.37a1 1 0 0 1 0-1.41Z"
    clip-rule="evenodd"
  />
</svg>`;
var d3 = Object.freeze({
    __proto__: null,
    chevronBottomSvg: l3
});
const u3 = M`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M11.04 1.46a1 1 0 0 1 0 1.41L5.91 8l5.13 5.13a1 1 0 1 1-1.41 1.41L3.79 8.71a1 1 0 0 1 0-1.42l5.84-5.83a1 1 0 0 1 1.41 0Z"
    clip-rule="evenodd"
  />
</svg>`;
var h3 = Object.freeze({
    __proto__: null,
    chevronLeftSvg: u3
});
const p3 = M`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M4.96 14.54a1 1 0 0 1 0-1.41L10.09 8 4.96 2.87a1 1 0 0 1 1.41-1.41l5.84 5.83a1 1 0 0 1 0 1.42l-5.84 5.83a1 1 0 0 1-1.41 0Z"
    clip-rule="evenodd"
  />
</svg>`;
var f3 = Object.freeze({
    __proto__: null,
    chevronRightSvg: p3
});
const g3 = M`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M14.54 11.04a1 1 0 0 1-1.41 0L8 5.92l-5.13 5.12a1 1 0 1 1-1.41-1.41l5.83-5.84a1 1 0 0 1 1.42 0l5.83 5.84a1 1 0 0 1 0 1.41Z"
    clip-rule="evenodd"
  />
</svg>`;
var w3 = Object.freeze({
    __proto__: null,
    chevronTopSvg: g3
});
const m3 = M`<svg width="36" height="36" fill="none">
  <path
    fill="#fff"
    fill-opacity=".05"
    d="M0 14.94c0-5.55 0-8.326 1.182-10.4a9 9 0 0 1 3.359-3.358C6.614 0 9.389 0 14.94 0h6.12c5.55 0 8.326 0 10.4 1.182a9 9 0 0 1 3.358 3.359C36 6.614 36 9.389 36 14.94v6.12c0 5.55 0 8.326-1.182 10.4a9 9 0 0 1-3.359 3.358C29.386 36 26.611 36 21.06 36h-6.12c-5.55 0-8.326 0-10.4-1.182a9 9 0 0 1-3.358-3.359C0 29.386 0 26.611 0 21.06v-6.12Z"
  />
  <path
    stroke="#fff"
    stroke-opacity=".05"
    d="M14.94.5h6.12c2.785 0 4.84 0 6.46.146 1.612.144 2.743.43 3.691.97a8.5 8.5 0 0 1 3.172 3.173c.541.948.826 2.08.971 3.692.145 1.62.146 3.675.146 6.459v6.12c0 2.785 0 4.84-.146 6.46-.145 1.612-.43 2.743-.97 3.691a8.5 8.5 0 0 1-3.173 3.172c-.948.541-2.08.826-3.692.971-1.62.145-3.674.146-6.459.146h-6.12c-2.784 0-4.84 0-6.46-.146-1.612-.145-2.743-.43-3.691-.97a8.5 8.5 0 0 1-3.172-3.173c-.541-.948-.827-2.08-.971-3.692C.5 25.9.5 23.845.5 21.06v-6.12c0-2.784 0-4.84.146-6.46.144-1.612.43-2.743.97-3.691A8.5 8.5 0 0 1 4.79 1.617C5.737 1.076 6.869.79 8.48.646 10.1.5 12.156.5 14.94.5Z"
  />
  <path
    fill="url(#a)"
    d="M17.998 10.8h12.469a14.397 14.397 0 0 0-24.938.001l6.234 10.798.006-.001a7.19 7.19 0 0 1 6.23-10.799Z"
  />
  <path
    fill="url(#b)"
    d="m24.237 21.598-6.234 10.798A14.397 14.397 0 0 0 30.47 10.798H18.002l-.002.006a7.191 7.191 0 0 1 6.237 10.794Z"
  />
  <path
    fill="url(#c)"
    d="M11.765 21.601 5.531 10.803A14.396 14.396 0 0 0 18.001 32.4l6.235-10.798-.004-.004a7.19 7.19 0 0 1-12.466.004Z"
  />
  <path fill="#fff" d="M18 25.2a7.2 7.2 0 1 0 0-14.4 7.2 7.2 0 0 0 0 14.4Z" />
  <path fill="#1A73E8" d="M18 23.7a5.7 5.7 0 1 0 0-11.4 5.7 5.7 0 0 0 0 11.4Z" />
  <defs>
    <linearGradient
      id="a"
      x1="6.294"
      x2="41.1"
      y1="5.995"
      y2="5.995"
      gradientUnits="userSpaceOnUse"
    >
      <stop stop-color="#D93025" />
      <stop offset="1" stop-color="#EA4335" />
    </linearGradient>
    <linearGradient
      id="b"
      x1="20.953"
      x2="37.194"
      y1="32.143"
      y2="2.701"
      gradientUnits="userSpaceOnUse"
    >
      <stop stop-color="#FCC934" />
      <stop offset="1" stop-color="#FBBC04" />
    </linearGradient>
    <linearGradient
      id="c"
      x1="25.873"
      x2="9.632"
      y1="31.2"
      y2="1.759"
      gradientUnits="userSpaceOnUse"
    >
      <stop stop-color="#1E8E3E" />
      <stop offset="1" stop-color="#34A853" />
    </linearGradient>
  </defs>
</svg>`;
var b3 = Object.freeze({
    __proto__: null,
    chromeStoreSvg: m3
});
const v3 = M`<svg width="14" height="14" viewBox="0 0 14 14" fill="none">
  <path 
    fill-rule="evenodd" 
    clip-rule="evenodd" 
    d="M7.00235 2C4.24 2 2.00067 4.23858 2.00067 7C2.00067 9.76142 4.24 12 7.00235 12C9.7647 12 12.004 9.76142 12.004 7C12.004 4.23858 9.7647 2 7.00235 2ZM0 7C0 3.13401 3.13506 0 7.00235 0C10.8696 0 14.0047 3.13401 14.0047 7C14.0047 10.866 10.8696 14 7.00235 14C3.13506 14 0 10.866 0 7ZM7.00235 3C7.55482 3 8.00269 3.44771 8.00269 4V6.58579L9.85327 8.43575C10.2439 8.82627 10.2439 9.45944 9.85327 9.84996C9.46262 10.2405 8.82924 10.2405 8.43858 9.84996L6.29501 7.70711C6.10741 7.51957 6.00201 7.26522 6.00201 7V4C6.00201 3.44771 6.44988 3 7.00235 3Z" 
    fill="currentColor"
  />
</svg>`;
var C3 = Object.freeze({
    __proto__: null,
    clockSvg: v3
});
const y3 = M`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M2.54 2.54a1 1 0 0 1 1.42 0L8 6.6l4.04-4.05a1 1 0 1 1 1.42 1.42L9.4 8l4.05 4.04a1 1 0 0 1-1.42 1.42L8 9.4l-4.04 4.05a1 1 0 0 1-1.42-1.42L6.6 8 2.54 3.96a1 1 0 0 1 0-1.42Z"
    clip-rule="evenodd"
  />
</svg>`;
var x3 = Object.freeze({
    __proto__: null,
    closeSvg: y3
});
const E3 = M`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M8 2a6 6 0 1 0 0 12A6 6 0 0 0 8 2ZM0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8Zm10.66-2.65a1 1 0 0 1 .23 1.06L9.83 9.24a1 1 0 0 1-.59.58l-2.83 1.06A1 1 0 0 1 5.13 9.6l1.06-2.82a1 1 0 0 1 .58-.59L9.6 5.12a1 1 0 0 1 1.06.23ZM7.9 7.89l-.13.35.35-.13.12-.35-.34.13Z"
    clip-rule="evenodd"
  />
</svg>`;
var A3 = Object.freeze({
    __proto__: null,
    compassSvg: E3
});
const S3 = M`<svg fill="none" viewBox="0 0 20 20">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M10 3a7 7 0 0 0-6.85 8.44l8.29-8.3C10.97 3.06 10.49 3 10 3Zm3.49.93-9.56 9.56c.32.55.71 1.06 1.16 1.5L15 5.1a7.03 7.03 0 0 0-1.5-1.16Zm2.7 2.8-9.46 9.46a7 7 0 0 0 9.46-9.46ZM1.99 5.9A9 9 0 1 1 18 14.09 9 9 0 0 1 1.98 5.91Z"
    clip-rule="evenodd"
  />
</svg>`;
var _3 = Object.freeze({
    __proto__: null,
    coinPlaceholderSvg: S3
});
const I3 = M`<svg
  xmlns="http://www.w3.org/2000/svg"
  width="16"
  height="16"
  viewBox="0 0 16 16"
  fill="none"
>
  <path
    fill="currentColor"
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M9.21498 1.28565H10.5944C11.1458 1.28562 11.6246 1.2856 12.0182 1.32093C12.4353 1.35836 12.853 1.44155 13.2486 1.66724C13.7005 1.92498 14.0749 2.29935 14.3326 2.75122C14.5583 3.14689 14.6415 3.56456 14.6789 3.9817C14.7143 4.37531 14.7142 4.85403 14.7142 5.40545V6.78489C14.7142 7.33631 14.7143 7.81503 14.6789 8.20865C14.6415 8.62578 14.5583 9.04345 14.3326 9.43912C14.0749 9.89099 13.7005 10.2654 13.2486 10.5231C12.853 10.7488 12.4353 10.832 12.0182 10.8694C11.7003 10.8979 11.3269 10.9034 10.9045 10.9045C10.9034 11.3269 10.8979 11.7003 10.8694 12.0182C10.832 12.4353 10.7488 12.853 10.5231 13.2486C10.2654 13.7005 9.89099 14.0749 9.43912 14.3326C9.04345 14.5583 8.62578 14.6415 8.20865 14.6789C7.81503 14.7143 7.33631 14.7142 6.78489 14.7142H5.40545C4.85403 14.7142 4.37531 14.7143 3.9817 14.6789C3.56456 14.6415 3.14689 14.5583 2.75122 14.3326C2.29935 14.0749 1.92498 13.7005 1.66724 13.2486C1.44155 12.853 1.35836 12.4353 1.32093 12.0182C1.2856 11.6246 1.28562 11.1458 1.28565 10.5944V9.21498C1.28562 8.66356 1.2856 8.18484 1.32093 7.79122C1.35836 7.37409 1.44155 6.95642 1.66724 6.56074C1.92498 6.10887 2.29935 5.73451 2.75122 5.47677C3.14689 5.25108 3.56456 5.16789 3.9817 5.13045C4.2996 5.10192 4.67301 5.09645 5.09541 5.09541C5.09645 4.67302 5.10192 4.2996 5.13045 3.9817C5.16789 3.56456 5.25108 3.14689 5.47676 2.75122C5.73451 2.29935 6.10887 1.92498 6.56074 1.66724C6.95642 1.44155 7.37409 1.35836 7.79122 1.32093C8.18484 1.2856 8.66356 1.28562 9.21498 1.28565ZM5.09541 7.09552C4.68397 7.09667 4.39263 7.10161 4.16046 7.12245C3.88053 7.14757 3.78516 7.18949 3.74214 7.21403C3.60139 7.29431 3.48478 7.41091 3.4045 7.55166C3.37997 7.59468 3.33804 7.69005 3.31292 7.96999C3.28659 8.26345 3.28565 8.65147 3.28565 9.25708V10.5523C3.28565 11.1579 3.28659 11.5459 3.31292 11.8394C3.33804 12.1193 3.37997 12.2147 3.4045 12.2577C3.48478 12.3985 3.60139 12.5151 3.74214 12.5954C3.78516 12.6199 3.88053 12.6618 4.16046 12.6869C4.45393 12.7133 4.84195 12.7142 5.44755 12.7142H6.74279C7.3484 12.7142 7.73641 12.7133 8.02988 12.6869C8.30981 12.6618 8.40518 12.6199 8.44821 12.5954C8.58895 12.5151 8.70556 12.3985 8.78584 12.2577C8.81038 12.2147 8.8523 12.1193 8.87742 11.8394C8.89825 11.6072 8.90319 11.3159 8.90435 10.9045C8.48219 10.9034 8.10898 10.8979 7.79122 10.8694C7.37409 10.832 6.95641 10.7488 6.56074 10.5231C6.10887 10.2654 5.73451 9.89099 5.47676 9.43912C5.25108 9.04345 5.16789 8.62578 5.13045 8.20865C5.10194 7.89089 5.09645 7.51767 5.09541 7.09552ZM7.96999 3.31292C7.69005 3.33804 7.59468 3.37997 7.55166 3.4045C7.41091 3.48478 7.29431 3.60139 7.21403 3.74214C7.18949 3.78516 7.14757 3.88053 7.12245 4.16046C7.09611 4.45393 7.09517 4.84195 7.09517 5.44755V6.74279C7.09517 7.3484 7.09611 7.73641 7.12245 8.02988C7.14757 8.30981 7.18949 8.40518 7.21403 8.4482C7.29431 8.58895 7.41091 8.70556 7.55166 8.78584C7.59468 8.81038 7.69005 8.8523 7.96999 8.87742C8.26345 8.90376 8.65147 8.9047 9.25708 8.9047H10.5523C11.1579 8.9047 11.5459 8.90376 11.8394 8.87742C12.1193 8.8523 12.2147 8.81038 12.2577 8.78584C12.3985 8.70556 12.5151 8.58895 12.5954 8.4482C12.6199 8.40518 12.6618 8.30981 12.6869 8.02988C12.7133 7.73641 12.7142 7.3484 12.7142 6.74279V5.44755C12.7142 4.84195 12.7133 4.45393 12.6869 4.16046C12.6618 3.88053 12.6199 3.78516 12.5954 3.74214C12.5151 3.60139 12.3985 3.48478 12.2577 3.4045C12.2147 3.37997 12.1193 3.33804 11.8394 3.31292C11.5459 3.28659 11.1579 3.28565 10.5523 3.28565H9.25708C8.65147 3.28565 8.26345 3.28659 7.96999 3.31292Z"
    fill="#788181"
  /></svg
>`;
var N3 = Object.freeze({
    __proto__: null,
    copySvg: I3
});
const k3 = M` <svg fill="none" viewBox="0 0 13 4">
  <path fill="currentColor" d="M.5 0h12L8.9 3.13a3.76 3.76 0 0 1-4.8 0L.5 0Z" />
</svg>`;
var T3 = Object.freeze({
    __proto__: null,
    cursorSvg: k3
});
const O3 = M`<svg fill="none" viewBox="0 0 14 6">
  <path style="fill: var(--wui-color-bg-150);" d="M0 1h14L9.21 5.12a3.31 3.31 0 0 1-4.49 0L0 1Z" />
  <path
    style="stroke: var(--wui-color-inverse-100);"
    stroke-opacity=".05"
    d="M1.33 1.5h11.32L8.88 4.75l-.01.01a2.81 2.81 0 0 1-3.8 0l-.02-.01L1.33 1.5Z"
  />
  <path
    style="fill: var(--wui-color-bg-150);"
    d="M1.25.71h11.5L9.21 3.88a3.31 3.31 0 0 1-4.49 0L1.25.71Z"
  />
</svg> `;
var $3 = Object.freeze({
    __proto__: null,
    cursorTransparentSvg: O3
});
const P3 = M`<svg fill="none" viewBox="0 0 20 20">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M13.66 2H6.34c-1.07 0-1.96 0-2.68.08-.74.08-1.42.25-2.01.68a4 4 0 0 0-.89.89c-.43.6-.6 1.27-.68 2.01C0 6.38 0 7.26 0 8.34v.89c0 1.07 0 1.96.08 2.68.08.74.25 1.42.68 2.01a4 4 0 0 0 .89.89c.6.43 1.27.6 2.01.68a27 27 0 0 0 2.68.08h7.32a27 27 0 0 0 2.68-.08 4.03 4.03 0 0 0 2.01-.68 4 4 0 0 0 .89-.89c.43-.6.6-1.27.68-2.01.08-.72.08-1.6.08-2.68v-.89c0-1.07 0-1.96-.08-2.68a4.04 4.04 0 0 0-.68-2.01 4 4 0 0 0-.89-.89c-.6-.43-1.27-.6-2.01-.68C15.62 2 14.74 2 13.66 2ZM2.82 4.38c.2-.14.48-.25 1.06-.31C4.48 4 5.25 4 6.4 4h7.2c1.15 0 1.93 0 2.52.07.58.06.86.17 1.06.31a2 2 0 0 1 .44.44c.14.2.25.48.31 1.06.07.6.07 1.37.07 2.52v.77c0 1.15 0 1.93-.07 2.52-.06.58-.17.86-.31 1.06a2 2 0 0 1-.44.44c-.2.14-.48.25-1.06.32-.6.06-1.37.06-2.52.06H6.4c-1.15 0-1.93 0-2.52-.06-.58-.07-.86-.18-1.06-.32a2 2 0 0 1-.44-.44c-.14-.2-.25-.48-.31-1.06C2 11.1 2 10.32 2 9.17V8.4c0-1.15 0-1.93.07-2.52.06-.58.17-.86.31-1.06a2 2 0 0 1 .44-.44Z"
    clip-rule="evenodd"
  />
  <path fill="currentColor" d="M6.14 17.57a1 1 0 1 0 0 2h7.72a1 1 0 1 0 0-2H6.14Z" />
</svg>`;
var B3 = Object.freeze({
    __proto__: null,
    desktopSvg: P3
});
const R3 = M`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M6.07 1h.57a1 1 0 0 1 0 2h-.52c-.98 0-1.64 0-2.14.06-.48.05-.7.14-.84.24-.13.1-.25.22-.34.35-.1.14-.2.35-.25.83-.05.5-.05 1.16-.05 2.15v2.74c0 .99 0 1.65.05 2.15.05.48.14.7.25.83.1.14.2.25.34.35.14.1.36.2.84.25.5.05 1.16.05 2.14.05h.52a1 1 0 0 1 0 2h-.57c-.92 0-1.69 0-2.3-.07a3.6 3.6 0 0 1-1.8-.61c-.3-.22-.57-.49-.8-.8a3.6 3.6 0 0 1-.6-1.79C.5 11.11.5 10.35.5 9.43V6.58c0-.92 0-1.7.06-2.31a3.6 3.6 0 0 1 .62-1.8c.22-.3.48-.57.79-.79a3.6 3.6 0 0 1 1.8-.61C4.37 1 5.14 1 6.06 1ZM9.5 3a1 1 0 0 1 1.42 0l4.28 4.3a1 1 0 0 1 0 1.4L10.93 13a1 1 0 0 1-1.42-1.42L12.1 9H6.8a1 1 0 1 1 0-2h5.3L9.51 4.42a1 1 0 0 1 0-1.41Z"
    clip-rule="evenodd"
  />
</svg>`;
var L3 = Object.freeze({
    __proto__: null,
    disconnectSvg: R3
});
const U3 = M`<svg fill="none" viewBox="0 0 40 40">
  <g clip-path="url(#a)">
    <g clip-path="url(#b)">
      <circle cx="20" cy="19.89" r="20" fill="#5865F2" />
      <path
        fill="#fff"
        fill-rule="evenodd"
        d="M25.71 28.15C30.25 28 32 25.02 32 25.02c0-6.61-2.96-11.98-2.96-11.98-2.96-2.22-5.77-2.15-5.77-2.15l-.29.32c3.5 1.07 5.12 2.61 5.12 2.61a16.75 16.75 0 0 0-10.34-1.93l-.35.04a15.43 15.43 0 0 0-5.88 1.9s1.71-1.63 5.4-2.7l-.2-.24s-2.81-.07-5.77 2.15c0 0-2.96 5.37-2.96 11.98 0 0 1.73 2.98 6.27 3.13l1.37-1.7c-2.6-.79-3.6-2.43-3.6-2.43l.58.35.09.06.08.04.02.01.08.05a17.25 17.25 0 0 0 4.52 1.58 14.4 14.4 0 0 0 8.3-.86c.72-.27 1.52-.66 2.37-1.21 0 0-1.03 1.68-3.72 2.44.61.78 1.35 1.67 1.35 1.67Zm-9.55-9.6c-1.17 0-2.1 1.03-2.1 2.28 0 1.25.95 2.28 2.1 2.28 1.17 0 2.1-1.03 2.1-2.28.01-1.25-.93-2.28-2.1-2.28Zm7.5 0c-1.17 0-2.1 1.03-2.1 2.28 0 1.25.95 2.28 2.1 2.28 1.17 0 2.1-1.03 2.1-2.28 0-1.25-.93-2.28-2.1-2.28Z"
        clip-rule="evenodd"
      />
    </g>
  </g>
  <defs>
    <clipPath id="a"><rect width="40" height="40" fill="#fff" rx="20" /></clipPath>
    <clipPath id="b"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
  </defs>
</svg>`;
var M3 = Object.freeze({
    __proto__: null,
    discordSvg: U3
});
const D3 = M`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    d="M4.25 7a.63.63 0 0 0-.63.63v3.97c0 .28-.2.51-.47.54l-.75.07a.93.93 0 0 1-.9-.47A7.51 7.51 0 0 1 5.54.92a7.5 7.5 0 0 1 9.54 4.62c.12.35.06.72-.16 1-.74.97-1.68 1.78-2.6 2.44V4.44a.64.64 0 0 0-.63-.64h-1.06c-.35 0-.63.3-.63.64v5.5c0 .23-.12.42-.32.5l-.52.23V6.05c0-.36-.3-.64-.64-.64H7.45c-.35 0-.64.3-.64.64v4.97c0 .25-.17.46-.4.52a5.8 5.8 0 0 0-.45.11v-4c0-.36-.3-.65-.64-.65H4.25ZM14.07 12.4A7.49 7.49 0 0 1 3.6 14.08c4.09-.58 9.14-2.5 11.87-6.6v.03a7.56 7.56 0 0 1-1.41 4.91Z"
  />
</svg>`;
var z3 = Object.freeze({
    __proto__: null,
    etherscanSvg: D3
});
const W3 = M`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M6.71 2.99a.57.57 0 0 0-.57.57 1 1 0 0 1-1 1c-.58 0-.96 0-1.24.03-.27.03-.37.07-.42.1a.97.97 0 0 0-.36.35c-.04.08-.09.21-.11.67a2.57 2.57 0 0 1 0 5.13c.02.45.07.6.11.66.09.15.21.28.36.36.07.04.21.1.67.12a2.57 2.57 0 0 1 5.12 0c.46-.03.6-.08.67-.12a.97.97 0 0 0 .36-.36c.03-.04.07-.14.1-.41.02-.29.03-.66.03-1.24a1 1 0 0 1 1-1 .57.57 0 0 0 0-1.15 1 1 0 0 1-1-1c0-.58 0-.95-.03-1.24a1.04 1.04 0 0 0-.1-.42.97.97 0 0 0-.36-.36 1.04 1.04 0 0 0-.42-.1c-.28-.02-.65-.02-1.24-.02a1 1 0 0 1-1-1 .57.57 0 0 0-.57-.57ZM5.15 13.98a1 1 0 0 0 .99-1v-.78a.57.57 0 0 1 1.14 0v.78a1 1 0 0 0 .99 1H8.36a66.26 66.26 0 0 0 .73 0 3.78 3.78 0 0 0 1.84-.38c.46-.26.85-.64 1.1-1.1.23-.4.32-.8.36-1.22.02-.2.03-.4.03-.63a2.57 2.57 0 0 0 0-4.75c0-.23-.01-.44-.03-.63a2.96 2.96 0 0 0-.35-1.22 2.97 2.97 0 0 0-1.1-1.1c-.4-.22-.8-.31-1.22-.35a8.7 8.7 0 0 0-.64-.04 2.57 2.57 0 0 0-4.74 0c-.23 0-.44.02-.63.04-.42.04-.83.13-1.22.35-.46.26-.84.64-1.1 1.1-.33.57-.37 1.2-.39 1.84a21.39 21.39 0 0 0 0 .72v.1a1 1 0 0 0 1 .99h.78a.57.57 0 0 1 0 1.15h-.77a1 1 0 0 0-1 .98v.1a63.87 63.87 0 0 0 0 .73c0 .64.05 1.27.38 1.83.26.47.64.85 1.1 1.11.56.32 1.2.37 1.84.38a20.93 20.93 0 0 0 .72 0h.1Z"
    clip-rule="evenodd"
  />
</svg>`;
var j3 = Object.freeze({
    __proto__: null,
    extensionSvg: W3
});
const F3 = M`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M3.74 3.99a1 1 0 0 1 1-1H11a1 1 0 0 1 1 1v6.26a1 1 0 0 1-2 0V6.4l-6.3 6.3a1 1 0 0 1-1.4-1.42l6.29-6.3H4.74a1 1 0 0 1-1-1Z"
    clip-rule="evenodd"
  />
</svg>`;
var H3 = Object.freeze({
    __proto__: null,
    externalLinkSvg: F3
});
const V3 = M`<svg fill="none" viewBox="0 0 40 40">
  <g clip-path="url(#a)">
    <g clip-path="url(#b)">
      <circle cx="20" cy="19.89" r="20" fill="#1877F2" />
      <g clip-path="url(#c)">
        <path
          fill="#fff"
          d="M26 12.38h-2.89c-.92 0-1.61.38-1.61 1.34v1.66H26l-.36 4.5H21.5v12H17v-12h-3v-4.5h3V12.5c0-3.03 1.6-4.62 5.2-4.62H26v4.5Z"
        />
      </g>
    </g>
    <path
      fill="#1877F2"
      d="M40 20a20 20 0 1 0-23.13 19.76V25.78H11.8V20h5.07v-4.4c0-5.02 3-7.79 7.56-7.79 2.19 0 4.48.4 4.48.4v4.91h-2.53c-2.48 0-3.25 1.55-3.25 3.13V20h5.54l-.88 5.78h-4.66v13.98A20 20 0 0 0 40 20Z"
    />
    <path
      fill="#fff"
      d="m27.79 25.78.88-5.78h-5.55v-3.75c0-1.58.78-3.13 3.26-3.13h2.53V8.2s-2.3-.39-4.48-.39c-4.57 0-7.55 2.77-7.55 7.78V20H11.8v5.78h5.07v13.98a20.15 20.15 0 0 0 6.25 0V25.78h4.67Z"
    />
  </g>
  <defs>
    <clipPath id="a"><rect width="40" height="40" fill="#fff" rx="20" /></clipPath>
    <clipPath id="b"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
    <clipPath id="c"><path fill="#fff" d="M8 7.89h24v24H8z" /></clipPath>
  </defs>
</svg>`;
var Z3 = Object.freeze({
    __proto__: null,
    facebookSvg: V3
});
const G3 = M`<svg style="border-radius: 9999px; overflow: hidden;"  fill="none" viewBox="0 0 1000 1000">
  <rect width="1000" height="1000" rx="9999" ry="9999" fill="#855DCD"/>
  <path fill="#855DCD" d="M0 0h1000v1000H0V0Z" />
  <path
    fill="#fff"
    d="M320 248h354v504h-51.96V521.13h-.5c-5.76-63.8-59.31-113.81-124.54-113.81s-118.78 50-124.53 113.81h-.5V752H320V248Z"
  />
  <path
    fill="#fff"
    d="m225 320 21.16 71.46h17.9v289.09a16.29 16.29 0 0 0-16.28 16.24v19.49h-3.25a16.3 16.3 0 0 0-16.28 16.24V752h182.26v-19.48a16.22 16.22 0 0 0-16.28-16.24h-3.25v-19.5a16.22 16.22 0 0 0-16.28-16.23h-19.52V320H225Zm400.3 360.55a16.3 16.3 0 0 0-15.04 10.02 16.2 16.2 0 0 0-1.24 6.22v19.49h-3.25a16.29 16.29 0 0 0-16.27 16.24V752h182.24v-19.48a16.23 16.23 0 0 0-16.27-16.24h-3.25v-19.5a16.2 16.2 0 0 0-10.04-15 16.3 16.3 0 0 0-6.23-1.23v-289.1h17.9L775 320H644.82v360.55H625.3Z"
  />
</svg>`;
var q3 = Object.freeze({
    __proto__: null,
    farcasterSvg: G3
});
const K3 = M`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M0 3a1 1 0 0 1 1-1h14a1 1 0 1 1 0 2H1a1 1 0 0 1-1-1Zm2.63 5.25a1 1 0 0 1 1-1h8.75a1 1 0 1 1 0 2H3.63a1 1 0 0 1-1-1Zm2.62 5.25a1 1 0 0 1 1-1h3.5a1 1 0 0 1 0 2h-3.5a1 1 0 0 1-1-1Z"
    clip-rule="evenodd"
  />
</svg>`;
var Y3 = Object.freeze({
    __proto__: null,
    filtersSvg: K3
});
const X3 = M`<svg fill="none" viewBox="0 0 40 40">
  <g clip-path="url(#a)">
    <g clip-path="url(#b)">
      <circle cx="20" cy="19.89" r="20" fill="#1B1F23" />
      <g clip-path="url(#c)">
        <path
          fill="#fff"
          d="M8 19.89a12 12 0 1 1 15.8 11.38c-.6.12-.8-.26-.8-.57v-3.3c0-1.12-.4-1.85-.82-2.22 2.67-.3 5.48-1.31 5.48-5.92 0-1.31-.47-2.38-1.24-3.22.13-.3.54-1.52-.12-3.18 0 0-1-.32-3.3 1.23a11.54 11.54 0 0 0-6 0c-2.3-1.55-3.3-1.23-3.3-1.23a4.32 4.32 0 0 0-.12 3.18 4.64 4.64 0 0 0-1.24 3.22c0 4.6 2.8 5.63 5.47 5.93-.34.3-.65.83-.76 1.6-.69.31-2.42.84-3.5-1 0 0-.63-1.15-1.83-1.23 0 0-1.18-.02-.09.73 0 0 .8.37 1.34 1.76 0 0 .7 2.14 4.03 1.41v2.24c0 .31-.2.68-.8.57A12 12 0 0 1 8 19.9Z"
        />
      </g>
    </g>
  </g>
  <defs>
    <clipPath id="a"><rect width="40" height="40" fill="#fff" rx="20" /></clipPath>
    <clipPath id="b"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
    <clipPath id="c"><path fill="#fff" d="M8 7.89h24v24H8z" /></clipPath>
  </defs>
</svg>`;
var J3 = Object.freeze({
    __proto__: null,
    githubSvg: X3
});
const Q3 = M`<svg fill="none" viewBox="0 0 40 40">
  <path
    fill="#4285F4"
    d="M32.74 20.3c0-.93-.08-1.81-.24-2.66H20.26v5.03h7a6 6 0 0 1-2.62 3.91v3.28h4.22c2.46-2.27 3.88-5.6 3.88-9.56Z"
  />
  <path
    fill="#34A853"
    d="M20.26 33a12.4 12.4 0 0 0 8.6-3.14l-4.22-3.28a7.74 7.74 0 0 1-4.38 1.26 7.76 7.76 0 0 1-7.28-5.36H8.65v3.36A12.99 12.99 0 0 0 20.26 33Z"
  />
  <path
    fill="#FBBC05"
    d="M12.98 22.47a7.79 7.79 0 0 1 0-4.94v-3.36H8.65a12.84 12.84 0 0 0 0 11.66l3.37-2.63.96-.73Z"
  />
  <path
    fill="#EA4335"
    d="M20.26 12.18a7.1 7.1 0 0 1 4.98 1.93l3.72-3.72A12.47 12.47 0 0 0 20.26 7c-5.08 0-9.47 2.92-11.6 7.17l4.32 3.36a7.76 7.76 0 0 1 7.28-5.35Z"
  />
</svg>`;
var e5 = Object.freeze({
    __proto__: null,
    googleSvg: Q3
});
const t5 = M`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    d="M8.51 5.66a.83.83 0 0 0-.57-.2.83.83 0 0 0-.52.28.8.8 0 0 0-.25.52 1 1 0 0 1-2 0c0-.75.34-1.43.81-1.91a2.75 2.75 0 0 1 4.78 1.92c0 1.24-.8 1.86-1.25 2.2l-.04.03c-.47.36-.5.43-.5.65a1 1 0 1 1-2 0c0-1.25.8-1.86 1.24-2.2l.04-.04c.47-.36.5-.43.5-.65 0-.3-.1-.49-.24-.6ZM9.12 11.87a1.13 1.13 0 1 1-2.25 0 1.13 1.13 0 0 1 2.25 0Z"
  />
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8Zm8-6a6 6 0 1 0 0 12A6 6 0 0 0 8 2Z"
    clip-rule="evenodd"
  />
</svg>`;
var r5 = Object.freeze({
    __proto__: null,
    helpCircleSvg: t5
});
const n5 = M`<svg width="14" height="14" viewBox="0 0 14 14" fill="none">
  <path d="M4.98926 3.73932C4.2989 3.73932 3.73926 4.29896 3.73926 4.98932C3.73926 5.67968 4.2989 6.23932 4.98926 6.23932C5.67962 6.23932 6.23926 5.67968 6.23926 4.98932C6.23926 4.29896 5.67962 3.73932 4.98926 3.73932Z" fill="currentColor"/>
  <path fill-rule="evenodd" clip-rule="evenodd" d="M7.60497 0.500001H6.39504C5.41068 0.499977 4.59185 0.499958 3.93178 0.571471C3.24075 0.64634 2.60613 0.809093 2.04581 1.21619C1.72745 1.44749 1.44749 1.72745 1.21619 2.04581C0.809093 2.60613 0.64634 3.24075 0.571471 3.93178C0.499958 4.59185 0.499977 5.41065 0.500001 6.39501V7.57815C0.499998 8.37476 0.499995 9.05726 0.534869 9.62725C0.570123 10.2034 0.644114 10.7419 0.828442 11.2302C0.925651 11.4877 1.05235 11.7287 1.21619 11.9542C1.44749 12.2726 1.72745 12.5525 2.04581 12.7838C2.60613 13.1909 3.24075 13.3537 3.93178 13.4285C4.59185 13.5001 5.41066 13.5 6.39503 13.5H7.60496C8.58933 13.5 9.40815 13.5001 10.0682 13.4285C10.7593 13.3537 11.3939 13.1909 11.9542 12.7838C12.2726 12.5525 12.5525 12.2726 12.7838 11.9542C13.1909 11.3939 13.3537 10.7593 13.4285 10.0682C13.5 9.40816 13.5 8.58935 13.5 7.60497V6.39505C13.5 5.41068 13.5 4.59185 13.4285 3.93178C13.3537 3.24075 13.1909 2.60613 12.7838 2.04581C12.5525 1.72745 12.2726 1.44749 11.9542 1.21619C11.3939 0.809093 10.7593 0.64634 10.0682 0.571471C9.40816 0.499958 8.58933 0.499977 7.60497 0.500001ZM3.22138 2.83422C3.38394 2.71612 3.62634 2.61627 4.14721 2.55984C4.68679 2.50138 5.39655 2.5 6.45 2.5H7.55C8.60345 2.5 9.31322 2.50138 9.8528 2.55984C10.3737 2.61627 10.6161 2.71612 10.7786 2.83422C10.9272 2.94216 11.0578 3.07281 11.1658 3.22138C11.2839 3.38394 11.3837 3.62634 11.4402 4.14721C11.4986 4.68679 11.5 5.39655 11.5 6.45V6.49703C10.9674 6.11617 10.386 5.84936 9.74213 5.81948C8.40536 5.75745 7.3556 6.73051 6.40509 7.84229C6.33236 7.92737 6.27406 7.98735 6.22971 8.02911L6.1919 8.00514L6.17483 7.99427C6.09523 7.94353 5.98115 7.87083 5.85596 7.80302C5.56887 7.64752 5.18012 7.4921 4.68105 7.4921C4.66697 7.4921 4.6529 7.49239 4.63884 7.49299C3.79163 7.52878 3.09922 8.1106 2.62901 8.55472C2.58751 8.59392 2.54594 8.6339 2.50435 8.6745C2.50011 8.34653 2.5 7.97569 2.5 7.55V6.45C2.5 5.39655 2.50138 4.68679 2.55984 4.14721C2.61627 3.62634 2.71612 3.38394 2.83422 3.22138C2.94216 3.07281 3.07281 2.94216 3.22138 2.83422ZM10.3703 8.14825C10.6798 8.37526 11.043 8.71839 11.4832 9.20889C11.4744 9.44992 11.4608 9.662 11.4402 9.8528C11.3837 10.3737 11.2839 10.6161 11.1658 10.7786C11.0578 10.9272 10.9272 11.0578 10.7786 11.1658C10.6161 11.2839 10.3737 11.3837 9.8528 11.4402C9.31322 11.4986 8.60345 11.5 7.55 11.5H6.45C5.39655 11.5 4.68679 11.4986 4.14721 11.4402C3.62634 11.3837 3.38394 11.2839 3.22138 11.1658C3.15484 11.1174 3.0919 11.0645 3.03298 11.0075C3.10126 10.9356 3.16806 10.8649 3.23317 10.7959L3.29772 10.7276C3.55763 10.4525 3.78639 10.2126 4.00232 10.0087C4.22016 9.80294 4.39412 9.66364 4.53524 9.57742C4.63352 9.51738 4.69022 9.49897 4.71275 9.49345C4.76387 9.49804 4.81803 9.51537 4.90343 9.56162C4.96409 9.59447 5.02355 9.63225 5.11802 9.69238L5.12363 9.69595C5.20522 9.74789 5.32771 9.82587 5.46078 9.89278C5.76529 10.0459 6.21427 10.186 6.74977 10.0158C7.21485 9.86796 7.59367 9.52979 7.92525 9.14195C8.91377 7.98571 9.38267 7.80495 9.64941 7.81733C9.7858 7.82366 10.0101 7.884 10.3703 8.14825Z" fill="currentColor"/>
</svg>`;
var i5 = Object.freeze({
    __proto__: null,
    imageSvg: n5
});
const o5 = M`<svg
 xmlns="http://www.w3.org/2000/svg"
 width="28"
 height="28"
 viewBox="0 0 28 28"
 fill="none">
  <path
    fill="#949E9E"
    fill-rule="evenodd"
    d="M7.974 2.975h12.052c1.248 0 2.296 0 3.143.092.89.096 1.723.307 2.461.844a4.9 4.9 0 0 1 1.084 1.084c.537.738.748 1.57.844 2.461.092.847.092 1.895.092 3.143v6.802c0 1.248 0 2.296-.092 3.143-.096.89-.307 1.723-.844 2.461a4.9 4.9 0 0 1-1.084 1.084c-.738.537-1.57.748-2.461.844-.847.092-1.895.092-3.143.092H7.974c-1.247 0-2.296 0-3.143-.092-.89-.096-1.723-.307-2.461-.844a4.901 4.901 0 0 1-1.084-1.084c-.537-.738-.748-1.571-.844-2.461C.35 19.697.35 18.649.35 17.4v-6.802c0-1.248 0-2.296.092-3.143.096-.89.307-1.723.844-2.461A4.9 4.9 0 0 1 2.37 3.91c.738-.537 1.571-.748 2.461-.844.847-.092 1.895-.092 3.143-.092ZM5.133 5.85c-.652.071-.936.194-1.117.326a2.1 2.1 0 0 0-.465.465c-.132.181-.255.465-.325 1.117-.074.678-.076 1.573-.076 2.917v6.65c0 1.344.002 2.239.076 2.917.07.652.193.936.325 1.117a2.1 2.1 0 0 0 .465.465c.181.132.465.255 1.117.326.678.073 1.574.075 2.917.075h11.9c1.344 0 2.239-.002 2.917-.075.652-.071.936-.194 1.117-.326.179-.13.335-.286.465-.465.132-.181.255-.465.326-1.117.073-.678.075-1.573.075-2.917v-6.65c0-1.344-.002-2.239-.075-2.917-.071-.652-.194-.936-.326-1.117a2.1 2.1 0 0 0-.465-.465c-.181-.132-.465-.255-1.117-.326-.678-.073-1.573-.075-2.917-.075H8.05c-1.343 0-2.239.002-2.917.075Zm.467 7.275a3.15 3.15 0 1 1 6.3 0 3.15 3.15 0 0 1-6.3 0Zm8.75-1.75a1.4 1.4 0 0 1 1.4-1.4h3.5a1.4 1.4 0 0 1 0 2.8h-3.5a1.4 1.4 0 0 1-1.4-1.4Zm0 5.25a1.4 1.4 0 0 1 1.4-1.4H21a1.4 1.4 0 1 1 0 2.8h-5.25a1.4 1.4 0 0 1-1.4-1.4Z"
    clip-rule="evenodd"/>
</svg>`;
var s5 = Object.freeze({
    __proto__: null,
    idSvg: o5
});
const a5 = M`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    d="M6 10.49a1 1 0 1 0 2 0v-2a1 1 0 0 0-2 0v2ZM7 4.49a1 1 0 1 0 0 2 1 1 0 0 0 0-2Z"
  />
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M7 14.99a7 7 0 1 0 0-14 7 7 0 0 0 0 14Zm5-7a5 5 0 1 1-10 0 5 5 0 0 1 10 0Z"
    clip-rule="evenodd"
  />
</svg>`;
var c5 = Object.freeze({
    __proto__: null,
    infoCircleSvg: a5
});
const l5 = M`<svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M5.00177 1.78569C3.8179 1.78569 2.85819 2.74508 2.85819 3.92855C2.85819 4.52287 3.09928 5.05956 3.49077 5.4485L3.5005 5.45817C3.64381 5.60054 3.76515 5.72108 3.85631 5.81845C3.93747 5.90512 4.05255 6.03218 4.12889 6.1805C4.16999 6.26034 4.19 6.30843 4.21768 6.39385C4.22145 6.40546 4.22499 6.41703 4.22833 6.42855H5.77521C5.77854 6.41703 5.78208 6.40547 5.78585 6.39385C5.81353 6.30843 5.83354 6.26034 5.87464 6.1805C5.95098 6.03218 6.06606 5.90512 6.14722 5.81845C6.23839 5.72108 6.35973 5.60053 6.50304 5.45816L6.51276 5.4485C6.90425 5.05956 7.14534 4.52287 7.14534 3.92855C7.14534 2.74508 6.18563 1.78569 5.00177 1.78569ZM5.71629 7.85712H4.28724C4.28724 8.21403 4.28876 8.40985 4.30703 8.54571C4.30727 8.54748 4.30751 8.54921 4.30774 8.55091C4.30944 8.55115 4.31118 8.55138 4.31295 8.55162C4.44884 8.56989 4.64474 8.5714 5.00177 8.5714C5.3588 8.5714 5.55469 8.56989 5.69059 8.55162C5.69236 8.55138 5.69409 8.55115 5.69579 8.55091C5.69603 8.54921 5.69627 8.54748 5.6965 8.54571C5.71477 8.40985 5.71629 8.21403 5.71629 7.85712ZM2.85819 7.14283C2.85819 6.9948 2.85796 6.91114 2.8548 6.85032C2.85461 6.84656 2.85441 6.84309 2.85421 6.83988C2.84393 6.8282 2.83047 6.81334 2.81301 6.79469C2.74172 6.71856 2.63908 6.61643 2.48342 6.46178C1.83307 5.81566 1.42914 4.91859 1.42914 3.92855C1.42914 1.9561 3.02866 0.357117 5.00177 0.357117C6.97487 0.357117 8.57439 1.9561 8.57439 3.92855C8.57439 4.91859 8.17047 5.81566 7.52012 6.46178C7.36445 6.61643 7.26182 6.71856 7.19053 6.79469C7.17306 6.81334 7.1596 6.8282 7.14932 6.83988C7.14912 6.84309 7.14892 6.84656 7.14873 6.85032C7.14557 6.91114 7.14534 6.9948 7.14534 7.14283V7.85712C7.14534 7.87009 7.14535 7.88304 7.14535 7.89598C7.14541 8.19889 7.14547 8.49326 7.11281 8.73606C7.076 9.00978 6.98631 9.32212 6.72678 9.58156C6.46726 9.841 6.15481 9.93065 5.881 9.96745C5.63813 10.0001 5.34365 10 5.04064 9.99998C5.0277 9.99998 5.01474 9.99998 5.00177 9.99998C4.98879 9.99998 4.97583 9.99998 4.96289 9.99998C4.65988 10 4.36541 10.0001 4.12253 9.96745C3.84872 9.93065 3.53628 9.841 3.27675 9.58156C3.01722 9.32212 2.92753 9.00978 2.89072 8.73606C2.85807 8.49326 2.85812 8.19889 2.85818 7.89598C2.85819 7.88304 2.85819 7.87008 2.85819 7.85712V7.14283ZM7.1243 6.86977C7.12366 6.87069 7.1233 6.87116 7.12327 6.87119C7.12323 6.87123 7.12356 6.87076 7.1243 6.86977ZM2.88027 6.8712C2.88025 6.87119 2.87988 6.8707 2.87921 6.86975C2.87995 6.87072 2.88028 6.8712 2.88027 6.8712Z" fill="#949E9E"/>
</svg>`;
var d5 = Object.freeze({
    __proto__: null,
    lightbulbSvg: l5
});
const u5 = M`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M4.83 1.34h6.34c.68 0 1.26 0 1.73.04.5.05.97.15 1.42.4.52.3.95.72 1.24 1.24.26.45.35.92.4 1.42.04.47.04 1.05.04 1.73v3.71c0 .69 0 1.26-.04 1.74-.05.5-.14.97-.4 1.41-.3.52-.72.95-1.24 1.25-.45.25-.92.35-1.42.4-.47.03-1.05.03-1.73.03H4.83c-.68 0-1.26 0-1.73-.04-.5-.04-.97-.14-1.42-.4-.52-.29-.95-.72-1.24-1.24a3.39 3.39 0 0 1-.4-1.41A20.9 20.9 0 0 1 0 9.88v-3.7c0-.7 0-1.27.04-1.74.05-.5.14-.97.4-1.42.3-.52.72-.95 1.24-1.24.45-.25.92-.35 1.42-.4.47-.04 1.05-.04 1.73-.04ZM3.28 3.38c-.36.03-.51.08-.6.14-.21.11-.39.29-.5.5a.8.8 0 0 0-.08.19l5.16 3.44c.45.3 1.03.3 1.48 0L13.9 4.2a.79.79 0 0 0-.08-.2c-.11-.2-.29-.38-.5-.5-.09-.05-.24-.1-.6-.13-.37-.04-.86-.04-1.6-.04H4.88c-.73 0-1.22 0-1.6.04ZM14 6.54 9.85 9.31a3.33 3.33 0 0 1-3.7 0L2 6.54v3.3c0 .74 0 1.22.03 1.6.04.36.1.5.15.6.11.2.29.38.5.5.09.05.24.1.6.14.37.03.86.03 1.6.03h6.25c.73 0 1.22 0 1.6-.03.35-.03.5-.09.6-.14.2-.12.38-.3.5-.5.05-.1.1-.24.14-.6.03-.38.03-.86.03-1.6v-3.3Z"
    clip-rule="evenodd"
  />
</svg>`;
var h5 = Object.freeze({
    __proto__: null,
    mailSvg: u5
});
const p5 = M`<svg fill="none" viewBox="0 0 20 20">
  <path fill="currentColor" d="M10.81 5.81a2 2 0 1 1-4 0 2 2 0 0 1 4 0Z" />
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M3 4.75A4.75 4.75 0 0 1 7.75 0h4.5A4.75 4.75 0 0 1 17 4.75v10.5A4.75 4.75 0 0 1 12.25 20h-4.5A4.75 4.75 0 0 1 3 15.25V4.75ZM7.75 2A2.75 2.75 0 0 0 5 4.75v10.5A2.75 2.75 0 0 0 7.75 18h4.5A2.75 2.75 0 0 0 15 15.25V4.75A2.75 2.75 0 0 0 12.25 2h-4.5Z"
    clip-rule="evenodd"
  />
</svg>`;
var f5 = Object.freeze({
    __proto__: null,
    mobileSvg: p5
});
const g5 = M`<svg fill="none" viewBox="0 0 41 40">
  <path
    style="fill: var(--wui-color-fg-100);"
    fill-opacity=".05"
    d="M.6 20a20 20 0 1 1 40 0 20 20 0 0 1-40 0Z"
  />
  <path
    fill="#949E9E"
    d="M15.6 20.31a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0ZM23.1 20.31a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0ZM28.1 22.81a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z"
  />
</svg>`;
var w5 = Object.freeze({
    __proto__: null,
    moreSvg: g5
});
const m5 = M`<svg fill="none" viewBox="0 0 22 20">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M16.32 13.62a3.14 3.14 0 1 1-.99 1.72l-1.6-.93a3.83 3.83 0 0 1-3.71 1 3.66 3.66 0 0 1-1.74-1l-1.6.94a3.14 3.14 0 1 1-1-1.73l1.6-.94a3.7 3.7 0 0 1 0-2 3.81 3.81 0 0 1 1.8-2.33c.29-.17.6-.3.92-.38V6.1a3.14 3.14 0 1 1 2 0l-.01.02v1.85H12a3.82 3.82 0 0 1 2.33 1.8 3.7 3.7 0 0 1 .39 2.91l1.6.93ZM2.6 16.54a1.14 1.14 0 0 0 1.98-1.14 1.14 1.14 0 0 0-1.98 1.14ZM11 2.01a1.14 1.14 0 1 0 0 2.28 1.14 1.14 0 0 0 0-2.28Zm1.68 10.45c.08-.19.14-.38.16-.58v-.05l.02-.13v-.13a1.92 1.92 0 0 0-.24-.8l-.11-.15a1.89 1.89 0 0 0-.74-.6 1.86 1.86 0 0 0-.77-.17h-.19a1.97 1.97 0 0 0-.89.34 1.98 1.98 0 0 0-.61.74 1.99 1.99 0 0 0-.16.9v.05a1.87 1.87 0 0 0 .24.74l.1.15c.12.16.26.3.42.42l.16.1.13.07.04.02a1.84 1.84 0 0 0 .76.17h.17a2 2 0 0 0 .91-.35 1.78 1.78 0 0 0 .52-.58l.03-.05a.84.84 0 0 0 .05-.11Zm5.15 4.5a1.14 1.14 0 0 0 1.14-1.97 1.13 1.13 0 0 0-1.55.41c-.32.55-.13 1.25.41 1.56Z"
    clip-rule="evenodd"
  />
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M4.63 9.43a1.5 1.5 0 1 0 1.5-2.6 1.5 1.5 0 0 0-1.5 2.6Zm.32-1.55a.5.5 0 0 1 .68-.19.5.5 0 0 1 .18.68.5.5 0 0 1-.68.19.5.5 0 0 1-.18-.68ZM17.94 8.88a1.5 1.5 0 1 1-2.6-1.5 1.5 1.5 0 1 1 2.6 1.5ZM16.9 7.69a.5.5 0 0 0-.68.19.5.5 0 0 0 .18.68.5.5 0 0 0 .68-.19.5.5 0 0 0-.18-.68ZM9.75 17.75a1.5 1.5 0 1 1 2.6 1.5 1.5 1.5 0 1 1-2.6-1.5Zm1.05 1.18a.5.5 0 0 0 .68-.18.5.5 0 0 0-.18-.68.5.5 0 0 0-.68.18.5.5 0 0 0 .18.68Z"
    clip-rule="evenodd"
  />
</svg>`;
var b5 = Object.freeze({
    __proto__: null,
    networkPlaceholderSvg: m5
});
const v5 = M`<svg fill="none" viewBox="0 0 20 20">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M9.13 1h1.71c1.46 0 2.63 0 3.56.1.97.1 1.8.33 2.53.85a5 5 0 0 1 1.1 1.11c.53.73.75 1.56.86 2.53.1.93.1 2.1.1 3.55v1.72c0 1.45 0 2.62-.1 3.55-.1.97-.33 1.8-.86 2.53a5 5 0 0 1-1.1 1.1c-.73.53-1.56.75-2.53.86-.93.1-2.1.1-3.55.1H9.13c-1.45 0-2.62 0-3.56-.1-.96-.1-1.8-.33-2.52-.85a5 5 0 0 1-1.1-1.11 5.05 5.05 0 0 1-.86-2.53c-.1-.93-.1-2.1-.1-3.55V9.14c0-1.45 0-2.62.1-3.55.1-.97.33-1.8.85-2.53a5 5 0 0 1 1.1-1.1 5.05 5.05 0 0 1 2.53-.86C6.51 1 7.67 1 9.13 1ZM5.79 3.09a3.1 3.1 0 0 0-1.57.48 3 3 0 0 0-.66.67c-.24.32-.4.77-.48 1.56-.1.82-.1 1.88-.1 3.4v1.6c0 1.15 0 2.04.05 2.76l.41-.42c.5-.5.93-.92 1.32-1.24.41-.33.86-.6 1.43-.7a3 3 0 0 1 .94 0c.35.06.66.2.95.37a17.11 17.11 0 0 0 .8.45c.1-.08.2-.2.41-.4l.04-.03a27 27 0 0 1 1.95-1.84 4.03 4.03 0 0 1 1.91-.94 4 4 0 0 1 1.25 0c.73.11 1.33.46 1.91.94l.64.55V9.2c0-1.52 0-2.58-.1-3.4a3.1 3.1 0 0 0-.48-1.56 3 3 0 0 0-.66-.67 3.1 3.1 0 0 0-1.56-.48C13.37 3 12.3 3 10.79 3h-1.6c-1.52 0-2.59 0-3.4.09Zm11.18 10-.04-.05a26.24 26.24 0 0 0-1.83-1.74c-.45-.36-.73-.48-.97-.52a2 2 0 0 0-.63 0c-.24.04-.51.16-.97.52-.46.38-1.01.93-1.83 1.74l-.02.02c-.17.18-.34.34-.49.47a2.04 2.04 0 0 1-1.08.5 1.97 1.97 0 0 1-1.25-.27l-.79-.46-.02-.02a.65.65 0 0 0-.24-.1 1 1 0 0 0-.31 0c-.08.02-.21.06-.49.28-.3.24-.65.59-1.2 1.14l-.56.56-.65.66a3 3 0 0 0 .62.6c.33.24.77.4 1.57.49.81.09 1.88.09 3.4.09h1.6c1.52 0 2.58 0 3.4-.09a3.1 3.1 0 0 0 1.56-.48 3 3 0 0 0 .66-.67c.24-.32.4-.77.49-1.56l.07-1.12Zm-8.02-1.03ZM4.99 7a2 2 0 1 1 4 0 2 2 0 0 1-4 0Z"
    clip-rule="evenodd"
  />
</svg>`;
var C5 = Object.freeze({
    __proto__: null,
    nftPlaceholderSvg: v5
});
const y5 = M`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M8 0a1 1 0 0 1 1 1v5.38a1 1 0 0 1-2 0V1a1 1 0 0 1 1-1ZM5.26 2.6a1 1 0 0 1-.28 1.39 5.46 5.46 0 1 0 6.04 0 1 1 0 1 1 1.1-1.67 7.46 7.46 0 1 1-8.25 0 1 1 0 0 1 1.4.28Z"
    clip-rule="evenodd"
  />
</svg>`;
var x5 = Object.freeze({
    __proto__: null,
    offSvg: y5
});
const E5 = M` <svg
  width="36"
  height="36"
  fill="none"
>
  <path
    d="M0 8a8 8 0 0 1 8-8h20a8 8 0 0 1 8 8v20a8 8 0 0 1-8 8H8a8 8 0 0 1-8-8V8Z"
    fill="#fff"
    fill-opacity=".05"
  />
  <path
    d="m18.262 17.513-8.944 9.49v.01a2.417 2.417 0 0 0 3.56 1.452l.026-.017 10.061-5.803-4.703-5.132Z"
    fill="#EA4335"
  />
  <path
    d="m27.307 15.9-.008-.008-4.342-2.52-4.896 4.36 4.913 4.912 4.325-2.494a2.42 2.42 0 0 0 .008-4.25Z"
    fill="#FBBC04"
  />
  <path
    d="M9.318 8.997c-.05.202-.084.403-.084.622V26.39c0 .218.025.42.084.621l9.246-9.247-9.246-8.768Z"
    fill="#4285F4"
  />
  <path
    d="m18.33 18 4.627-4.628-10.053-5.828a2.427 2.427 0 0 0-3.586 1.444L18.329 18Z"
    fill="#34A853"
  />
  <path
    d="M8 .5h20A7.5 7.5 0 0 1 35.5 8v20a7.5 7.5 0 0 1-7.5 7.5H8A7.5 7.5 0 0 1 .5 28V8A7.5 7.5 0 0 1 8 .5Z"
    stroke="#fff"
    stroke-opacity=".05"
  />
</svg>`;
var A5 = Object.freeze({
    __proto__: null,
    playStoreSvg: E5
});
const S5 = M`<svg
  width="13"
  height="12"
  viewBox="0 0 13 12"
  fill="none"
>
  <path
    fill="currentColor"
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M0.794373 5.99982C0.794373 5.52643 1.17812 5.14268 1.6515 5.14268H5.643V1.15109C5.643 0.677701 6.02675 0.293946 6.50012 0.293945C6.9735 0.293946 7.35725 0.677701 7.35725 1.15109V5.14268H11.3488C11.8221 5.14268 12.2059 5.52643 12.2059 5.99982C12.2059 6.47321 11.8221 6.85696 11.3488 6.85696H7.35725V10.8486C7.35725 11.3219 6.9735 11.7057 6.50012 11.7057C6.02675 11.7057 5.643 11.3219 5.643 10.8486V6.85696H1.6515C1.17812 6.85696 0.794373 6.47321 0.794373 5.99982Z"
  /></svg
>`;
var _5 = Object.freeze({
    __proto__: null,
    plusSvg: S5
});
const I5 = M`<svg fill="none" viewBox="0 0 20 20">
  <path
    fill="currentColor"
    d="M3 6a3 3 0 0 1 3-3h1a1 1 0 1 0 0-2H6a5 5 0 0 0-5 5v1a1 1 0 0 0 2 0V6ZM13 1a1 1 0 1 0 0 2h1a3 3 0 0 1 3 3v1a1 1 0 1 0 2 0V6a5 5 0 0 0-5-5h-1ZM3 13a1 1 0 1 0-2 0v1a5 5 0 0 0 5 5h1a1 1 0 1 0 0-2H6a3 3 0 0 1-3-3v-1ZM19 13a1 1 0 1 0-2 0v1a3 3 0 0 1-3 3h-1a1 1 0 1 0 0 2h1.01a5 5 0 0 0 5-5v-1ZM5.3 6.36c-.04.2-.04.43-.04.89s0 .7.05.89c.14.52.54.92 1.06 1.06.19.05.42.05.89.05.46 0 .7 0 .88-.05A1.5 1.5 0 0 0 9.2 8.14c.06-.2.06-.43.06-.89s0-.7-.06-.89A1.5 1.5 0 0 0 8.14 5.3c-.19-.05-.42-.05-.88-.05-.47 0-.7 0-.9.05a1.5 1.5 0 0 0-1.05 1.06ZM10.8 6.36c-.04.2-.04.43-.04.89s0 .7.05.89c.14.52.54.92 1.06 1.06.19.05.42.05.89.05.46 0 .7 0 .88-.05a1.5 1.5 0 0 0 1.06-1.06c.06-.2.06-.43.06-.89s0-.7-.06-.89a1.5 1.5 0 0 0-1.06-1.06c-.19-.05-.42-.05-.88-.05-.47 0-.7 0-.9.05a1.5 1.5 0 0 0-1.05 1.06ZM5.26 12.75c0-.46 0-.7.05-.89a1.5 1.5 0 0 1 1.06-1.06c.19-.05.42-.05.89-.05.46 0 .7 0 .88.05.52.14.93.54 1.06 1.06.06.2.06.43.06.89s0 .7-.06.89a1.5 1.5 0 0 1-1.06 1.06c-.19.05-.42.05-.88.05-.47 0-.7 0-.9-.05a1.5 1.5 0 0 1-1.05-1.06c-.05-.2-.05-.43-.05-.89ZM10.8 11.86c-.04.2-.04.43-.04.89s0 .7.05.89c.14.52.54.92 1.06 1.06.19.05.42.05.89.05.46 0 .7 0 .88-.05a1.5 1.5 0 0 0 1.06-1.06c.06-.2.06-.43.06-.89s0-.7-.06-.89a1.5 1.5 0 0 0-1.06-1.06c-.19-.05-.42-.05-.88-.05-.47 0-.7 0-.9.05a1.5 1.5 0 0 0-1.05 1.06Z"
  />
</svg>`;
var N5 = Object.freeze({
    __proto__: null,
    qrCodeIcon: I5
});
const k5 = M`<svg
  fill="none"
  viewBox="0 0 21 20"
>
  <path
    fill="currentColor"
    d="M8.8071 0.292893C9.19763 0.683417 9.19763 1.31658 8.8071 1.70711L6.91421 3.6H11.8404C14.3368 3.6 16.5533 5.1975 17.3427 7.56588L17.4487 7.88377C17.6233 8.40772 17.3402 8.97404 16.8162 9.14868C16.2923 9.32333 15.726 9.04017 15.5513 8.51623L15.4453 8.19834C14.9281 6.64664 13.476 5.6 11.8404 5.6H6.91421L8.8071 7.49289C9.19763 7.88342 9.19763 8.51658 8.8071 8.90711C8.41658 9.29763 7.78341 9.29763 7.39289 8.90711L3.79289 5.30711C3.40236 4.91658 3.40236 4.28342 3.79289 3.89289L7.39289 0.292893C7.78341 -0.0976311 8.41658 -0.0976311 8.8071 0.292893ZM4.18377 10.8513C4.70771 10.6767 5.27403 10.9598 5.44868 11.4838L5.55464 11.8017C6.07188 13.3534 7.52401 14.4 9.15964 14.4L14.0858 14.4L12.1929 12.5071C11.8024 12.1166 11.8024 11.4834 12.1929 11.0929C12.5834 10.7024 13.2166 10.7024 13.6071 11.0929L17.2071 14.6929C17.5976 15.0834 17.5976 15.7166 17.2071 16.1071L13.6071 19.7071C13.2166 20.0976 12.5834 20.0976 12.1929 19.7071C11.8024 19.3166 11.8024 18.6834 12.1929 18.2929L14.0858 16.4L9.15964 16.4C6.66314 16.4 4.44674 14.8025 3.65728 12.4341L3.55131 12.1162C3.37667 11.5923 3.65983 11.026 4.18377 10.8513Z"
  /></svg
>`;
var T5 = Object.freeze({
    __proto__: null,
    recycleHorizontalSvg: k5
});
const O5 = M`<svg fill="none" viewBox="0 0 14 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M3.94 1.04a1 1 0 0 1 .7 1.23l-.48 1.68a5.85 5.85 0 0 1 8.53 4.32 5.86 5.86 0 0 1-11.4 2.56 1 1 0 0 1 1.9-.57 3.86 3.86 0 1 0 1.83-4.5l1.87.53a1 1 0 0 1-.55 1.92l-4.1-1.15a1 1 0 0 1-.69-1.23l1.16-4.1a1 1 0 0 1 1.23-.7Z"
    clip-rule="evenodd"
  />
</svg>`;
var $5 = Object.freeze({
    __proto__: null,
    refreshSvg: O5
});
const P5 = M`<svg fill="none" viewBox="0 0 20 20">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M9.36 4.21a5.14 5.14 0 1 0 0 10.29 5.14 5.14 0 0 0 0-10.29ZM1.64 9.36a7.71 7.71 0 1 1 14 4.47l2.52 2.5a1.29 1.29 0 1 1-1.82 1.83l-2.51-2.51A7.71 7.71 0 0 1 1.65 9.36Z"
    clip-rule="evenodd"
  />
</svg>`;
var B5 = Object.freeze({
    __proto__: null,
    searchSvg: P5
});
const R5 = M`<svg fill="none" viewBox="0 0 21 20">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M14.3808 4.34812C13.72 4.47798 12.8501 4.7587 11.5748 5.17296L9.00869 6.00646C6.90631 6.68935 5.40679 7.17779 4.38121 7.63178C3.87166 7.85734 3.5351 8.05091 3.32022 8.22035C3.11183 8.38466 3.07011 8.48486 3.05969 8.51817C2.98058 8.77103 2.98009 9.04195 3.05831 9.29509C3.06861 9.32844 3.10998 9.42878 3.31777 9.59384C3.53205 9.76404 3.86792 9.95881 4.37667 10.1862C5.29287 10.5957 6.58844 11.0341 8.35529 11.6164L10.8876 8.59854C11.2426 8.17547 11.8733 8.12028 12.2964 8.47528C12.7195 8.83029 12.7746 9.46104 12.4196 9.88412L9.88738 12.9019C10.7676 14.5408 11.4244 15.7406 11.9867 16.5718C12.299 17.0333 12.5491 17.3303 12.7539 17.5117C12.9526 17.6877 13.0586 17.711 13.0932 17.7154C13.3561 17.7484 13.6228 17.7009 13.8581 17.5791C13.8891 17.563 13.9805 17.5046 14.1061 17.2708C14.2357 17.0298 14.3679 16.6647 14.5015 16.1237C14.7705 15.0349 14.9912 13.4733 15.2986 11.2843L15.6738 8.61249C15.8603 7.28456 15.9857 6.37917 15.9989 5.7059C16.012 5.03702 15.9047 4.8056 15.8145 4.69183C15.7044 4.55297 15.5673 4.43792 15.4114 4.35365C15.2837 4.28459 15.0372 4.2191 14.3808 4.34812ZM7.99373 13.603C6.11919 12.9864 4.6304 12.4902 3.5606 12.0121C2.98683 11.7557 2.4778 11.4808 2.07383 11.1599C1.66337 10.8339 1.31312 10.4217 1.14744 9.88551C0.949667 9.24541 0.950886 8.56035 1.15094 7.92096C1.31852 7.38534 1.67024 6.97442 2.08185 6.64985C2.48697 6.33041 2.99697 6.05734 3.57166 5.80295C4.70309 5.3021 6.30179 4.78283 8.32903 4.12437L11.0196 3.25042C12.2166 2.86159 13.2017 2.54158 13.9951 2.38566C14.8065 2.22618 15.6202 2.19289 16.3627 2.59437C16.7568 2.80747 17.1035 3.09839 17.3818 3.4495C17.9062 4.111 18.0147 4.91815 17.9985 5.74496C17.9827 6.55332 17.8386 7.57903 17.6636 8.82534L17.2701 11.6268C16.9737 13.7376 16.7399 15.4022 16.4432 16.6034C16.2924 17.2135 16.1121 17.7632 15.8678 18.2176C15.6197 18.6794 15.2761 19.0971 14.7777 19.3551C14.1827 19.6632 13.5083 19.7833 12.8436 19.6997C12.2867 19.6297 11.82 19.3563 11.4277 19.0087C11.0415 18.6666 10.6824 18.213 10.3302 17.6925C9.67361 16.722 8.92648 15.342 7.99373 13.603Z"
    clip-rule="evenodd"
  />
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="21"
    height="20"
    viewBox="0 0 21 20"
    fill="none"
  ></svg></svg
>`;
var L5 = Object.freeze({
    __proto__: null,
    sendSvg: R5
});
const U5 = M`<svg fill="none" viewBox="0 0 20 20">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M6.76.3a1 1 0 0 1 0 1.4L4.07 4.4h9a1 1 0 1 1 0 2h-9l2.69 2.68a1 1 0 1 1-1.42 1.42L.95 6.09a1 1 0 0 1 0-1.4l4.4-4.4a1 1 0 0 1 1.4 0Zm6.49 9.21a1 1 0 0 1 1.41 0l4.39 4.4a1 1 0 0 1 0 1.4l-4.39 4.4a1 1 0 0 1-1.41-1.42l2.68-2.68h-9a1 1 0 0 1 0-2h9l-2.68-2.68a1 1 0 0 1 0-1.42Z"
    clip-rule="evenodd"
  />
</svg>`;
var M5 = Object.freeze({
    __proto__: null,
    swapHorizontalSvg: U5
});
const D5 = M`<svg
  width="14"
  height="14"
  viewBox="0 0 14 14"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M13.7306 3.24213C14.0725 3.58384 14.0725 4.13786 13.7306 4.47957L10.7418 7.46737C10.4 7.80908 9.84581 7.80908 9.50399 7.46737C9.16216 7.12567 9.16216 6.57165 9.50399 6.22994L10.9986 4.73585H5.34082C4.85741 4.73585 4.46553 4.3441 4.46553 3.86085C4.46553 3.3776 4.85741 2.98585 5.34082 2.98585L10.9986 2.98585L9.50399 1.49177C9.16216 1.15006 9.16216 0.596037 9.50399 0.254328C9.84581 -0.0873803 10.4 -0.0873803 10.7418 0.254328L13.7306 3.24213ZM9.52515 10.1352C9.52515 10.6185 9.13327 11.0102 8.64986 11.0102L2.9921 11.0102L4.48669 12.5043C4.82852 12.846 4.82852 13.4001 4.48669 13.7418C4.14487 14.0835 3.59066 14.0835 3.24884 13.7418L0.26003 10.754C0.0958806 10.5899 0.0036621 10.3673 0.00366211 10.1352C0.00366212 9.90318 0.0958806 9.68062 0.26003 9.51652L3.24884 6.52872C3.59066 6.18701 4.14487 6.18701 4.48669 6.52872C4.82851 6.87043 4.82851 7.42445 4.48669 7.76616L2.9921 9.26024L8.64986 9.26024C9.13327 9.26024 9.52515 9.65199 9.52515 10.1352Z"
    fill="currentColor"
  />
</svg>

`;
var z5 = Object.freeze({
    __proto__: null,
    swapHorizontalMediumSvg: D5
});
const W5 = M`<svg width="10" height="10" viewBox="0 0 10 10">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M3.77986 0.566631C4.0589 0.845577 4.0589 1.29784 3.77986 1.57678L3.08261 2.2738H6.34184C6.73647 2.2738 7.05637 2.5936 7.05637 2.98808C7.05637 3.38257 6.73647 3.70237 6.34184 3.70237H3.08261L3.77986 4.39938C4.0589 4.67833 4.0589 5.13059 3.77986 5.40954C3.50082 5.68848 3.04841 5.68848 2.76937 5.40954L0.852346 3.49316C0.573306 3.21421 0.573306 2.76195 0.852346 2.48301L2.76937 0.566631C3.04841 0.287685 3.50082 0.287685 3.77986 0.566631ZM6.22 4.59102C6.49904 4.31208 6.95145 4.31208 7.23049 4.59102L9.14751 6.5074C9.42655 6.78634 9.42655 7.23861 9.14751 7.51755L7.23049 9.43393C6.95145 9.71287 6.49904 9.71287 6.22 9.43393C5.94096 9.15498 5.94096 8.70272 6.22 8.42377L6.91725 7.72676L3.65802 7.72676C3.26339 7.72676 2.94349 7.40696 2.94349 7.01247C2.94349 6.61798 3.26339 6.29819 3.65802 6.29819L6.91725 6.29819L6.22 5.60117C5.94096 5.32223 5.94096 4.86997 6.22 4.59102Z"
    clip-rule="evenodd"
  />
</svg>`;
var j5 = Object.freeze({
    __proto__: null,
    swapHorizontalBoldSvg: W5
});
const F5 = M`<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
  <path 
    fill="currentColor"
    fill-rule="evenodd" 
    clip-rule="evenodd" 
    d="M8.3071 0.292893C8.69763 0.683417 8.69763 1.31658 8.3071 1.70711L6.41421 3.6H11.3404C13.8368 3.6 16.0533 5.1975 16.8427 7.56588L16.9487 7.88377C17.1233 8.40772 16.8402 8.97404 16.3162 9.14868C15.7923 9.32333 15.226 9.04017 15.0513 8.51623L14.9453 8.19834C14.4281 6.64664 12.976 5.6 11.3404 5.6H6.41421L8.3071 7.49289C8.69763 7.88342 8.69763 8.51658 8.3071 8.90711C7.91658 9.29763 7.28341 9.29763 6.89289 8.90711L3.29289 5.30711C2.90236 4.91658 2.90236 4.28342 3.29289 3.89289L6.89289 0.292893C7.28341 -0.0976311 7.91658 -0.0976311 8.3071 0.292893ZM3.68377 10.8513C4.20771 10.6767 4.77403 10.9598 4.94868 11.4838L5.05464 11.8017C5.57188 13.3534 7.024 14.4 8.65964 14.4L13.5858 14.4L11.6929 12.5071C11.3024 12.1166 11.3024 11.4834 11.6929 11.0929C12.0834 10.7024 12.7166 10.7024 13.1071 11.0929L16.7071 14.6929C17.0976 15.0834 17.0976 15.7166 16.7071 16.1071L13.1071 19.7071C12.7166 20.0976 12.0834 20.0976 11.6929 19.7071C11.3024 19.3166 11.3024 18.6834 11.6929 18.2929L13.5858 16.4L8.65964 16.4C6.16314 16.4 3.94674 14.8025 3.15728 12.4341L3.05131 12.1162C2.87667 11.5923 3.15983 11.026 3.68377 10.8513Z" 
  />
</svg>`;
var H5 = Object.freeze({
    __proto__: null,
    swapHorizontalRoundedBoldSvg: F5
});
const V5 = M`<svg fill="none" viewBox="0 0 14 14">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M3.48 2.18a1 1 0 0 1 1.41 0l2.68 2.68a1 1 0 1 1-1.41 1.42l-.98-.98v4.56a1 1 0 0 1-2 0V5.3l-.97.98A1 1 0 0 1 .79 4.86l2.69-2.68Zm6.34 2.93a1 1 0 0 1 1 1v4.56l.97-.98a1 1 0 1 1 1.42 1.42l-2.69 2.68a1 1 0 0 1-1.41 0l-2.68-2.68a1 1 0 0 1 1.41-1.42l.98.98V6.1a1 1 0 0 1 1-1Z"
    clip-rule="evenodd"
  />
</svg>`;
var Z5 = Object.freeze({
    __proto__: null,
    swapVerticalSvg: V5
});
const G5 = M`<svg width="32" height="32" fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
  <g clip-path="url(#a)">
    <path fill="url(#b)" d="M0 0h32v32H0z"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M7.034 15.252c4.975-2.167 8.293-3.596 9.953-4.287 4.74-1.971 5.725-2.314 6.366-2.325.142-.002.457.033.662.198.172.14.22.33.243.463.022.132.05.435.028.671-.257 2.7-1.368 9.248-1.933 12.27-.24 1.28-.71 1.708-1.167 1.75-.99.091-1.743-.655-2.703-1.284-1.502-.985-2.351-1.598-3.81-2.558-1.684-1.11-.592-1.721.368-2.718.252-.261 4.619-4.233 4.703-4.594.01-.045.02-.213-.08-.301-.1-.09-.246-.059-.353-.035-.15.034-2.55 1.62-7.198 4.758-.682.468-1.298.696-1.851.684-.61-.013-1.782-.344-2.653-.628-1.069-.347-1.918-.53-1.845-1.12.039-.308.462-.623 1.27-.944Z" fill="#fff"/>
  </g>
  <path d="M.5 16C.5 7.44 7.44.5 16 .5 24.56.5 31.5 7.44 31.5 16c0 8.56-6.94 15.5-15.5 15.5C7.44 31.5.5 24.56.5 16Z" stroke="#141414" stroke-opacity=".05"/>
  <defs>
    <linearGradient id="b" x1="1600" y1="0" x2="1600" y2="3176.27" gradientUnits="userSpaceOnUse">
      <stop stop-color="#2AABEE"/>
      <stop offset="1" stop-color="#229ED9"/>
    </linearGradient>
    <clipPath id="a">
      <path d="M0 16C0 7.163 7.163 0 16 0s16 7.163 16 16-7.163 16-16 16S0 24.837 0 16Z" fill="#fff"/>
    </clipPath>
  </defs>
</svg>`;
var q5 = Object.freeze({
    __proto__: null,
    telegramSvg: G5
});
const K5 = M`<svg width="14" height="15" viewBox="0 0 14 15" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M7 3.71875C6.0335 3.71875 5.25 2.93525 5.25 1.96875C5.25 1.00225 6.0335 0.21875 7 0.21875C7.9665 0.21875 8.75 1.00225 8.75 1.96875C8.75 2.93525 7.9665 3.71875 7 3.71875Z" fill="#949E9E"/>
  <path d="M7 8.96875C6.0335 8.96875 5.25 8.18525 5.25 7.21875C5.25 6.25225 6.0335 5.46875 7 5.46875C7.9665 5.46875 8.75 6.25225 8.75 7.21875C8.75 8.18525 7.9665 8.96875 7 8.96875Z" fill="#949E9E"/>
  <path d="M5.25 12.4688C5.25 13.4352 6.0335 14.2187 7 14.2187C7.9665 14.2187 8.75 13.4352 8.75 12.4688C8.75 11.5023 7.9665 10.7188 7 10.7188C6.0335 10.7188 5.25 11.5023 5.25 12.4688Z" fill="#949E9E"/>
</svg>`;
var Y5 = Object.freeze({
    __proto__: null,
    threeDotsSvg: K5
});
const X5 = M`<svg fill="none" viewBox="0 0 40 40">
  <g clip-path="url(#a)">
    <g clip-path="url(#b)">
      <circle cx="20" cy="19.89" r="20" fill="#5A3E85" />
      <g clip-path="url(#c)">
        <path
          fill="#fff"
          d="M18.22 25.7 20 23.91h3.34l2.1-2.1v-6.68H15.4v8.78h2.82v1.77Zm3.87-8.16h1.25v3.66H22.1v-3.66Zm-3.34 0H20v3.66h-1.25v-3.66ZM20 7.9a12 12 0 1 0 0 24 12 12 0 0 0 0-24Zm6.69 14.56-3.66 3.66h-2.72l-1.77 1.78h-1.88V26.1H13.3v-9.82l.94-2.4H26.7v8.56Z"
        />
      </g>
    </g>
  </g>
  <defs>
    <clipPath id="a"><rect width="40" height="40" fill="#fff" rx="20" /></clipPath>
    <clipPath id="b"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
    <clipPath id="c"><path fill="#fff" d="M8 7.89h24v24H8z" /></clipPath>
  </defs>
</svg>`;
var J5 = Object.freeze({
    __proto__: null,
    twitchSvg: X5
});
const Q5 = M`<svg fill="none" viewBox="0 0 41 40">
  <g clip-path="url(#a)">
    <path fill="#000" d="M.8 0h40v40H.8z" />
    <path
      fill="#fff"
      d="m22.63 18.46 7.14-8.3h-1.69l-6.2 7.2-4.96-7.2H11.2l7.5 10.9-7.5 8.71h1.7l6.55-7.61 5.23 7.61h5.72l-7.77-11.31Zm-9.13-7.03h2.6l11.98 17.13h-2.6L13.5 11.43Z"
    />
  </g>
  <defs>
    <clipPath id="a"><path fill="#fff" d="M.8 20a20 20 0 1 1 40 0 20 20 0 0 1-40 0Z" /></clipPath>
  </defs>
</svg>`;
var x0 = Object.freeze({
    __proto__: null,
    xSvg: Q5
});
const eb = M`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    d="m14.36 4.74.01.42c0 4.34-3.3 9.34-9.34 9.34A9.3 9.3 0 0 1 0 13.03a6.6 6.6 0 0 0 4.86-1.36 3.29 3.29 0 0 1-3.07-2.28c.5.1 1 .07 1.48-.06A3.28 3.28 0 0 1 .64 6.11v-.04c.46.26.97.4 1.49.41A3.29 3.29 0 0 1 1.11 2.1a9.32 9.32 0 0 0 6.77 3.43 3.28 3.28 0 0 1 5.6-3 6.59 6.59 0 0 0 2.08-.8 3.3 3.3 0 0 1-1.45 1.82A6.53 6.53 0 0 0 16 3.04c-.44.66-1 1.23-1.64 1.7Z"
  />
</svg>`;
var tb = Object.freeze({
    __proto__: null,
    twitterIconSvg: eb
});
const rb = M`<svg fill="none" viewBox="0 0 28 28">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M18.1 4.76c-.42-.73-1.33-1.01-2.09-.66l-1.42.66c-.37.18-.8.18-1.18 0l-1.4-.65a1.63 1.63 0 0 0-2.1.66l-.84 1.45c-.2.34-.53.59-.92.67l-1.7.35c-.83.17-1.39.94-1.3 1.78l.19 1.56c.04.39-.08.78-.33 1.07l-1.12 1.3c-.52.6-.52 1.5 0 2.11L5 16.38c.25.3.37.68.33 1.06l-.18 1.57c-.1.83.46 1.6 1.28 1.78l1.7.35c.4.08.73.32.93.66l.84 1.43a1.63 1.63 0 0 0 2.09.66l1.41-.66c.37-.17.8-.17 1.18 0l1.43.67c.76.35 1.66.07 2.08-.65l.86-1.45c.2-.34.54-.58.92-.66l1.68-.35A1.63 1.63 0 0 0 22.84 19l-.18-1.57a1.4 1.4 0 0 1 .33-1.06l1.12-1.32c.52-.6.52-1.5 0-2.11l-1.12-1.3a1.4 1.4 0 0 1-.33-1.07l.18-1.57c.1-.83-.46-1.6-1.28-1.77l-1.68-.35a1.4 1.4 0 0 1-.92-.66l-.86-1.47Zm-3.27-3.2a4.43 4.43 0 0 1 5.69 1.78l.54.93 1.07.22a4.43 4.43 0 0 1 3.5 4.84l-.11.96.7.83a4.43 4.43 0 0 1 .02 5.76l-.72.85.1.96a4.43 4.43 0 0 1-3.5 4.84l-1.06.22-.54.92a4.43 4.43 0 0 1-5.68 1.77l-.84-.4-.82.39a4.43 4.43 0 0 1-5.7-1.79l-.51-.89-1.09-.22a4.43 4.43 0 0 1-3.5-4.84l.1-.96-.72-.85a4.43 4.43 0 0 1 .01-5.76l.71-.83-.1-.95a4.43 4.43 0 0 1 3.5-4.84l1.08-.23.53-.9a4.43 4.43 0 0 1 5.7-1.8l.81.38.83-.39ZM18.2 9.4c.65.42.84 1.28.42 1.93l-4.4 6.87a1.4 1.4 0 0 1-2.26.14L9.5 15.39a1.4 1.4 0 0 1 2.15-1.8l1.23 1.48 3.38-5.26a1.4 1.4 0 0 1 1.93-.42Z"
    clip-rule="evenodd"
  />
</svg>`;
var nb = Object.freeze({
    __proto__: null,
    verifySvg: rb
});
const ib = M`<svg fill="none" viewBox="0 0 14 14">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="m4.1 12.43-.45-.78-.93-.2a1.65 1.65 0 0 1-1.31-1.8l.1-.86-.61-.71a1.65 1.65 0 0 1 0-2.16l.6-.7-.09-.85c-.1-.86.47-1.64 1.3-1.81l.94-.2.45-.78A1.65 1.65 0 0 1 6.23.9l.77.36.78-.36c.77-.36 1.69-.07 2.12.66l.47.8.91.2c.84.17 1.4.95 1.31 1.8l-.1.86.6.7c.54.62.54 1.54.01 2.16l-.6.71.09.86c.1.85-.47 1.63-1.3 1.8l-.92.2-.47.79a1.65 1.65 0 0 1-2.12.66L7 12.74l-.77.36c-.78.35-1.7.07-2.13-.67Zm5.74-6.9a1 1 0 1 0-1.68-1.07L6.32 7.3l-.55-.66a1 1 0 0 0-1.54 1.28l1.43 1.71a1 1 0 0 0 1.61-.1l2.57-4Z"
    clip-rule="evenodd"
  />
</svg>`;
var ob = Object.freeze({
    __proto__: null,
    verifyFilledSvg: ib
});
const sb = M`<svg fill="none" viewBox="0 0 20 20">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M0 5.5c0-1.8 1.46-3.25 3.25-3.25H14.5c1.8 0 3.25 1.46 3.25 3.25v.28A3.25 3.25 0 0 1 20 8.88v2.24c0 1.45-.94 2.68-2.25 3.1v.28c0 1.8-1.46 3.25-3.25 3.25H3.25A3.25 3.25 0 0 1 0 14.5v-9Zm15.75 8.88h-2.38a4.38 4.38 0 0 1 0-8.76h2.38V5.5c0-.69-.56-1.25-1.25-1.25H3.25C2.56 4.25 2 4.81 2 5.5v9c0 .69.56 1.25 1.25 1.25H14.5c.69 0 1.25-.56 1.25-1.25v-.13Zm-2.38-6.76a2.37 2.37 0 1 0 0 4.75h3.38c.69 0 1.25-.55 1.25-1.24V8.87c0-.69-.56-1.24-1.25-1.24h-3.38Z"
    clip-rule="evenodd"
  />
</svg>`;
var ab = Object.freeze({
    __proto__: null,
    walletSvg: sb
});
const cb = M`<svg fill="none" viewBox="0 0 96 67">
  <path
    fill="currentColor"
    d="M25.32 18.8a32.56 32.56 0 0 1 45.36 0l1.5 1.47c.63.62.63 1.61 0 2.22l-5.15 5.05c-.31.3-.82.3-1.14 0l-2.07-2.03a22.71 22.71 0 0 0-31.64 0l-2.22 2.18c-.31.3-.82.3-1.14 0l-5.15-5.05a1.55 1.55 0 0 1 0-2.22l1.65-1.62Zm56.02 10.44 4.59 4.5c.63.6.63 1.6 0 2.21l-20.7 20.26c-.62.61-1.63.61-2.26 0L48.28 41.83a.4.4 0 0 0-.56 0L33.03 56.21c-.63.61-1.64.61-2.27 0L10.07 35.95a1.55 1.55 0 0 1 0-2.22l4.59-4.5a1.63 1.63 0 0 1 2.27 0L31.6 43.63a.4.4 0 0 0 .57 0l14.69-14.38a1.63 1.63 0 0 1 2.26 0l14.69 14.38a.4.4 0 0 0 .57 0l14.68-14.38a1.63 1.63 0 0 1 2.27 0Z"
  />
  <path
    stroke="#000"
    stroke-opacity=".1"
    d="M25.67 19.15a32.06 32.06 0 0 1 44.66 0l1.5 1.48c.43.42.43 1.09 0 1.5l-5.15 5.05a.31.31 0 0 1-.44 0l-2.07-2.03a23.21 23.21 0 0 0-32.34 0l-2.22 2.18a.31.31 0 0 1-.44 0l-5.15-5.05a1.05 1.05 0 0 1 0-1.5l1.65-1.63ZM81 29.6l4.6 4.5c.42.41.42 1.09 0 1.5l-20.7 20.26c-.43.43-1.14.43-1.57 0L48.63 41.47a.9.9 0 0 0-1.26 0L32.68 55.85c-.43.43-1.14.43-1.57 0L10.42 35.6a1.05 1.05 0 0 1 0-1.5l4.59-4.5a1.13 1.13 0 0 1 1.57 0l14.68 14.38a.9.9 0 0 0 1.27 0l-.35-.35.35.35L47.22 29.6a1.13 1.13 0 0 1 1.56 0l14.7 14.38a.9.9 0 0 0 1.26 0L79.42 29.6a1.13 1.13 0 0 1 1.57 0Z"
  />
</svg>`, lb = M`
<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_22274_4692)">
<path d="M0 6.64C0 4.17295 0 2.93942 0.525474 2.01817C0.880399 1.39592 1.39592 0.880399 2.01817 0.525474C2.93942 0 4.17295 0 6.64 0H9.36C11.8271 0 13.0606 0 13.9818 0.525474C14.6041 0.880399 15.1196 1.39592 15.4745 2.01817C16 2.93942 16 4.17295 16 6.64V9.36C16 11.8271 16 13.0606 15.4745 13.9818C15.1196 14.6041 14.6041 15.1196 13.9818 15.4745C13.0606 16 11.8271 16 9.36 16H6.64C4.17295 16 2.93942 16 2.01817 15.4745C1.39592 15.1196 0.880399 14.6041 0.525474 13.9818C0 13.0606 0 11.8271 0 9.36V6.64Z" fill="#C7B994"/>
<path d="M4.49038 5.76609C6.42869 3.86833 9.5713 3.86833 11.5096 5.76609L11.7429 5.99449C11.8398 6.08938 11.8398 6.24323 11.7429 6.33811L10.9449 7.11942C10.8964 7.16686 10.8179 7.16686 10.7694 7.11942L10.4484 6.80512C9.09617 5.48119 6.90381 5.48119 5.5516 6.80512L5.20782 7.14171C5.15936 7.18915 5.08079 7.18915 5.03234 7.14171L4.23434 6.3604C4.13742 6.26552 4.13742 6.11167 4.23434 6.01678L4.49038 5.76609ZM13.1599 7.38192L13.8702 8.07729C13.9671 8.17217 13.9671 8.32602 13.8702 8.4209L10.6677 11.5564C10.5708 11.6513 10.4137 11.6513 10.3168 11.5564L8.04388 9.33105C8.01965 9.30733 7.98037 9.30733 7.95614 9.33105L5.6833 11.5564C5.58638 11.6513 5.42925 11.6513 5.33234 11.5564L2.12982 8.42087C2.0329 8.32598 2.0329 8.17213 2.12982 8.07724L2.84004 7.38188C2.93695 7.28699 3.09408 7.28699 3.191 7.38188L5.46392 9.60726C5.48815 9.63098 5.52743 9.63098 5.55166 9.60726L7.82447 7.38188C7.92138 7.28699 8.07851 7.28699 8.17543 7.38187L10.4484 9.60726C10.4726 9.63098 10.5119 9.63098 10.5361 9.60726L12.809 7.38192C12.9059 7.28703 13.063 7.28703 13.1599 7.38192Z" fill="#202020"/>
</g>
<defs>
<clipPath id="clip0_22274_4692">
<path d="M0 8C0 3.58172 3.58172 0 8 0C12.4183 0 16 3.58172 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8Z" fill="white"/>
</clipPath>
</defs>
</svg>
`, db = M`
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="11" cy="11" r="11" transform="matrix(-1 0 0 1 23 1)" fill="#202020"/>
<circle cx="11" cy="11" r="11.5" transform="matrix(-1 0 0 1 23 1)" stroke="#C7B994" stroke-opacity="0.7"/>
<path d="M15.4523 11.0686L16.7472 9.78167C13.8205 6.87297 10.1838 6.87297 7.25708 9.78167L8.55201 11.0686C10.7779 8.85645 13.2279 8.85645 15.4538 11.0686H15.4523Z" fill="#C7B994"/>
<path d="M15.0199 14.067L12 11.0656L8.98 14.067L5.96004 11.0656L4.66663 12.3511L8.98 16.6393L12 13.638L15.0199 16.6393L19.3333 12.3511L18.0399 11.0656L15.0199 14.067Z" fill="#C7B994"/>
</svg>
`;
var Yc = Object.freeze({
    __proto__: null,
    walletConnectSvg: cb,
    walletConnectLightBrownSvg: lb,
    walletConnectBrownSvg: db
});
const ub = M`
  <svg fill="none" viewBox="0 0 48 44">
    <path
      style="fill: var(--wui-color-bg-300);"
      d="M4.56 8.64c-1.23 1.68-1.23 4.08-1.23 8.88v8.96c0 4.8 0 7.2 1.23 8.88.39.55.87 1.02 1.41 1.42C7.65 38 10.05 38 14.85 38h14.3c4.8 0 7.2 0 8.88-1.22a6.4 6.4 0 0 0 1.41-1.42c.83-1.14 1.1-2.6 1.19-4.92a6.4 6.4 0 0 0 5.16-4.65c.21-.81.21-1.8.21-3.79 0-1.98 0-2.98-.22-3.79a6.4 6.4 0 0 0-5.15-4.65c-.1-2.32-.36-3.78-1.19-4.92a6.4 6.4 0 0 0-1.41-1.42C36.35 6 33.95 6 29.15 6h-14.3c-4.8 0-7.2 0-8.88 1.22a6.4 6.4 0 0 0-1.41 1.42Z"
    />
    <path
      style="fill: var(--wui-color-fg-200);"
      fill-rule="evenodd"
      d="M2.27 11.33a6.4 6.4 0 0 1 6.4-6.4h26.66a6.4 6.4 0 0 1 6.4 6.4v1.7a6.4 6.4 0 0 1 5.34 6.3v5.34a6.4 6.4 0 0 1-5.34 6.3v1.7a6.4 6.4 0 0 1-6.4 6.4H8.67a6.4 6.4 0 0 1-6.4-6.4V11.33ZM39.6 31.07h-6.93a9.07 9.07 0 1 1 0-18.14h6.93v-1.6a4.27 4.27 0 0 0-4.27-4.26H8.67a4.27 4.27 0 0 0-4.27 4.26v21.34a4.27 4.27 0 0 0 4.27 4.26h26.66a4.27 4.27 0 0 0 4.27-4.26v-1.6Zm-6.93-16a6.93 6.93 0 0 0 0 13.86h8a4.27 4.27 0 0 0 4.26-4.26v-5.34a4.27 4.27 0 0 0-4.26-4.26h-8Z"
      clip-rule="evenodd"
    />
  </svg>
`;
var hb = Object.freeze({
    __proto__: null,
    walletPlaceholderSvg: ub
});
const pb = M`<svg fill="none" viewBox="0 0 20 20">
  <path
    fill="currentColor"
    d="M11 6.67a1 1 0 1 0-2 0v2.66a1 1 0 0 0 2 0V6.67ZM10 14.5a1.25 1.25 0 1 0 0-2.5 1.25 1.25 0 0 0 0 2.5Z"
  />
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M10 1a9 9 0 1 0 0 18 9 9 0 0 0 0-18Zm-7 9a7 7 0 1 1 14 0 7 7 0 0 1-14 0Z"
    clip-rule="evenodd"
  />
</svg>`;
var fb = Object.freeze({
    __proto__: null,
    warningCircleSvg: pb
});
const gb = M`<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M9.125 6.875C9.125 6.57833 9.21298 6.28832 9.3778 6.04165C9.54262 5.79497 9.77689 5.60271 10.051 5.48918C10.3251 5.37565 10.6267 5.34594 10.9176 5.40382C11.2086 5.4617 11.4759 5.60456 11.6857 5.81434C11.8954 6.02412 12.0383 6.29139 12.0962 6.58236C12.1541 6.87334 12.1244 7.17494 12.0108 7.44903C11.8973 7.72311 11.705 7.95738 11.4584 8.1222C11.2117 8.28703 10.9217 8.375 10.625 8.375C10.2272 8.375 9.84565 8.21696 9.56434 7.93566C9.28304 7.65436 9.125 7.27282 9.125 6.875ZM21.125 11C21.125 13.0025 20.5312 14.9601 19.4186 16.6251C18.3061 18.2902 16.7248 19.5879 14.8747 20.3543C13.0246 21.1206 10.9888 21.3211 9.02471 20.9305C7.06066 20.5398 5.25656 19.5755 3.84055 18.1595C2.42454 16.7435 1.46023 14.9393 1.06955 12.9753C0.678878 11.0112 0.879387 8.97543 1.64572 7.12533C2.41206 5.27523 3.70981 3.69392 5.37486 2.58137C7.0399 1.46882 8.99747 0.875 11 0.875C13.6844 0.877978 16.258 1.94567 18.1562 3.84383C20.0543 5.74199 21.122 8.3156 21.125 11ZM18.875 11C18.875 9.44247 18.4131 7.91992 17.5478 6.62488C16.6825 5.32985 15.4526 4.32049 14.0136 3.72445C12.5747 3.12841 10.9913 2.97246 9.46367 3.27632C7.93607 3.58017 6.53288 4.3302 5.43154 5.43153C4.3302 6.53287 3.58018 7.93606 3.27632 9.46366C2.97246 10.9913 3.12841 12.5747 3.72445 14.0136C4.32049 15.4526 5.32985 16.6825 6.62489 17.5478C7.91993 18.4131 9.44248 18.875 11 18.875C13.0879 18.8728 15.0896 18.0424 16.566 16.566C18.0424 15.0896 18.8728 13.0879 18.875 11ZM12.125 14.4387V11.375C12.125 10.8777 11.9275 10.4008 11.5758 10.0492C11.2242 9.69754 10.7473 9.5 10.25 9.5C9.98433 9.4996 9.72708 9.59325 9.52383 9.76435C9.32058 9.93544 9.18444 10.173 9.13952 10.4348C9.09461 10.6967 9.14381 10.966 9.27843 11.195C9.41304 11.4241 9.62438 11.5981 9.875 11.6863V14.75C9.875 15.2473 10.0725 15.7242 10.4242 16.0758C10.7758 16.4275 11.2527 16.625 11.75 16.625C12.0157 16.6254 12.2729 16.5318 12.4762 16.3607C12.6794 16.1896 12.8156 15.952 12.8605 15.6902C12.9054 15.4283 12.8562 15.159 12.7216 14.93C12.587 14.7009 12.3756 14.5269 12.125 14.4387Z" fill="currentColor"/>
</svg>`;
var wb = Object.freeze({
    __proto__: null,
    infoSvg: gb
});
const mb = M`<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M15.0162 11.6312L9.55059 2.13937C9.39228 1.86862 9.16584 1.64405 8.8938 1.48798C8.62176 1.33192 8.3136 1.2498 7.99997 1.2498C7.68634 1.2498 7.37817 1.33192 7.10613 1.48798C6.83409 1.64405 6.60765 1.86862 6.44934 2.13937L0.983716 11.6312C0.830104 11.894 0.749146 12.1928 0.749146 12.4972C0.749146 12.8015 0.830104 13.1004 0.983716 13.3631C1.14027 13.6352 1.3664 13.8608 1.63889 14.0166C1.91139 14.1725 2.22044 14.253 2.53434 14.25H13.4656C13.7793 14.2528 14.0881 14.1721 14.3603 14.0163C14.6326 13.8604 14.8585 13.635 15.015 13.3631C15.1688 13.1005 15.2499 12.8017 15.2502 12.4973C15.2504 12.193 15.1696 11.8941 15.0162 11.6312ZM13.7162 12.6125C13.6908 12.6558 13.6541 12.6914 13.6101 12.7157C13.5661 12.7399 13.5164 12.7517 13.4662 12.75H2.53434C2.48415 12.7517 2.43442 12.7399 2.39042 12.7157C2.34641 12.6914 2.30976 12.6558 2.28434 12.6125C2.26278 12.5774 2.25137 12.5371 2.25137 12.4959C2.25137 12.4548 2.26278 12.4144 2.28434 12.3794L7.74997 2.88749C7.77703 2.84583 7.81408 2.8116 7.85774 2.7879C7.9014 2.7642 7.95029 2.75178 7.99997 2.75178C8.04964 2.75178 8.09854 2.7642 8.1422 2.7879C8.18586 2.8116 8.2229 2.84583 8.24997 2.88749L13.715 12.3794C13.7367 12.4143 13.7483 12.4546 13.7486 12.4958C13.7488 12.5369 13.7376 12.5773 13.7162 12.6125ZM7.24997 8.49999V6.49999C7.24997 6.30108 7.32898 6.11031 7.46964 5.96966C7.61029 5.82901 7.80105 5.74999 7.99997 5.74999C8.19888 5.74999 8.38964 5.82901 8.5303 5.96966C8.67095 6.11031 8.74997 6.30108 8.74997 6.49999V8.49999C8.74997 8.6989 8.67095 8.88967 8.5303 9.03032C8.38964 9.17097 8.19888 9.24999 7.99997 9.24999C7.80105 9.24999 7.61029 9.17097 7.46964 9.03032C7.32898 8.88967 7.24997 8.6989 7.24997 8.49999ZM8.99997 11C8.99997 11.1978 8.94132 11.3911 8.83144 11.5556C8.72155 11.72 8.56538 11.8482 8.38265 11.9239C8.19992 11.9996 7.99886 12.0194 7.80488 11.9808C7.6109 11.9422 7.43271 11.847 7.29286 11.7071C7.15301 11.5672 7.05777 11.3891 7.01918 11.1951C6.9806 11.0011 7.0004 10.8 7.07609 10.6173C7.15177 10.4346 7.27995 10.2784 7.4444 10.1685C7.60885 10.0586 7.80219 9.99999 7.99997 9.99999C8.26518 9.99999 8.51954 10.1053 8.70707 10.2929C8.89461 10.4804 8.99997 10.7348 8.99997 11Z" fill="currentColor"/>
</svg>
`;
var bb = Object.freeze({
    __proto__: null,
    exclamationTriangleSvg: mb
});
const vb = M`<svg width="60" height="16" viewBox="0 0 60 16" fill="none"">
  <path d="M9.3335 4.66667C9.3335 2.08934 11.4229 0 14.0002 0H20.6669C23.2442 0 25.3335 2.08934 25.3335 4.66667V11.3333C25.3335 13.9106 23.2442 16 20.6669 16H14.0002C11.4229 16 9.3335 13.9106 9.3335 11.3333V4.66667Z" fill="#363636"/>
  <path d="M15.6055 11.0003L17.9448 4.66699H18.6316L16.2923 11.0003H15.6055Z" fill="#F6F6F6"/>
  <path d="M0 4.33333C0 1.9401 1.9401 0 4.33333 0C6.72657 0 8.66669 1.9401 8.66669 4.33333V11.6667C8.66669 14.0599 6.72657 16 4.33333 16C1.9401 16 0 14.0599 0 11.6667V4.33333Z" fill="#363636"/>
  <path d="M3.9165 9.99934V9.16602H4.74983V9.99934H3.9165Z" fill="#F6F6F6"/>
  <path d="M26 8C26 3.58172 29.3517 0 33.4863 0H52.5137C56.6483 0 60 3.58172 60 8C60 12.4183 56.6483 16 52.5137 16H33.4863C29.3517 16 26 12.4183 26 8Z" fill="#363636"/>
  <path d="M49.3687 9.95834V6.26232H50.0213V6.81966C50.256 6.40899 50.7326 6.16699 51.2606 6.16699C52.0599 6.16699 52.6173 6.67299 52.6173 7.65566V9.95834H51.972V7.69234C51.972 7.04696 51.6053 6.70966 51.07 6.70966C50.4906 6.70966 50.0213 7.17168 50.0213 7.82433V9.95834H49.3687Z" fill="#F6F6F6"/>
  <path d="M45.2538 9.95773L44.5718 6.26172H45.1877L45.6717 9.31242L46.3098 7.30306H46.9184L47.5491 9.29041L48.0404 6.26172H48.6564L47.9744 9.95773H47.2411L46.6178 8.03641L45.9871 9.95773H45.2538Z" fill="#F6F6F6"/>
  <path d="M42.3709 10.0536C41.2489 10.0536 40.5889 9.21765 40.5889 8.1103C40.5889 7.01035 41.2489 6.16699 42.3709 6.16699C43.4929 6.16699 44.1529 7.01035 44.1529 8.1103C44.1529 9.21765 43.4929 10.0536 42.3709 10.0536ZM42.3709 9.51096C43.1775 9.51096 43.4856 8.82164 43.4856 8.10296C43.4856 7.39163 43.1775 6.70966 42.3709 6.70966C41.5642 6.70966 41.2562 7.39163 41.2562 8.10296C41.2562 8.82164 41.5642 9.51096 42.3709 9.51096Z" fill="#F6F6F6"/>
  <path d="M38.2805 10.0536C37.1952 10.0536 36.5132 9.22499 36.5132 8.1103C36.5132 7.00302 37.1952 6.16699 38.2805 6.16699C39.1972 6.16699 40.0038 6.68766 39.9159 8.27896H37.1805C37.2319 8.96103 37.5472 9.5183 38.2805 9.5183C38.7718 9.5183 39.0945 9.21765 39.2045 8.87299H39.8499C39.7472 9.48903 39.1679 10.0536 38.2805 10.0536ZM37.1952 7.78765H39.2852C39.2338 7.04696 38.8892 6.70232 38.2805 6.70232C37.6132 6.70232 37.2832 7.18635 37.1952 7.78765Z" fill="#F6F6F6"/>
  <path d="M33.3828 9.95773V6.26172H34.0501V6.88506C34.2848 6.47439 34.6882 6.26172 35.1061 6.26172H35.9935V6.88506H35.0548C34.4682 6.88506 34.0501 7.26638 34.0501 8.00706V9.95773H33.3828Z" fill="#F6F6F6"/>
</svg>`;
var Cb = Object.freeze({
    __proto__: null,
    reownSvg: vb
});
;
 //# sourceMappingURL=index.es.js.map
}),
];

//# sourceMappingURL=84aae_%40walletconnect_ethereum-provider_dist_index_es_0c1ee7ba.js.map