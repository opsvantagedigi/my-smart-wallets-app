(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/wagmi/node_modules/@noble/curves/esm/secp256k1.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_5d152ee4._.js",
  "static/chunks/84aae_@noble_curves_esm_secp256k1_8f3b433d.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/wagmi/node_modules/@noble/curves/esm/secp256k1.js [app-client] (ecmascript)");
    });
});
}),
]);