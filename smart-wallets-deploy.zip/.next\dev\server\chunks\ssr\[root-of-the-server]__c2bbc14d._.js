module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/node:crypto [external] (node:crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:crypto", () => require("node:crypto"));

module.exports = mod;
}),
"[externals]/buffer [external] (buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/punycode [external] (punycode, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("punycode", () => require("punycode"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[externals]/net [external] (net, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}),
"[externals]/tls [external] (tls, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/node:url [external] (node:url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:url", () => require("node:url"));

module.exports = mod;
}),
"[project]/lib/chains.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "chainNFTMintContractData",
    ()=>chainNFTMintContractData
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@account-kit/infra/dist/esm/chains.js [app-ssr] (ecmascript)");
;
const chainNFTMintContractData = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["arbitrumSepolia"].id]: {
        chain: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["arbitrumSepolia"],
        nftContractAddress: "0x6D1BaA7951f26f600b4ABc3a9CF8F18aBf36fac1"
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["baseSepolia"].id]: {
        chain: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["baseSepolia"],
        nftContractAddress: "0x6d15c130d9B2548597C1d2D0c8CB2067Ce9C4525"
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["polygonAmoy"].id]: {
        chain: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["polygonAmoy"],
        nftContractAddress: "0x6d15c130d9B2548597C1d2D0c8CB2067Ce9C4525"
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sepolia"].id]: {
        chain: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sepolia"],
        nftContractAddress: "0xc59b508C90425C8e25e3F9dA30e52057908E2838"
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["shapeSepolia"].id]: {
        chain: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["shapeSepolia"],
        nftContractAddress: "0x6d15c130d9B2548597C1d2D0c8CB2067Ce9C4525"
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["soneiumMinato"].id]: {
        chain: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["soneiumMinato"],
        nftContractAddress: "0x6d15c130d9B2548597C1d2D0c8CB2067Ce9C4525"
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["unichainSepolia"].id]: {
        chain: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["unichainSepolia"],
        nftContractAddress: "0x6d15c130d9B2548597C1d2D0c8CB2067Ce9C4525"
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["inkSepolia"].id]: {
        chain: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["inkSepolia"],
        nftContractAddress: "0x6d15c130d9B2548597C1d2D0c8CB2067Ce9C4525"
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["monadTestnet"].id]: {
        chain: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["monadTestnet"],
        nftContractAddress: "0x6d15c130d9B2548597C1d2D0c8CB2067Ce9C4525"
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["riseTestnet"].id]: {
        chain: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["riseTestnet"],
        nftContractAddress: "0x6d15c130d9B2548597C1d2D0c8CB2067Ce9C4525"
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["storyAeneid"].id]: {
        chain: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["storyAeneid"],
        nftContractAddress: "0x6d15c130d9B2548597C1d2D0c8CB2067Ce9C4525"
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["teaSepolia"].id]: {
        chain: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$chains$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["teaSepolia"],
        nftContractAddress: "0x6d15c130d9B2548597C1d2D0c8CB2067Ce9C4525"
    }
};
}),
"[project]/config.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "config",
    ()=>config,
    "queryClient",
    ()=>queryClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$core$2f$dist$2f$esm$2f$utils$2f$cookies$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@account-kit/core/dist/esm/utils/cookies.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$react$2f$dist$2f$esm$2f$createConfig$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@account-kit/react/dist/esm/createConfig.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/query-core/build/modern/queryClient.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$chains$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/chains.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$alchemyTransport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@account-kit/infra/dist/esm/alchemyTransport.js [app-ssr] (ecmascript)");
;
;
;
;
const API_KEY = ("TURBOPACK compile-time value", "c4YUdaSKyJjyNxSM8EOoO");
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
const SPONSORSHIP_POLICY_ID = ("TURBOPACK compile-time value", "e42cf63e-a5ed-45b9-aa02-45334e47ba52");
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
const CHAIN_ID = parseInt(process.env.NEXT_PUBLIC_CHAIN_ID ?? '') || 421614;
const chain = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$chains$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["chainNFTMintContractData"][CHAIN_ID]?.chain;
if (!chain) {
    throw new Error("Invalid chain ID");
}
const uiConfig = {
    illustrationStyle: "flat",
    auth: {
        header: "/assets/brand-logo.png",
        sections: [
            [
                {
                    type: "email"
                }
            ],
            [
                {
                    type: "passkey"
                },
                {
                    type: "social",
                    authProviderId: "google",
                    mode: "popup"
                },
                {
                    type: "social",
                    authProviderId: "facebook",
                    mode: "popup"
                },
                {
                    type: "social",
                    authProviderId: "twitch",
                    mode: "popup"
                },
                {
                    type: "social",
                    authProviderId: "auth0",
                    mode: "popup",
                    auth0Connection: "discord",
                    displayName: "Discord",
                    logoUrl: "/images/discord.svg",
                    scope: "openid profile"
                },
                {
                    type: "social",
                    authProviderId: "auth0",
                    mode: "popup",
                    auth0Connection: "twitter",
                    displayName: "Twitter",
                    logoUrl: "/images/twitter.svg",
                    logoUrlDark: "/images/twitter-dark.svg",
                    scope: "openid profile"
                }
            ],
            [
                {
                    type: "external_wallets",
                    walletConnect: {
                        projectId: ("TURBOPACK compile-time value", "cea30225a7e5e5f5aecc8c4a6d937e11") || "30e7ffaff99063e68cc9870c105d905b"
                    },
                    wallets: [
                        "wallet_connect",
                        "coinbase_wallet"
                    ],
                    chainType: [
                        "svm",
                        "evm"
                    ],
                    moreButtonText: "More wallets",
                    hideMoreButton: false,
                    numFeaturedWallets: 1
                }
            ]
        ],
        addPasskeyOnSignup: true
    },
    supportUrl: "support@opsvantagedigital.online"
};
const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$react$2f$dist$2f$esm$2f$createConfig$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createConfig"])({
    transport: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$infra$2f$dist$2f$esm$2f$alchemyTransport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alchemy"])({
        apiKey: API_KEY
    }),
    chain,
    ssr: true,
    storage: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$core$2f$dist$2f$esm$2f$utils$2f$cookies$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cookieStorage"],
    enablePopupOauth: true,
    policyId: SPONSORSHIP_POLICY_ID
}, uiConfig);
const queryClient = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["QueryClient"]();
}),
"[externals]/assert [external] (assert, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}),
"[project]/app/providers.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Providers",
    ()=>Providers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/config.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$react$2f$dist$2f$esm$2f$AlchemyAccountProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@account-kit/react/dist/esm/AlchemyAccountProvider.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
const Providers = (props)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["QueryClientProvider"], {
        client: __TURBOPACK__imported__module__$5b$project$5d2f$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["queryClient"],
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$account$2d$kit$2f$react$2f$dist$2f$esm$2f$AlchemyAccountProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlchemyAccountProvider"], {
            config: __TURBOPACK__imported__module__$5b$project$5d2f$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["config"],
            queryClient: __TURBOPACK__imported__module__$5b$project$5d2f$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["queryClient"],
            initialState: props.initialState,
            children: props.children
        }, void 0, false, {
            fileName: "[project]/app/providers.tsx",
            lineNumber: 13,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/app/providers.tsx",
        lineNumber: 12,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
}),
"[project]/app/components/AIAvatar.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
;
;
;
const AIAvatar = ()=>{
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed bottom-6 right-6 z-50",
        children: [
            isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute bottom-20 right-0 w-80 sm:w-96 bg-black/50 backdrop-blur-2xl border border-white/20 rounded-2xl shadow-2xl overflow-hidden transition-all duration-300 origin-bottom-right animate-fade-in-up",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "p-4 bg-white/10 border-b border-white/10",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "font-orbitron text-lg font-bold text-white",
                                children: "OpsVantage AI Assistant"
                            }, void 0, false, {
                                fileName: "[project]/app/components/AIAvatar.tsx",
                                lineNumber: 12,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-gray-300",
                                children: "Ask about features, security, or onboarding."
                            }, void 0, false, {
                                fileName: "[project]/app/components/AIAvatar.tsx",
                                lineNumber: 13,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/AIAvatar.tsx",
                        lineNumber: 11,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "p-4 h-80 overflow-y-auto space-y-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-blue-500/20 text-gray-200 p-3 rounded-lg max-w-xs",
                                    children: "Hello! How can I help you take control of your crypto today?"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/AIAvatar.tsx",
                                    lineNumber: 17,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/app/components/AIAvatar.tsx",
                                lineNumber: 16,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-end",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-gray-700 text-white p-3 rounded-lg max-w-xs",
                                    children: "How do you protect against scams?"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/AIAvatar.tsx",
                                    lineNumber: 22,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/app/components/AIAvatar.tsx",
                                lineNumber: 21,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-blue-500/20 text-gray-200 p-3 rounded-lg max-w-xs",
                                    children: "Great question! OpsVantage uses a real-time intelligence engine to analyze transactions and dApp interactions, warning you of potential phishing attempts or malicious smart contracts before you approve them."
                                }, void 0, false, {
                                    fileName: "[project]/app/components/AIAvatar.tsx",
                                    lineNumber: 27,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/app/components/AIAvatar.tsx",
                                lineNumber: 26,
                                columnNumber: 14
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/AIAvatar.tsx",
                        lineNumber: 15,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "p-4 border-t border-white/10",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "group relative",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute -inset-0.5 bg-gradient-to-r from-[#0030ff] via-green-400 to-[#ffe600] rounded-full blur opacity-50 group-hover:opacity-90 group-focus-within:opacity-90 transition-opacity duration-300 animate-tilt"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/AIAvatar.tsx",
                                    lineNumber: 34,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative flex items-center space-x-2 bg-gray-900 rounded-full px-1 py-0.5",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "text",
                                            placeholder: "Type your question...",
                                            className: "flex-grow bg-transparent border-none rounded-full py-2 px-3 text-white placeholder-gray-400 focus:ring-0 focus:outline-none"
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/AIAvatar.tsx",
                                            lineNumber: 36,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "p-2.5 bg-gradient-to-br from-[#0030ff] to-blue-600 rounded-full hover:scale-125 hover:brightness-110 transform transition-transform duration-300",
                                            "aria-label": "Send message",
                                            title: "Send message",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                xmlns: "http://www.w3.org/2000/svg",
                                                className: "h-5 w-5 text-white",
                                                viewBox: "0 0 20 20",
                                                fill: "currentColor",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    d: "M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/components/AIAvatar.tsx",
                                                    lineNumber: 47,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/AIAvatar.tsx",
                                                lineNumber: 46,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/AIAvatar.tsx",
                                            lineNumber: 41,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/AIAvatar.tsx",
                                    lineNumber: 35,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/AIAvatar.tsx",
                            lineNumber: 33,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/app/components/AIAvatar.tsx",
                        lineNumber: 32,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/AIAvatar.tsx",
                lineNumber: 10,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>setIsOpen(!isOpen),
                className: "w-16 h-16 bg-gradient-to-br from-[#0030ff] to-[#ffe600] rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform duration-300 overflow-hidden",
                "aria-label": "Toggle AI Assistant",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    src: "/assets/avatar-headshot.png",
                    alt: "AI Avatar",
                    width: 64,
                    height: 64,
                    className: "w-full h-full object-cover"
                }, void 0, false, {
                    fileName: "[project]/app/components/AIAvatar.tsx",
                    lineNumber: 60,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/components/AIAvatar.tsx",
                lineNumber: 55,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/AIAvatar.tsx",
        lineNumber: 8,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = AIAvatar;
}),
"[project]/app/ClientLayout.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ClientLayout",
    ()=>ClientLayout
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$AIAvatar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/AIAvatar.tsx [app-ssr] (ecmascript)");
"use client";
;
;
function ClientLayout() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$AIAvatar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
        fileName: "[project]/app/ClientLayout.tsx",
        lineNumber: 6,
        columnNumber: 10
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__c2bbc14d._.js.map