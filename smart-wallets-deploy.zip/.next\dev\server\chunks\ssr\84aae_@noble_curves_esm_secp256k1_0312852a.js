module.exports = [
"[project]/node_modules/wagmi/node_modules/@noble/curves/esm/secp256k1.js [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_da0b0399._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/wagmi/node_modules/@noble/curves/esm/secp256k1.js [app-ssr] (ecmascript)");
    });
});
}),
];